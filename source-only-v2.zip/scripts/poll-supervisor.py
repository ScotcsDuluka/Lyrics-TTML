#!/usr/bin/env python3
"""
Supervisor — keeps poll-realtime.py alive forever.
Detaches from controlling terminal and survives parent session death.
"""
import os
import sys
import time
import subprocess
import signal
from pathlib import Path

POLL_SCRIPT = "/home/z/my-project/scripts/poll-realtime.py"
LOG_FILE = "/home/z/my-project/commands.log"
OUTPUT_LOG = "/tmp/poll-output.log"
SUPERVISOR_LOG = "/tmp/poll-supervisor.log"
STOP_FILE = "/tmp/.stop-poll"


def log(msg):
    with open(SUPERVISOR_LOG, "a") as f:
        f.write(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] {msg}\n")
        f.flush()


def get_log_line_count():
    try:
        with open(LOG_FILE, "r", encoding="utf-8", errors="replace") as f:
            return sum(1 for _ in f)
    except FileNotFoundError:
        return 0


def reset_marker():
    """Reset marker file to current log size so old messages are skipped."""
    count = get_log_line_count()
    try:
        with open("/tmp/.web-poll-line", "w") as f:
            f.write(str(count))
    except Exception as e:
        log(f"Failed to reset marker: {e}")


def should_stop():
    if Path(STOP_FILE).exists():
        try:
            Path(STOP_FILE).unlink()
        except:
            pass
        return True
    return False


def main():
    log("Supervisor starting")
    reset_marker()

    while True:
        if should_stop():
            log("Stop signal received")
            # Kill any running poll
            try:
                subprocess.run(["pkill", "-f", "poll-realtime.py"], capture_output=True)
            except:
                pass
            return 0

        # Check if poll is running
        try:
            result = subprocess.run(
                ["pgrep", "-f", "poll-realtime.py"],
                capture_output=True, text=True
            )
            poll_running = result.returncode == 0
        except Exception:
            poll_running = False

        if not poll_running:
            log("Poll not running, starting...")
            reset_marker()
            # Start poll detached — redirect all stdio
            with open(OUTPUT_LOG, "a") as out:
                proc = subprocess.Popen(
                    ["python3", POLL_SCRIPT],
                    stdin=subprocess.DEVNULL,
                    stdout=out,
                    stderr=subprocess.STDOUT,
                    start_new_session=True,  # equivalent to setsid
                )
            log(f"Started poll PID: {proc.pid}")

        time.sleep(30)


if __name__ == "__main__":
    # Detach ourselves too — double fork
    if os.fork() != 0:
        # Parent exits immediately
        sys.exit(0)

    # Child becomes session leader
    os.setsid()

    if os.fork() != 0:
        # First child exits
        sys.exit(0)

    # Second child is the daemon
    os.chdir("/")
    os.umask(0)

    # Close stdio, redirect to log
    sys.stdout.flush()
    sys.stderr.flush()
    with open("/dev/null", "r") as devnull:
        os.dup2(devnull.fileno(), sys.stdin.fileno())
    with open(SUPERVISOR_LOG, "a") as logf:
        os.dup2(logf.fileno(), sys.stdout.fileno())
        os.dup2(logf.fileno(), sys.stderr.fileno())

    # Ignore signals that would kill us
    signal.signal(signal.SIGHUP, signal.SIG_IGN)
    signal.signal(signal.SIGTERM, signal.SIG_IGN)

    main()
