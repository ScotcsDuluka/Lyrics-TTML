#!/bin/bash
# Keep poll-realtime.py alive — restart if dies
# Stops only if /tmp/.stop-poll marker exists
# Use setsid + nohup + stdio redirect to survive parent session death
while true; do
  if [ -f /tmp/.stop-poll ]; then
    rm -f /tmp/.stop-poll
    echo "[keep-alive] Stop signal received, exiting at $(date)"
    pkill -f "poll-realtime.py" 2>/dev/null
    break
  fi
  if ! pgrep -f "poll-realtime.py" > /dev/null; then
    echo "[keep-alive] Poll died, restarting at $(date)"
    cd /home/z/my-project
    LINES=$(wc -l < commands.log 2>/dev/null || echo "0")
    echo "$LINES" > /tmp/.web-poll-line
    setsid nohup python3 /home/z/my-project/scripts/poll-realtime.py </dev/null >>/tmp/poll-output.log 2>&1 &
    disown
  fi
  sleep 30
done
