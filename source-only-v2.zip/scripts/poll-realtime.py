#!/usr/bin/env python3
"""
UPGRADED poll script — handles messages even when GLM session is dead.

Flow:
  1. User sends message → poll script reads it
  2. If slash command → dispatch bl:playback event (handled by web UI)
  3. If non-slash → auto-trigger /api/ai-reply (LLM responds)
  4. If code-change request → queue to /tmp/.glm-pending-tasks
  5. When GLM session starts → GLM checks pending tasks

Survives session death via double-fork daemon (supervisor).
"""
import subprocess, sys, os, time, re, json, urllib.request, threading
from pathlib import Path

LOG = Path("/home/z/my-project/commands.log")
MARKER = Path("/tmp/.web-poll-line")
MUTE_FILE = Path("/tmp/.web-poll-mute")
STATUS_FILE = Path("/tmp/.glm-status")
ACTIVITY_FILE = Path("/tmp/.glm-activity")
HB_FILE = Path("/tmp/.glm-heartbeat")
PENDING_TASKS = Path("/tmp/.glm-pending-tasks")
AI_REPLY_URL = "http://localhost:3000/api/ai-reply"
COMMIT_URL = "http://localhost:3000/api/command"

MUTE_PATTERNS = re.compile(r"/(lyricswidth|bg|lyricsscale|cover|offset|hue)\b")
COALESCE_SEC = 3.0

def set_status(s, activity=""):
    try:
        STATUS_FILE.write_text(s)
        HB_FILE.write_text(str(time.time()))
        if activity: ACTIVITY_FILE.write_text(activity)
    except: pass

def heartbeat_loop():
    def loop():
        while True:
            try: HB_FILE.write_text(str(time.time()))
            except: pass
            time.sleep(10)
    threading.Thread(target=loop, daemon=True).start()

def is_muted():
    if not MUTE_FILE.exists(): return False
    age = time.time() - MUTE_FILE.stat().st_mtime
    if age > 60:
        try: MUTE_FILE.unlink()
        except: pass
        return False
    return True

def parse_line(line):
    m = re.match(r"\[([^\]]+)\] \[(applied|note|ai|ai-chat)\] (.*)", line.strip())
    if m: return m.group(1), m.group(2), m.group(3)
    return None

def extract_cmd(text):
    if not text.startswith("/"): return None
    parts = text.split(None, 1)
    return parts[0] if parts else None

def is_code_request(text):
    """Detect if message is a code-change request (needs GLM, not LLM)."""
    keywords = [
        "แก้บัค", "แก้โค้ด", "เพิ่ม", "ลบ", "เปลี่ยน", "สร้าง", "port",
        "fix", "bug", "add", "remove", "change", "create", "implement",
        "อัพเกรด", "upgrade", "ทำใหม่", "remake", "commit", "git",
        "spicy", "lyrics", "CSS", "UI", "component", "API",
    ]
    lower = text.lower()
    return any(kw.lower() in lower for kw in keywords)

def queue_task(text):
    """Queue a code-change task for GLM to process when session starts."""
    try:
        tasks = []
        if PENDING_TASKS.exists():
            tasks = json.loads(PENDING_TASKS.read_text(encoding="utf-8"))
        tasks.append({"text": text, "ts": time.strftime("%H:%M:%S"), "done": False})
        PENDING_TASKS.write_text(json.dumps(tasks, ensure_ascii=False, indent=2), encoding="utf-8")
    except: pass

def trigger_llm_reply(text):
    """Auto-trigger LLM response via /api/ai-reply."""
    try:
        body = json.dumps({"message": text}).encode("utf-8")
        req = urllib.request.Request(AI_REPLY_URL, data=body,
            headers={"Content-Type": "application/json"}, method="POST")
        with urllib.request.urlopen(req, timeout=15) as resp:
            data = json.loads(resp.read())
            if data.get("ok"):
                print(f"[auto-llm] replied to: {text[:50]}", flush=True)
            return True
    except Exception as e:
        print(f"[auto-llm] failed: {e}", flush=True)
        return False

def main():
    heartbeat_loop()
    set_status("idle", "พร้อมรับคำสั่ง")

    # Wait for AI Chat to reply (8s) before sending to GLM
    WAIT_FOR_AI_CHAT = 8.0

    if MARKER.exists():
        try: last_line = int(MARKER.read_text().strip() or "0")
        except: last_line = 0
    else:
        if LOG.exists(): last_line = len(LOG.read_text(encoding="utf-8", errors="replace").splitlines())
        else: last_line = 0
        MARKER.write_text(str(last_line))

    # Process existing unprocessed messages
    if LOG.exists():
        lines = LOG.read_text(encoding="utf-8", errors="replace").splitlines()
        for i in range(last_line, len(lines)):
            line = lines[i].rstrip()
            if not line: continue
            parsed = parse_line(line)
            if not parsed: continue
            ts_str, marker, text = parsed
            if marker in ("ai", "ai-chat"): continue
            last_line = i + 1
            MARKER.write_text(str(last_line))
            # Auto-process: trigger LLM for non-slash messages
            if not text.startswith("/") and not is_muted():
                if is_code_request(text):
                    queue_task(text)
                    print(f"[queued] {text[:60]}", flush=True)
                else:
                    trigger_llm_reply(text)

    set_status("idle", "พร้อมรับคำสั่ง")

    # tail -f loop
    proc = subprocess.Popen(["tail", "-n", "0", "-f", str(LOG)],
        stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True)
    try:
        for line in proc.stdout:
            line = line.rstrip()
            if not line: continue
            parsed = parse_line(line)
            if not parsed: continue
            ts_str, marker, text = parsed
            # Skip AI messages
            if marker in ("ai", "ai-chat"): continue

            if text.startswith("/panic") or text.startswith("/stop"):
                MUTE_FILE.touch()
                set_status("muted", "ถูกปิดเสียง 60 วินาที")
                continue
            if is_muted():
                continue

            if not text.startswith("/"):
                # Auto-process: LLM handles it, or queue for GLM
                if is_code_request(text):
                    # Code request — queue + trigger LLM to acknowledge
                    queue_task(text)
                    set_status("processing", f"รอ GLM: \"{text[:50]}\"")
                    # LLM acknowledges
                    trigger_llm_reply(text)
                    print(f"[queued+llm] {text[:60]}", flush=True)
                else:
                    # General message — LLM handles
                    set_status("processing", f"LLM กำลังตอบ: \"{text[:50]}\"")
                    trigger_llm_reply(text)
                    print(f"[llm] {text[:60]}", flush=True)
                continue

            # Slash commands
            cmd_name = extract_cmd(text) or ""
            if MUTE_PATTERNS.search(cmd_name):
                set_status("polling", f"กำลังรอ slider นิ่ง: {cmd_name}")
            else:
                set_status("processing", f"กำลังประมวลผล: {text[:50]}")
                print(line, flush=True)
    except KeyboardInterrupt: pass
    finally:
        proc.terminate()
        proc.wait()
    return 0

if __name__ == "__main__":
    sys.exit(main())
