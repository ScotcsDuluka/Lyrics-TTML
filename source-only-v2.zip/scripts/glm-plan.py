#!/usr/bin/env python3
"""
GLM plan/thinking tracker — writes what GLM is about to do.
AI Chat reads this to answer 'GLM จะทำอะไร' questions.

Usage:
  python3 scripts/glm-plan.py "จะแก้บัค auto-scroll ใน CommandOverlay"
  python3 scripts/glm-plan.py clear  # clear plan when done
"""
import sys
from pathlib import Path
import time

PLAN_FILE = Path("/tmp/.glm-plan")
ACTIVITY_FILE = Path("/tmp/.glm-activity")
STATUS_FILE = Path("/tmp/.glm-status")
HB_FILE = Path("/tmp/.glm-heartbeat")

def main():
    if len(sys.argv) < 2:
        print("Usage: glm-plan.py <plan text | clear>", file=sys.stderr)
        sys.exit(1)

    arg = " ".join(sys.argv[1:])

    if arg.lower() == "clear":
        PLAN_FILE.unlink(missing_ok=True)
        ACTIVITY_FILE.write_text("พร้อมรับคำสั่ง", encoding="utf-8")
        STATUS_FILE.write_text("idle", encoding="utf-8")
        print("[plan] cleared", flush=True)
    else:
        # Write plan + timestamp
        plan_data = f"{arg}\n[written: {time.strftime('%H:%M:%S')}]"
        PLAN_FILE.write_text(plan_data, encoding="utf-8")
        # Also update activity to show the plan
        ACTIVITY_FILE.write_text(f"วางแผน: {arg}", encoding="utf-8")
        STATUS_FILE.write_text("processing", encoding="utf-8")
        HB_FILE.write_text(str(time.time()))
        print(f"[plan] {arg}", flush=True)

if __name__ == "__main__":
    main()
