#!/usr/bin/env python3
"""
AI reply helper — write [ai] message to commands.log via /api/command.
Used by the AI session to send replies that appear in the CommandOverlay.

Usage:
  python3 scripts/ai-reply.py "reply text here"
"""
import sys
import urllib.request
import json

def main():
    if len(sys.argv) < 2:
        print("Usage: ai-reply.py <message>", file=sys.stderr)
        sys.exit(1)
    text = " ".join(sys.argv[1:])
    body = json.dumps({"text": f"[ai] {text}"}).encode("utf-8")
    req = urllib.request.Request(
        "http://localhost:3000/api/command",
        data=body,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=5) as resp:
            print(f"[ai-reply] sent: {text[:80]}", flush=True)
        # Reset status to idle after replying
        try:
            from pathlib import Path
            Path("/tmp/.glm-status").write_text("idle", encoding="utf-8")
            Path("/tmp/.glm-activity").write_text("พร้อมรับคำสั่ง", encoding="utf-8")
        except: pass

        # Trigger auto-conversation: LLM responds to GLM's message
        try:
            converse_req = urllib.request.Request(
                "http://localhost:3000/api/auto-converse",
                data=json.dumps({"triggerText": text, "conversationCount": 0}).encode("utf-8"),
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            with urllib.request.urlopen(converse_req, timeout=10) as resp:
                data = json.loads(resp.read())
                if data.get("ok") and data.get("response"):
                    print(f"[auto-converse] LLM replied: {data['response'][:60]}", flush=True)
        except Exception as ce:
            print(f"[auto-converse] failed: {ce}", file=sys.stderr, flush=True)
    except Exception as e:
        print(f"[ai-reply] failed: {e}", file=sys.stderr, flush=True)
        sys.exit(1)

if __name__ == "__main__":
    main()
