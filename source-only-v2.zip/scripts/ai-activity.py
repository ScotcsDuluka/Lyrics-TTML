#!/usr/bin/env python3
"""
AI activity updater — writes current activity to /tmp/.glm-activity
so /api/glm-status returns real-time activity text.

Usage:
  python3 scripts/ai-activity.py "กำลังแก้บัค auto-scroll"
  python3 scripts/ai-activity.py idle  # reset to idle
"""
import sys
import os
from pathlib import Path
import time

ACTIVITY_FILE = Path("/tmp/.glm-activity")
STATUS_FILE = Path("/tmp/.glm-status")
HB_FILE = Path("/tmp/.glm-heartbeat")

def main():
    if len(sys.argv) < 2:
        print("Usage: ai-activity.py <activity text | idle>", file=sys.stderr)
        sys.exit(1)

    arg = " ".join(sys.argv[1:])

    if arg.lower() == "idle":
        ACTIVITY_FILE.write_text("พร้อมรับคำสั่ง", encoding="utf-8")
        STATUS_FILE.write_text("idle", encoding="utf-8")
    else:
        ACTIVITY_FILE.write_text(arg, encoding="utf-8")
        # Smart status: if activity contains "รอ" (waiting), treat as idle
        # Otherwise it's processing/working
        if "รอ" in arg or "idle" in arg.lower():
            STATUS_FILE.write_text("idle", encoding="utf-8")
        else:
            STATUS_FILE.write_text("processing", encoding="utf-8")

    # Update heartbeat
    HB_FILE.write_text(str(time.time()))

    print(f"[activity] {arg}", flush=True)

if __name__ == "__main__":
    main()
