#!/usr/bin/env node
/**
 * Seed script — reads /public/songs/manifest.json and imports tracks into Prisma DB.
 * Also creates default playlists based on the "playlist" field in manifest.
 * Idempotent: skips tracks that already exist (matched by audioUrl).
 */
const { PrismaClient } = require("@prisma/client");
const fs = require("fs");
const path = require("path");

const prisma = new PrismaClient();
const MANIFEST = "/home/z/my-project/public/songs/manifest.json";

async function main() {
  const raw = fs.readFileSync(MANIFEST, "utf8");
  const data = JSON.parse(raw);
  const tracks = data.tracks || [];
  console.log(`[seed] Found ${tracks.length} tracks in manifest`);

  // Group by playlist
  const byPlaylist = {};
  for (const t of tracks) {
    const p = t.playlist || "Unknown";
    if (!byPlaylist[p]) byPlaylist[p] = [];
    byPlaylist[p].push(t);
  }

  // Create playlists
  for (const [name, list] of Object.entries(byPlaylist)) {
    let playlist = await prisma.playlist.findFirst({ where: { name } });
    if (!playlist) {
      playlist = await prisma.playlist.create({
        data: {
          name,
          description: `Imported from manifest`,
          coverUrl: list.find(t => t.coverUrl)?.coverUrl || null,
        },
      });
      console.log(`[seed] Created playlist: ${name}`);
    }

    // Add tracks
    for (let i = 0; i < list.length; i++) {
      const t = list[i];
      let track = await prisma.track.findFirst({ where: { audioUrl: t.audioUrl } });
      if (!track) {
        track = await prisma.track.create({
          data: {
            title: t.title,
            artists: JSON.stringify(t.artists || []),
            album: t.album || "",
            audioUrl: t.audioUrl,
            lyricsUrl: t.lyricsUrl || null,
            coverUrl: t.coverUrl || null,
          },
        });
      }

      // Add to playlist if not already
      const existing = await prisma.playlistTrack.findUnique({
        where: { playlistId_trackId: { playlistId: playlist.id, trackId: track.id } },
      });
      if (!existing) {
        await prisma.playlistTrack.create({
          data: { playlistId: playlist.id, trackId: track.id, position: i },
        });
      }
    }
    console.log(`[seed] ✓ ${name}: ${list.length} tracks`);
  }

  // Create "Liked Songs" system playlist
  let liked = await prisma.playlist.findFirst({ where: { isSystem: true, name: "Liked Songs" } });
  if (!liked) {
    liked = await prisma.playlist.create({
      data: {
        name: "Liked Songs",
        description: "Your liked songs",
        isSystem: true,
        coverUrl: null,
      },
    });
    console.log(`[seed] Created system playlist: Liked Songs`);
  }

  const total = await prisma.track.count();
  const playlists = await prisma.playlist.count();
  console.log(`[seed] Done. ${total} tracks, ${playlists} playlists`);
}

main()
  .catch(e => { console.error(e); process.exit(1); })
  .finally(() => prisma.$disconnect());
