"use client";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useAudioPlayer } from "@/hooks/use-audio-player";
import { useAppStore } from "@/lib/store";
import { Sidebar } from "@/components/sidebar";
import { TopBar } from "@/components/top-bar";
import { HomeView } from "@/components/home-view";
import { PlaylistView } from "@/components/playlist-view";
import { TrackTable } from "@/components/track-table";
import { QueuePanel } from "@/components/queue-panel";
import { PlayerBar } from "@/components/player-bar";
import { CommandOverlay } from "@/components/command-overlay";
import { LyricsView } from "@/components/lyrics-view";
import { X } from "lucide-react";
import type { Track, Playlist } from "@/lib/types";

export default function Home() {
  // Store
  const view = useAppStore(s => s.view);
  const setView = useAppStore(s => s.setView);
  const searchQuery = useAppStore(s => s.searchQuery);
  const setSearchQuery = useAppStore(s => s.setSearchQuery);
  const volume = useAppStore(s => s.volume);
  const muted = useAppStore(s => s.muted);
  const setVolume = useAppStore(s => s.setVolume);
  const setMuted = useAppStore(s => s.setMuted);
  const shuffle = useAppStore(s => s.shuffle);
  const setShuffle = useAppStore(s => s.setShuffle);
  const repeat = useAppStore(s => s.repeat);
  const setRepeat = useAppStore(s => s.setRepeat);
  const currentTrackId = useAppStore(s => s.currentTrackId);
  const isPlaying = useAppStore(s => s.isPlaying);
  const queue = useAppStore(s => s.queue);
  const queueIndex = useAppStore(s => s.queueIndex);
  const history = useAppStore(s => s.history);
  const showQueue = useAppStore(s => s.showQueue);
  const setShowQueue = useAppStore(s => s.setShowQueue);

  // Local state
  const [allTracks, setAllTracks] = useState<Track[]>([]);
  const [playlists, setPlaylists] = useState<Playlist[]>([]);
  const [currentPlaylist, setCurrentPlaylist] = useState<Playlist | null>(null);
  const [playlistTracks, setPlaylistTracks] = useState<Track[]>([]);
  const [searchResults, setSearchResults] = useState<{ tracks: Track[]; playlists: Playlist[] }>({ tracks: [], playlists: [] });
  const [showLyrics, setShowLyrics] = useState(true);

  // Current track resolution
  const currentTrack = useMemo(() => allTracks.find(t => t.id === currentTrackId) || null, [allTracks, currentTrackId]);
  const queueTracks = useMemo(() => queue.map(id => allTracks.find(t => t.id === id)).filter(Boolean) as Track[], [queue, allTracks]);

  // Audio
  const [audioState, audioControls, audioRef] = useAudioPlayer(currentTrack?.audioUrl ?? null, volume, muted);

  // Register audio with spicy-lyrics engine

  // Sync volume from store
  useEffect(() => {
    audioControls.setVolume(volume);
  }, [volume]);

  // Sync playing state to store
  useEffect(() => {
    useAppStore.getState().setCurrentTrack(currentTrackId);
    useAppStore.getState().setIsPlaying(audioState.isPlaying);
    useAppStore.getState().setCurrentTime(audioState.currentTime);
    useAppStore.getState().setDuration(audioState.duration);
  }, [currentTrackId, audioState.isPlaying, audioState.currentTime, audioState.duration]);

  // Load all tracks + playlists
  const loadAllTracks = useCallback(async () => {
    try {
      const res = await fetch("/api/tracks");
      const data = await res.json();
      setAllTracks(data.tracks || []);
    } catch (e) { console.error(e); }
  }, []);

  const loadPlaylists = useCallback(async () => {
    try {
      const res = await fetch("/api/playlists");
      const data = await res.json();
      setPlaylists(data.playlists || []);
    } catch (e) { console.error(e); }
  }, []);

  const loadPlaylistDetail = useCallback(async (id: string) => {
    try {
      const res = await fetch(`/api/playlists/${id}`);
      const data = await res.json();
      setCurrentPlaylist(data.playlist);
      setPlaylistTracks(data.playlist?.tracks || []);
    } catch (e) { console.error(e); }
  }, []);

  useEffect(() => {
    loadAllTracks();
    loadPlaylists();
  }, [loadAllTracks, loadPlaylists]);

  // When view changes
  useEffect(() => {
    if (view.type === "playlist") {
      loadPlaylistDetail(view.id);
    } else if (view.type === "liked") {
      // Load liked tracks via /api/likes
      (async () => {
        try {
          const res = await fetch("/api/likes");
          const data = await res.json();
          setCurrentPlaylist({
            id: "liked",
            name: "Liked Songs",
            description: "Your liked songs",
            coverUrl: null,
            isSystem: true,
            trackCount: data.tracks.length,
          });
          setPlaylistTracks(data.tracks);
        } catch (e) { console.error(e); }
      })();
    }
  }, [view, loadPlaylistDetail]);

  // Search
  useEffect(() => {
    if (view.type !== "search" || !searchQuery.trim()) {
      setSearchResults({ tracks: [], playlists: [] });
      return;
    }
    const id = setTimeout(async () => {
      try {
        const res = await fetch(`/api/search?q=${encodeURIComponent(searchQuery)}`);
        const data = await res.json();
        setSearchResults({ tracks: data.tracks || [], playlists: data.playlists || [] });
      } catch (e) { console.error(e); }
    }, 250);
    return () => clearTimeout(id);
  }, [view, searchQuery]);

  // Auto-advance on track end
  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;
    const onEnded = () => {
      // NOTE: History is recorded when track STARTS (in playTrackFromList),
      // not when it ends — prevents double-recording.

      if (repeat === "one") {
        audioControls.seek(0);
        setTimeout(() => audioControls.play(), 80);
        return;
      }

      const nextId = useAppStore.getState().nextInQueue();
      if (nextId) {
        useAppStore.getState().setCurrentTrack(nextId);
        // Wait for src to load before playing
        const waitAndPlay = () => {
          const a = audioRef.current;
          if (!a) return;
          if (a.readyState >= 2) {
            audioControls.play();
          } else {
            a.addEventListener("canplay", () => audioControls.play(), { once: true });
          }
        };
        setTimeout(waitAndPlay, 100);
      }
    };
    audio.addEventListener("ended", onEnded);
    return () => audio.removeEventListener("ended", onEnded);
  }, [audioRef, currentTrackId, repeat, audioControls]);

  // Keyboard
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement;
      if (t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA")) return;
      if (e.code === "Space") {
        e.preventDefault();
        audioControls.toggle();
      } else if (e.code === "ArrowRight" && !e.shiftKey) {
        e.preventDefault();
        audioControls.seek(audioState.currentTime + 5);
      } else if (e.code === "ArrowLeft" && !e.shiftKey) {
        e.preventDefault();
        audioControls.seek(audioState.currentTime - 5);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [audioControls, audioState.currentTime]);

  // Actions
  const playTrackFromList = useCallback((track: Track, index: number, list: Track[]) => {
    const trackIds = list.map(t => t.id);
    useAppStore.getState().setQueue(trackIds, index);
    useAppStore.getState().setCurrentTrack(track.id);
    useAppStore.getState().addToHistory(track.id);
    // Record history (only on start, not on end — prevents duplicate)
    fetch("/api/history", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ trackId: track.id }),
    }).catch(() => {});
    // Wait for audio src to be ready before playing (fixes slow-network bug)
    const waitAndPlay = () => {
      const a = audioRef.current;
      if (!a) return;
      if (a.readyState >= 2) {
        audioControls.play();
      } else {
        // Wait for canplay event (one-shot)
        const onCanPlay = () => {
          audioControls.play();
          a.removeEventListener("canplay", onCanPlay);
        };
        a.addEventListener("canplay", onCanPlay);
        // Safety timeout: try to play after 2s regardless
        setTimeout(() => {
          a.removeEventListener("canplay", onCanPlay);
          audioControls.play();
        }, 2000);
      }
    };
    setTimeout(waitAndPlay, 80);
  }, [audioControls, audioRef]);

  const handlePrev = useCallback(() => {
    const prevId = useAppStore.getState().prevInQueue();
    if (prevId) {
      useAppStore.getState().setCurrentTrack(prevId);
      setTimeout(() => audioControls.play(), 100);
    } else {
      audioControls.seek(0);
    }
  }, [audioControls]);

  const handleNext = useCallback(() => {
    const nextId = useAppStore.getState().nextInQueue();
    if (nextId) {
      useAppStore.getState().setCurrentTrack(nextId);
      setTimeout(() => audioControls.play(), 100);
    }
  }, [audioControls]);

  const toggleLike = useCallback(async (trackId: string) => {
    const track = allTracks.find(t => t.id === trackId);
    if (!track) return;
    if (track.liked) {
      await fetch(`/api/likes?trackId=${trackId}`, { method: "DELETE" });
    } else {
      await fetch("/api/likes", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ trackId }),
      });
    }
    // Update local state
    const wasLiked = allTracks.find(t => t.id === trackId)?.liked;
    setAllTracks(prev => prev.map(t => t.id === trackId ? { ...t, liked: !t.liked } : t));
    setPlaylistTracks(prev => {
      // If currently viewing Liked Songs and track was just unliked, remove it from list
      if (wasLiked && view.type === "liked") {
        return prev.filter(t => t.id !== trackId).map(t => t.id === trackId ? { ...t, liked: false } : t);
      }
      return prev.map(t => t.id === trackId ? { ...t, liked: !t.liked } : t);
    });
    // Also remove from search results if needed
    setSearchResults(prev => ({
      ...prev,
      tracks: prev.tracks.map(t => t.id === trackId ? { ...t, liked: !t.liked } : t),
    }));
    // Refresh playlists (Liked Songs count may have changed)
    loadPlaylists();
  }, [allTracks, view.type, loadPlaylists]);

  const handleCreatePlaylist = useCallback(async () => {
    const name = prompt("Playlist name:", `My Playlist #${playlists.length + 1}`);
    if (!name) return;
    try {
      const res = await fetch("/api/playlists", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name }),
      });
      if (res.ok) {
        const data = await res.json();
        await loadPlaylists();
        setView({ type: "playlist", id: data.playlist.id });
      }
    } catch (e) { console.error(e); }
  }, [playlists.length, loadPlaylists, setView]);

  const handleDeletePlaylist = useCallback(async (id: string) => {
    if (!confirm("Delete this playlist?")) return;
    try {
      await fetch(`/api/playlists/${id}`, { method: "DELETE" });
      await loadPlaylists();
      setView({ type: "home" });
    } catch (e) { console.error(e); }
  }, [loadPlaylists, setView]);

  // Note: Realtime Chat moved to /real-time-chat page (standalone)
  // Main page no longer polls or shows chat inline.

  const likedTrackCount = playlists.find(p => p.isSystem && p.name === "Liked Songs")?.trackCount || 0;
  const recentlyPlayed = history.map(id => allTracks.find(t => t.id === id)).filter(Boolean) as Track[];

  // Scroll main content to top when view changes
  const mainScrollRef = useRef<HTMLDivElement | null>(null);
  useEffect(() => {
    if (mainScrollRef.current) {
      mainScrollRef.current.scrollTop = 0;
    }
  }, [view]);

  return (
    <div className="bl-app">
      <audio ref={audioRef} preload="auto" />

      {/* Top: Sidebar + Main + optional Queue + Explorer (right) */}
      <div className="bl-app-top">
        <Sidebar
          playlists={playlists}
          likedTrackCount={likedTrackCount}
          onSelectPlaylist={(id) => setView({ type: "playlist", id })}
          onCreatePlaylist={handleCreatePlaylist}
          onGoHome={() => setView({ type: "home" })}
          onGoSearch={() => setView({ type: "search", query: "" })}
          onGoLiked={() => setView({ type: "liked" })}
        />

        <div className="grid min-h-0 overflow-hidden" style={{
          gridTemplateColumns: showQueue ? `1fr 280px${showLyrics ? " 400px" : ""}` : (showLyrics ? "1fr 400px" : "1fr"),
          gap: 8,
        }}>
          <main className="bl-main">
            <TopBar
              searchValue={searchQuery}
              onSearch={setSearchQuery}
              onBack={() => window.history.back()}
              onForward={() => window.history.forward()}
            />

            <div ref={mainScrollRef} className="bl-scroll flex-1">
              {view.type === "home" && (
                <HomeView
                  playlists={playlists}
                  recentlyPlayed={recentlyPlayed}
                  allTracks={allTracks}
                  likedTrackCount={likedTrackCount}
                  onSelectPlaylist={(id) => setView({ type: "playlist", id })}
                  onGoLiked={() => setView({ type: "liked" })}
                  onPlayTrack={(t) => playTrackFromList(t, 0, allTracks)}
                />
              )}

              {view.type === "playlist" && (
                <PlaylistView
                  playlist={currentPlaylist}
                  tracks={playlistTracks}
                  currentTrackId={currentTrackId}
                  isPlaying={isPlaying && playlistTracks.some(t => t.id === currentTrackId)}
                  isLikedPlaylist={false}
                  coverHue={currentPlaylist ? hashHue(currentPlaylist.id) : 280}
                  onPlay={() => {
                    if (playlistTracks.length === 0) return;
                    if (currentTrackId && playlistTracks.some(t => t.id === currentTrackId)) {
                      audioControls.toggle();
                    } else {
                      playTrackFromList(playlistTracks[0], 0, playlistTracks);
                    }
                  }}
                  onSelectTrack={(t, i) => playTrackFromList(t, i, playlistTracks)}
                  onToggleLike={toggleLike}
                  onDeletePlaylist={() => currentPlaylist && handleDeletePlaylist(currentPlaylist.id)}
                />
              )}

              {view.type === "liked" && (
                <PlaylistView
                  playlist={currentPlaylist}
                  tracks={playlistTracks}
                  currentTrackId={currentTrackId}
                  isPlaying={isPlaying && playlistTracks.some(t => t.id === currentTrackId)}
                  isLikedPlaylist
                  coverHue={280}
                  onPlay={() => {
                    if (playlistTracks.length === 0) return;
                    if (currentTrackId && playlistTracks.some(t => t.id === currentTrackId)) {
                      audioControls.toggle();
                    } else {
                      playTrackFromList(playlistTracks[0], 0, playlistTracks);
                    }
                  }}
                  onSelectTrack={(t, i) => playTrackFromList(t, i, playlistTracks)}
                  onToggleLike={toggleLike}
                />
              )}

              {view.type === "search" && (
                <div className="px-6 py-4">
                  <h2 className="mb-4 text-2xl font-bold text-white">
                    {searchQuery ? `Results for "${searchQuery}"` : "Search"}
                  </h2>
                  {searchResults.tracks.length > 0 && (
                    <TrackTable
                      tracks={searchResults.tracks}
                      currentTrackId={currentTrackId}
                      isPlaying={isPlaying}
                      onSelect={(t, i) => playTrackFromList(t, i, searchResults.tracks)}
                      onTogglePlay={audioControls.toggle}
                      onToggleLike={toggleLike}
                    />
                  )}
                  {searchQuery && searchResults.tracks.length === 0 && (
                    <div className="text-center text-[var(--sp-text-subdued)] py-12">
                      No results found
                    </div>
                  )}
                </div>
              )}
            </div>
          </main>

          {showQueue && (
            <QueuePanel
              queue={queueTracks}
              currentTrackId={currentTrackId}
              onClose={() => setShowQueue(false)}
              onSelect={(t) => {
                const idx = queue.findIndex(id => id === t.id);
                if (idx >= 0) {
                  useAppStore.getState().setQueue(queue, idx);
                  useAppStore.getState().setCurrentTrack(t.id);
                  setTimeout(() => audioControls.play(), 80);
                }
              }}
            />
          )}

          {/* Lyrics panel */}
          {showLyrics && currentTrack?.lyricsUrl && (
            <aside className="bl-panel bl-lyrics-viewport relative overflow-hidden" style={{ width: "400px" }}>
              <button onClick={() => setShowLyrics(false)} className="absolute right-2 top-2 z-10 flex h-7 w-7 items-center justify-center rounded-full bg-white/10 text-white/70 backdrop-blur-md hover:bg-white/20 hover:text-white">
                <X size={12} />
              </button>
              <LyricsView lyricsUrl={currentTrack.lyricsUrl} />
            </aside>
          )}
        </div>
      </div>

      {/* Bottom: Player bar */}
      <PlayerBar
        track={currentTrack}
        currentTime={audioState.currentTime}
        duration={audioState.duration}
        isPlaying={audioState.isPlaying}
        volume={volume}
        muted={muted}
        shuffle={shuffle}
        repeat={repeat}
        isLiked={currentTrack ? !!currentTrack.liked : false}
        showQueue={showQueue}
        onToggle={audioControls.toggle}
        onSeek={audioControls.seek}
        onPrev={handlePrev}
        onNext={handleNext}
        onVolume={setVolume}
        onToggleMute={() => setMuted(!muted)}
        onToggleShuffle={() => setShuffle(!shuffle)}
        onToggleRepeat={() => setRepeat(repeat === "off" ? "all" : repeat === "all" ? "one" : "off")}
        onToggleLike={() => currentTrack && toggleLike(currentTrack.id)}
        onToggleQueue={() => setShowQueue(!showQueue)}
        onSetEqBand={audioControls.setEqBand}
        onResetEq={audioControls.resetEq}
      />

      {/* AI Command Overlay */}
      <CommandOverlay />
    </div>
  );
}

function hashHue(s: string): number {
  if (!s) return 280;
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0;
  return h % 360;
}
