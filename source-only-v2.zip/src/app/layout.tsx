import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Spotify — Music for everyone",
  description: "Spotify clone — music streaming with playlists and library",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="th" className="dark">
      <head>
        <meta name="theme-color" content="#000000" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
        {/* Mi Sans font (CJK + Latin) from CDN */}
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Noto+Sans+Thai:wght@400;500;600;700&display=swap"
          rel="stylesheet"
        />
        <link
          rel="stylesheet"
          href="https://cdn.jsdelivr.net/npm/mi-sans@1.0.0/lib/Normal/MiSans-Regular.min.css"
        />
        <link
          rel="stylesheet"
          href="https://cdn.jsdelivr.net/npm/mi-sans@1.0.0/lib/Normal/MiSans-Medium.min.css"
        />
        <link
          rel="stylesheet"
          href="https://cdn.jsdelivr.net/npm/mi-sans@1.0.0/lib/Normal/MiSans-Semibold.min.css"
        />
        <link
          rel="stylesheet"
          href="https://cdn.jsdelivr.net/npm/mi-sans@1.0.0/lib/Normal/MiSans-Bold.min.css"
        />
      </head>
      <body>{children}</body>
    </html>
  );
}
