import { NextRequest, NextResponse } from "next/server";
import { promises as fs } from "fs";
const LOG_FILE = "/home/z/my-project/commands.log";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    if (!body?.text) return NextResponse.json({ error: "missing text" }, { status: 400 });
    const ts = new Date().toISOString();
    if (body.text.startsWith("[ai] ")) {
      const aiText = body.text.slice(5);
      // Escape newlines so multi-line AI messages stay on one log line
      const escapedText = aiText.replace(/\n/g, "\\n");
      const aiLine = `[${ts}] [ai] ${escapedText}`;
      try { await fs.appendFile(LOG_FILE, aiLine + "\n", "utf8"); } catch {}
      return NextResponse.json({ ok: true, aiResponse: aiText });
    }
    const status = body.applied ? "applied" : "note";
    const suffix = body.response ? ` → ${body.response}` : "";
    // Escape newlines in user text too
    const escapedText = body.text.replace(/\n/g, "\\n");
    const escapedResponse = body.response ? body.response.replace(/\n/g, "\\n") : "";
    const suffix2 = escapedResponse ? ` → ${escapedResponse}` : "";
    const userLine = `[${ts}] [${status}] ${escapedText}${suffix2}`;
    try { await fs.appendFile(LOG_FILE, userLine + "\n", "utf8"); } catch {}
    return NextResponse.json({ ok: true });
  } catch (e: any) { return NextResponse.json({ error: e.message }, { status: 500 }); }
}

export async function GET() {
  try {
    const data = await fs.readFile(LOG_FILE, "utf8");
    return NextResponse.json({ log: data.split("\n").slice(-200).join("\n") });
  } catch { return NextResponse.json({ log: "" }); }
}
