import { NextRequest, NextResponse } from "next/server";
import { promises as fs } from "fs";
import path from "path";

const PROJECT_ROOT = "/home/z/my-project";

/** GET /api/fs?path=xxx — list directory contents */
export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const relPath = searchParams.get("path") || "";
    const absPath = path.resolve(PROJECT_ROOT, relPath);

    // Security: ensure path is within project root
    if (!absPath.startsWith(PROJECT_ROOT)) {
      return NextResponse.json({ error: "access denied" }, { status: 403 });
    }

    const stat = await fs.stat(absPath);

    if (stat.isFile()) {
      // Return file content (text only, max 100KB)
      if (stat.size > 100 * 1024) {
        return NextResponse.json({ error: "file too large", size: stat.size }, { status: 413 });
      }
      const content = await fs.readFile(absPath, "utf8");
      return NextResponse.json({
        type: "file",
        path: relPath,
        size: stat.size,
        content,
      });
    }

    // Directory listing
    const entries = await fs.readdir(absPath, { withFileTypes: true });
    const items = await Promise.all(
      entries
        .filter(e => !e.name.startsWith(".") && e.name !== "node_modules" && e.name !== ".next" && e.name !== ".git")
        .map(async e => {
          const itemPath = path.join(relPath, e.name);
          const itemAbs = path.join(absPath, e.name);
          try {
            const s = await fs.stat(itemAbs);
            return {
              name: e.name,
              path: itemPath,
              type: e.isDirectory() ? "dir" : "file",
              size: s.size,
              modified: s.mtime.toISOString(),
            };
          } catch {
            return null;
          }
        })
    );

    const validItems = items.filter(Boolean) as Array<{
      name: string;
      path: string;
      type: "dir" | "file";
      size: number;
      modified: string;
    }>;

    // Sort: dirs first, then files (alphabetical)
    validItems.sort((a, b) => {
      if (a.type !== b.type) return a.type === "dir" ? -1 : 1;
      return a.name.localeCompare(b.name);
    });

    return NextResponse.json({
      type: "dir",
      path: relPath,
      items: validItems,
    });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
