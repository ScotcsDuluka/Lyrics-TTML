import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";

export async function GET() {
  try {
    const trackCount = await prisma.track.count();
    const playlistCount = await prisma.playlist.count();
    const likeCount = await prisma.like.count();
    return NextResponse.json({
      ok: true,
      db: true,
      trackCount,
      playlistCount,
      likeCount,
      timestamp: new Date().toISOString(),
    });
  } catch (e: any) {
    return NextResponse.json({
      ok: true,
      db: false,
      error: e.message,
      timestamp: new Date().toISOString(),
    }, { status: 500 });
  }
}
