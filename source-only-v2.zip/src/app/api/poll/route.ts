import { NextRequest, NextResponse } from "next/server";
import { promises as fs } from "fs";

const LOG_FILE = "/home/z/my-project/commands.log";

interface ChatEntry {
  id: string;
  ts: string;
  source: "user" | "ai" | "system";
  applied: boolean;
  text: string;
  response?: string;
}

const LINE_REGEX = /^\[([^\]]+)\] \[(applied|note|ai)\] (.*)$/;

function parseLine(line: string): ChatEntry | null {
  const m = line.trim().match(LINE_REGEX);
  if (!m) return null;
  const [, ts, status, rest] = m;
  const isAi = status === "ai";
  const isApplied = status === "applied";

  let text = rest;
  let response: string | undefined;

  // Split "text → response" if present
  const arrowIdx = rest.indexOf(" → ");
  if (arrowIdx >= 0) {
    text = rest.slice(0, arrowIdx);
    response = rest.slice(arrowIdx + 3); // " → " is 3 chars
  }

  return {
    id: `${ts}-${Math.random().toString(36).slice(2, 6)}`,
    ts,
    source: isAi ? "ai" : "user",
    applied: isApplied,
    text,
    response,
  };
}

/** GET /api/poll?since=ISO — return entries newer than `since` */
export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const since = searchParams.get("since");
    const sinceMs = since ? Date.parse(since) : 0;

    let data: string;
    try {
      data = await fs.readFile(LOG_FILE, "utf8");
    } catch {
      return NextResponse.json({ entries: [] });
    }

    const lines = data.split("\n").filter(Boolean);
    const entries: ChatEntry[] = [];
    for (const line of lines) {
      const e = parseLine(line);
      if (!e) continue;
      if (since && Date.parse(e.ts) <= sinceMs) continue;
      entries.push(e);
    }

    // If no `since`, return last 50
    const result = since ? entries : entries.slice(-50);
    return NextResponse.json({ entries: result });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}

/** POST /api/poll — append entry (legacy plain text format) */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    if (!body?.text) return NextResponse.json({ error: "missing text" }, { status: 400 });

    const ts = new Date().toISOString();
    let line: string;

    if (body.source === "ai" || body.text.startsWith("[ai] ")) {
      const aiText = body.text.startsWith("[ai] ") ? body.text.slice(5) : body.text;
      line = `[${ts}] [ai] ${aiText}`;
    } else {
      const status = body.applied ? "applied" : "note";
      const suffix = body.response ? ` → ${body.response}` : "";
      line = `[${ts}] [${status}] ${body.text}${suffix}`;
    }

    try {
      await fs.appendFile(LOG_FILE, line + "\n", "utf8");
    } catch {}

    return NextResponse.json({ ok: true });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}

/** DELETE /api/poll — clear log */
export async function DELETE() {
  try {
    await fs.writeFile(LOG_FILE, "", "utf8");
    return NextResponse.json({ ok: true });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
