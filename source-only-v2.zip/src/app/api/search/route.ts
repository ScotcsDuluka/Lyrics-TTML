import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";

/** GET /api/search?q=xxx — search tracks, playlists */
export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const q = (searchParams.get("q") || "").trim().toLowerCase();
    if (!q) return NextResponse.json({ tracks: [], playlists: [] });

    const tracks = await prisma.track.findMany({
      where: {
        OR: [
          { title: { contains: q } },
          { artists: { contains: q } },
          { album: { contains: q } },
        ],
      },
      take: 50,
      include: { likes: true },
    });

    const playlists = await prisma.playlist.findMany({
      where: {
        OR: [
          { name: { contains: q } },
          { description: { contains: q } },
        ],
      },
      take: 20,
      include: { tracks: { select: { trackId: true } } },
    });

    return NextResponse.json({
      tracks: tracks.map(t => ({
        id: t.id,
        title: t.title,
        artists: JSON.parse(t.artists),
        album: t.album,
        audioUrl: t.audioUrl,
        lyricsUrl: t.lyricsUrl,
        coverUrl: t.coverUrl,
        duration: t.duration,
        liked: t.likes.length > 0,
      })),
      playlists: playlists.map(p => ({
        id: p.id,
        name: p.name,
        description: p.description,
        coverUrl: p.coverUrl,
        isSystem: p.isSystem,
        trackCount: p.tracks.length,
      })),
    });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
