import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";

/** GET /api/tracks — list all tracks (with liked status) */
export async function GET() {
  try {
    const tracks = await prisma.track.findMany({
      orderBy: { title: "asc" },
      include: { likes: true },
    });
    return NextResponse.json({
      tracks: tracks.map(t => ({
        id: t.id,
        title: t.title,
        artists: JSON.parse(t.artists),
        album: t.album,
        audioUrl: t.audioUrl,
        lyricsUrl: t.lyricsUrl,
        coverUrl: t.coverUrl,
        duration: t.duration,
        liked: t.likes.length > 0,
      })),
    });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
