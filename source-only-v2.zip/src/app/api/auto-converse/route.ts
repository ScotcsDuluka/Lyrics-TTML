import { NextRequest, NextResponse } from "next/server";
import { promises as fs } from "fs";

const LOG_FILE = "/home/z/my-project/commands.log";

async function appendAiReply(text: string) {
  const ts = new Date().toISOString();
  const escaped = text.replace(/\n/g, "\\n");
  const line = `[${ts}] [ai-chat] ${escaped}`;
  try {
    await fs.appendFile(LOG_FILE, line + "\n", "utf8");
  } catch {}
}

/**
 * POST /api/auto-converse
 * Called when GLM ([ai]) sends a message — LLM auto-responds.
 * Limits: max 2 auto-replies per conversation to prevent infinite loop.
 */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const triggerText = body?.triggerText || "";
    const conversationCount = body?.conversationCount || 0;

    if (conversationCount >= 1) {
      return NextResponse.json({ ok: true, skipped: true, reason: "max conversation count" });
    }

    const SYSTEM_PROMPT = `คุณเป็น LLM ที่กำลังคุยกับ GLM (ผู้ช่วยอีกคน) ในแชทกลุ่ม
ตอบภาษาไทยสั้นๆ เหมือนเพื่อนคุย

GLM เพิ่งพูด: "${triggerText}"

ตอบ GLM กลับ 1 ประโยคสั้นๆ แบบเพื่อนคุย ไม่เกิน 1 บรรทัด
ห้าม: ขอโทษ, ขอบคุณ, สัญญา, พูดทางการ`;

    const ZAI = (await import("z-ai-web-dev-sdk")).default;
    const zai = await ZAI.create();
    const completion = await zai.chat.completions.create({
      messages: [
        { role: "assistant", content: SYSTEM_PROMPT },
        { role: "user", content: triggerText },
      ],
      thinking: { type: "disabled" },
      max_tokens: 100,
      temperature: 0.8,
    });

    const response = completion.choices[0]?.message?.content?.trim();
    if (!response) {
      return NextResponse.json({ ok: true, skipped: true, reason: "empty response" });
    }

    await appendAiReply(response);

    return NextResponse.json({
      ok: true,
      response,
      conversationCount: conversationCount + 1,
    });
  } catch (e: any) {
    console.error("[auto-converse] error:", e);
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
