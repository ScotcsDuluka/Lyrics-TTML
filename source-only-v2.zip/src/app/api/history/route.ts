import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";

/** GET /api/history — get recently played (latest 50) */
export async function GET() {
  try {
    const history = await prisma.playHistory.findMany({
      orderBy: { playedAt: "desc" },
      take: 50,
      include: { track: { include: { likes: true } } },
    });
    return NextResponse.json({
      history: history.map(h => ({
        id: h.id,
        playedAt: h.playedAt,
        track: {
          id: h.track.id,
          title: h.track.title,
          artists: JSON.parse(h.track.artists),
          album: h.track.album,
          audioUrl: h.track.audioUrl,
          lyricsUrl: h.track.lyricsUrl,
          coverUrl: h.track.coverUrl,
          duration: h.track.duration,
          liked: h.track.likes.length > 0,
        },
      })),
    });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}

/** POST /api/history — record a play */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const trackId = body.trackId;
    if (!trackId) return NextResponse.json({ error: "missing trackId" }, { status: 400 });

    const entry = await prisma.playHistory.create({
      data: { trackId },
    });
    return NextResponse.json({ ok: true, entry });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
