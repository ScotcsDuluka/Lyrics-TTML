import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";

interface Params { params: Promise<{ id: string }> }

/** GET /api/playlists/[id] — get playlist with full track list (ordered) */
export async function GET(req: NextRequest, { params }: Params) {
  try {
    const { id } = await params;
    const playlist = await prisma.playlist.findUnique({
      where: { id },
      include: {
        tracks: {
          orderBy: { position: "asc" },
          include: { track: { include: { likes: true } } },
        },
      },
    });
    if (!playlist) return NextResponse.json({ error: "not found" }, { status: 404 });

    return NextResponse.json({
      playlist: {
        id: playlist.id,
        name: playlist.name,
        description: playlist.description,
        coverUrl: playlist.coverUrl,
        isSystem: playlist.isSystem,
        trackCount: playlist.tracks.length,
        tracks: playlist.tracks.map(pt => ({
          id: pt.track.id,
          title: pt.track.title,
          artists: JSON.parse(pt.track.artists),
          album: pt.track.album,
          audioUrl: pt.track.audioUrl,
          lyricsUrl: pt.track.lyricsUrl,
          coverUrl: pt.track.coverUrl,
          duration: pt.track.duration,
          liked: pt.track.likes.length > 0,
          addedAt: pt.addedAt,
        })),
      },
    });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}

/** PUT /api/playlists/[id] — update playlist (name, description, cover) */
export async function PUT(req: NextRequest, { params }: Params) {
  try {
    const { id } = await params;
    const body = await req.json();
    const playlist = await prisma.playlist.update({
      where: { id },
      data: {
        ...(body.name !== undefined && { name: body.name }),
        ...(body.description !== undefined && { description: body.description }),
        ...(body.coverUrl !== undefined && { coverUrl: body.coverUrl }),
      },
    });
    return NextResponse.json({ playlist });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}

/** DELETE /api/playlists/[id] — delete playlist (only non-system) */
export async function DELETE(req: NextRequest, { params }: Params) {
  try {
    const { id } = await params;
    const playlist = await prisma.playlist.findUnique({ where: { id } });
    if (!playlist) return NextResponse.json({ error: "not found" }, { status: 404 });
    if (playlist.isSystem) return NextResponse.json({ error: "cannot delete system playlist" }, { status: 400 });
    await prisma.playlist.delete({ where: { id } });
    return NextResponse.json({ ok: true });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
