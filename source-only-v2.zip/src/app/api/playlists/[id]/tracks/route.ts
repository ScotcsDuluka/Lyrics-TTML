import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";

interface Params { params: Promise<{ id: string }> }

/** POST /api/playlists/[id]/tracks — add track to playlist */
export async function POST(req: NextRequest, { params }: Params) {
  try {
    const { id } = await params;
    const body = await req.json();
    const trackId = body.trackId;
    if (!trackId) return NextResponse.json({ error: "missing trackId" }, { status: 400 });

    // Get current max position
    const existing = await prisma.playlistTrack.findMany({
      where: { playlistId: id },
      orderBy: { position: "desc" },
      take: 1,
    });
    const nextPos = (existing[0]?.position ?? -1) + 1;

    // For Liked Songs (system playlist), also create a Like record
    const playlist = await prisma.playlist.findUnique({ where: { id } });
    if (playlist?.isSystem && playlist.name === "Liked Songs") {
      await prisma.like.upsert({
        where: { trackId },
        update: {},
        create: { trackId },
      });
    }

    const pt = await prisma.playlistTrack.upsert({
      where: { playlistId_trackId: { playlistId: id, trackId } },
      update: {},
      create: { playlistId: id, trackId, position: nextPos },
    });
    return NextResponse.json({ ok: true, playlistTrack: pt });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}

/** DELETE /api/playlists/[id]/tracks?trackId=xxx — remove track from playlist */
export async function DELETE(req: NextRequest, { params }: Params) {
  try {
    const { id } = await params;
    const { searchParams } = new URL(req.url);
    const trackId = searchParams.get("trackId");
    if (!trackId) return NextResponse.json({ error: "missing trackId" }, { status: 400 });

    const playlist = await prisma.playlist.findUnique({ where: { id } });
    if (playlist?.isSystem && playlist.name === "Liked Songs") {
      await prisma.like.deleteMany({ where: { trackId } });
    }

    await prisma.playlistTrack.deleteMany({
      where: { playlistId: id, trackId },
    });
    return NextResponse.json({ ok: true });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
