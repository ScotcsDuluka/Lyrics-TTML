import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";

/** GET /api/playlists — list all playlists (with track count) */
export async function GET() {
  try {
    const playlists = await prisma.playlist.findMany({
      orderBy: [{ isSystem: "desc" }, { createdAt: "asc" }],
      include: {
        tracks: { select: { trackId: true } },
      },
    });
    return NextResponse.json({
      playlists: playlists.map(p => ({
        id: p.id,
        name: p.name,
        description: p.description,
        coverUrl: p.coverUrl,
        isSystem: p.isSystem,
        trackCount: p.tracks.length,
      })),
    });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}

/** POST /api/playlists — create a new playlist */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const name = (body.name || "").trim();
    if (!name) return NextResponse.json({ error: "missing name" }, { status: 400 });

    const playlist = await prisma.playlist.create({
      data: {
        name,
        description: body.description || "",
        coverUrl: body.coverUrl || null,
      },
    });
    return NextResponse.json({ playlist });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
