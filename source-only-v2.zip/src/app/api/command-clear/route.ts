import { NextResponse } from "next/server";
import { promises as fs } from "fs";
const LOG_FILE = "/home/z/my-project/commands.log";
export async function POST() {
  try { await fs.writeFile(LOG_FILE, "", "utf8"); return NextResponse.json({ ok: true }); }
  catch (e: any) { return NextResponse.json({ error: e.message }, { status: 500 }); }
}
