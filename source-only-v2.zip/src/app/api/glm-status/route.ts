import { NextResponse } from "next/server";
import { promises as fs } from "fs";
import { existsSync } from "fs";

const STATUS_FILE = "/tmp/.glm-status";
const ACTIVITY_FILE = "/tmp/.glm-activity";
const HB_FILE = "/tmp/.glm-heartbeat";
const MUTE_FILE = "/tmp/.web-poll-mute";

async function readFileSafe(path: string): Promise<string> {
  try { return await fs.readFile(path, "utf8"); } catch { return ""; }
}

async function fileMtime(path: string): Promise<number> {
  try {
    const stat = await fs.stat(path);
    return stat.mtimeMs;
  } catch { return 0; }
}

export async function GET() {
  try {
    const status = (await readFileSafe(STATUS_FILE)).trim() || "idle";
    const activity = (await readFileSafe(ACTIVITY_FILE)).trim();
    const hbMs = await fileMtime(HB_FILE);
    const hbAgeSec = hbMs > 0 ? Math.floor((Date.now() - hbMs) / 1000) : -1;

    let mutedSecondsLeft = 0;
    if (existsSync(MUTE_FILE)) {
      const muteMs = await fileMtime(MUTE_FILE);
      const age = (Date.now() - muteMs) / 1000;
      if (age < 60) {
        mutedSecondsLeft = Math.ceil(60 - age);
      } else {
        // expired
        try { await fs.unlink(MUTE_FILE); } catch {}
      }
    }

    // Map status: "muted" overrides everything
    const finalStatus = mutedSecondsLeft > 0 ? "muted" : status;

    return NextResponse.json({
      status: finalStatus,
      activity,
      lastHeartbeatAgeSec: hbAgeSec,
      mutedSecondsLeft,
      online: hbAgeSec >= 0 && hbAgeSec < 60,
      timestamp: new Date().toISOString(),
    });
  } catch (e: any) {
    return NextResponse.json({
      status: "offline",
      activity: "",
      lastHeartbeatAgeSec: -1,
      mutedSecondsLeft: 0,
      online: false,
      error: e.message,
    });
  }
}
