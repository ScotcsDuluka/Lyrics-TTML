import { NextRequest, NextResponse } from "next/server";
import { exec } from "child_process";
import { promisify } from "util";

const execAsync = promisify(exec);

/** POST /api/commit — git add + commit with message */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const message = body?.message || `commit at ${new Date().toISOString()}`;

    // Check if there are changes first
    const { stdout: statusOut } = await execAsync(`cd /home/z/my-project && git status --short`);
    if (!statusOut.trim()) {
      return NextResponse.json({
        ok: true,
        nothingToCommit: true,
        message: "nothing to commit, working tree clean",
      });
    }

    // Git add + commit
    await execAsync(`cd /home/z/my-project && git add -A`);
    try {
      await execAsync(`cd /home/z/my-project && git commit -m "${message.replace(/"/g, '\\"')}"`);
    } catch (commitErr: any) {
      // If nothing to commit after add, return success
      if (commitErr.message?.includes("nothing to commit")) {
        return NextResponse.json({ ok: true, nothingToCommit: true });
      }
      throw commitErr;
    }

    // Get latest commit hash
    const { stdout: hashOut } = await execAsync(`cd /home/z/my-project && git rev-parse --short HEAD`);

    return NextResponse.json({
      ok: true,
      hash: hashOut.trim(),
      message,
    });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}

/** GET /api/commit — check git status */
export async function GET() {
  try {
    const { stdout: status } = await execAsync(`cd /home/z/my-project && git status --short`);
    const { stdout: log } = await execAsync(`cd /home/z/my-project && git log --oneline -5`);
    const hasChanges = status.trim().length > 0;
    return NextResponse.json({
      hasChanges,
      status: status.trim(),
      recentCommits: log.trim(),
    });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
