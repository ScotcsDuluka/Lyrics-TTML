import { NextRequest, NextResponse } from "next/server";
import { promises as fs } from "fs";
import { PathLike } from "fs";

const LOG_FILE = "/home/z/my-project/commands.log";

const SYSTEM_PROMPT = `คุณเป็น LLM ในเว็บเพลง ตอบภาษาไทยสั้นๆ 1-2 คำตอบ

ถ้าถามว่า GLM ทำอะไร → ตอบสั้นๆ จาก activity (แปลเป็นภาษาง่ายๆ ไม่ก๊อปปี้ raw text)
ถ้าถามเรื่องเพลง/เว็บ → ตอบสั้นๆ
ถ้าเกี่ยวกับโค้ด/บัค → "GLM ตอบได้ดีกว่า"
ถ้าไม่เข้าใจ → "ไม่เข้าใจ"
ถ้าพิมพ์สุ่ม → "?"

ห้าม: ขอโทษ, ขอบคุณ, สัญญา, พูดทางการ, ตอบยาว, แต่งเรื่อง, ก๊อปปี้ raw text
ห้าม: แสดง timestamp, แสดง [written: ...], แสดง format ดิบๆ

รู้: 61 เพลง, 4 playlists`;

interface LogEntry {
  ts: string;
  source: "user" | "ai" | "system";
  text: string;
}

function parseLine(line: string): LogEntry | null {
  const m = line.match(/^\[([^\]]+)\] \[(applied|note|ai)\] (.*)$/);
  if (!m) return null;
  const [, ts, status, rest] = m;
  let text = rest;
  const arrowIdx = rest.indexOf(" → ");
  if (arrowIdx >= 0) text = rest.slice(0, arrowIdx);
  // Unescape \\n
  text = text.replace(/\\n/g, "\n");
  return {
    ts,
    source: status === "ai" ? "ai" : "user",
    text,
  };
}

async function readRecentHistory(count: number = 20): Promise<LogEntry[]> {
  try {
    const data = await fs.readFile(LOG_FILE, "utf8");
    const lines = data.split("\n").filter(Boolean);
    return lines.slice(-count).map(parseLine).filter(Boolean) as LogEntry[];
  } catch {
    return [];
  }
}

async function appendAiReply(text: string) {
  const ts = new Date().toISOString();
  const escaped = text.replace(/\n/g, "\\n");
  // Use [ai-chat] to distinguish from [ai] (which is the real GLM/dev)
  const line = `[${ts}] [ai-chat] ${escaped}`;
  try {
    await fs.appendFile(LOG_FILE, line + "\n", "utf8");
  } catch {}
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const userMessage = body?.message;
    if (!userMessage) {
      return NextResponse.json({ error: "missing message" }, { status: 400 });
    }

    // Skip slash commands
    if (userMessage.trim().startsWith("/")) {
      return NextResponse.json({ ok: true, skipped: true, reason: "slash command" });
    }

    // Read GLM's current activity + plan + recent history
    const history = await readRecentHistory(20);

    // Read GLM activity + plan from /tmp files
    let glmActivity = "";
    let glmPlan = "";
    try {
      const { readFile } = await import("fs/promises");
      glmActivity = await readFile("/tmp/.glm-activity", "utf8").catch(() => "");
      glmPlan = await readFile("/tmp/.glm-plan", "utf8").catch(() => "");
    } catch {}

    // Build context-aware prompt with plan
    const contextPrompt = `${SYSTEM_PROMPT}

---
GLM กำลังทำ: ${glmActivity || "พร้อมรับคำสั่ง"}
GLM วางแผนจะทำ: ${glmPlan || "—"}
---

สำคัญ: อ่านบริบทแชทข้างล่างก่อนตอบ
ถ้า user พูดต่อจากข้อความก่อนหน้า → ตอบตามบริบท
ถ้า user ถามว่า GLM กำลังทำอะไร → ตอบจาก activity + plan
ถ้า user ถามเรื่องแก้โค้ด/บัค → "GLM ตอบได้ดีกว่า"`;

    const messages: Array<{ role: "assistant" | "user"; content: string }> = [
      { role: "assistant", content: contextPrompt },
    ];

    // Add recent history (last 10 entries for context — important!)
    for (const entry of history.slice(-10)) {
      if (entry.source === "user") {
        messages.push({ role: "user", content: entry.text });
      } else if (entry.source === "ai") {
        messages.push({ role: "assistant", content: entry.text });
      }
    }

    messages.push({ role: "user", content: userMessage });

    // Call LLM
    const ZAI = (await import("z-ai-web-dev-sdk")).default;
    const zai = await ZAI.create();
    const completion = await zai.chat.completions.create({
      messages,
      thinking: { type: "disabled" },
      max_tokens: 200,
      temperature: 0.6,
    });

    const aiResponse = completion.choices[0]?.message?.content;
    if (!aiResponse) {
      return NextResponse.json({ error: "empty response" }, { status: 500 });
    }

    const cleaned = aiResponse.trim();
    await appendAiReply(cleaned);

    return NextResponse.json({ ok: true, response: cleaned });
  } catch (e: any) {
    console.error("[ai-reply] error:", e);
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
