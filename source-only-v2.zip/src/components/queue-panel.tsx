"use client";
import { Music2, X } from "lucide-react";
import type { Track } from "@/lib/types";

interface Props {
  queue: Track[];
  currentTrackId: string | null;
  onClose: () => void;
  onSelect: (track: Track) => void;
}

export function QueuePanel({ queue, currentTrackId, onClose, onSelect }: Props) {
  const currentIndex = queue.findIndex(t => t.id === currentTrackId);
  const upcoming = currentIndex >= 0 ? queue.slice(currentIndex + 1) : queue;

  return (
    <div className="flex h-full flex-col bg-[var(--sp-highlight)] rounded-lg overflow-hidden">
      <div className="flex shrink-0 items-center justify-between px-4 py-3">
        <h2 className="text-sm font-bold text-white">Queue</h2>
        <button onClick={onClose} className="rounded-full p-1 text-[var(--sp-text-subdued)] hover:text-white">
          <X size={14} />
        </button>
      </div>

      <div className="bl-scroll flex-1 px-2 pb-2">
        {currentIndex >= 0 && queue[currentIndex] && (
          <div className="mb-4">
            <div className="px-2 py-1 text-xs font-bold uppercase tracking-wider text-[var(--sp-text-subdued)]">
              Now playing
            </div>
            <QueueItem track={queue[currentIndex]} active onClick={() => onSelect(queue[currentIndex])} />
          </div>
        )}

        <div>
          <div className="px-2 py-1 text-xs font-bold uppercase tracking-wider text-[var(--sp-text-subdued)]">
            Next up
          </div>
          {upcoming.length === 0 ? (
            <div className="px-2 py-4 text-sm text-[var(--sp-text-subdued)]">No upcoming tracks</div>
          ) : (
            upcoming.map(t => (
              <QueueItem key={t.id} track={t} onClick={() => onSelect(t)} />
            ))
          )}
        </div>
      </div>
    </div>
  );
}

function QueueItem({ track, active, onClick }: { track: Track; active?: boolean; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className={`flex w-full items-center gap-3 rounded-md p-2 text-left transition-colors ${
        active ? "bg-white/10" : "hover:bg-white/5"
      }`}
    >
      <div className="h-10 w-10 shrink-0 overflow-hidden rounded">
        {track.coverUrl ? (
          <img src={track.coverUrl} alt="" className="h-full w-full object-cover" />
        ) : (
          <div className="flex h-full w-full items-center justify-center bg-white/10">
            <Music2 size={14} className="text-white/40" />
          </div>
        )}
      </div>
      <div className="min-w-0 flex-1">
        <div className={`truncate text-sm font-medium ${active ? "text-emerald-400" : "text-white"}`}>
          {track.title}
        </div>
        <div className="truncate text-xs text-[var(--sp-text-subdued)]">
          {track.artists.join(", ")}
        </div>
      </div>
    </button>
  );
}
