"use client";
import { useEffect, useRef, useState, useCallback } from "react";
import { useCommandStore } from "@/lib/command-store";
import { MessageSquare, X, Send, Trash2, Bot, User, Clock, Zap, ChevronDown, ChevronUp, GitCommit } from "lucide-react";

interface AiMessage { id: string; ts: number; text: string; source: "ai" | "ai-chat"; }

export function CommandOverlay() {
  const [open, setOpen] = useState(false);
  const [input, setInput] = useState("");
  const [minimized, setMinimized] = useState(false);
  const entries = useCommandStore(s => s.entries);
  const push = useCommandStore(s => s.push);
  const scrollerRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<any>(null);
  const [aiMessages, setAiMessages] = useState<AiMessage[]>([]);
  const lastLogSeenRef = useRef("");
  const [aiTyping, setAiTyping] = useState(false);
  const typingStartRef = useRef(0);
  const [glmStatus, setGlmStatus] = useState<any>({ status: "offline", activity: "", lastHeartbeatAgeSec: -1, mutedSecondsLeft: 0 });
  const [unreadCount, setUnreadCount] = useState(0);
  const [lastSeenTs, setLastSeenTs] = useState(Date.now());

  // Persist chat messages to localStorage so they survive page refresh
  const STORAGE_KEY = "bl-chat-history-v1";
  const loadFromStorage = (): AiMessage[] => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return [];
      const data = JSON.parse(raw);
      return Array.isArray(data) ? data : [];
    } catch { return []; }
  };
  const saveToStorage = (msgs: AiMessage[]) => {
    try {
      // Keep only last 100 messages
      const toSave = msgs.slice(-100);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(toSave));
    } catch {}
  };

  // Load on mount
  useEffect(() => {
    const stored = loadFromStorage();
    if (stored.length > 0) {
      setAiMessages(stored);
      lastLogSeenRef.current = ""; // force re-read
    }
  }, []);

  // Hotkey: Escape to close
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setOpen(false);
        setMinimized(false);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  // Poll /api/command for AI messages + /api/glm-status for status
  useEffect(() => {
    let cancelled = false;
    const poll = async () => {
      try {
        const res = await fetch("/api/command");
        if (!res.ok) return;
        const data = await res.json();
        const log: string = data.log || "";
        if (log !== lastLogSeenRef.current) {
          lastLogSeenRef.current = log;
          const lines = log.split("\n").filter(Boolean);
          const aiLines: AiMessage[] = [];
          let aiCount = 0;
          for (const line of lines) {
            const m = line.match(/^\[([^\]]+)\] \[(ai|ai-chat|ai-glm)\] (.*)$/);
            if (m) {
              const ts = new Date(m[1]).getTime() || Date.now();
              aiCount++;
              // Unescape \\n back to newlines for multi-line display
              const text = m[3].replace(/\\n/g, "\n");
              const source = (m[2] === "ai-chat") ? "ai-chat" : "ai";
              aiLines.push({ id: `${ts}-${aiCount}`, ts, text, source });
            }
          }
          if (!cancelled) {
            // Check for new AI messages since last seen
            const newAiCount = aiLines.filter(m => m.ts > lastSeenTs).length;
            if (newAiCount > 0 && !open) {
              setUnreadCount(c => c + newAiCount);
            }
            setAiMessages(prev => {
              // Merge with existing to avoid duplicates
              const existingIds = new Set(prev.map(m => m.id));
              const newMsgs = aiLines.filter(m => !existingIds.has(m.id));
              const merged = [...prev, ...newMsgs].slice(-100);
              saveToStorage(merged);
              return merged;
            });
            if (aiLines.length > 0 && aiTyping && aiLines[aiLines.length-1].ts > typingStartRef.current) {
              setAiTyping(false);
            }
          }
        }
      } catch {}
      try {
        const r = await fetch("/api/glm-status");
        if (r.ok) {
          const s = await r.json();
          if (!cancelled) setGlmStatus(s);
        }
      } catch {}
    };
    poll();
    const interval = setInterval(poll, 300); // 300ms — fast polling
    return () => {
      cancelled = true;
      clearInterval(interval);
    };
  }, [aiTyping, open, lastSeenTs]);

  // Mark messages as read when overlay opens
  useEffect(() => {
    if (open) {
      setUnreadCount(0);
      setLastSeenTs(Date.now());
      setTimeout(() => inputRef.current?.focus(), 50);
    }
  }, [open]);

  // Set typing indicator when user sends non-slash message
  useEffect(() => {
    if (entries.length === 0) return;
    const last = entries[entries.length - 1];
    if (!last.text.startsWith("/")) {
      setAiTyping(true);
      typingStartRef.current = Date.now();
    }
  }, [entries]);

  // When GLM is processing (not aiTyping), also track start time for timer
  useEffect(() => {
    if (glmStatus.status === "processing" && !aiTyping && typingStartRef.current === 0) {
      typingStartRef.current = Date.now();
    }
    if (glmStatus.status !== "processing" && !aiTyping) {
      typingStartRef.current = 0;
    }
  }, [glmStatus.status, aiTyping]);

  // Stop typing when ANY new AI message arrives (regardless of timestamp)
  useEffect(() => {
    if (aiMessages.length > 0 && aiTyping) {
      setAiTyping(false);
    }
  }, [aiMessages, aiTyping]);

  // Auto-scroll to bottom on new messages
  useEffect(() => {
    if (scrollerRef.current && !minimized) {
      // Use requestAnimationFrame to ensure DOM has updated
      requestAnimationFrame(() => {
        if (scrollerRef.current) {
          scrollerRef.current.scrollTop = scrollerRef.current.scrollHeight;
        }
      });
    }
  }, [entries, aiMessages, aiTyping, minimized, open]);

  // Force re-render every second when typing (to update timer)
  const [, forceTick] = useState(0);
  useEffect(() => {
    if (!aiTyping) return;
    const id = setInterval(() => forceTick(t => t + 1), 1000);
    return () => clearInterval(id);
  }, [aiTyping]);

  const submit = useCallback(() => {
    if (!input.trim()) return;
    push(input);
    setInput("");
  }, [input, push]);

  const formatTime = (ts: number) => {
    const d = new Date(ts);
    return d.toLocaleTimeString("th-TH", { hour: "2-digit", minute: "2-digit" });
  };

  // Render merged timeline of user entries + AI messages
  const renderMessages = () => {
    type Item = { kind: "user"; ts: number; entry: any } | { kind: "ai"; ts: number; msg: AiMessage };
    const items: Item[] = [];
    for (const e of entries) items.push({ kind: "user", ts: e.ts, entry: e });
    for (const m of aiMessages) items.push({ kind: "ai", ts: m.ts, msg: m });
    items.sort((a, b) => a.ts - b.ts);
    return items.map(item => {
      if (item.kind === "user") {
        const e = item.entry;
        const hideResponse = e.response === "note logged for AI";
        return (
          <div key={`u-${e.id}-${item.ts}`} className="mb-3 bl-msg-in">
            <div className="flex justify-end">
              <div className="flex items-start gap-2 max-w-[80%]">
                <div className="rounded-2xl rounded-br-md bg-emerald-500 px-3 py-2 text-sm text-white shadow-sm">
                  {e.text}
                </div>
                <div className="flex flex-col items-center gap-0.5 shrink-0">
                  <div className="flex h-7 w-7 items-center justify-center rounded-full bg-emerald-500 shadow-md">
                    <User size={14} className="text-white" fill="currentColor" />
                  </div>
                  <span className="text-[8px] font-bold text-emerald-400">Users</span>
                </div>
              </div>
            </div>
            {e.response && !hideResponse && (
              <div className="mt-1 flex justify-end">
                <div className={`max-w-[80%] rounded-lg px-2 py-1 text-[10px] ${e.applied ? "text-emerald-400/70" : "text-amber-300/70"}`}>
                  {e.applied ? "✓ " : ""}{e.response}
                </div>
              </div>
            )}
          </div>
        );
      } else {
        const m = item.msg;
        const isAutoChat = m.source === "ai-chat";
        const label = isAutoChat ? "LLM" : "GLM";
        const avatarGradient = isAutoChat
          ? "from-blue-500 to-cyan-500"
          : "from-indigo-500 to-purple-600";
        const labelColor = isAutoChat ? "text-blue-400" : "text-purple-400";
        return (
          <div key={`a-${m.id}-${m.ts}`} className="mb-3 flex justify-start bl-msg-in">
            <div className="flex items-start gap-2 max-w-[85%]">
              <div className="flex flex-col items-center gap-0.5 shrink-0">
                <div className={`flex h-7 w-7 items-center justify-center rounded-full bg-gradient-to-br ${avatarGradient} shadow-md`}>
                  <Bot size={14} className="text-white" />
                </div>
                <span className={`text-[8px] font-bold ${labelColor}`}>{label}</span>
              </div>
              <div>
                <div className="rounded-2xl rounded-bl-md bg-white/10 px-3 py-2 text-sm text-white shadow-sm whitespace-pre-wrap break-words">
                  {m.text}
                </div>
                <div className="mt-0.5 ml-1 flex items-center gap-1 text-[9px] text-white/40">
                  <Clock size={9} />{formatTime(m.ts)}
                </div>
              </div>
            </div>
          </div>
        );
      }
    });
  };

  return (
    <>
      {/* Floating button */}
      <button
        onClick={() => { setOpen(v => !v); setMinimized(false); }}
        className="fixed bottom-24 right-4 z-[9998] flex h-12 w-12 items-center justify-center rounded-full bg-emerald-500 text-black shadow-lg transition-all hover:scale-105 hover:bg-emerald-400 active:scale-95"
        aria-label="Open command overlay"
        title="GLM 5.2 Chat"
      >
        {open && !minimized ? <X size={18} /> : <MessageSquare size={18} />}
        {unreadCount > 0 && !open && (
          <span className="absolute -top-1 -right-1 flex h-5 w-5 items-center justify-center rounded-full bg-red-500 text-[10px] font-bold text-white">
            {unreadCount > 9 ? "9+" : unreadCount}
          </span>
        )}
      </button>

      {/* Overlay panel */}
      {open && (
        <div
          className="fixed z-[9998] flex flex-col overflow-hidden rounded-xl border border-white/15 bg-black/95 backdrop-blur-xl shadow-2xl resize-y"
          style={{
            bottom: "6rem",
            right: "1rem",
            width: "min(480px, calc(100vw - 2rem))",
            height: minimized ? "auto" : "min(560px, calc(100vh - 12rem))",
            minHeight: minimized ? "auto" : "300px",
          }}
        >
          {/* Header */}
          <div className="flex items-center justify-between border-b border-white/10 bg-white/5 px-4 py-3 shrink-0">
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 text-[11px] font-bold text-white">
                <Bot size={16} />
              </div>
              <div>
                <div className="text-sm font-semibold text-white">GLM 5.2</div>
                <div className="flex items-center gap-1.5 text-[10px]">
                  {/* Status indicator */}
                  {glmStatus.status === "muted" ? (
                    <><span className="h-1.5 w-1.5 rounded-full bg-yellow-400 animate-pulse" /><span className="text-yellow-300">MUTED {glmStatus.mutedSecondsLeft}s</span></>
                  ) : glmStatus.status === "offline" ? (
                    <><span className="h-1.5 w-1.5 rounded-full bg-red-500" /><span className="text-red-300">OFFLINE</span></>
                  ) : glmStatus.status === "processing" ? (
                    <><span className="h-1.5 w-1.5 rounded-full bg-blue-400 animate-pulse" /><span className="text-blue-300">THINKING</span></>
                  ) : (
                    <><span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" /><span className="text-emerald-300">ACTIVE</span></>
                  )}
                  <span className="text-white/40">•</span>
                  <span className="text-white/60 truncate max-w-[180px]">{glmStatus.activity || "รอคำสั่ง..."}</span>
                </div>
              </div>
            </div>
            <div className="flex items-center gap-1">
              <button
                onClick={() => setMinimized(v => !v)}
                className="rounded p-1 text-white/60 hover:bg-white/10 hover:text-white"
                title={minimized ? "Expand" : "Minimize"}
              >
                {minimized ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
              </button>
              <button
                onClick={async () => {
                  try {
                    const res = await fetch("/api/commit", {
                      method: "POST",
                      headers: { "Content-Type": "application/json" },
                      body: JSON.stringify({ message: `commit by user at ${new Date().toLocaleString("th-TH")}` }),
                    });
                    const data = await res.json();
                    if (data.ok) {
                      if (data.nothingToCommit) {
                        push(`/commit ไม่มีอะไรจะ commit (working tree clean)`);
                      } else {
                        push(`/commit ✓ ${data.hash || "success"}`);
                      }
                    } else {
                      push(`/commit failed: ${data.error}`);
                    }
                  } catch (e: any) {
                    push(`/commit error: ${e.message}`);
                  }
                }}
                className="rounded p-1 text-white/60 hover:bg-emerald-500/20 hover:text-emerald-400"
                title="Commit changes (git add + commit)"
              >
                <GitCommit size={14} />
              </button>
              <button
                onClick={() => { useCommandStore.getState().clear(); setAiMessages([]); lastLogSeenRef.current = ""; try { localStorage.removeItem(STORAGE_KEY); } catch {} }}
                className="rounded p-1 text-white/60 hover:bg-white/10 hover:text-white"
                title="ล้างแชท"
              >
                <Trash2 size={14} />
              </button>
              <button
                onClick={() => setOpen(false)}
                className="rounded p-1 text-white/60 hover:bg-white/10 hover:text-white"
                title="ปิด"
              >
                <X size={16} />
              </button>
            </div>
          </div>

          {/* Messages — hidden when minimized */}
          {!minimized && (
            <>
              {/* Status banner — shows when THINKING or processing */}
              {(aiTyping || glmStatus.status === "processing") && (
                <div className="shrink-0 border-b border-blue-400/20 bg-blue-500/10 px-4 py-2.5 bl-msg-in">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="h-2 w-2 shrink-0 animate-pulse rounded-full bg-blue-400" />
                    <span className="text-xs font-bold text-blue-300">
                      {aiTyping ? "AI กำลังคิด..." : "GLM กำลังทำงาน..."}
                    </span>
                    {typingStartRef.current > 0 && (
                      <span className="ml-auto text-[10px] text-blue-300/60 tabular-nums">
                        {Math.floor((Date.now() - typingStartRef.current) / 1000)}s
                      </span>
                    )}
                  </div>
                  <div className="text-[10px] text-blue-300/70 leading-tight">
                    {aiTyping ? (
                      <div className="space-y-0.5">
                        <div>📝 กำลังอ่านข้อความของคุณ...</div>
                        <div>🧠 กำลังประมวลผลด้วย LLM...</div>
                        <div>✍️ กำลังเขียนคำตอบ...</div>
                      </div>
                    ) : (
                      <div className="space-y-0.5">
                        <div className="truncate font-medium text-blue-300">
                          ⚙️ {glmStatus.activity || "กำลังทำงาน..."}
                        </div>
                        <div className="text-blue-300/50">
                          💡 GLM กำลังอัปเดต activity ทุกครั้งที่ทำอะไรใหม่
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}
              <div ref={scrollerRef} className="bl-scroll flex-1 overflow-y-auto px-3 py-3" style={{ scrollbarWidth: "thin" }}>
                {entries.length === 0 && aiMessages.length === 0 ? (
                  <div className="flex h-full flex-col items-center justify-center text-center">
                    <Bot size={32} className="mb-3 opacity-30" />
                    <div className="text-sm text-white/40">พิมพ์อะไรก็ได้ — GLM กำลังเฝ้าดู 🤖</div>
                    <div className="mt-2 text-[10px] text-white/30">Esc ปิด</div>
                  </div>
                ) : (
                  renderMessages()
                )}
                {aiTyping && (
                  <div className="mb-3 flex justify-start bl-msg-in">
                    <div className="flex items-start gap-2 max-w-[85%]">
                      <div className="flex flex-col items-center gap-0.5 shrink-0">
                        <div className="flex h-7 w-7 items-center justify-center rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 shadow-md">
                          <Bot size={14} className="text-white" />
                        </div>
                        <span className="text-[8px] font-bold text-purple-400">GLM</span>
                      </div>
                      <div className="rounded-2xl rounded-bl-md bg-white/10 px-4 py-3 shadow-sm">
                        <div className="flex gap-1.5">
                          <span className="bl-typing-dot h-2 w-2 rounded-full bg-white/60" style={{ animationDelay: "0ms" }} />
                          <span className="bl-typing-dot h-2 w-2 rounded-full bg-white/60" style={{ animationDelay: "150ms" }} />
                          <span className="bl-typing-dot h-2 w-2 rounded-full bg-white/60" style={{ animationDelay: "300ms" }} />
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Input */}
              <div className="flex items-center gap-2 border-t border-white/10 bg-white/5 px-3 py-2 shrink-0">
                <textarea
                  ref={inputRef as any}
                  value={input}
                  onChange={e => setInput(e.target.value)}
                  onKeyDown={e => {
                    if (e.key === "Enter" && !e.shiftKey) {
                      e.preventDefault();
                      submit();
                    }
                  }}
                  placeholder="พิมพ์คำสั่ง หรือข้อความ..."
                  rows={1}
                  className="bl-chat-input flex-1 resize-none rounded-2xl bg-white/10 px-4 py-2 text-sm text-white placeholder:text-white/40 focus:bg-white/15 focus:outline-none"
                  style={{ minHeight: '38px', maxHeight: '120px' }}
                  onInput={(e) => {
                    const t = e.target as HTMLTextAreaElement;
                    t.style.height = 'auto';
                    t.style.height = Math.min(t.scrollHeight, 120) + 'px';
                  }}
                />
                <button
                  onClick={submit}
                  disabled={!input.trim()}
                  className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-emerald-500 text-white hover:bg-emerald-400 active:scale-95 disabled:opacity-30"
                >
                  <Send size={14} />
                </button>
              </div>


            </>
          )}
        </div>
      )}
    </>
  );
}
