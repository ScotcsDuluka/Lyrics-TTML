"use client";
import { memo, useEffect, useRef, useState } from "react";
import { parseSpicyTTML } from "@/lib/spicy-ttml";

interface Props { lyricsUrl: string | null; }

export const LyricsView = memo(function LyricsView({ lyricsUrl }: Props) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const scrollRef = useRef<HTMLDivElement | null>(null);
  const lineRefs = useRef<(HTMLDivElement | null)[]>([]);
  const [parsed, setParsed] = useState<Awaited<ReturnType<typeof parseSpicyTTML>> | null>(null);
  const [activeIdx, setActiveIdx] = useState(-1);
  const lastActiveRef = useRef(-1);
  const lastUserScrollRef = useRef(0);
  const rafRef = useRef<number | null>(null);

  useEffect(() => {
    if (!lyricsUrl) { setParsed(null); return; }
    let cancelled = false;
    (async () => {
      try {
        const res = await fetch(lyricsUrl);
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const text = await res.text();
        if (cancelled) return;
        const p = parseSpicyTTML(text);
        if (cancelled) return;
        setParsed(p);
        setActiveIdx(-1);
        lastActiveRef.current = -1;
        if (scrollRef.current) scrollRef.current.scrollTop = 0;
      } catch (e) { console.error("[LyricsView] failed:", e); setParsed(null); }
    })();
    return () => { cancelled = true; };
  }, [lyricsUrl]);

  // Get current audio time from global audio element
  const getTime = () => {
    const audio = document.querySelector("audio");
    return audio?.currentTime ?? 0;
  };

  useEffect(() => {
    if (!parsed || parsed.Content.length === 0) return;
    const tick = () => {
      const t = getTime();
      const lines = parsed.Content;
      let idx = -1;
      for (let i = 0; i < lines.length; i++) {
        if (lines[i].StartTime <= t && t < lines[i].EndTime) { idx = i; break; }
      }
      if (idx === -1) {
        for (let i = lines.length - 1; i >= 0; i--) {
          if (lines[i].StartTime <= t) { idx = i; break; }
        }
      }
      if (idx !== lastActiveRef.current) {
        lastActiveRef.current = idx;
        setActiveIdx(idx);
        const since = performance.now() - lastUserScrollRef.current;
        if (since > 750 && idx >= 0 && lineRefs.current[idx]) {
          lineRefs.current[idx]!.scrollIntoView({ behavior: "smooth", block: "center" });
        }
      }
      rafRef.current = requestAnimationFrame(tick);
    };
    rafRef.current = requestAnimationFrame(tick);
    return () => { if (rafRef.current) cancelAnimationFrame(rafRef.current); };
  }, [parsed]);

  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    const onScroll = () => { lastUserScrollRef.current = performance.now(); };
    el.addEventListener("wheel", onScroll, { passive: true });
    el.addEventListener("touchmove", onScroll, { passive: true });
    return () => { el.removeEventListener("wheel", onScroll); el.removeEventListener("touchmove", onScroll); };
  }, [parsed]);

  if (!parsed || parsed.Content.length === 0) {
    return (
      <div className="flex h-full items-center justify-center text-white/30">
        <div className="text-sm">No lyrics</div>
      </div>
    );
  }

  return (
    <div ref={containerRef} id="SpicyLyricsPage" className="SpicyRenderer h-full">
      <div className="ContentBox h-full">
        <div className="LyricsContainer h-full">
          <div ref={scrollRef} className="LyricsContent bl-scroll h-full" style={{ padding: "35vh 1.5rem" }}>
            <div className="VirtualLyricsContainer" style={{ containerType: "size" }}>
              {parsed.Content.map((line, i) => {
                const isActive = i === activeIdx;
                const isPast = i < activeIdx;
                if (line.IsInterlude || line.Content.length === 0) {
                  return <div key={i} ref={el => { lineRefs.current[i] = el; }} style={{ height: "2em" }} />;
                }
                const lead = line.Content[0]?.Lead;
                const syllables = lead?.Syllables ?? [];
                return (
                  <div
                    key={i}
                    ref={el => { lineRefs.current[i] = el; }}
                    className={`line ${isActive ? "Active" : isPast ? "Sung" : "NotSung"}`}
                    style={{ marginBottom: "0.5em", cursor: "pointer" }}
                    onClick={() => {
                      const audio = document.querySelector("audio");
                      if (audio) audio.currentTime = line.StartTime;
                    }}
                  >
                    {syllables.map((syl, j) => (
                      <span key={j} className={`word ${j === syllables.length - 1 ? "LastWordInLine" : ""} ${syl.IsPartOfWord ? "PartOfWord" : ""}`} style={{ display: "inline-block" }}>
                        {syl.Text}
                      </span>
                    ))}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
});
