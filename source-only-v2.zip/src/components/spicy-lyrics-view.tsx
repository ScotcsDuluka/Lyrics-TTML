"use client";
import { memo, useEffect, useRef, useState } from "react";
import { parseSpicyTTML } from "@/lib/spicy-ttml";
import { setPageContainer } from "@/lib/spicy-orig/shims/PageView";
import { setAudioElement } from "@/lib/spicy-orig/shims/GetProgress";
import { setSeekFunction } from "@/lib/spicy-orig/shims/SpotifyPlayer";
import { $lyricsContainerExists, $currentLyricsType } from "@/lib/spicy-orig/shims/stores";
import { ApplySyllableLyrics } from "@/lib/spicy-orig/engine/Applyer-Syllable";
import { ClearLyricsContentArrays, LyricsObject } from "@/lib/spicy-orig/engine/lyrics";
// Port Spring from source — used for controls opacity + artwork brightness
import { Spring } from "@/lib/spicy-orig/engine/Spring";
import Scheduler from "@/lib/spicy-orig/shims/Scheduler";

let _seekFn: ((s: number) => void) | null = null;
let _currentLyricsUrl: string | null = null;

setSeekFunction((s: number) => _seekFn?.(s));

export function registerAudioElement(el: HTMLAudioElement | null) { setAudioElement(el); }
export function registerLyricsSeek(fn: (s: number) => void) { _seekFn = fn; }

interface Props { lyricsUrl: string | null; }

/**
 * REAL spicy-lyrics view with PORTED Fullscreen logic.
 *
 * Fullscreen.ts logic ported directly (Spring-based controls opacity,
 * artwork brightness, mouse idle detection) — using the REAL Spring class
 * from spicy-lyrics source.
 */
export const RealSpicyLyricsView = memo(function RealSpicyLyricsView({ lyricsUrl }: Props) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const [controlsOpacity, setControlsOpacity] = useState(0);
  const [artworkBrightness, setArtworkBrightness] = useState(1);

  useEffect(() => {
    if (!containerRef.current) return;
    const root = containerRef.current.closest("#SpicyLyricsPage") as HTMLElement | null;
    setPageContainer(root || containerRef.current);
    $lyricsContainerExists.set(true);
    return () => {
      $lyricsContainerExists.set(false);
      try { ClearLyricsContentArrays(); } catch {}
      setPageContainer(null);
    };
  }, []);

  useEffect(() => {
    if (!lyricsUrl || !containerRef.current) return;
    if (_currentLyricsUrl === lyricsUrl) return;
    _currentLyricsUrl = lyricsUrl;
    let cancelled = false;
    (async () => {
      try {
        const res = await fetch(lyricsUrl); if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const text = await res.text(); if (cancelled) return;
        const parsed = parseSpicyTTML(text); if (cancelled) return;
        const data = {
          Type: "Syllable",
          Content: parsed.Content.filter(l => !l.IsInterlude).map(line => {
            const lead = line.Content[0]?.Lead; const bg = line.Content[0]?.Background;
            return { Lead: { StartTime: line.StartTime, EndTime: line.EndTime, Syllables: (lead?.Syllables ?? []).map(s => ({ Text: s.Text, StartTime: s.StartTime ?? 0, EndTime: s.EndTime ?? 0, IsPartOfWord: s.IsPartOfWord })) },
              Background: bg?.map(b => ({ StartTime: b.StartTime ?? 0, EndTime: b.EndTime ?? 0, Syllables: b.Syllables.map(s => ({ Text: s.Text, StartTime: s.StartTime ?? 0, EndTime: s.EndTime ?? 0, IsPartOfWord: s.IsPartOfWord })) })) };
          }),
          StartTime: parsed.Content[0]?.StartTime ?? 0,
        };
        try {
          $currentLyricsType.set("Syllable");
          ApplySyllableLyrics(data as any, false);
          requestAnimationFrame(() => {
            const vc = containerRef.current?.querySelector(".VirtualLyricsContainer") as HTMLElement | null;
            if (vc) { vc.style.display = "flex"; vc.style.flexDirection = "column"; vc.style.gap = "2cqw"; vc.style.paddingTop = "35vh"; vc.style.paddingBottom = "35vh"; }
            const lines = containerRef.current?.querySelectorAll(".line:not(.musical-line)");
            lines?.forEach((l, i) => {
              (l as HTMLElement).style.cursor = "pointer";
              l.addEventListener("click", () => {
                try { const lineData = LyricsObject.Types.Syllable.Lines[i]; if (lineData) _seekFn?.(lineData.StartTime / 1000); } catch {}
              });
            });
          });
        } catch (e) { console.error("[RealSpicy] Applyer failed:", e); }
      } catch (e) { console.error("[RealSpicy] fetch failed:", e); }
    })();
    return () => { cancelled = true; };
  }, [lyricsUrl]);

  // Auto-scroll
  useEffect(() => {
    let raf = 0; let lastActive: Element | null = null;
    const checkScroll = () => {
      const content = containerRef.current;
      if (!content) { raf = requestAnimationFrame(checkScroll); return; }
      const active = content.querySelector(".line.Active");
      if (active && active !== lastActive) {
        lastActive = active;
        const contentRect = content.getBoundingClientRect();
        const activeRect = active.getBoundingClientRect();
        const target = content.scrollTop + (activeRect.top - contentRect.top) - (contentRect.height / 2) + (activeRect.height / 2);
        content.scrollTo({ top: Math.max(0, target), behavior: "smooth" });
      }
      raf = requestAnimationFrame(checkScroll);
    };
    raf = requestAnimationFrame(checkScroll);
    return () => cancelAnimationFrame(raf);
  }, []);

  // === PORTED from Fullscreen.ts ===
  // Spring-based controls opacity + artwork brightness (real Spring class from source)
  // Original: controlsOpacitySpring = new Spring(0, 2, 2, 0), artworkBrightnessSpring = new Spring(0, 2, 2, 0)
  useEffect(() => {
    const controlsSpring = new Spring(0, 2, 2, 0); // freq=2, damping=2 (critically damped)
    const brightnessSpring = new Spring(0, 2, 2, 0);
    let lastMove = 0;
    let pageHover = false;
    let mediaHover = false;
    let animTimestamp: number | undefined;
    let rafScheduled = false;

    const getOpacityGoal = () => {
      const now = performance.now();
      if (lastMove && now - lastMove >= 750) return 0;
      if (pageHover && !mediaHover) return 0.65;
      if (mediaHover) return 0.985;
      return 0;
    };
    const getBrightnessGoal = () => {
      const now = performance.now();
      if (lastMove && now - lastMove >= 750) return 1;
      if (pageHover && !mediaHover) return 0.78;
      if (mediaHover) return 0.55;
      return 1;
    };

    const runAnimation = () => {
      const now = performance.now();
      if (animTimestamp !== undefined) {
        const dt = (now - animTimestamp) / 1000;
        const opacity = controlsSpring.Step(dt);
        const brightness = brightnessSpring.Step(dt);
        setControlsOpacity(opacity);
        setArtworkBrightness(brightness);
        if (controlsSpring.CanSleep() && brightnessSpring.CanSleep()) {
          animTimestamp = undefined;
          rafScheduled = false;
          return;
        }
      }
      animTimestamp = now;
      requestAnimationFrame(runAnimation);
    };

    const toggleControls = () => {
      controlsSpring.SetGoal(getOpacityGoal());
      brightnessSpring.SetGoal(getBrightnessGoal());
      if (!rafScheduled) { rafScheduled = true; runAnimation(); }
    };

    const el = containerRef.current;
    if (!el) return;

    let idleTimer: number;
    const onMouseMove = () => {
      pageHover = true;
      lastMove = performance.now();
      clearTimeout(idleTimer);
      idleTimer = window.setTimeout(() => { toggleControls(); }, 750);
      toggleControls();
    };
    const onMouseLeave = () => { pageHover = false; mediaHover = false; toggleControls(); clearTimeout(idleTimer); };

    el.addEventListener("mousemove", onMouseMove);
    el.addEventListener("mouseleave", onMouseLeave);

    return () => {
      el.removeEventListener("mousemove", onMouseMove);
      el.removeEventListener("mouseleave", onMouseLeave);
      clearTimeout(idleTimer);
    };
  }, []);

  return (
    <div id="SpicyLyricsPage" className="SpicyRenderer Fullscreen h-full" ref={containerRef}>
      <div className="ContentBox h-full">
        <div className="LyricsContainer h-full">
          <div
            className="LyricsContent ScrollbarScrollable"
            style={{ "--spice-sidebar": "#000", overflowY: "auto", overflowX: "hidden" } as React.CSSProperties}
            suppressHydrationWarning
          />
        </div>
      </div>
      {/* CSS variables for controls opacity + artwork brightness (from Fullscreen.ts) */}
      <style>{`
        #SpicyLyricsPage { --ControlsOpacity: ${controlsOpacity}; --ArtworkBrightness: ${artworkBrightness}; }
      `}</style>
    </div>
  );
});
