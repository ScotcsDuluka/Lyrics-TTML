"use client";
import { useState } from "react";
import {
  Pause, Play, SkipBack, SkipForward, Volume2, VolumeX,
  Repeat, Repeat1, Shuffle, ListMusic, Mic2, SlidersHorizontal,
  Heart, Maximize2, Minimize2, Monitor, X,
} from "lucide-react";
import type { Track } from "@/lib/types";
import type { RepeatMode } from "@/lib/types";

interface Props {
  track: Track | null;
  currentTime: number;
  duration: number;
  isPlaying: boolean;
  volume: number;
  muted: boolean;
  shuffle: boolean;
  repeat: RepeatMode;
  isLiked: boolean;
  showQueue: boolean;
  onToggle: () => void;
  onSeek: (s: number) => void;
  onPrev: () => void;
  onNext: () => void;
  onVolume: (v: number) => void;
  onToggleMute: () => void;
  onToggleShuffle: () => void;
  onToggleRepeat: () => void;
  onToggleLike: () => void;
  onToggleQueue: () => void;
  onSetEqBand?: (freq: number, gain: number) => void;
  onResetEq?: () => void;
}

function fmt(s: number): string {
  if (!isFinite(s) || s < 0) return "0:00";
  const t = Math.floor(s);
  return `${Math.floor(t/60)}:${(t%60).toString().padStart(2,"0")}`;
}

import { EQ_FREQS } from "@/hooks/use-audio-player";

export function PlayerBar(p: Props) {
  const [showEq, setShowEq] = useState(false);
  const [eqGains, setEqGains] = useState<Record<number, number>>({});
  const pct = p.duration > 0 ? (p.currentTime / p.duration) * 100 : 0;
  const noTrack = !p.track;

  return (
    <footer className="grid grid-cols-3 items-center gap-4 bg-[var(--player-bg)] px-4 py-3" style={{ height: "90px" }}>
      {/* LEFT — Now playing */}
      <div className="flex min-w-0 items-center gap-3">
        <div className="relative h-14 w-14 shrink-0 overflow-hidden rounded">
          {p.track?.coverUrl ? (
            <img src={p.track.coverUrl} alt="" className="h-full w-full object-cover" />
          ) : (
            <div className="h-full w-full bg-white/10" />
          )}
        </div>
        <div className="min-w-0">
          <div className={`truncate text-sm font-medium ${noTrack ? "text-[var(--sp-text-subdued)]" : "text-white"}`}>
            {p.track?.title || "Not playing"}
          </div>
          <div className="truncate text-xs text-[var(--sp-text-subdued)]">
            {p.track?.artists.join(", ") || ""}
          </div>
        </div>
        {!noTrack && (
          <button
            onClick={p.onToggleLike}
            className={`ml-2 shrink-0 rounded-full p-1 transition-colors ${
              p.isLiked ? "text-emerald-400" : "text-[var(--sp-text-subdued)] hover:text-white"
            }`}
          >
            <Heart size={16} fill={p.isLiked ? "currentColor" : "none"} />
          </button>
        )}
      </div>

      {/* CENTER — Controls + Seek */}
      <div className="flex flex-col items-center gap-2">
        <div className="flex items-center gap-4">
          <button
            onClick={p.onToggleShuffle}
            className={`relative transition-colors ${p.shuffle ? "text-emerald-400" : "text-[var(--sp-text-subdued)] hover:text-white"}`}
            title="Shuffle"
          >
            <Shuffle size={16} />
            {p.shuffle && (
              <span className="absolute -bottom-1.5 left-1/2 h-1 w-1 -translate-x-1/2 rounded-full bg-emerald-400" />
            )}
          </button>
          <button onClick={p.onPrev} disabled={noTrack} className="text-[var(--sp-text-subdued)] hover:text-white disabled:opacity-30">
            <SkipBack size={20} fill="currentColor" />
          </button>
          <button
            onClick={p.onToggle}
            disabled={noTrack}
            className="flex h-8 w-8 items-center justify-center rounded-full bg-white text-black transition-transform hover:scale-105 active:scale-95 disabled:opacity-30"
          >
            {p.isPlaying ? <Pause size={16} fill="currentColor" /> : <Play size={16} fill="currentColor" className="ml-0.5" />}
          </button>
          <button onClick={p.onNext} disabled={noTrack} className="text-[var(--sp-text-subdued)] hover:text-white disabled:opacity-30">
            <SkipForward size={20} fill="currentColor" />
          </button>
          <button
            onClick={p.onToggleRepeat}
            className={`relative transition-colors ${p.repeat !== "off" ? "text-emerald-400" : "text-[var(--sp-text-subdued)] hover:text-white"}`}
            title="Repeat"
          >
            {p.repeat === "one" ? <Repeat1 size={16} /> : <Repeat size={16} />}
            {p.repeat !== "off" && (
              <span className="absolute -bottom-1.5 left-1/2 h-1 w-1 -translate-x-1/2 rounded-full bg-emerald-400" />
            )}
          </button>
        </div>
        <div className="flex w-full max-w-[600px] items-center gap-2">
          <span className="w-10 shrink-0 text-right text-[10px] tabular-nums text-[var(--sp-text-subdued)]">
            {fmt(p.currentTime)}
          </span>
          <input
            type="range"
            min={0}
            max={p.duration > 0 ? p.duration : 1}
            step={0.05}
            value={p.currentTime}
            disabled={p.duration === 0}
            onChange={e => p.onSeek(parseFloat(e.target.value))}
            className={`bl-slider bl-seek flex-1 ${p.duration === 0 ? "opacity-50 cursor-not-allowed" : ""}`}
            style={{ "--progress": `${pct}%` } as React.CSSProperties}
            aria-label="Seek"
          />
          <span className="w-10 shrink-0 text-[10px] tabular-nums text-[var(--sp-text-subdued)]">
            {fmt(p.duration)}
          </span>
        </div>
      </div>

      {/* RIGHT — Volume + extras */}
      <div className="flex items-center justify-end gap-2">
        <button className="hidden rounded p-1.5 text-[var(--sp-text-subdued)] hover:text-white lg:block" title="Now playing view">
          <Mic2 size={16} />
        </button>
        <button
          onClick={p.onToggleQueue}
          className={`hidden rounded p-1.5 transition-colors lg:block ${p.showQueue ? "text-emerald-400" : "text-[var(--sp-text-subdued)] hover:text-white"}`}
          title="Queue"
        >
          <ListMusic size={16} />
        </button>
        <button className="hidden rounded p-1.5 text-[var(--sp-text-subdued)] hover:text-white lg:block" title="Connect to device">
          <Monitor size={16} />
        </button>
        <button onClick={p.onToggleMute} className="rounded p-1.5 text-[var(--sp-text-subdued)] hover:text-white">
          {p.muted || p.volume === 0 ? <VolumeX size={16} /> : <Volume2 size={16} />}
        </button>
        <input
          type="range"
          min={0}
          max={1}
          step={0.01}
          value={p.muted ? 0 : p.volume}
          onChange={e => p.onVolume(parseFloat(e.target.value))}
          className="bl-slider w-24"
          style={{ "--progress": `${(p.muted ? 0 : p.volume) * 100}%` } as React.CSSProperties}
          aria-label="Volume"
        />
        <button className="hidden rounded p-1.5 text-[var(--sp-text-subdued)] hover:text-white lg:block">
          <Maximize2 size={14} />
        </button>
      </div>
      {showEq && p.onSetEqBand && (
        <div className="absolute bottom-full right-4 mb-2 flex flex-col rounded-xl border border-white/15 bg-black/95 p-4 shadow-2xl backdrop-blur-xl bl-msg-in" style={{ width: "380px" }}>
          <div className="mb-3 flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-white/70">Equalizer</span>
            <div className="flex gap-2">
              <button onClick={() => { EQ_FREQS.forEach(f => { setEqGains(g => ({ ...g, [f]: 0 })); }); p.onResetEq?.(); }} className="rounded bg-white/10 px-2 py-0.5 text-[10px] text-white/70 hover:bg-white/20">Reset</button>
              <button onClick={() => setShowEq(false)} className="rounded p-0.5 text-white/40 hover:text-white"><X size={14} /></button>
            </div>
          </div>
          <div className="flex justify-between gap-1" style={{ height: "120px" }}>
            {EQ_FREQS.map(freq => (
              <div key={freq} className="flex flex-1 flex-col items-center gap-1">
                <span className="text-[9px] tabular-nums text-white/40">{eqGains[freq] ? (eqGains[freq] > 0 ? "+" : "") + eqGains[freq].toFixed(0) : "0"}</span>
                <input type="range" min={-12} max={12} step={1} value={eqGains[freq] ?? 0}
                  onChange={e => { const v = parseFloat(e.target.value); setEqGains(g => ({ ...g, [freq]: v })); p.onSetEqBand?.(freq, v); }}
                  className="bl-eq-slider" style={{ "--eq-val": `${((eqGains[freq] ?? 0) + 12) / 24 * 100}%` } as React.CSSProperties} />
                <span className="text-[9px] text-white/50">{freq >= 1000 ? `${freq/1000}k` : freq}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </footer>
  );
}
