"use client";
import { Play, Heart, Clock, Music2 } from "lucide-react";
import type { Playlist, Track } from "@/lib/types";

interface Props {
  playlists: Playlist[];
  recentlyPlayed: Track[];
  allTracks: Track[];
  likedTrackCount: number;
  onSelectPlaylist: (id: string) => void;
  onGoLiked: () => void;
  onPlayTrack: (track: Track) => void;
}

export function HomeView({ playlists, recentlyPlayed, allTracks, likedTrackCount, onSelectPlaylist, onGoLiked, onPlayTrack }: Props) {
  const quickLinks = [
    { id: "liked", label: "Liked Songs", count: likedTrackCount, cover: null, onClick: onGoLiked, gradient: "from-purple-500 to-pink-600", icon: <Heart size={20} fill="currentColor" className="text-white" /> },
  ];

  const greeting = () => {
    const h = new Date().getHours();
    if (h < 12) return "Good morning";
    if (h < 18) return "Good afternoon";
    return "Good evening";
  };

  return (
    <div className="bl-scroll flex-1 px-6 pb-6">
      {/* Greeting header (Spotify style) */}
      <div className="pt-8 pb-6">
        <h1 className="text-3xl font-extrabold tracking-tight text-white">
          {greeting()}
        </h1>
      </div>

      {/* Quick access grid */}
      <div className="grid grid-cols-1 gap-2 sm:grid-cols-2 lg:grid-cols-3">
        {quickLinks.map(q => (
          <button
            key={q.id}
            onClick={q.onClick}
            className="group flex items-center gap-4 overflow-hidden rounded bg-white/10 hover:bg-white/20 transition-colors"
          >
            <div className={`flex h-16 w-16 shrink-0 items-center justify-center bg-gradient-to-br ${q.gradient}`}>
              {q.icon}
            </div>
            <div className="min-w-0 flex-1 truncate text-left text-sm font-bold text-white">{q.label}</div>
            <div className="pr-4 opacity-0 transition-opacity group-hover:opacity-100">
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-emerald-500 text-black shadow-lg">
                <Play size={18} fill="currentColor" className="ml-0.5" />
              </div>
            </div>
          </button>
        ))}
      </div>

      {/* Recently played */}
      {recentlyPlayed.length > 0 && (
        <Section title="Recently played">
          <CardGrid>
            {recentlyPlayed.slice(0, 10).map(t => (
              <TrackCard key={t.id} track={t} onClick={() => onPlayTrack(t)} />
            ))}
          </CardGrid>
        </Section>
      )}

      {/* All tracks — always visible so user can start playing immediately */}
      {allTracks.length > 0 && (
        <Section title="All tracks">
          <CardGrid>
            {allTracks.slice(0, 15).map(t => (
              <TrackCard key={t.id} track={t} onClick={() => onPlayTrack(t)} />
            ))}
          </CardGrid>
        </Section>
      )}

      {/* Playlists */}
      {playlists.filter(p => !p.isSystem).length > 0 && (
        <Section title="Your playlists">
          <CardGrid>
            {playlists.filter(p => !p.isSystem).map(pl => (
              <PlaylistCard key={pl.id} playlist={pl} onClick={() => onSelectPlaylist(pl.id)} />
            ))}
          </CardGrid>
        </Section>
      )}
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="mt-8">
      <div className="mb-4 flex items-center justify-between">
        <h2 className="text-2xl font-bold text-white">{title}</h2>
        <button className="text-xs font-bold uppercase tracking-wider text-[var(--sp-text-subdued)] hover:text-white">
          Show all
        </button>
      </div>
      {children}
    </section>
  );
}

function CardGrid({ children }: { children: React.ReactNode }) {
  return (
    <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
      {children}
    </div>
  );
}

function TrackCard({ track, onClick }: { track: Track; onClick: () => void }) {
  return (
    <button onClick={onClick} className="bl-card group">
      <div className="relative">
        {track.coverUrl ? (
          <img src={track.coverUrl} alt="" className="bl-card-cover" />
        ) : (
          <div className="bl-card-cover flex items-center justify-center bg-white/10">
            <Music2 size={40} className="text-white/40" />
          </div>
        )}
        <div className="absolute bottom-2 right-2 h-10 w-10 translate-y-2 opacity-0 transition-all group-hover:translate-y-0 group-hover:opacity-100">
          <div className="flex h-full w-full items-center justify-center rounded-full bg-emerald-500 text-black shadow-lg">
            <Play size={18} fill="currentColor" className="ml-0.5" />
          </div>
        </div>
      </div>
      <div className="truncate text-sm font-bold text-white">{track.title}</div>
      <div className="mt-1 truncate text-xs text-[var(--sp-text-subdued)]">
        {track.artists.join(", ")}
      </div>
    </button>
  );
}

function PlaylistCard({ playlist, onClick }: { playlist: Playlist; onClick: () => void }) {
  return (
    <button onClick={onClick} className="bl-card group">
      <div className="relative">
        {playlist.coverUrl ? (
          <img src={playlist.coverUrl} alt="" className="bl-card-cover" />
        ) : (
          <div className="bl-card-cover flex items-center justify-center bg-gradient-to-br from-emerald-500/40 to-teal-700/40">
            <Music2 size={40} className="text-white/40" />
          </div>
        )}
        <div className="absolute bottom-2 right-2 h-10 w-10 translate-y-2 opacity-0 transition-all group-hover:translate-y-0 group-hover:opacity-100">
          <div className="flex h-full w-full items-center justify-center rounded-full bg-emerald-500 text-black shadow-lg">
            <Play size={18} fill="currentColor" className="ml-0.5" />
          </div>
        </div>
      </div>
      <div className="truncate text-sm font-bold text-white">{playlist.name}</div>
      <div className="mt-1 truncate text-xs text-[var(--sp-text-subdued)]">
        Playlist • {playlist.trackCount} songs
      </div>
    </button>
  );
}
