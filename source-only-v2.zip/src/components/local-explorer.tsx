"use client";
import { useEffect, useState, useCallback } from "react";
import { ChevronRight, ChevronDown, Folder, File, RefreshCw, Home } from "lucide-react";

interface FsItem {
  name: string;
  path: string;
  type: "dir" | "file";
  size: number;
  modified: string;
}

interface Props {
  onOpenFile?: (path: string, content: string) => void;
}

export function LocalExplorer({ onOpenFile }: Props) {
  const [currentPath, setCurrentPath] = useState("");
  const [items, setItems] = useState<FsItem[]>([]);
  const [expandedDirs, setExpandedDirs] = useState<Set<string>>(new Set([""]));
  const [dirCache, setDirCache] = useState<Record<string, FsItem[]>>({});
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [selectedFile, setSelectedFile] = useState<string | null>(null);

  const fetchDir = useCallback(async (dirPath: string) => {
    try {
      const res = await fetch(`/api/fs?path=${encodeURIComponent(dirPath)}`);
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || "fetch failed");
      }
      const data = await res.json();
      if (data.type !== "dir") throw new Error("not a directory");
      return data.items as FsItem[];
    } catch (e: any) {
      throw e;
    }
  }, []);

  const loadRoot = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const rootItems = await fetchDir("");
      setDirCache({ "": rootItems });
      setItems(rootItems);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }, [fetchDir]);

  useEffect(() => { loadRoot(); }, [loadRoot]);

  const toggleDir = useCallback(async (dirPath: string) => {
    setExpandedDirs(prev => {
      const next = new Set(prev);
      if (next.has(dirPath)) {
        next.delete(dirPath);
      } else {
        next.add(dirPath);
      }
      return next;
    });

    // Load if not cached
    if (!dirCache[dirPath]) {
      try {
        const subItems = await fetchDir(dirPath);
        setDirCache(prev => ({ ...prev, [dirPath]: subItems }));
      } catch (e: any) {
        setError(e.message);
      }
    }
  }, [dirCache, fetchDir]);

  const openFile = useCallback(async (filePath: string) => {
    setSelectedFile(filePath);
    try {
      const res = await fetch(`/api/fs?path=${encodeURIComponent(filePath)}`);
      if (!res.ok) return;
      const data = await res.json();
      if (data.type === "file" && onOpenFile) {
        onOpenFile(filePath, data.content);
      }
    } catch (e) {
      console.error(e);
    }
  }, [onOpenFile]);

  const renderItem = (item: FsItem, depth: number) => {
    const isExpanded = expandedDirs.has(item.path);
    const isSelected = selectedFile === item.path;

    return (
      <div key={item.path}>
        <button
          onClick={() => item.type === "dir" ? toggleDir(item.path) : openFile(item.path)}
          className={`flex w-full items-center gap-1 rounded px-1 py-0.5 text-left text-xs hover:bg-white/10 ${
            isSelected ? "bg-white/15 text-emerald-400" : "text-white/80"
          }`}
          style={{ paddingLeft: `${depth * 12 + 4}px` }}
        >
          {item.type === "dir" ? (
            <>
              {isExpanded ? <ChevronDown size={12} className="shrink-0 text-white/50" /> : <ChevronRight size={12} className="shrink-0 text-white/50" />}
              <Folder size={12} className="shrink-0 text-amber-400" />
            </>
          ) : (
            <>
              <span className="w-3 shrink-0" />
              <File size={12} className="shrink-0 text-blue-400" />
            </>
          )}
          <span className="truncate">{item.name}</span>
        </button>
        {item.type === "dir" && isExpanded && dirCache[item.path] && (
          <div>
            {dirCache[item.path].map(sub => renderItem(sub, depth + 1))}
          </div>
        )}
      </div>
    );
  };

  return (
    <aside className="bl-panel flex flex-col" style={{ width: "240px" }}>
      {/* Header */}
      <div className="flex shrink-0 items-center justify-between border-b border-white/10 px-3 py-2">
        <div className="flex items-center gap-1.5">
          <Home size={12} className="text-emerald-400" />
          <span className="text-xs font-bold text-white">Explorer</span>
        </div>
        <button
          onClick={() => {
            setDirCache({});
            setExpandedDirs(new Set([""]));
            loadRoot();
          }}
          className="rounded p-1 text-white/50 hover:bg-white/10 hover:text-white"
          title="Refresh"
        >
          <RefreshCw size={11} className={loading ? "animate-spin" : ""} />
        </button>
      </div>

      {/* Breadcrumb */}
      <div className="shrink-0 border-b border-white/10 px-2 py-1 text-[10px] text-white/40 truncate">
        /{currentPath || ""}
      </div>

      {/* File tree */}
      <div className="bl-scroll flex-1 overflow-y-auto py-1">
        {error ? (
          <div className="px-3 py-2 text-xs text-red-400">{error}</div>
        ) : items.length === 0 ? (
          <div className="px-3 py-2 text-xs text-white/40">{loading ? "Loading..." : "Empty"}</div>
        ) : (
          items.map(item => renderItem(item, 0))
        )}
      </div>

      {/* Footer */}
      <div className="shrink-0 border-t border-white/10 px-3 py-1 text-[9px] text-white/30">
        {items.length} items • click file to view
      </div>
    </aside>
  );
}
