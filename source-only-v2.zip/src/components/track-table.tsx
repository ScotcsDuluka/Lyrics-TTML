"use client";
import { Play, Pause, Heart, Clock } from "lucide-react";
import type { Track } from "@/lib/types";

interface Props {
  tracks: Track[];
  currentTrackId: string | null;
  isPlaying: boolean;
  onSelect: (track: Track, index: number) => void;
  onTogglePlay: () => void;
  onToggleLike: (trackId: string) => void;
}

function fmtDuration(s?: number | null): string {
  if (!s || !isFinite(s)) return "--:--";
  const t = Math.floor(s);
  const m = Math.floor(t / 60);
  const sec = t % 60;
  return `${m}:${sec.toString().padStart(2, "0")}`;
}

export function TrackTable({ tracks, currentTrackId, isPlaying, onSelect, onTogglePlay, onToggleLike }: Props) {
  if (tracks.length === 0) {
    return (
      <div className="px-6 py-12 text-center text-[var(--sp-text-subdued)]">
        <Clock size={48} className="mx-auto mb-4 opacity-30" />
        <div className="text-lg">No tracks here yet</div>
      </div>
    );
  }

  return (
    <div className="px-6 pb-6">
      {/* Header row */}
      <div className="grid grid-cols-[16px_4fr_3fr_minmax(80px,1fr)_minmax(60px,auto)] items-center gap-4 border-b border-white/10 px-4 py-2 text-xs uppercase tracking-wider text-[var(--sp-text-subdued)] sticky top-0 z-10 bg-black/40 backdrop-blur-sm">
        <div className="text-center">#</div>
        <div>Title</div>
        <div>Album</div>
        <div className="hidden md:block">Plays</div>
        <div className="text-right">
          <Clock size={14} className="ml-auto" />
        </div>
      </div>

      {/* Track rows */}
      <div>
        {tracks.map((t, i) => {
          const active = t.id === currentTrackId;
          return (
            <div
              key={t.id}
              onDoubleClick={() => onSelect(t, i)}
              className={`bl-track-row group grid grid-cols-[16px_4fr_3fr_minmax(80px,1fr)_minmax(60px,auto)] items-center gap-4 rounded-md px-4 py-2 ${
                active ? "active" : ""
              }`}
            >
              {/* Index / Play button */}
              <div className="text-center text-sm tabular-nums text-[var(--sp-text-subdued)]">
                {active && isPlaying ? (
                  <>
                    <span className="text-emerald-400 group-hover:hidden">
                      <span className="bl-eq-bar">
                        {[0,1,2,3].map(j => (
                          <span key={j} style={{
                            animationDelay: `${j*0.15}s`,
                            animationDuration: "0.8s",
                            height: `${[60,100,70,90][j]}%`,
                          }} />
                        ))}
                      </span>
                    </span>
                    <button
                      onClick={onTogglePlay}
                      className="hidden text-white group-hover:block"
                    >
                      <Pause size={14} fill="currentColor" />
                    </button>
                  </>
                ) : (
                  <>
                    <span className="group-hover:hidden">{i + 1}</span>
                    <button
                      onClick={() => onSelect(t, i)}
                      className="hidden text-white group-hover:block"
                    >
                      <Play size={14} fill="currentColor" />
                    </button>
                  </>
                )}
              </div>

              {/* Title + artist */}
              <div className="flex min-w-0 items-center gap-3">
                <div className="h-10 w-10 shrink-0 overflow-hidden rounded">
                  {t.coverUrl ? (
                    <img src={t.coverUrl} alt="" className="h-full w-full object-cover" />
                  ) : (
                    <div className="h-full w-full bg-white/10" />
                  )}
                </div>
                <div className="min-w-0">
                  <div className={`truncate text-sm font-medium ${active ? "text-emerald-400" : "text-white"}`}>
                    {t.title}
                  </div>
                  <div className="truncate text-xs text-[var(--sp-text-subdued)]">
                    {t.artists.join(", ")}
                  </div>
                </div>
              </div>

              {/* Album */}
              <div className="truncate text-sm text-[var(--sp-text-subdued)]">
                {t.album || "—"}
              </div>

              {/* Plays (fake) */}
              <div className="hidden text-sm text-[var(--sp-text-subdued)] md:block">
                {(parseInt(t.id.slice(-4), 36) % 999 + 1).toLocaleString()}
              </div>

              {/* Like + duration */}
              <div className="flex items-center justify-end gap-3">
                <button
                  onClick={() => onToggleLike(t.id)}
                  className={`transition-opacity ${t.liked ? "text-emerald-400 opacity-100" : "text-[var(--sp-text-subdued)] opacity-0 group-hover:opacity-100 hover:text-white"}`}
                >
                  <Heart size={14} fill={t.liked ? "currentColor" : "none"} />
                </button>
                <span className="text-sm tabular-nums text-[var(--sp-text-subdued)]">
                  {fmtDuration(t.duration)}
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
