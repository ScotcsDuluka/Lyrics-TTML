"use client";
import { Play, Pause, Heart, Clock, MoreHorizontal, Pencil, Trash2 } from "lucide-react";
import type { Playlist, Track } from "@/lib/types";
import { TrackTable } from "./track-table";

interface Props {
  playlist: Playlist | null;
  tracks: Track[];
  currentTrackId: string | null;
  isPlaying: boolean;
  isLikedPlaylist?: boolean; // kept for compat but not used (heart removed)
  coverHue: number;
  onPlay: () => void;
  onSelectTrack: (track: Track, index: number) => void;
  onToggleLike: (trackId: string) => void;
  onEditPlaylist?: () => void;
  onDeletePlaylist?: () => void;
}

export function PlaylistView(p: Props) {
  if (!p.playlist) {
    return (
      <div className="flex h-full items-center justify-center text-[var(--sp-text-subdued)]">
        Playlist not found
      </div>
    );
  }

  const isSystemLiked = p.playlist.isSystem && p.playlist.name === "Liked Songs";
  const gradientFrom = isSystemLiked
    ? "from-purple-600"
    : `from-[hsl(${p.coverHue},40%,30%)]`;

  return (
    <div className="bl-scroll flex-1">
      {/* Header — Spotify style: smaller top padding */}
      <div className={`bg-gradient-to-b ${gradientFrom} to-transparent px-6 pb-6 pt-6`}>
        <div className="flex items-end gap-6">
          {p.playlist.coverUrl ? (
            <img src={p.playlist.coverUrl} alt="" className="h-48 w-48 shrink-0 rounded-md object-cover shadow-2xl" />
          ) : isSystemLiked ? (
            <div className="flex h-48 w-48 shrink-0 items-center justify-center rounded-md bg-gradient-to-br from-purple-500 to-pink-600 shadow-2xl">
              <Heart size={80} fill="currentColor" className="text-white" />
            </div>
          ) : (
            <div className="flex h-48 w-48 shrink-0 items-center justify-center rounded-md bg-gradient-to-br from-emerald-500/40 to-teal-700/40 shadow-2xl">
              <Clock size={64} className="text-white/60" />
            </div>
          )}
          <div className="min-w-0 flex-1 pb-4">
            <div className="text-xs font-bold uppercase tracking-wider text-white">Playlist</div>
            <h1 className="mt-2 truncate text-7xl font-extrabold tracking-tight text-white">
              {p.playlist.name}
            </h1>
            <p className="mt-4 text-sm text-white/70">{p.playlist.description || ""}</p>
            <div className="mt-2 flex items-center gap-1 text-sm text-white/80">
              <span className="font-bold text-white">Beautiful Lyrics</span>
              <span>•</span>
              <span>{p.tracks.length} songs</span>
            </div>
          </div>
        </div>
      </div>

      {/* Toolbar */}
      <div className="bg-black/20 px-6 py-4">
        <div className="flex items-center gap-6">
          <button
            onClick={p.onPlay}
            disabled={p.tracks.length === 0}
            className="flex h-14 w-14 items-center justify-center rounded-full bg-emerald-500 text-black shadow-lg transition-all hover:scale-105 hover:bg-emerald-400 active:scale-95 disabled:opacity-40"
          >
            {p.isPlaying ? <Pause size={24} fill="currentColor" /> : <Play size={24} fill="currentColor" className="ml-1" />}
          </button>
          {!p.playlist.isSystem && (
            <div className="group relative">
              <button className="text-[var(--sp-text-subdued)] hover:text-white">
                <MoreHorizontal size={28} />
              </button>
              <div className="absolute right-0 top-full mt-2 hidden group-hover:block z-20 w-48 rounded-md bg-[var(--sp-elevated)] border border-white/10 py-1 shadow-xl">
                {p.onEditPlaylist && (
                  <button
                    onClick={p.onEditPlaylist}
                    className="flex w-full items-center gap-3 px-3 py-2 text-sm text-white hover:bg-white/10"
                  >
                    <Pencil size={14} /> Edit details
                  </button>
                )}
                {p.onDeletePlaylist && (
                  <button
                    onClick={p.onDeletePlaylist}
                    className="flex w-full items-center gap-3 px-3 py-2 text-sm text-red-400 hover:bg-white/10"
                  >
                    <Trash2 size={14} /> Delete
                  </button>
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Track table */}
      <TrackTable
        tracks={p.tracks}
        currentTrackId={p.currentTrackId}
        isPlaying={p.isPlaying}
        onSelect={p.onSelectTrack}
        onTogglePlay={p.onPlay}
        onToggleLike={p.onToggleLike}
      />
    </div>
  );
}
