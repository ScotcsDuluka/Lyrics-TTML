"use client";
import { useState } from "react";
import { Home, Search, Library, Plus, Heart, Clock, ListMusic, Music2 } from "lucide-react";
import type { Playlist } from "@/lib/types";
import { useAppStore } from "@/lib/store";

interface Props {
  playlists: Playlist[];
  likedTrackCount: number;
  onSelectPlaylist: (id: string) => void;
  onCreatePlaylist: () => void;
  onGoHome: () => void;
  onGoSearch: () => void;
  onGoLiked: () => void;
}

export function Sidebar({ playlists, likedTrackCount, onSelectPlaylist, onCreatePlaylist, onGoHome, onGoSearch, onGoLiked }: Props) {
  const view = useAppStore(s => s.view);
  const activePlaylistId = view.type === "playlist" ? view.id : null;

  return (
    <div className="bl-sidebar">
      {/* Top nav */}
      <nav className="bl-bg-elevated rounded-lg p-2">
        <NavButton icon={<Home size={24} />} label="Home" active={view.type === "home"} onClick={onGoHome} />
        <NavButton icon={<Search size={24} />} label="Search" active={view.type === "search"} onClick={onGoSearch} />
      </nav>

      {/* Library */}
      <div className="bl-bg-elevated rounded-lg flex flex-col min-h-0 overflow-hidden">
        {/* Library header */}
        <div className="flex items-center justify-between px-4 py-3">
          <button className="flex items-center gap-3 text-[var(--sp-text-subdued)] hover:text-white transition-colors">
            <Library size={22} />
            <span className="text-sm font-bold">Your Library</span>
          </button>
          <button
            onClick={onCreatePlaylist}
            className="rounded-full p-2 text-[var(--sp-text-subdued)] hover:bg-white/10 hover:text-white transition-colors"
            title="Create playlist"
          >
            <Plus size={18} />
          </button>
        </div>

        {/* Filter chips */}
        <div className="flex gap-2 px-3 pb-2">
          <button className="rounded-full bg-white/10 px-3 py-1 text-xs font-medium text-white">Playlists</button>
          <button className="rounded-full bg-white/5 px-3 py-1 text-xs font-medium text-[var(--sp-text-subdued)] hover:bg-white/10">Artists</button>
        </div>

        {/* Library list */}
        <div className="bl-scroll flex-1 px-2 pb-2">
          {/* Liked Songs (special) */}
          <LibraryItem
            cover={<div className="flex h-12 w-12 items-center justify-center rounded bg-gradient-to-br from-purple-500 to-pink-600"><Heart size={20} fill="currentColor" className="text-white" /></div>}
            title="Liked Songs"
            subtitle={`${likedTrackCount} songs`}
            active={view.type === "liked"}
            onClick={onGoLiked}
          />

          {playlists.filter(p => !p.isSystem).map(pl => (
            <LibraryItem
              key={pl.id}
              cover={
                pl.coverUrl ? (
                  <img src={pl.coverUrl} alt="" className="h-12 w-12 rounded object-cover" />
                ) : (
                  <div className="flex h-12 w-12 items-center justify-center rounded bg-gradient-to-br from-emerald-500/40 to-teal-700/40">
                    <ListMusic size={18} className="text-white/60" />
                  </div>
                )
              }
              title={pl.name}
              subtitle={`Playlist • ${pl.trackCount} songs`}
              active={activePlaylistId === pl.id}
              onClick={() => onSelectPlaylist(pl.id)}
            />
          ))}

          {playlists.filter(p => p.isSystem && p.name !== "Liked Songs").map(pl => (
            <LibraryItem
              key={pl.id}
              cover={
                pl.coverUrl ? (
                  <img src={pl.coverUrl} alt="" className="h-12 w-12 rounded object-cover" />
                ) : (
                  <div className="flex h-12 w-12 items-center justify-center rounded bg-white/10">
                    <Clock size={18} className="text-white/60" />
                  </div>
                )
              }
              title={pl.name}
              subtitle={`Playlist • ${pl.trackCount} songs`}
              active={activePlaylistId === pl.id}
              onClick={() => onSelectPlaylist(pl.id)}
            />
          ))}
        </div>
      </div>
    </div>
  );
}

function NavButton({ icon, label, active, onClick }: { icon: React.ReactNode; label: string; active: boolean; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className={`flex w-full items-center gap-4 rounded-md px-3 py-2 font-bold transition-colors ${
        active ? "text-white" : "text-[var(--sp-text-subdued)] hover:text-white"
      }`}
    >
      {icon}
      <span className="text-sm">{label}</span>
    </button>
  );
}

function LibraryItem({ cover, title, subtitle, active, onClick }: { cover: React.ReactNode; title: string; subtitle: string; active: boolean; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className={`flex w-full items-center gap-3 rounded-md p-2 text-left transition-colors ${
        active ? "bg-white/10" : "hover:bg-white/5"
      }`}
    >
      {cover}
      <div className="min-w-0 flex-1">
        <div className={`truncate text-sm font-medium ${active ? "text-emerald-400" : "text-white"}`}>{title}</div>
        <div className="truncate text-xs text-[var(--sp-text-subdued)]">{subtitle}</div>
      </div>
    </button>
  );
}
