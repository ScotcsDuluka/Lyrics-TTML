"use client";
import { ChevronLeft, ChevronRight, Search, Bell, User } from "lucide-react";
import { useAppStore } from "@/lib/store";

interface Props {
  searchValue: string;
  onSearch: (q: string) => void;
  onBack: () => void;
  onForward: () => void;
}

export function TopBar({ searchValue, onSearch, onBack, onForward }: Props) {
  const view = useAppStore(s => s.view);

  return (
    <header className="flex shrink-0 items-center justify-between px-6 py-3">
      {/* Left: navigation arrows */}
      <div className="flex items-center gap-2">
        <button
          onClick={onBack}
          className="flex h-8 w-8 items-center justify-center rounded-full bg-black/40 text-white/70 hover:bg-black/60"
        >
          <ChevronLeft size={20} />
        </button>
        <button
          onClick={onForward}
          className="flex h-8 w-8 items-center justify-center rounded-full bg-black/40 text-white/70 hover:bg-black/60"
        >
          <ChevronRight size={20} />
        </button>

        {/* Search bar (visible on search view) */}
        {view.type === "search" && (
          <div className="relative ml-4">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-black/60" />
            <input
              type="text"
              value={searchValue}
              onChange={e => onSearch(e.target.value)}
              placeholder="What do you want to play?"
              className="w-96 rounded-full bg-white py-2 pl-9 pr-4 text-sm text-black placeholder:text-black/50 focus:outline-none focus:ring-2 focus:ring-white"
              autoFocus
            />
          </div>
        )}
      </div>

      {/* Right: user menu */}
      <div className="flex items-center gap-3">
        <button className="rounded-full bg-black/40 p-2 text-white/70 hover:bg-black/60">
          <Bell size={16} />
        </button>
        <button className="flex h-8 w-8 items-center justify-center rounded-full bg-emerald-500 text-black hover:scale-105">
          <User size={16} />
        </button>
      </div>
    </header>
  );
}
