"use client";
import { useEffect, useRef } from "react";

interface ChatEntry {
  id: string;
  ts: string;
  source: "user" | "ai" | "system";
  applied: boolean;
  text: string;
  response?: string;
}

interface Options {
  onUserCommand?: (text: string) => void;
  onAiReply?: (text: string) => void;
  onSystemEntry?: (entry: ChatEntry) => void;
}

/** Polls /api/poll for new chat entries every 2s. */
export function useChatPoll(opts: Options = {}) {
  const lastTsRef = useRef<string | null>(null);
  const seenIdsRef = useRef<Set<string>>(new Set());
  const seenContentRef = useRef<Set<string>>(new Set());

  useEffect(() => {
    let cancelled = false;
    let timer: any;

    const poll = async () => {
      if (cancelled) return;
      try {
        const url = `/api/poll${lastTsRef.current ? `?since=${encodeURIComponent(lastTsRef.current)}` : ""}`;
        const res = await fetch(url);
        if (!res.ok) return;
        const data = await res.json();
        const entries: ChatEntry[] = data.entries || [];
        for (const e of entries) {
          if (seenIdsRef.current.has(e.id)) continue;
          seenIdsRef.current.add(e.id);
          lastTsRef.current = e.ts;

          // Dedup by content (source + text) — external bot may spam
          // the same message with different IDs
          const contentKey = `${e.source}:${e.text}`;
          if (seenContentRef.current.has(contentKey)) continue;
          seenContentRef.current.add(contentKey);

          // Cap memory usage
          if (seenContentRef.current.size > 500) {
            const arr = Array.from(seenContentRef.current);
            seenContentRef.current = new Set(arr.slice(-250));
          }

          if (e.source === "user" && opts.onUserCommand) {
            opts.onUserCommand(e.text);
          } else if (e.source === "ai" && opts.onAiReply) {
            opts.onAiReply(e.text);
          } else if (e.source === "system" && opts.onSystemEntry) {
            opts.onSystemEntry(e);
          }
        }
      } catch (e) {
        // silent retry
      } finally {
        if (!cancelled) timer = setTimeout(poll, 2000);
      }
    };

    poll();
    return () => {
      cancelled = true;
      if (timer) clearTimeout(timer);
    };
  }, [opts.onUserCommand, opts.onAiReply, opts.onSystemEntry]);
}
