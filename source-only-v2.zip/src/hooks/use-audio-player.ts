"use client";
import { useEffect, useRef, useState, useCallback } from "react";

export const EQ_FREQS = [60, 170, 310, 600, 1000, 3000, 6000, 12000, 14000, 16000];

interface AudioState {
  currentTime: number;
  duration: number;
  isPlaying: boolean;
  volume: number;
  muted: boolean;
  error: string | null;
}

interface AudioControls {
  play: () => void;
  pause: () => void;
  toggle: () => void;
  seek: (s: number) => void;
  setVolume: (v: number) => void;
  setMuted: (m: boolean) => void;
  toggleMute: () => void;
  setEqBand: (freq: number, gain: number) => void;
  resetEq: () => void;
}

export function useAudioPlayer(src: string | null, externalVolume?: number, externalMuted?: boolean): [AudioState, AudioControls, React.RefObject<HTMLAudioElement>] {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const sourceNodeRef = useRef<MediaElementAudioSourceNode | null>(null);
  const filterNodesRef = useRef<BiquadFilterNode[]>([]);
  const gainNodeRef = useRef<GainNode | null>(null);
  const eqGainsRef = useRef<Record<number, number>>({});

  const [state, setState] = useState<AudioState>({
    currentTime: 0, duration: 0, isPlaying: false, volume: 0.7, muted: false, error: null,
  });

  useEffect(() => {
    if (!audioRef.current) return;
    const audio = audioRef.current;
    const onTime = () => setState(s => ({ ...s, currentTime: audio.currentTime }));
    const onDur = () => setState(s => ({ ...s, duration: audio.duration || 0 }));
    const onPlay = () => setState(s => ({ ...s, isPlaying: true }));
    const onPause = () => setState(s => ({ ...s, isPlaying: false }));
    const onErr = () => {
      const err = audio.error;
      let msg = "Audio error";
      if (err) {
        switch (err.code) {
          case 1: msg = "Loading aborted"; break;
          case 2: msg = "Network error"; break;
          case 3: msg = "Decode error"; break;
          case 4: msg = `Source not supported: ${audio.src}`; break;
        }
      }
      console.error("[Audio]", msg, { src: audio.src, code: err?.code });
      setState(s => ({ ...s, error: msg, isPlaying: false }));
    };
    audio.addEventListener("timeupdate", onTime);
    audio.addEventListener("loadedmetadata", onDur);
    audio.addEventListener("durationchange", onDur);
    audio.addEventListener("play", onPlay);
    audio.addEventListener("pause", onPause);
    audio.addEventListener("error", onErr);
    return () => {
      audio.removeEventListener("timeupdate", onTime);
      audio.removeEventListener("loadedmetadata", onDur);
      audio.removeEventListener("durationchange", onDur);
      audio.removeEventListener("play", onPlay);
      audio.removeEventListener("pause", onPause);
      audio.removeEventListener("error", onErr);
    };
  }, []);

  useEffect(() => {
    if (!audioRef.current) return;
    if (!src) {
      audioRef.current.pause();
      audioRef.current.removeAttribute("src");
      setState(s => ({ ...s, currentTime: 0, duration: 0, isPlaying: false }));
      return;
    }
    audioRef.current.src = src;
    audioRef.current.load();
  }, [src]);

  // Sync external volume + muted from store
  useEffect(() => {
    if (externalVolume !== undefined) {
      setState(s => ({ ...s, volume: externalVolume }));
    }
  }, [externalVolume]);

  useEffect(() => {
    if (externalMuted !== undefined) {
      setState(s => ({ ...s, muted: externalMuted }));
    }
  }, [externalMuted]);

  // Apply volume + muted to audio element
  useEffect(() => {
    if (!audioRef.current) return;
    const vol = state.muted ? 0 : state.volume;
    audioRef.current.volume = vol;
    if (gainNodeRef.current && audioCtxRef.current) {
      gainNodeRef.current.gain.setTargetAtTime(vol, audioCtxRef.current.currentTime, 0.01);
    }
  }, [state.volume, state.muted]);

  const initWebAudio = useCallback(() => {
    if (audioCtxRef.current || !audioRef.current) return;
    try {
      const Ctx = window.AudioContext || (window as any).webkitAudioContext;
      const ctx = new Ctx();
      const source = ctx.createMediaElementSource(audioRef.current);
      const filters = EQ_FREQS.map((freq, i) => {
        const f = ctx.createBiquadFilter();
        f.type = i === 0 ? "lowshelf" : i === EQ_FREQS.length - 1 ? "highshelf" : "peaking";
        f.frequency.value = freq;
        f.Q.value = 1.0;
        f.gain.value = 0;
        return f;
      });
      const gain = ctx.createGain();
      gain.gain.value = state.muted ? 0 : state.volume;
      source.connect(filters[0]);
      for (let i = 0; i < filters.length - 1; i++) filters[i].connect(filters[i + 1]);
      filters[filters.length - 1].connect(gain);
      gain.connect(ctx.destination);
      audioCtxRef.current = ctx;
      sourceNodeRef.current = source;
      filterNodesRef.current = filters;
      gainNodeRef.current = gain;
    } catch (e) { console.warn("[Audio] Web Audio init failed:", e); }
  }, [state.volume, state.muted]);

  const play = useCallback(() => {
    initWebAudio();
    if (audioCtxRef.current?.state === "suspended") audioCtxRef.current.resume();
    audioRef.current?.play().catch(e => {
      console.warn("[Audio] play failed:", e);
      setState(s => ({ ...s, error: "Play blocked. Click again." }));
    });
  }, [initWebAudio]);

  const pause = useCallback(() => { audioRef.current?.pause(); }, []);
  const toggle = useCallback(() => { state.isPlaying ? pause() : play(); }, [state.isPlaying, play, pause]);
  const seek = useCallback((s: number) => {
    if (!audioRef.current) return;
    audioRef.current.currentTime = s;
    setState(cur => ({ ...cur, currentTime: s }));
  }, []);
  const setVolume = useCallback((v: number) => { setState(s => ({ ...s, volume: v, muted: v === 0 })); }, []);
  const setMuted = useCallback((m: boolean) => { setState(s => ({ ...s, muted: m })); }, []);
  const toggleMute = useCallback(() => { setState(s => ({ ...s, muted: !s.muted })); }, []);

  const setEqBand = useCallback((freq: number, gain: number) => {
    const idx = EQ_FREQS.indexOf(freq);
    if (idx < 0) return;
    eqGainsRef.current[freq] = gain;
    const filter = filterNodesRef.current[idx];
    if (!filter || !audioCtxRef.current) return;
    filter.gain.setTargetAtTime(gain, audioCtxRef.current.currentTime, 0.01);
  }, []);

  const resetEq = useCallback(() => {
    if (!audioCtxRef.current) return;
    filterNodesRef.current.forEach(f => f.gain.setTargetAtTime(0, audioCtxRef.current!.currentTime, 0.01));
    eqGainsRef.current = {};
  }, []);

  return [state, { play, pause, toggle, seek, setVolume, setMuted, toggleMute, setEqBand, resetEq }, audioRef as React.RefObject<HTMLAudioElement>];
}
