export interface Track {
  id: string;
  title: string;
  artists: string[];
  album: string;
  audioUrl: string;
  lyricsUrl: string | null;
  coverUrl: string | null;
  duration: number | null;
  liked?: boolean;
}

export interface Playlist {
  id: string;
  name: string;
  description: string;
  coverUrl: string | null;
  isSystem: boolean;
  trackCount: number;
  tracks?: Track[];
}

export interface PlayHistoryEntry {
  id: string;
  track: Track;
  playedAt: string;
}

export type RepeatMode = "off" | "all" | "one";

export type View = 
  | { type: "home" }
  | { type: "playlist"; id: string }
  | { type: "search"; query: string }
  | { type: "liked" }
  | { type: "history" };
