"use client";
import { create } from "zustand";

export interface CommandEntry {
  id: string;
  text: string;
  ts: number;
  source: "user" | "system" | "ai";
  applied: boolean;
  response?: string;
}

interface CommandStore {
  entries: CommandEntry[];
  push: (raw: string) => void;
  clear: () => void;
}

const ENTRY_STORAGE_KEY = "bl-chat-entries-v1";

function loadEntries(): CommandEntry[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = localStorage.getItem(ENTRY_STORAGE_KEY);
    if (!raw) return [];
    const data = JSON.parse(raw);
    return Array.isArray(data) ? data.slice(-100) : [];
  } catch { return []; }
}

function saveEntries(entries: CommandEntry[]) {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(ENTRY_STORAGE_KEY, JSON.stringify(entries.slice(-100)));
  } catch {}
}

export const useCommandStore = create<CommandStore>((set, get) => ({
  entries: loadEntries(),
  push: (raw: string) => {
    const text = raw.trim();
    if (!text) return;
    const id = `${Date.now()}-${Math.random().toString(36).slice(2,8)}`;
    const entry: CommandEntry = {
      id,
      text,
      ts: Date.now(),
      source: "user",
      applied: false,
    };

    // Process slash commands (basic ones that work in main app)
    const lower = text.toLowerCase();
    const cmd = lower.startsWith("/") ? lower.slice(1) : lower;
    const parts = cmd.split(/\s+/);
    const op = parts[0];
    const arg = parts.slice(1).join(" ");
    let response = "";
    let applied = false;

    switch (op) {
      case "help":
        response = "Commands: /play /pause /next /prev /seek <s> /fullscreen <on|off>";
        applied = true;
        break;
      case "play":
        window.dispatchEvent(new CustomEvent("bl:playback", { detail: "play" }));
        response = "▶ Playing";
        applied = true;
        break;
      case "pause":
        window.dispatchEvent(new CustomEvent("bl:playback", { detail: "pause" }));
        response = "⏸ Paused";
        applied = true;
        break;
      case "next":
        window.dispatchEvent(new CustomEvent("bl:playback", { detail: "next" }));
        response = "⏭ Next";
        applied = true;
        break;
      case "prev":
        window.dispatchEvent(new CustomEvent("bl:playback", { detail: "prev" }));
        response = "⏮ Previous";
        applied = true;
        break;
      default:
        // Plain text — log for AI to see
        response = "note logged for AI";
        applied = true;
    }

    const updated: CommandEntry = { ...entry, applied, response };
    set({ entries: [...get().entries, updated] });
    saveEntries([...get().entries, updated]);

    // Forward to /api/command for external AI bot
    try {
      fetch("/api/command", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text, applied, response }),
      });
    } catch {}

    // Trigger AI auto-reply (LLM generates response, writes [ai] to log)
    // CommandOverlay polls /api/command and picks up the [ai] entry
    if (!text.startsWith("/")) {
      try {
        fetch("/api/ai-reply", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ message: text }),
        });
      } catch {}
    }
  },
  clear: () => {
    set({ entries: [] });
    saveEntries([]);
    fetch("/api/command-clear", { method: "POST" }).catch(() => {});
  },
}));

if (typeof window !== "undefined") {
  (window as any).__useCommandStore = useCommandStore;
}
