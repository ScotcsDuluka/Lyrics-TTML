"use client";
import { create } from "zustand";
import type { RepeatMode, View } from "./types";

const PERSIST_KEY = "bl-spotify-state-v1";

interface PersistedState {
  volume: number;
  muted: boolean;
  shuffle: boolean;
  repeat: RepeatMode;
  activePlaylistId: string | null;
}

const DEFAULT_PERSISTED: PersistedState = {
  volume: 0.7,
  muted: false,
  shuffle: false,
  repeat: "off",
  activePlaylistId: null,
};

function loadPersisted(): Partial<PersistedState> {
  if (typeof window === "undefined") return {};
  try {
    const raw = window.localStorage.getItem(PERSIST_KEY);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

function savePersisted(state: PersistedState) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(PERSIST_KEY, JSON.stringify(state));
  } catch {}
}

interface AppStore extends PersistedState {
  // Player state (not persisted)
  currentTrackId: string | null;
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  queue: string[]; // track IDs
  queueIndex: number;
  history: string[]; // recently played track IDs

  // UI state
  view: View;
  searchQuery: string;
  showQueue: boolean;
  showRightPanel: boolean;
  sidebarCollapsed: boolean;

  // Setters
  setVolume: (v: number) => void;
  setMuted: (v: boolean) => void;
  setShuffle: (v: boolean) => void;
  setRepeat: (v: RepeatMode) => void;
  setActivePlaylistId: (id: string | null) => void;

  setView: (v: View) => void;
  setSearchQuery: (q: string) => void;
  setShowQueue: (v: boolean) => void;
  setShowRightPanel: (v: boolean) => void;
  setSidebarCollapsed: (v: boolean) => void;

  setCurrentTrack: (id: string | null) => void;
  setIsPlaying: (v: boolean) => void;
  setCurrentTime: (t: number) => void;
  setDuration: (d: number) => void;

  setQueue: (ids: string[], startIndex?: number) => void;
  nextInQueue: () => string | null;
  prevInQueue: () => string | null;
  addToHistory: (id: string) => void;

  reset: () => void;
}

export const useAppStore = create<AppStore>((set, get) => ({
  ...DEFAULT_PERSISTED,
  ...loadPersisted(),

  currentTrackId: null,
  isPlaying: false,
  currentTime: 0,
  duration: 0,
  queue: [],
  queueIndex: -1,
  history: [],

  view: { type: "home" },
  searchQuery: "",
  showQueue: false,
  showRightPanel: true,
  sidebarCollapsed: false,

  setVolume: (v) => { set({ volume: v }); persist(get()); },
  setMuted: (v) => { set({ muted: v }); persist(get()); },
  setShuffle: (v) => { set({ shuffle: v }); persist(get()); },
  setRepeat: (v) => { set({ repeat: v }); persist(get()); },
  setActivePlaylistId: (id) => { set({ activePlaylistId: id }); persist(get()); },

  setView: (v) => set({ view: v }),
  setSearchQuery: (q) => set({ searchQuery: q }),
  setShowQueue: (v) => set({ showQueue: v }),
  setShowRightPanel: (v) => set({ showRightPanel: v }),
  setSidebarCollapsed: (v) => set({ sidebarCollapsed: v }),

  setCurrentTrack: (id) => set({ currentTrackId: id }),
  setIsPlaying: (v) => set({ isPlaying: v }),
  setCurrentTime: (t) => set({ currentTime: t }),
  setDuration: (d) => set({ duration: d }),

  setQueue: (ids, startIndex = 0) => set({ queue: ids, queueIndex: startIndex }),
  nextInQueue: () => {
    const s = get();
    if (s.shuffle && s.queue.length > 1) {
      let r = s.queueIndex;
      while (r === s.queueIndex) r = Math.floor(Math.random() * s.queue.length);
      set({ queueIndex: r });
      return s.queue[r];
    }
    if (s.queueIndex + 1 < s.queue.length) {
      const next = s.queueIndex + 1;
      set({ queueIndex: next });
      return s.queue[next];
    }
    if (s.repeat === "all" && s.queue.length > 0) {
      set({ queueIndex: 0 });
      return s.queue[0];
    }
    return null;
  },
  prevInQueue: () => {
    const s = get();
    if (s.queueIndex > 0) {
      const prev = s.queueIndex - 1;
      set({ queueIndex: prev });
      return s.queue[prev];
    }
    return null;
  },
  addToHistory: (id) => {
    const s = get();
    const filtered = s.history.filter(h => h !== id);
    set({ history: [id, ...filtered].slice(0, 50) });
  },

  reset: () => {
    set({ ...DEFAULT_PERSISTED });
    savePersisted(DEFAULT_PERSISTED);
  },
}));

function persist(state: AppStore) {
  const persisted: PersistedState = {
    volume: state.volume,
    muted: state.muted,
    shuffle: state.shuffle,
    repeat: state.repeat,
    activePlaylistId: state.activePlaylistId,
  };
  savePersisted(persisted);
}

let pt: any;
useAppStore.subscribe(() => {
  if (pt) clearTimeout(pt);
  pt = setTimeout(() => persist(useAppStore.getState()), 600);
});

if (typeof window !== "undefined") {
  (window as any).__useAppStore = useAppStore;
}
