// Shim for components/Global/SpotifyPlayer.ts
// Hooks into our Next.js audio element instead of Spotify.
import GetProgress, { setAudioElement } from "./GetProgress";

let _seekFn: (positionSec: number) => void = () => {};
export function setSeekFunction(fn: (positionSec: number) => void) { _seekFn = fn; }

export type CoverSizes = "standard" | "small" | "large" | "xlarge";
export type Artist = { type: "artist"; name: string; uri: string };

export const SpotifyPlayer = {
  IsPlaying: false,
  GetPosition: GetProgress,
  Seek: (s: number) => { _seekFn(s); },
  GetContentType: () => "track", GetMediaType: () => "audio", GetDuration: () => 0,
  GetCover: () => undefined, GetUri: () => undefined, IsDJ: () => false, IsLiked: () => false,
  ToggleLike: async () => {}, Pause: () => {}, Play: () => {}, TogglePlayState: () => {},
  Skip: { Next: () => {}, Prev: () => {} }, LoopType: "none", ShuffleType: "none",
  Playbar: { Button: class {}, Widget: class {} },
};

export { setAudioElement };
