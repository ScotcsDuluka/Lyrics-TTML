export function EnableCompactMode() {}
export function DisableCompactMode() {}
export function IsCompactMode() { return false; }
export function Compactify() {}
