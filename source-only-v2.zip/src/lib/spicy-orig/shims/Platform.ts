const Platform = { GetSpotifyAccessToken: async () => "shim-token" };
export default Platform;
