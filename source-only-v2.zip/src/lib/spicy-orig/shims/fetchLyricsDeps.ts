export async function Query(): Promise<Map<string, { data: any; httpStatus: number }>> { return new Map(); }
export const LocalLyricsManager = { get: async () => null };
export const LyricsQueueRetry = { NotifyResolved: () => {}, HandleQueued: () => {}, IsRetryingFor: () => false };
export function GetExpireStore() { return null; }
export class SLObjPack { unpack(d: any) { return d; } pack(d: any) { return d; } }
export async function RetrievePackage() { return undefined; }
export function ClearLyricsPageContainer() {
  if (typeof document === "undefined") return;
  const el = document.querySelector<HTMLElement>(".LyricsContainer .LyricsContent");
  if (el) el.innerHTML = "";
}
