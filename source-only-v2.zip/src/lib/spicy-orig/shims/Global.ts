import Event from "./EventManager";
const getScope = (): Record<string, any> => {
  if (typeof window === "undefined") return {};
  if (!(window as any)._spicy_lyrics) (window as any)._spicy_lyrics = {};
  return (window as any)._spicy_lyrics;
};
const Global = {
  get Scope() { return getScope(); },
  Event, NonLocalTimeOffset: 0, Saves: {} as Record<string, any>,
  SetScope: (key: string, value: any) => { const s = getScope(); const p = key.split("."); let o = s; for (let i = 0; i < p.length-1; i++) { if (!o[p[i]]) o[p[i]] = {}; o = o[p[i]]; } o[p[p.length-1]] = value; },
  GetScope: (key: string, fallback?: any) => { const s = getScope(); const p = key.split("."); let o = s; for (const x of p) { if (o == null) return fallback; o = o[x]; } return o ?? fallback; },
};
export default Global;
