export function ApplyIsByCommunity(_d: any, _c: HTMLElement) {}
export function CleanUpIsByCommunity() {}
export function ApplyLyricsCredits(_d: any, _c: HTMLElement) {}
export function ApplyLyricsProvider(_d: any, _c: HTMLElement) {}
