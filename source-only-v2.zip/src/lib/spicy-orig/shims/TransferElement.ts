// No-op: we don't need to transfer elements between Spotify containers
export default function TransferElement(_el: HTMLElement, _to: HTMLElement) {}
