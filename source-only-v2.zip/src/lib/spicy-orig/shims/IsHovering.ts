export let IsMouseInLyricsPage = false;
export function SetIsMouseInLyricsPage(v: boolean) { IsMouseInLyricsPage = v; }
export function LyricsPageMouseEnter() { SetIsMouseInLyricsPage(true); }
export function LyricsPageMouseLeave() { SetIsMouseInLyricsPage(false); }
