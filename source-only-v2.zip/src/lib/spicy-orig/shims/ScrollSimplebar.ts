export let ScrollSimplebar: any = null;
export function MountScrollSimplebar() {}
export function ClearScrollSimplebar() { ScrollSimplebar = null; }
export function RecalculateScrollSimplebar() {}
