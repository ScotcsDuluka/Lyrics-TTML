export class IntervalManager {
  constructor(private _d: number, private _cb: () => void) {}
  Start(): this { return this; }
  Stop() {}
}
