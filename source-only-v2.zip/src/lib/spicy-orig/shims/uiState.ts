import { atom } from "nanostores";

function persistAtom<T>(key: string, defaultValue: T) {
  const a = atom<T>(defaultValue);
  try { if (typeof window !== "undefined") { const raw = window.localStorage.getItem(key); if (raw) a.set(JSON.parse(raw)); } } catch {}
  a.listen(v => { try { if (typeof window !== "undefined") window.localStorage.setItem(key, JSON.stringify(v)); } catch {} });
  return a;
}

export const $romanization = persistAtom("SL:romanization", false);
export const forceCompactMode = atom<boolean>(false);
export const isNowBarOpen = atom<boolean>(false);
