export function OpenNowBar(_v?: boolean) {}
export function CloseNowBar() {}
export function CleanUpNowBarComponents() {}
export function DeregisterNowBarBtn() {}
