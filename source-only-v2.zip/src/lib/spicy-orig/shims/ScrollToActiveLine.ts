export function QueueForceScroll() {}
export function InitializeScrollEvents(_s: any) {}
export function CleanupScrollEvents() {}
export function ResetLastLine() {}
