export let PageContainer: HTMLElement | null = null;
export function setPageContainer(el: HTMLElement | null) { PageContainer = el; }
export function Compactify() {}
export function GetPageRoot() { return PageContainer; }
export let IsCardMode = false;
export let LyricsApplied = false;
export const Tooltips: Record<string, any> = {};
const PageView = { Open: async () => {}, Destroy: async () => {}, AppendViewControls: () => {}, IsOpened: false, IsTippyCapable: true };
export default PageView;
