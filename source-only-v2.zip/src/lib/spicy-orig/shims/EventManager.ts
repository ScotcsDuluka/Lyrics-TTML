type Cb = (data: any) => void;
const subs: Map<string, Set<Cb>> = new Map();
const Event = {
  evoke(name: string, data?: any) { subs.get(name)?.forEach(cb => cb(data)); },
  listen(name: string, cb: Cb) { if (!subs.has(name)) subs.set(name, new Set()); subs.get(name)!.add(cb); return () => subs.get(name)?.delete(cb); },
};
export default Event;
