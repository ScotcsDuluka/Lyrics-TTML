export function TimeSetter(_p: number) {}
