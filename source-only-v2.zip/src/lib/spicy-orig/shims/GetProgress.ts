// Shim for utils/Gets/GetProgress.ts
// Reads audio.currentTime DIRECTLY from the <audio> element for zero-latency sync.
// spicy-lyrics stores line/word times in MILLISECONDS (via ConvertTime).
// Our audio element returns seconds. Multiply by 1000 to match.

let _audioEl: HTMLAudioElement | null = null;

/** Register the audio element so GetProgress can read currentTime directly. */
export function setAudioElement(el: HTMLAudioElement | null): void {
  _audioEl = el;
}

export default function GetProgress(): number {
  if (_audioEl) {
    return _audioEl.currentTime * 1000; // seconds → milliseconds
  }
  return 0;
}

export const _DEPRECATED___GetProgress = GetProgress;
