export default class Logger {
  constructor(public scope: string) {}
  debug(..._a: any[]) {}
  info(..._a: any[]) {}
  warn(..._a: any[]) {}
  error(..._a: any[]) {}
}
