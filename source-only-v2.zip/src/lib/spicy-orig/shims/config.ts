export const ProjectVersion = "shim-1.0.0";
