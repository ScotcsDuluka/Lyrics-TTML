import { atom } from "nanostores";
import { ProjectVersion } from "./config";

function persistAtom<T>(key: string, defaultValue: T) {
  const a = atom<T>(defaultValue);
  try { if (typeof window !== "undefined") { const raw = window.localStorage.getItem(key); if (raw) a.set(JSON.parse(raw)); } } catch {}
  a.listen(v => { try { if (typeof window !== "undefined") window.localStorage.setItem(key, JSON.stringify(v)); } catch {} });
  return a;
}
export const $staticBackgroundMode = persistAtom("SL:staticBackgroundMode", "off");
export const $simpleLyricsMode = persistAtom("SL:simpleLyricsMode", false);
export const $simpleLyricsModeRenderingType = persistAtom("SL:simpleLyricsModeRenderingType", "calculate");
export const $minimalLyricsMode = persistAtom("SL:minimalLyricsMode", false);
export const $lyricsContainerExists = atom<boolean>(false);
export const $currentLyricsType = atom<string>("None");
export const $currentlyFetching = atom<boolean>(false);
export const $currentLyricsData = atom<string>("");
export const $spicyLyricsVersion = atom<string>(ProjectVersion);
