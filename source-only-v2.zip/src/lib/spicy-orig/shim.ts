/**
 * Shims for Spicetify-related modules so we can use spicy-lyrics source code
 * verbatim. These provide the minimal interface the original code expects.
 */

// Stub for stores.ts — reactive state (we use simple getters)
export const $currentLyricsType = {
  get: () => "Syllable" as "Syllable" | "Line" | "Static",
  subscribe: (_cb: (v: string) => void) => () => {},
};
export const $simpleLyricsMode = {
  get: () => false,
  subscribe: (_cb: (v: boolean) => void) => () => {},
};
export const $simpleLyricsModeRenderingType = {
  get: () => "calculate" as "calculate" | "animate",
  subscribe: (_cb: (v: string) => void) => () => {},
};
export const $minimalLyricsMode = {
  get: () => false,
  subscribe: (_cb: (v: boolean) => void) => () => {},
};
export const $romanization = {
  get: () => false,
  subscribe: (_cb: (v: boolean) => void) => () => {},
};
export const $lyricsContainerExists = {
  get: () => true,
  subscribe: (_cb: (v: boolean) => void) => () => {},
};

// Stub for SpotifyPlayer
export const SpotifyPlayer = {
  GetPosition: () => 0,
  Seek: (_s: number) => {},
  GetContentType: () => "audio",
  IsDJ: () => false,
  GetCover: (_size: string) => null as string | null,
};

// Stub for Global event system
export const Global = {
  Event: {
    listen: (_name: string, _cb: (e: any) => void) => () => {},
    evoke: (_name: string, _data: any) => {},
  },
};

// Stub for PageContainer
export const PageContainer: HTMLElement | null = null;

// Stub for LyricsVirtualizer.setOnNewElementMounted
export const setOnNewElementMounted = (_cb: () => void) => {};

// Stub for CSS/Styles
export const applyStyles = (_el: HTMLElement, _styles: Record<string, string>) => {};
export const removeAllStyles = (_el: HTMLElement) => {};

// Stub for SimpleBar
export const ScrollSimplebar = null;
export const MountScrollSimplebar = (_el: HTMLElement) => null;
export const ClearScrollSimplebar = () => {};
export const RecalculateScrollSimplebar = () => {};

// Stub for Maid (cleanup container)
export class Maid {
  private items: Array<() => void> = [];
  Give<T extends { Destroy?: () => void } | (() => void)>(item: T): T {
    if (typeof item === "function") {
      this.items.push(item as () => void);
    } else if (item && typeof (item as any).Destroy === "function") {
      this.items.push(() => (item as any).Destroy());
    }
    return item;
  }
  Destroy() {
    for (const item of this.items) {
      try { item(); } catch {}
    }
    this.items = [];
  }
}

// Stub for ClearLyricsContentArrays / ClearLyricsPageContainer / fetchLyrics
export const ClearLyricsContentArrays = () => {};
export const ClearLyricsPageContainer = () => {};

// Stub for isRtl
export const isRtl = (_text: string) => false;
