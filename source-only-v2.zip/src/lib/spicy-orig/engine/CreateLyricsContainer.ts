import { QueueForceScroll } from "../shims/ScrollToActiveLine";
import { ScrollSimplebar } from "../shims/ScrollSimplebar";
import { destroyLyricsVirtualizer } from "./LyricsVirtualizer";

type LyricsContainerReturnObject = {
  Container: HTMLElement;
  ResizeListener: ResizeObserver;
  Append: (AppendTo: HTMLElement) => void;
  Remove: () => void;
  Resize: () => void;
};

const LyricsContainerInstances = new Map<number, LyricsContainerReturnObject>();

let lastMapIndex = -1;

const CreateLyricsContainer = (): LyricsContainerReturnObject => {
  const Container = document.createElement("div");
  Container.classList.add("SpicyLyricsScrollContainer");

  lastMapIndex += 1;
  const currentIndex = lastMapIndex;

  const Resize = () => {
    requestAnimationFrame(() => {
      QueueForceScroll();
      ScrollSimplebar?.recalculate();
    });
  };

  const ResizeListener = new ResizeObserver(() => Resize());
  const _unobs = ResizeListener.unobserve.bind(ResizeListener);
  const _obs = ResizeListener.observe.bind(ResizeListener);
  ResizeListener.unobserve = (t: Element) => { if (t && t instanceof Element) _unobs(t); };
  ResizeListener.observe = (t: Element) => { if (t && t instanceof Element) _obs(t); };

  const Remove = () => {
    if (Container.parentElement) ResizeListener.unobserve(Container.parentElement);
    ResizeListener.disconnect();
    Container.remove();
    LyricsContainerInstances.delete(currentIndex);
  };

  const ReturnObject = {
    Container,
    ResizeListener,
    Append: (AppendTo: HTMLElement) => {
      AppendTo.appendChild(Container);
      const p = Container.parentElement; if (p) ResizeListener.observe(p);
    },
    Remove,
    Resize,
  };

  LyricsContainerInstances.set(currentIndex, ReturnObject);

  return ReturnObject;
};

const GetCurrentLyricsContainerInstance = (): LyricsContainerReturnObject | undefined => {
  if (lastMapIndex === -1) {
    return undefined;
  }
  return LyricsContainerInstances.get(lastMapIndex);
};

const DestroyAllLyricsContainers = () => {
  destroyLyricsVirtualizer();
  LyricsContainerInstances.forEach((Instance) => {
    Instance.Remove();
  });
  LyricsContainerInstances.clear();
  lastMapIndex = -1;
};

export { CreateLyricsContainer, DestroyAllLyricsContainers, GetCurrentLyricsContainerInstance };
