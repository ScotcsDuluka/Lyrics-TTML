import { Animate } from "./LyricsAnimator";
import { TimeSetter } from "../shims/LyricsSetter";

export const Lyrics = {
  Animate,
  TimeSetter,
};
