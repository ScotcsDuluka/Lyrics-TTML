"use client";
import { useCallback, useEffect, useRef, useState } from "react";

export interface AudioPlayerState { isPlaying: boolean; currentTime: number; duration: number; volume: number; muted: boolean; isBuffering: boolean; error: string | null; }
export interface AudioPlayerControls { play: () => void; pause: () => void; toggle: () => void; seek: (s: number) => void; setVolume: (v: number) => void; toggleMute: () => void; }

export function useAudioPlayer(src: string | null): [AudioPlayerState, AudioPlayerControls, React.RefObject<HTMLAudioElement | null>] {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [state, setState] = useState<AudioPlayerState>({ isPlaying: false, currentTime: 0, duration: 0, volume: 0.85, muted: false, isBuffering: false, error: null });

  useEffect(() => {
    const audio = audioRef.current; if (!audio) return;
    const onTime = () => setState(s => ({ ...s, currentTime: audio.currentTime }));
    const onDur = () => setState(s => ({ ...s, duration: audio.duration || 0 }));
    const onPlay = () => setState(s => ({ ...s, isPlaying: true }));
    const onPause = () => setState(s => ({ ...s, isPlaying: false }));
    const onErr = () => setState(s => ({ ...s, error: `Audio error (code ${audio.error?.code})`, isPlaying: false }));
    audio.addEventListener("timeupdate", onTime); audio.addEventListener("durationchange", onDur); audio.addEventListener("loadedmetadata", onDur);
    audio.addEventListener("play", onPlay); audio.addEventListener("pause", onPause); audio.addEventListener("error", onErr);
    return () => { audio.removeEventListener("timeupdate", onTime); audio.removeEventListener("durationchange", onDur); audio.removeEventListener("loadedmetadata", onDur); audio.removeEventListener("play", onPlay); audio.removeEventListener("pause", onPause); audio.removeEventListener("error", onErr); };
  }, []);

  useEffect(() => {
    const audio = audioRef.current; if (!audio) return;
    if (!src) { audio.pause(); audio.removeAttribute("src"); setState(s => ({ ...s, currentTime: 0, duration: 0, isPlaying: false, error: null })); return; }
    audio.src = src; audio.load(); setState(s => ({ ...s, currentTime: 0, error: null }));
  }, [src]);

  useEffect(() => { if (audioRef.current) audioRef.current.volume = state.volume; }, [state.volume]);
  useEffect(() => { if (audioRef.current) audioRef.current.muted = state.muted; }, [state.muted]);

  // rAF loop — update currentTime every frame for smooth sync (NO throttle)
  useEffect(() => {
    let raf = 0;
    const loop = () => { const audio = audioRef.current; if (audio && !audio.paused) { setState(s => ({ ...s, currentTime: audio.currentTime })); } raf = requestAnimationFrame(loop); };
    raf = requestAnimationFrame(loop); return () => cancelAnimationFrame(raf);
  }, []);

  const play = useCallback(() => { audioRef.current?.play().catch(e => setState(s => ({ ...s, error: `Play failed: ${e.message}` }))); }, []);
  const pause = useCallback(() => { audioRef.current?.pause(); }, []);
  const toggle = useCallback(() => { const a = audioRef.current; if (!a) return; a.paused ? play() : pause(); }, [play, pause]);
  const seek = useCallback((s: number) => { const a = audioRef.current; if (!a || !isFinite(s)) return; a.currentTime = Math.max(0, Math.min(s, a.duration || s)); setState(s2 => ({ ...s2, currentTime: a.currentTime })); }, []);
  const setVolume = useCallback((v: number) => { const c = Math.max(0, Math.min(1, v)); setState(s => ({ ...s, volume: c, muted: c === 0 })); }, []);
  const toggleMute = useCallback(() => { setState(s => ({ ...s, muted: !s.muted })); }, []);

  return [state, { play, pause, toggle, seek, setVolume, toggleMute }, audioRef];
}
