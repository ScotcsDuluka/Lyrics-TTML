"use client";
import { Pause, Play, SkipBack, SkipForward, Volume2, VolumeX, Repeat, Shuffle } from "lucide-react";
import { useEffect, useState } from "react";

interface Props { title: string; artists: string[]; currentTime: number; duration: number; isPlaying: boolean; volume: number; muted: boolean; onToggle: () => void; onSeek: (s: number) => void; onPrev: () => void; onNext: () => void; onVolume: (v: number) => void; onToggleMute: () => void; }

function fmt(s: number): string { if (!isFinite(s)) return "0:00"; const t = Math.max(0, Math.floor(s)); return `${Math.floor(t/60)}:${(t%60).toString().padStart(2,"0")}`; }

export function PlayerBar(p: Props) {
  const [seeking, setSeeking] = useState<number | null>(null);
  const [shuffle, setShuffle] = useState(false);
  const [repeat, setRepeat] = useState<"off"|"all"|"one">("off");
  const dt = seeking !== null ? seeking : p.currentTime;
  const pct = p.duration > 0 ? (dt / p.duration) * 100 : 0;
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => { const t = e.target as HTMLElement; if (t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA")) return; if (e.code === "Space") { e.preventDefault(); p.onToggle(); } else if (e.code === "ArrowRight") p.onSeek(p.currentTime + 5); else if (e.code === "ArrowLeft") p.onSeek(p.currentTime - 5); };
    window.addEventListener("keydown", onKey); return () => window.removeEventListener("keydown", onKey);
  }, [p.onToggle, p.onSeek, p.currentTime]);
  return (
    <footer className="bl-player-bar px-4 py-3 sm:px-6">
      <div className="mx-auto flex max-w-7xl flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
        <div className="flex min-w-0 flex-1 items-center gap-3">
          <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-md bg-gradient-to-br from-pink-500/40 via-purple-500/30 to-indigo-500/40 text-xs font-semibold uppercase text-white/80">♪</div>
          <div className="min-w-0"><div className="truncate text-sm font-semibold text-white">{p.title || "ไม่ได้เลือกเพลง"}</div><div className="truncate text-xs text-white/60">{p.artists.length > 0 ? p.artists.join(", ") : "\u00A0"}</div></div>
        </div>
        <div className="flex flex-1 flex-col items-center gap-2">
          <div className="flex items-center gap-4">
            <button onClick={() => setShuffle(s => !s)} className={`rounded p-1 ${shuffle ? "text-emerald-400" : "text-white/60 hover:text-white"}`}><Shuffle size={16} /></button>
            <button onClick={p.onPrev} className="rounded p-1 text-white/80 hover:text-white"><SkipBack size={20} fill="currentColor" /></button>
            <button onClick={p.onToggle} className="flex h-10 w-10 items-center justify-center rounded-full bg-white text-black hover:scale-105 active:scale-95">{p.isPlaying ? <Pause size={20} fill="currentColor" /> : <Play size={20} fill="currentColor" className="ml-0.5" />}</button>
            <button onClick={p.onNext} className="rounded p-1 text-white/80 hover:text-white"><SkipForward size={20} fill="currentColor" /></button>
            <button onClick={() => setRepeat(m => m === "off" ? "all" : m === "all" ? "one" : "off")} className={`rounded p-1 ${repeat !== "off" ? "text-emerald-400" : "text-white/60 hover:text-white"}`}><Repeat size={16} /></button>
          </div>
          <div className="flex w-full max-w-2xl items-center gap-2">
            <span className="w-10 text-right text-[11px] tabular-nums text-white/60">{fmt(dt)}</span>
            <input type="range" min={0} max={p.duration || 0} step={0.05} value={dt} onChange={e => setSeeking(parseFloat(e.target.value))} onPointerUp={() => { if (seeking !== null) { p.onSeek(seeking); setSeeking(null); } }} className="bl-seek-slider flex-1" style={{ "--progress": `${pct}%` } as React.CSSProperties} aria-label="Seek" />
            <span className="w-10 text-[11px] tabular-nums text-white/60">{fmt(p.duration)}</span>
          </div>
        </div>
        <div className="hidden flex-1 items-center justify-end gap-2 lg:flex">
          <button onClick={p.onToggleMute} className="rounded p-1 text-white/60 hover:text-white">{p.muted || p.volume === 0 ? <VolumeX size={18} /> : <Volume2 size={18} />}</button>
          <input type="range" min={0} max={1} step={0.01} value={p.muted ? 0 : p.volume} onChange={e => p.onVolume(parseFloat(e.target.value))} className="bl-volume-slider w-24" style={{ "--progress": `${(p.muted ? 0 : p.volume) * 100}%` } as React.CSSProperties} aria-label="Volume" />
        </div>
      </div>
    </footer>
  );
}
