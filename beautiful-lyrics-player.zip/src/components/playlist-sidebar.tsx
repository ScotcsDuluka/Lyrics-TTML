"use client";
import { useMemo, useState } from "react";
import { Search, Music2 } from "lucide-react";

export interface Track { id: string; title: string; artists: string[]; album: string; audioUrl: string; lyricsUrl: string; coverUrl?: string; sourceTtml: string; sourceMp3: string; }

interface Props { tracks: Track[]; currentId: string | null; isPlaying: boolean; onSelect: (t: Track) => void; }

export function PlaylistSidebar({ tracks, currentId, isPlaying, onSelect }: Props) {
  const [q, setQ] = useState("");
  const filtered = useMemo(() => { const s = q.trim().toLowerCase(); if (!s) return tracks; return tracks.filter(t => (t.title + " " + t.artists.join(" ") + " " + t.album).toLowerCase().includes(s)); }, [tracks, q]);
  return (
    <aside className="bl-playlist flex h-full flex-col">
      <div className="border-b border-white/10 p-4"><h2 className="mb-3 text-sm font-semibold uppercase tracking-wider text-white/60">Playlist</h2><div className="relative"><Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-white/40" /><input type="text" value={q} onChange={e => setQ(e.target.value)} placeholder="ค้นหาเพลงหรือศิลปิน..." className="w-full rounded-full bg-white/5 py-2 pl-9 pr-3 text-sm text-white placeholder:text-white/40 focus:bg-white/10 focus:outline-none" /></div></div>
      <div className="bl-scroll flex-1 overflow-y-auto">{filtered.length === 0 ? <div className="px-4 py-8 text-center text-sm text-white/40">ไม่พบเพลง</div> : <ul className="py-1">{filtered.map((t, i) => { const active = t.id === currentId; return <li key={t.id}><button onClick={() => onSelect(t)} className={`bl-playlist-item group flex w-full items-center gap-3 px-4 py-2.5 text-left ${active ? "active text-white" : "text-white/75 hover:text-white"}`}><div className="flex h-7 w-7 shrink-0 items-center justify-center text-[11px] tabular-nums text-white/40">{active && isPlaying ? <div className="flex h-4 items-end gap-[2px]">{[0,1,2,3].map(j => <span key={j} className="w-[2px] animate-pulse bg-emerald-400" style={{ height: `${[60,100,70,90][j]}%`, animationDelay: `${j*0.15}s`, animationDuration: "0.8s" }} />)}</div> : <span>{i+1}</span>}</div><div className="min-w-0 flex-1"><div className="truncate text-sm font-medium">{t.title}</div><div className="truncate text-xs text-white/50">{t.artists.length > 0 ? t.artists.join(", ") : "Unknown"}</div></div>{active && <Music2 size={14} className="shrink-0 text-emerald-400" />}</button></li>; })}</ul>}</div>
      <div className="border-t border-white/10 px-4 py-2 text-[11px] text-white/40">{filtered.length} เพลง • จาก Lyrics-TTML</div>
    </aside>
  );
}
