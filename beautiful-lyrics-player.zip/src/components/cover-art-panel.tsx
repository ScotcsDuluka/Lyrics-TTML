"use client";
import { Heart, Music2 } from "lucide-react";
import { useEffect, useState } from "react";

interface Props { title: string; artists: string[]; currentTime: number; duration: number; isPlaying: boolean; liked: boolean; onToggleLike: () => void; onSeek: (s: number) => void; hue: number; coverUrl?: string | null; }

function fmt(s: number): string { if (!isFinite(s)) return "0:00"; const t = Math.max(0, Math.floor(s)); return `${Math.floor(t/60)}:${(t%60).toString().padStart(2,"0")}`; }

export function CoverArtPanel({ title, artists, currentTime, duration, isPlaying, liked, onToggleLike, onSeek, hue, coverUrl }: Props) {
  const [seeking, setSeeking] = useState<number | null>(null);
  const displayTime = seeking !== null ? seeking : currentTime;
  const pct = duration > 0 ? (displayTime / duration) * 100 : 0;

  return (
    <div className="flex h-full w-full flex-col items-center justify-center gap-6 px-8 py-12">
      {/* Album art — BIG (like beautiful-lyrics fullscreen) */}
      <div className="relative aspect-square w-full" style={{ maxWidth: "min(50vw, 75vh)" }}>
        <div className="absolute inset-0 overflow-hidden rounded-lg shadow-2xl" style={coverUrl ? undefined : { background: `radial-gradient(circle at 35% 30%, hsl(${hue},70%,70%), hsl(${(hue+40)%360},65%,55%) 35%, hsl(${(hue+200)%360},60%,35%) 80%, hsl(${(hue+220)%360},55%,25%))` }}>
          {coverUrl ? (
            <img src={coverUrl} alt={`${title} cover`} className="absolute inset-0 h-full w-full object-cover" draggable={false} onError={e => { (e.currentTarget as HTMLImageElement).style.display = "none"; }} />
          ) : (
            <>
              <div className="absolute inset-0 opacity-15" style={{ backgroundImage: `repeating-radial-gradient(circle at center, transparent 0, transparent 8px, rgba(0,0,0,0.18) 8px, rgba(0,0,0,0.18) 9px)` }} />
              <Music2 className="absolute left-1/2 top-1/2 h-[36%] w-[36%] -translate-x-1/2 -translate-y-1/2 text-white/25" strokeWidth={1.2} />
            </>
          )}
        </div>
      </div>

      {/* Track details — below cover */}
      <div className="w-full text-center" style={{ maxWidth: "min(50vw, 75vh)" }}>
        <h2 className="truncate text-2xl font-bold text-white">{title || "ไม่ได้เลือกเพลง"}</h2>
        <p className="mt-2 truncate text-base text-white/60">{artists.length > 0 ? artists.join(", ") : "\u00A0"}</p>
      </div>

      {/* Seek bar + time — below title */}
      <div className="flex w-full items-center gap-3" style={{ maxWidth: "min(50vw, 75vh)" }}>
        <span className="w-10 shrink-0 text-right text-[11px] tabular-nums text-white/50">{fmt(displayTime)}</span>
        <input type="range" min={0} max={duration || 0} step={0.05} value={displayTime} onChange={e => setSeeking(parseFloat(e.target.value))} onPointerUp={() => { if (seeking !== null) { onSeek(seeking); setSeeking(null); } }} className="bl-seek-slider flex-1" style={{ "--progress": `${pct}%` } as React.CSSProperties} aria-label="Seek" />
        <span className="w-10 shrink-0 text-[11px] tabular-nums text-white/50">{fmt(duration)}</span>
      </div>
    </div>
  );
}
