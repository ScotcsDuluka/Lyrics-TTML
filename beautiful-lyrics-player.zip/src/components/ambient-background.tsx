"use client";
import { useEffect, useState } from "react";

interface Props { seed: string | null; coverUrl?: string | null; }

export function AmbientBackground({ seed, coverUrl }: Props) {
  const [h1, setH1] = useState(280), [h2, setH2] = useState(330), [h3, setH3] = useState(200);
  useEffect(() => {
    if (!seed) { setH1(280); setH2(330); setH3(200); return; }
    let h = 0; for (let i = 0; i < seed.length; i++) h = (h * 31 + seed.charCodeAt(i)) >>> 0;
    const b = h % 360; queueMicrotask(() => { setH1(b); setH2((b + 40 + (h >> 8) % 60) % 360); setH3((b + 200 + (h >> 16) % 40) % 360); });
  }, [seed]);
  return (
    <div className="bl-ambient-bg" aria-hidden="true">
      {coverUrl ? <div className="bl-ambient-cover" style={{ backgroundImage: `url(${coverUrl})` }} /> : <>
        <div className="bl-ambient-blob bl-ambient-blob--1" style={{ backgroundColor: `hsl(${h1},85%,55%)` }} />
        <div className="bl-ambient-blob bl-ambient-blob--2" style={{ backgroundColor: `hsl(${h2},80%,50%)` }} />
        <div className="bl-ambient-blob bl-ambient-blob--3" style={{ backgroundColor: `hsl(${h3},85%,60%)` }} />
      </>}
      <div style={{ position: "absolute", inset: 0, background: "radial-gradient(ellipse at center, rgba(0,0,0,0.1) 0%, rgba(0,0,0,0.45) 70%, rgba(0,0,0,0.75) 100%)" }} />
    </div>
  );
}
