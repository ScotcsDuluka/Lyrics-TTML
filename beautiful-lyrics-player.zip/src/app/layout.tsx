import type { Metadata } from "next";
import { Noto_Sans_Thai, Inter } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const notoSansThai = Noto_Sans_Thai({ variable: "--font-noto-thai", subsets: ["thai", "latin"], weight: ["400","500","600","700"], display: "swap" });
const inter = Inter({ variable: "--font-inter", subsets: ["latin"], display: "swap" });

export const metadata: Metadata = { title: "Beautiful Lyrics Player", description: "เครื่องเล่นเพลงพร้อมเนื้อเพลงแบบ karaoke sync สไตล์ spicy-lyrics", icons: { icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg" } };

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="th" suppressHydrationWarning><body className={`${notoSansThai.variable} ${inter.variable} antialiased bg-background text-foreground`}>{children}<Toaster /></body></html>;
}
