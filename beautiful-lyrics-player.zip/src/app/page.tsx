"use client";
import { useCallback, useEffect, useMemo, useState } from "react";
import { useAudioPlayer } from "@/hooks/use-audio-player";
import { RealSpicyLyricsView, registerAudioElement, registerLyricsSeek } from "@/components/real-spicy-lyrics-view";
import { PlayerBar } from "@/components/player-bar";
import { PlaylistSidebar, type Track } from "@/components/playlist-sidebar";
import { AmbientBackground } from "@/components/ambient-background";
import { ListMusic, X, Maximize2, Minimize2, Heart, Play, Pause, SkipBack, SkipForward, Volume2, VolumeX } from "lucide-react";

export default function Home() {
  const [tracks, setTracks] = useState<Track[]>([]);
  const [currentTrack, setCurrentTrack] = useState<Track | null>(null);
  const [showPlaylist, setShowPlaylist] = useState(false);
  const [tracksLoaded, setTracksLoaded] = useState(false);
  const [fullscreen, setFullscreen] = useState(true);
  const [likedTracks, setLikedTracks] = useState<Set<string>>(new Set());

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const res = await fetch("/songs/manifest.json"); if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const data = await res.json(); if (cancelled) return;
        const list: Track[] = Array.isArray(data?.tracks) ? data.tracks : [];
        setTracks(list); setTracksLoaded(true); if (list.length > 0) setCurrentTrack(list[0]);
      } catch (e) { console.error("Manifest load failed:", e); setTracksLoaded(true); }
    })();
    return () => { cancelled = true; };
  }, []);

  const [audioState, audioControls, audioRef] = useAudioPlayer(currentTrack ? currentTrack.audioUrl : null);

  useEffect(() => { registerAudioElement(audioRef.current); }, []);
  useEffect(() => { registerLyricsSeek(audioControls.seek); }, [audioControls.seek]);

  // Keyboard: Space = play/pause (prevent default scroll), arrows = seek
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement;
      if (t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA")) return;
      if (e.code === "Space") { e.preventDefault(); audioControls.toggle(); }
      else if (e.code === "ArrowRight") { e.preventDefault(); audioControls.seek(audioState.currentTime + 5); }
      else if (e.code === "ArrowLeft") { e.preventDefault(); audioControls.seek(audioState.currentTime - 5); }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [audioControls, audioState.currentTime]);

  useEffect(() => {
    if (!currentTrack || tracks.length === 0) return;
    if (audioState.duration > 0 && audioState.currentTime >= audioState.duration - 0.1 && !audioState.isPlaying) {
      const idx = tracks.findIndex(t => t.id === currentTrack.id);
      if (idx >= 0 && idx < tracks.length - 1) setCurrentTrack(tracks[idx + 1]);
    }
  }, [audioState.currentTime, audioState.duration, audioState.isPlaying, currentTrack, tracks]);

  const handleSelectTrack = useCallback((track: Track) => { setCurrentTrack(track); setShowPlaylist(false); setTimeout(() => audioControls.play(), 80); }, [audioControls]);
  const handlePrev = useCallback(() => { if (!currentTrack || !tracks.length) return; const i = tracks.findIndex(t => t.id === currentTrack.id); if (i > 0) { setCurrentTrack(tracks[i-1]); setTimeout(() => audioControls.play(), 80); } else audioControls.seek(0); }, [currentTrack, tracks, audioControls]);
  const handleNext = useCallback(() => { if (!currentTrack || !tracks.length) return; const i = tracks.findIndex(t => t.id === currentTrack.id); if (i >= 0 && i < tracks.length - 1) { setCurrentTrack(tracks[i+1]); setTimeout(() => audioControls.play(), 80); } }, [currentTrack, tracks, audioControls]);
  const toggleLike = useCallback(() => { if (!currentTrack) return; setLikedTracks(p => { const n = new Set(p); n.has(currentTrack.id) ? n.delete(currentTrack.id) : n.add(currentTrack.id); return n; }); }, [currentTrack]);

  const artists = currentTrack?.artists ?? [];
  const isLiked = currentTrack ? likedTracks.has(currentTrack.id) : false;
  const coverHue = useMemo(() => { const s = currentTrack?.id ?? ""; if (!s) return 280; let h = 0; for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0; return h % 360; }, [currentTrack?.id]);
  const lyricsUrl = currentTrack?.lyricsUrl ?? null;

  // === Fullscreen layout ports beautiful-lyrics Page/style.scss ===
  // PlayPanel: width = min(30cqw, 50cqh) * 1.1, positioned left of center
  // MediaSpace: 100cqw × 100cqw (square, fills PlayPanel width)
  // TrackDetails: below MediaSpace
  // Timeline: below TrackDetails
  // Controls: OVERLAY on MediaSpace (hover to show, auto-hide 750ms)

  return (
    <div className="bl-app">
      <audio ref={audioRef} preload="auto" />
      <AmbientBackground seed={currentTrack?.id ?? null} coverUrl={currentTrack?.coverUrl} />

      {/* Top-right toggle */}
      <button onClick={() => setFullscreen(f => !f)} className="bl-fullscreen-toggle hidden items-center justify-center rounded-full bg-white/10 p-2 text-white/80 backdrop-blur-md hover:bg-white/20 hover:text-white lg:flex z-50" aria-label="Toggle fullscreen">
        {fullscreen ? <Minimize2 size={16} /> : <Maximize2 size={16} />}
      </button>

      {/* Mobile header */}
      <header className="relative z-30 flex items-center justify-between border-b border-white/10 bg-black/30 px-4 py-3 backdrop-blur-md lg:hidden">
        <button onClick={() => setShowPlaylist(true)} className="flex items-center gap-2 rounded-full bg-white/10 px-3 py-1.5 text-sm text-white"><ListMusic size={16} /><span>Playlist</span><span className="text-xs text-white/60">{tracks.length}</span></button>
        <div className="truncate px-2 text-sm font-semibold text-white">{currentTrack?.title ?? "Beautiful Lyrics"}</div>
        <button onClick={() => setFullscreen(f => !f)} className="rounded-full bg-white/10 p-2 text-white/80">{fullscreen ? <Minimize2 size={16} /> : <Maximize2 size={16} />}</button>
      </header>

      {/* === MAIN CONTENT === */}
      {fullscreen ? (
        // === FULLSCREEN MODE — ports beautiful-lyrics Page/style.scss ===
        // Structure: .BeautifulLyricsPage.Fullscreen > .Content > [.LyricsScrollContainer, .PlayPanel]
        // PlayPanel: absolute, left = calc(50% - panelWidth - panelWidth/4)
        // Contains: .MediaSpace (cover art), .TrackDetails (title+artist), .Timeline (seek)
        // Controls OVERLAY on MediaSpace: .ViewControls (top), .LikeState (center), .PlaybackControls (bottom)
        <div className="relative z-10 flex min-h-0 flex-1 overflow-hidden">
          {/* Mobile: cover strip + lyrics */}
          <div className="flex min-h-0 flex-1 flex-col overflow-hidden lg:hidden">
            <div className="flex shrink-0 items-center gap-3 border-b border-white/10 bg-black/30 px-3 py-2 backdrop-blur-md">
              {currentTrack?.coverUrl ? <img src={currentTrack.coverUrl} alt="" className="h-12 w-12 shrink-0 rounded-md object-cover" draggable={false} /> : <div className="h-12 w-12 shrink-0 rounded-md" style={{ background: `radial-gradient(circle, hsl(${coverHue},85%,60%), hsl(${(coverHue+200)%360},70%,30%))` }} />}
              <div className="min-w-0 flex-1"><div className="truncate text-sm font-semibold text-white">{currentTrack?.title ?? ""}</div><div className="truncate text-xs text-white/60">{artists.join(", ") || ""}</div></div>
              <button onClick={toggleLike} className={`flex h-9 w-9 items-center justify-center rounded-full ${isLiked ? "bg-rose-500/30 text-rose-300" : "bg-white/10 text-white/70"}`}><Heart size={16} fill={isLiked ? "currentColor" : "none"} /></button>
            </div>
            <main className="bl-lyrics-viewport relative min-h-0 flex-1 overflow-hidden">
              {tracksLoaded && lyricsUrl ? <RealSpicyLyricsView lyricsUrl={lyricsUrl} /> : <div className="flex h-full items-center justify-center text-white/50">กำลังโหลด...</div>}
            </main>
          </div>

          {/* Desktop: PlayPanel (left) + Lyrics (right) — like beautiful-lyrics Fullscreen */}
          <div className="hidden min-h-0 flex-1 overflow-hidden lg:flex">
            {/* PlayPanel — positioned left of center, contains cover + metadata + timeline */}
            <div className="flex shrink-0 flex-col items-center justify-center" style={{ width: "calc(min(30vw, 50vh) * 1.1)", paddingTop: "calc(50vh - min(30vw, 50vh) * 0.66)", paddingBottom: "1vh" }}>
              {/* MediaSpace — square cover art */}
              <div className="relative aspect-square w-full" style={{ maxWidth: "calc(min(30vw, 50vh) * 1.1)" }}>
                <div className="absolute inset-0 overflow-hidden rounded-lg shadow-2xl" style={{ borderRadius: "2vh" }}>
                  {currentTrack?.coverUrl ? (
                    <img src={currentTrack.coverUrl} alt="" className="absolute inset-0 h-full w-full object-cover" draggable={false} />
                  ) : (
                    <div className="absolute inset-0" style={{ background: `radial-gradient(circle at 35% 30%, hsl(${coverHue},70%,70%), hsl(${(coverHue+40)%360},65%,55%) 35%, hsl(${(coverHue+200)%360},60%,35%) 80%)` }} />
                  )}
                </div>
                {/* LikeState — heart overlay (center of cover, like beautiful-lyrics) */}
                <button onClick={toggleLike} className={`absolute inset-0 z-10 flex items-center justify-center transition-opacity ${isLiked ? "opacity-100" : "opacity-0 hover:opacity-60"}`}>
                  <div className={`flex h-16 w-16 items-center justify-center rounded-full backdrop-blur-md ${isLiked ? "bg-rose-500/40" : "bg-black/30"}`}>
                    <Heart size={32} fill={isLiked ? "currentColor" : "none"} className={isLiked ? "text-rose-300" : "text-white/70"} />
                  </div>
                </button>
              </div>

              {/* TrackDetails — title + artist below cover */}
              <div className="mt-4 w-full text-center" style={{ maxWidth: "calc(min(30vw, 50vh) * 1.1)" }}>
                <h2 className="truncate text-xl font-bold text-white">{currentTrack?.title ?? ""}</h2>
                <p className="mt-1 truncate text-sm text-white/60">{artists.join(", ") || ""}</p>
              </div>

              {/* Timeline — seek bar below title */}
              <div className="mt-4 flex w-full items-center gap-3" style={{ maxWidth: "calc(min(30vw, 50vh) * 1.1)" }}>
                <span className="w-10 shrink-0 text-right text-[11px] tabular-nums text-white/50">{Math.floor(audioState.currentTime/60)}:{(Math.floor(audioState.currentTime)%60).toString().padStart(2,"0")}</span>
                <input type="range" min={0} max={audioState.duration || 0} step={0.05} value={audioState.currentTime} onChange={e => audioControls.seek(parseFloat(e.target.value))} className="bl-seek-slider flex-1" style={{ "--progress": `${audioState.duration > 0 ? (audioState.currentTime / audioState.duration) * 100 : 0}%` } as React.CSSProperties} aria-label="Seek" />
                <span className="w-10 shrink-0 text-[11px] tabular-nums text-white/50">{Math.floor(audioState.duration/60)}:{(Math.floor(audioState.duration)%60).toString().padStart(2,"0")}</span>
              </div>

              {/* PlaybackControls — play/skip below timeline */}
              <div className="mt-3 flex items-center gap-6">
                <button onClick={handlePrev} className="text-white/70 hover:text-white"><SkipBack size={20} fill="currentColor" /></button>
                <button onClick={audioControls.toggle} className="flex h-10 w-10 items-center justify-center rounded-full bg-white text-black hover:scale-105 active:scale-95">{audioState.isPlaying ? <Pause size={20} fill="currentColor" /> : <Play size={20} fill="currentColor" className="ml-0.5" />}</button>
                <button onClick={handleNext} className="text-white/70 hover:text-white"><SkipForward size={20} fill="currentColor" /></button>
              </div>
            </div>

            {/* Lyrics — right side */}
            <main className="bl-lyrics-viewport relative min-h-0 flex-1 overflow-hidden">
              {tracksLoaded && lyricsUrl ? <RealSpicyLyricsView lyricsUrl={lyricsUrl} /> : <div className="flex h-full items-center justify-center text-white/50">กำลังโหลด...</div>}
            </main>
          </div>

          {/* NO floating fullscreen controls — they block clicks. Controls are in PlayPanel. */}
        </div>
      ) : (
        // === NORMAL MODE — playlist sidebar + lyrics ===
        <div className="relative z-10 flex min-h-0 flex-1 overflow-hidden">
          <div className="hidden w-80 shrink-0 border-r border-white/10 lg:block">
            <PlaylistSidebar tracks={tracks} currentId={currentTrack?.id ?? null} isPlaying={audioState.isPlaying} onSelect={handleSelectTrack} />
          </div>
          <main className="bl-lyrics-viewport relative z-10 min-h-0 min-w-0 flex-1 overflow-hidden">
            {currentTrack && (
              <div className="bl-now-playing-overlay pointer-events-none absolute left-0 right-0 top-0 z-10 px-6 py-4 sm:px-10 sm:py-6">
                <div className="text-xs uppercase tracking-widest text-white/50">Now Playing</div>
                <h1 className="mt-1 truncate text-xl font-bold text-white sm:text-2xl">{currentTrack.title}</h1>
                {artists.length > 0 && <div className="truncate text-sm text-white/70">{artists.join(" • ")}</div>}
              </div>
            )}
            {tracksLoaded && tracks.length > 0 && lyricsUrl ? <RealSpicyLyricsView lyricsUrl={lyricsUrl} /> : <div className="flex h-full items-center justify-center text-white/50">{tracksLoaded ? "ไม่พบเพลง" : "กำลังโหลด..."}</div>}
          </main>
        </div>
      )}

      {/* Mobile playlist drawer */}
      {showPlaylist && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setShowPlaylist(false)} />
          <div className="bl-mobile-drawer absolute left-0 top-0 h-full w-80 max-w-[85vw]"><button onClick={() => setShowPlaylist(false)} className="absolute right-2 top-2 z-10 rounded-full bg-white/10 p-2 text-white/80"><X size={16} /></button><PlaylistSidebar tracks={tracks} currentId={currentTrack?.id ?? null} isPlaying={audioState.isPlaying} onSelect={handleSelectTrack} /></div>
        </div>
      )}

      {/* Player bar — only in non-fullscreen mode */}
      {!fullscreen && (
        <div className="relative z-30"><PlayerBar title={currentTrack?.title ?? ""} artists={artists} currentTime={audioState.currentTime} duration={audioState.duration} isPlaying={audioState.isPlaying} volume={audioState.volume} muted={audioState.muted} onToggle={audioControls.toggle} onSeek={audioControls.seek} onPrev={handlePrev} onNext={handleNext} onVolume={audioControls.setVolume} onToggleMute={audioControls.toggleMute} /></div>
      )}
    </div>
  );
}
