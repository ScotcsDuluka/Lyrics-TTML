/** Client-side TTML parser — produces output matching spicy-lyrics' tools.ts types. */

export interface SpicySyllable { Text: string; IsPartOfWord?: boolean; StartTime?: number; EndTime?: number; }
export interface SpicyLeadVocal { Syllables: SpicySyllable[]; StartTime?: number; EndTime?: number; }
export interface SpicyBackgroundVocal { Syllables: SpicySyllable[]; StartTime?: number; EndTime?: number; }
export interface SpicyVocalContent { Type: "Vocal"; Lead?: SpicyLeadVocal; Background?: SpicyBackgroundVocal[]; }
export interface SpicyLine { StartTime: number; EndTime: number; Content: SpicyVocalContent[]; IsInterlude?: boolean; }
export interface SpicyParsedLyrics { Type: "Syllable"; title: string; artists: string[]; album: string; Content: SpicyLine[]; duration: number; }

const TIME_REGEX = /^(?:(\d{2,}):)?(\d{1,2}):(\d{1,2}(?:\.\d+)?)$/;
export function parseTime(value: string | null | undefined): number | null {
  if (!value) return null;
  const m = value.trim().match(TIME_REGEX);
  if (!m) { const n = parseFloat(value); return isNaN(n) ? null : n; }
  return (m[1] ? parseInt(m[1]) : 0) * 3600 + parseInt(m[2]) * 60 + parseFloat(m[3]);
}
const NS = { tt: "http://www.w3.org/ns/ttml", amll: "http://www.example.com/ns/amll", ttm: "http://www.w3.org/ns/ttml#metadata" };
function getDirectText(el: Element): string { let o = ""; for (const c of Array.from(el.childNodes)) if (c.nodeType === 3) o += c.nodeValue ?? ""; return o; }
function parseMeta(root: Element) { const r = { title: "", artists: [] as string[], album: "" }; const ms = root.getElementsByTagNameNS(NS.amll, "meta"); for (let i = 0; i < ms.length; i++) { const m = ms[i]; const k = m.getAttribute("key"), v = m.getAttribute("value"); if (!k || !v) continue; if (k === "musicName" && !r.title) r.title = v; else if (k === "artists") r.artists.push(v); else if (k === "album" && !r.album) r.album = v; } return r; }

export function parseSpicyTTML(ttml: string): SpicyParsedLyrics {
  const doc = new DOMParser().parseFromString(ttml, "application/xml");
  const root = doc.documentElement;
  const meta = parseMeta(root);
  const body = root.getElementsByTagNameNS(NS.tt, "body")[0];
  let bodyDur = 0; if (body) { const d = parseTime(body.getAttribute("dur")); if (d) bodyDur = d; }
  const div = root.getElementsByTagNameNS(NS.tt, "div")[0];
  const lines: SpicyLine[] = [];
  if (div) {
    for (const p of Array.from(div.getElementsByTagNameNS(NS.tt, "p"))) {
      const pBegin = parseTime(p.getAttribute("begin")) ?? 0;
      const pEnd = parseTime(p.getAttribute("end")) ?? pBegin;
      const isBg = p.getAttribute("agent") === "v2";
      const syllables: SpicySyllable[] = [];
      for (const span of Array.from(p.getElementsByTagNameNS(NS.tt, "span"))) {
        const text = getDirectText(span); if (!text) continue;
        syllables.push({ Text: text, IsPartOfWord: false, StartTime: parseTime(span.getAttribute("begin")) ?? pBegin, EndTime: parseTime(span.getAttribute("end")) ?? pEnd });
      }
      syllables.sort((a, b) => (a.StartTime ?? 0) - (b.StartTime ?? 0));
      const ls = syllables.length ? syllables[0].StartTime! : pBegin;
      const le = syllables.length ? syllables[syllables.length - 1].EndTime! : pEnd;
      lines.push({ StartTime: ls, EndTime: le, Content: [{ Type: "Vocal", Lead: isBg ? undefined : { Syllables: syllables, StartTime: ls, EndTime: le }, Background: isBg ? [{ Syllables: syllables, StartTime: ls, EndTime: le }] : undefined }], IsInterlude: syllables.length === 0 });
    }
  }
  lines.sort((a, b) => a.StartTime - b.StartTime);
  const withInterludes: SpicyLine[] = [];
  const THRESHOLD = 3;
  for (let i = 0; i < lines.length; i++) {
    if (i > 0 && lines[i].StartTime - lines[i-1].EndTime >= THRESHOLD) withInterludes.push({ StartTime: lines[i-1].EndTime, EndTime: lines[i].StartTime, Content: [], IsInterlude: true });
    withInterludes.push(lines[i]);
  }
  if (withInterludes.length > 0 && withInterludes[0].StartTime >= THRESHOLD) withInterludes.unshift({ StartTime: 0, EndTime: withInterludes[0].StartTime, Content: [], IsInterlude: true });
  const lastEnd = withInterludes.length ? withInterludes[withInterludes.length - 1].EndTime : 0;
  return { Type: "Syllable", title: meta.title, artists: meta.artists, album: meta.album, Content: withInterludes, duration: Math.max(bodyDur, lastEnd) };
}
