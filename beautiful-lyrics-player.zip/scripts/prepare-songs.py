import json, re, shutil, xml.etree.ElementTree as ET
from pathlib import Path

REPO = Path("/home/z/my-project/repos/Lyrics-TTML")
OUT = Path("/home/z/my-project/public/songs")
OUT.mkdir(parents=True, exist_ok=True)

def normalize(s):
    s = s.strip()
    s = re.split(r"\s+-\s+", s, maxsplit=1)[0]
    for suffix in ["-Full-ReMake", "-Full", "-ReMake", " (1)", "-Full "]:
        s = s.replace(suffix, "")
    s = s.strip()
    s = re.sub(r"\([^)]*\)", "", s)
    s = re.sub(r"[^\w\u4e00-\u9fff\u3040-\u309f\u30a0-\u30ff\uac00-\ud7af\u0E00-\u0E7F\u0E80-\u0EFF]", "", s, flags=re.UNICODE)
    return s.lower()

def parse_ttml_meta(ttml_path):
    try:
        ET.register_namespace("amll", "http://www.example.com/ns/amll")
        tree = ET.parse(ttml_path)
        root = tree.getroot()
        meta = {"musicName": "", "artists": [], "album": ""}
        for elem in root.iter():
            tag = elem.tag
            if tag.endswith("}meta") or tag == "meta":
                key = elem.get("key"); value = elem.get("value")
                if not key or not value: continue
                if key == "musicName" and not meta["musicName"]: meta["musicName"] = value
                elif key == "artists": meta["artists"].append(value)
                elif key == "album" and not meta["album"]: meta["album"] = value
        if not meta["musicName"]: meta["musicName"] = ttml_path.stem
        return meta
    except: return {"musicName": ttml_path.stem, "artists": [], "album": ""}

ttml_files = sorted([p for p in REPO.glob("*.ttml")] + [p for p in (REPO / "Other").glob("*.ttml")])
mp3_files = sorted((REPO / "Playlists").glob("*.mp3"))
mp3_map = {}
for mp3 in mp3_files: mp3_map.setdefault(normalize(mp3.stem), mp3)

manifest = []
used = set()
for idx, ttml in enumerate(ttml_files, start=1):
    slug = f"track-{idx:03d}"
    meta = parse_ttml_meta(ttml)
    norm_stem = normalize(ttml.stem); norm_title = normalize(meta["musicName"])
    mp3 = mp3_map.get(norm_stem) or mp3_map.get(norm_title)
    if mp3 is None:
        for k, v in mp3_map.items():
            if v in used: continue
            if k.startswith(norm_stem) or norm_stem.startswith(k): mp3 = v; break
    if mp3 is None:
        for k, v in mp3_map.items():
            if v in used: continue
            if k.startswith(norm_title) or norm_title.startswith(k): mp3 = v; break
    if mp3 is None: print(f"  - No MP3 for {ttml.name}"); continue
    used.add(mp3)
    shutil.copy2(mp3, OUT / f"{slug}.mp3")
    shutil.copy2(ttml, OUT / f"{slug}.ttml")
    mp3_artist = mp3.stem.split(" - ", 1)[1].strip() if " - " in mp3.stem else ""
    display_title = meta["musicName"]
    norm_display = normalize(display_title)
    if norm_display != norm_stem and norm_stem not in norm_display and norm_display not in norm_stem:
        cleaned = re.sub(r"\s*\([^)]*\)", "", mp3.stem.split(" - ",1)[0]).strip()
        display_title = cleaned or mp3.stem.split(" - ",1)[0]
    for suffix in ["-Full-ReMake", "-Full", "-ReMake"]:
        if display_title.endswith(suffix): display_title = display_title[:-len(suffix)].strip(); break
    if len(display_title) > 60: display_title = re.sub(r"\s*\([^)]*\)", "", mp3.stem.split(" - ",1)[0]).strip()
    artists = meta["artists"] if meta["artists"] else ([mp3_artist] if mp3_artist else [])
    manifest.append({"id": slug, "title": display_title, "artists": artists, "album": meta["album"],
        "audioUrl": f"/songs/{slug}.mp3", "lyricsUrl": f"/songs/{slug}.ttml", "coverUrl": f"/songs/covers/{slug}.jpg",
        "sourceTtml": ttml.name, "sourceMp3": mp3.name})
    print(f"  + [{idx:02d}] {display_title} - {', '.join(artists) or '?'}")

with open(OUT / "manifest.json", "w", encoding="utf-8") as f:
    json.dump({"tracks": manifest}, f, ensure_ascii=False, indent=2)
print(f"\nWrote manifest with {len(manifest)} tracks")
