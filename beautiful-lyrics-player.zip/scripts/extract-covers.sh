#!/bin/bash
set -e
SONGS_DIR="/home/z/my-project/public/songs"
COVERS_DIR="${SONGS_DIR}/covers"
mkdir -p "${COVERS_DIR}"
for mp3 in "${SONGS_DIR}"/*.mp3; do
    [ -e "$mp3" ] || continue
    base=$(basename "$mp3" .mp3)
    out="${COVERS_DIR}/${base}.jpg"
    [ -f "$out" ] && continue
    ffmpeg -i "$mp3" -an -vcodec copy -f image2 "$out" 2>/dev/null && [ -s "$out" ] && echo "  + ${base}" || { rm -f "$out"; echo "  - ${base}"; }
done
echo "Done"
