import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { searchTracks, formatTrack } from "@/lib/track-queries";

/** GET /api/search?q=xxx — search tracks, playlists */
export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const q = (searchParams.get("q") || "").trim();
    if (!q) return NextResponse.json({ tracks: [], playlists: [] });

    const rawTracks = await searchTracks(q);

    const likes = await prisma.like.findMany();
    const likedTrackIds = new Set(likes.map(l => l.trackId));

    const playlists = await prisma.playlist.findMany({
      where: {
        OR: [
          { name: { contains: q } },
          { description: { contains: q } },
        ],
      },
      take: 20,
      include: { tracks: { select: { trackId: true } } },
    });

    return NextResponse.json({
      tracks: rawTracks.map(t => formatTrack(t, likedTrackIds)),
      playlists: playlists.map(p => ({
        id: p.id,
        name: p.name,
        description: p.description,
        coverUrl: p.coverUrl,
        isSystem: p.isSystem,
        trackCount: p.tracks.length,
      })),
    });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
