import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { fetchAllTracks, formatTrack } from "@/lib/track-queries";

/** GET /api/artists — list all unique artists with their tracks */
export async function GET(req: NextRequest) {
  try {
    const url = new URL(req.url);
    const name = url.searchParams.get("name");

    const rawTracks = await fetchAllTracks();

    const likes = await prisma.like.findMany();
    const likedTrackIds = new Set(likes.map(l => l.trackId));

    // Group tracks by artist
    const artistMap = new Map<string, {
      name: string;
      tracks: any[];
      coverUrl: string | null;
    }>();

    for (const t of rawTracks) {
      const trackData = formatTrack(t, likedTrackIds);
      const artists: string[] = trackData.artists;

      for (const artist of artists) {
        if (!artistMap.has(artist)) {
          artistMap.set(artist, {
            name: artist,
            tracks: [],
            coverUrl: t.coverUrl,
          });
        }
        artistMap.get(artist)!.tracks.push(trackData);
      }
    }

    // If name is provided, return only that artist
    if (name) {
      const artist = artistMap.get(name);
      if (!artist) {
        return NextResponse.json({ error: "Artist not found" }, { status: 404 });
      }
      return NextResponse.json({ artist });
    }

    // Return all artists
    const artists = Array.from(artistMap.values()).map(a => ({
      name: a.name,
      trackCount: a.tracks.length,
      coverUrl: a.coverUrl,
    }));

    return NextResponse.json({ artists });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
