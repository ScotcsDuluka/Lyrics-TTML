import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";

interface Params { params: Promise<{ id: string }> }

/** PUT /api/playlists/[id]/reorder — reorder tracks in a playlist
 * Body: { trackIds: string[] } — the new order of track IDs
 */
export async function PUT(req: NextRequest, { params }: Params) {
  try {
    const { id } = await params;
    const body = await req.json();
    const trackIds: string[] = body.trackIds;
    if (!Array.isArray(trackIds) || trackIds.length === 0) {
      return NextResponse.json({ error: "missing trackIds array" }, { status: 400 });
    }

    // Don't allow reordering system playlists (Liked Songs)
    const playlist = await prisma.playlist.findUnique({ where: { id } });
    if (playlist?.isSystem) {
      return NextResponse.json({ error: "Cannot reorder system playlists" }, { status: 400 });
    }

    // Update positions in parallel
    await Promise.all(trackIds.map((trackId, i) =>
      prisma.playlistTrack.updateMany({
        where: { playlistId: id, trackId },
        data: { position: i },
      })
    ));

    return NextResponse.json({ ok: true, count: trackIds.length });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
