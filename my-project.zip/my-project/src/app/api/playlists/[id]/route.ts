import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { fetchTracksByIds, formatTrack } from "@/lib/track-queries";

interface Params { params: Promise<{ id: string }> }

/** GET /api/playlists/[id] — get playlist with full track list (ordered) */
export async function GET(req: NextRequest, { params }: Params) {
  try {
    const { id } = await params;
    const playlist = await prisma.playlist.findUnique({
      where: { id },
      include: {
        tracks: {
          orderBy: { position: "asc" },
        },
      },
    });
    if (!playlist) return NextResponse.json({ error: "not found" }, { status: 404 });

    // Get track IDs from playlist in order
    const trackIds = playlist.tracks.map(pt => pt.trackId);

    const tracks = await fetchTracksByIds(trackIds);
    const trackMap = new Map(tracks.map(t => [t.id, t]));
    const likes = await prisma.like.findMany();
    const likedTrackIds = new Set(likes.map(l => l.trackId));

    return NextResponse.json({
      playlist: {
        id: playlist.id,
        name: playlist.name,
        description: playlist.description,
        coverUrl: playlist.coverUrl,
        isSystem: playlist.isSystem,
        trackCount: playlist.tracks.length,
        tracks: playlist.tracks.map(pt => {
          const t = trackMap.get(pt.trackId);
          if (!t) return null;
          return {
            ...formatTrack(t, likedTrackIds),
            addedAt: pt.addedAt,
          };
        }).filter(Boolean),
      },
    });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}

/** PUT /api/playlists/[id] — update playlist (name, description, cover) */
export async function PUT(req: NextRequest, { params }: Params) {
  try {
    const { id } = await params;
    const body = await req.json();
    const playlist = await prisma.playlist.update({
      where: { id },
      data: {
        ...(body.name !== undefined && { name: body.name }),
        ...(body.description !== undefined && { description: body.description }),
        ...(body.coverUrl !== undefined && { coverUrl: body.coverUrl }),
      },
    });
    return NextResponse.json({ playlist });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}

/** DELETE /api/playlists/[id] — delete playlist (only non-system) */
export async function DELETE(req: NextRequest, { params }: Params) {
  try {
    const { id } = await params;
    const playlist = await prisma.playlist.findUnique({ where: { id } });
    if (!playlist) return NextResponse.json({ error: "not found" }, { status: 404 });
    if (playlist.isSystem) return NextResponse.json({ error: "cannot delete system playlist" }, { status: 400 });
    await prisma.playlist.delete({ where: { id } });
    return NextResponse.json({ ok: true });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
