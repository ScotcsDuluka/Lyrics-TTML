import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { fetchTracksByIds, formatTrack } from "@/lib/track-queries";

/** GET /api/history — get recently played (latest 50) */
export async function GET() {
  try {
    const history = await prisma.playHistory.findMany({
      orderBy: { playedAt: "desc" },
      take: 50,
    });

    const trackIds = history.map(h => h.trackId);
    const uniqueIds = [...new Set(trackIds)];

    const tracks = await fetchTracksByIds(uniqueIds);
    const trackMap = new Map(tracks.map(t => [t.id, t]));
    const likes = await prisma.like.findMany();
    const likedTrackIds = new Set(likes.map(l => l.trackId));

    return NextResponse.json({
      history: history.map(h => {
        const t = trackMap.get(h.trackId);
        if (!t) return null;
        return {
          id: h.id,
          playedAt: h.playedAt,
          track: formatTrack(t, likedTrackIds),
        };
      }).filter(Boolean),
    });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}

/** POST /api/history — record a play */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const trackId = body.trackId;
    if (!trackId) return NextResponse.json({ error: "missing trackId" }, { status: 400 });

    const entry = await prisma.playHistory.create({
      data: { trackId },
    });
    return NextResponse.json({ ok: true, entry });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
