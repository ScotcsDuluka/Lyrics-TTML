import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { fetchTracksByIds, formatTrack } from "@/lib/track-queries";

/** GET /api/likes — list all liked tracks */
export async function GET() {
  try {
    const likes = await prisma.like.findMany({
      orderBy: { createdAt: "desc" },
      select: { trackId: true },
    });
    const likedTrackIds = likes.map(l => l.trackId);

    const tracks = await fetchTracksByIds(likedTrackIds);

    // Preserve the order from likes (descending by createdAt)
    const trackMap = new Map(tracks.map(t => [t.id, t]));
    const likedSet = new Set(likedTrackIds);

    return NextResponse.json({
      tracks: likedTrackIds.map(id => {
        const t = trackMap.get(id);
        if (!t) return null;
        return formatTrack(t, likedSet);
      }).filter(Boolean),
    });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}

/** POST /api/likes — like a track */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const trackId = body.trackId;
    if (!trackId) return NextResponse.json({ error: "missing trackId" }, { status: 400 });

    const like = await prisma.like.upsert({
      where: { trackId },
      update: {},
      create: { trackId },
    });

    // Also add to Liked Songs system playlist
    const likedPlaylist = await prisma.playlist.findFirst({
      where: { isSystem: true, name: "Liked Songs" },
    });
    if (likedPlaylist) {
      const existing = await prisma.playlistTrack.findMany({
        where: { playlistId: likedPlaylist.id },
        orderBy: { position: "desc" },
        take: 1,
      });
      const nextPos = (existing[0]?.position ?? -1) + 1;
      await prisma.playlistTrack.upsert({
        where: { playlistId_trackId: { playlistId: likedPlaylist.id, trackId } },
        update: {},
        create: { playlistId: likedPlaylist.id, trackId, position: nextPos },
      });
    }

    return NextResponse.json({ ok: true, like });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}

/** DELETE /api/likes?trackId=xxx — unlike a track */
export async function DELETE(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const trackId = searchParams.get("trackId");
    if (!trackId) return NextResponse.json({ error: "missing trackId" }, { status: 400 });

    await prisma.like.deleteMany({ where: { trackId } });

    // Remove from Liked Songs playlist too
    const likedPlaylist = await prisma.playlist.findFirst({
      where: { isSystem: true, name: "Liked Songs" },
    });
    if (likedPlaylist) {
      await prisma.playlistTrack.deleteMany({
        where: { playlistId: likedPlaylist.id, trackId },
      });
    }

    return NextResponse.json({ ok: true });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
