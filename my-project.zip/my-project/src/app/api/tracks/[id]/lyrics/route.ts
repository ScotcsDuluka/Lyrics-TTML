import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { writeFile, mkdir } from "fs/promises";
import path from "path";

/** GET /api/tracks/[id]/lyrics — get lyrics text */
export async function GET(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  try {
    const track = await prisma.track.findUnique({ where: { id } });
    if (!track) return NextResponse.json({ error: "Track not found" }, { status: 404 });
    if (!track.lyricsUrl) return NextResponse.json({ lyrics: null });

    // If lyrics URL is a relative path, read from local file system
    let lyrics: string | null = null;
    if (track.lyricsUrl.startsWith("/")) {
      try {
        const fs = await import("fs/promises");
        const filePath = path.join(process.cwd(), "public", track.lyricsUrl.replace(/^\//, ""));
        lyrics = await fs.readFile(filePath, "utf-8");
      } catch {
        lyrics = null;
      }
    } else {
      const res = await fetch(track.lyricsUrl);
      if (res.ok) lyrics = await res.text();
    }
    return NextResponse.json({ lyrics });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}

/** POST /api/tracks/[id]/lyrics — create or update lyrics */
export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  try {
    const body = await req.json();
    const lyrics = String(body.lyrics ?? "");
    if (!lyrics.trim()) {
      return NextResponse.json({ error: "Lyrics cannot be empty" }, { status: 400 });
    }

    const track = await prisma.track.findUnique({ where: { id } });
    if (!track) return NextResponse.json({ error: "Track not found" }, { status: 404 });

    // Ensure lyrics directory exists
    const lyricsDir = path.join(process.cwd(), "public", "lyrics");
    await mkdir(lyricsDir, { recursive: true });

    // Write lyrics file
    const fileName = `lyrics-${id}.txt`;
    const filePath = path.join(lyricsDir, fileName);
    await writeFile(filePath, lyrics, "utf-8");

    const lyricsUrl = `/lyrics/${fileName}`;
    await prisma.track.update({
      where: { id },
      data: { lyricsUrl },
    });

    return NextResponse.json({ ok: true, lyricsUrl });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}

/** DELETE /api/tracks/[id]/lyrics — remove lyrics */
export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  try {
    const track = await prisma.track.findUnique({ where: { id } });
    if (!track) return NextResponse.json({ error: "Track not found" }, { status: 404 });

    // Try to delete the file
    if (track.lyricsUrl?.startsWith("/")) {
      try {
        const fs = await import("fs/promises");
        const filePath = path.join(process.cwd(), "public", track.lyricsUrl.replace(/^\//, ""));
        await fs.unlink(filePath);
      } catch {
        // File may not exist - ignore
      }
    }

    await prisma.track.update({
      where: { id },
      data: { lyricsUrl: null },
    });

    return NextResponse.json({ ok: true });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
