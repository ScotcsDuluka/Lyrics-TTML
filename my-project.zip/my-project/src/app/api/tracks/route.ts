import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { fetchAllTracks, formatTrack } from "@/lib/track-queries";

/** GET /api/tracks — list all tracks (with liked status + genre) */
export async function GET() {
  try {
    const rawTracks = await fetchAllTracks();

    // Get likes separately
    const likes = await prisma.like.findMany();
    const likedTrackIds = new Set(likes.map(l => l.trackId));

    return NextResponse.json({
      tracks: rawTracks.map(t => formatTrack(t, likedTrackIds)),
    });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
