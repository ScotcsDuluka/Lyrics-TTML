"use client";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useAudioPlayer } from "@/hooks/use-audio-player";
import { useAudioAnalyzer } from "@/hooks/use-audio-analyzer";
import { useChatPoll } from "@/hooks/use-chat-poll";
import { useAppStore } from "@/lib/store";
import { Sidebar } from "@/components/sidebar";
import { TopBar } from "@/components/top-bar";
import { HomeView } from "@/components/home-view";
import { PlaylistView } from "@/components/playlist-view";
import { TrackTable } from "@/components/track-table";
import { QueuePanel } from "@/components/queue-panel";
import { PlayerBar } from "@/components/player-bar";
import { CommandOverlay } from "@/components/command-overlay";
import { LyricsView } from "@/components/lyrics-view";
import { NowPlayingView } from "@/components/now-playing-view";
import { HistoryView } from "@/components/history-view";
import { ArtistView } from "@/components/artist-view";
import { AlbumView } from "@/components/album-view";
import { TrackUpload } from "@/components/track-upload";
import { SleepTimer } from "@/components/sleep-timer";
import { SettingsPanel } from "@/components/settings-panel";
import { ShareModal } from "@/components/share-modal";
import { LyricsEditor } from "@/components/lyrics-editor";
import { MiniPlayer } from "@/components/mini-player";
import { KaraokeMode } from "@/components/karaoke-mode";
import { ShortcutsHelp } from "@/components/shortcuts-help";
import { TrackContextMenu } from "@/components/track-context-menu";
import { FriendActivity } from "@/components/friend-activity";
import { ListeningStatsView } from "@/components/listening-stats-view";
import { DiscoverWeekly } from "@/components/discover-weekly-view";
import { RadioStationView } from "@/components/radio-station-view";
import { MusicPersonalityView } from "@/components/music-personality-view";
import { PodcastsView } from "@/components/podcasts-view";
import { EqualizerView } from "@/components/equalizer-view";
import { YearlyRecapView } from "@/components/yearly-recap-view";
import { EQ_PRESETS, getPresetById } from "@/lib/eq-presets";
const EQ_FREQS_LOOKUP = [60, 170, 310, 600, 1000, 3000, 6000, 12000, 14000, 16000];
import { X, Home as HomeIcon, Search as SearchIcon, Heart as HeartIcon, Clock as ClockIcon, Menu, Keyboard, Radio as RadioIcon, User as UserIcon, Music2, Sparkles, Disc3, Tag } from "lucide-react";
import { toast } from "sonner";
import type { Track, Playlist, PlayHistoryEntry } from "@/lib/types";

export default function Home() {
  // Store
  const view = useAppStore(s => s.view);
  const setView = useAppStore(s => s.setView);
  const searchQuery = useAppStore(s => s.searchQuery);
  const setSearchQuery = useAppStore(s => s.setSearchQuery);
  const volume = useAppStore(s => s.volume);
  const muted = useAppStore(s => s.muted);
  const setVolume = useAppStore(s => s.setVolume);
  const setMuted = useAppStore(s => s.setMuted);
  const shuffle = useAppStore(s => s.shuffle);
  const setShuffle = useAppStore(s => s.setShuffle);
  const repeat = useAppStore(s => s.repeat);
  const setRepeat = useAppStore(s => s.setRepeat);
  const currentTrackId = useAppStore(s => s.currentTrackId);
  const isPlaying = useAppStore(s => s.isPlaying);
  const queue = useAppStore(s => s.queue);
  const queueIndex = useAppStore(s => s.queueIndex);
  const history = useAppStore(s => s.history);
  const showQueue = useAppStore(s => s.showQueue);
  const setShowQueue = useAppStore(s => s.setShowQueue);
  const showNowPlaying = useAppStore(s => s.showNowPlaying);
  const setShowNowPlaying = useAppStore(s => s.setShowNowPlaying);
  const showMobileSidebar = useAppStore(s => s.showMobileSidebar);
  const setShowMobileSidebar = useAppStore(s => s.setShowMobileSidebar);
  const showMiniPlayer = useAppStore(s => s.showMiniPlayer);
  const setShowMiniPlayer = useAppStore(s => s.setShowMiniPlayer);
  const showSleepTimer = useAppStore(s => s.showSleepTimer);
  const setShowSleepTimer = useAppStore(s => s.setShowSleepTimer);
  const setShowShareModal = useAppStore(s => s.setShowShareModal);
  const setSharePayload = useAppStore(s => s.setSharePayload);
  const setShowShortcutsHelp = useAppStore(s => s.setShowShortcutsHelp);
  const playbackRate = useAppStore(s => s.playbackRate);
  const setPlaybackRate = useAppStore(s => s.setPlaybackRate);
  const crossfadeDuration = useAppStore(s => s.crossfadeDuration);
  const setCrossfadeDuration = useAppStore(s => s.setCrossfadeDuration);
  const eqPreset = useAppStore(s => s.eqPreset);
  const setEqPreset = useAppStore(s => s.setEqPreset);
  const normalizeVolume = useAppStore(s => s.normalizeVolume);
  const setNormalizeVolume = useAppStore(s => s.setNormalizeVolume);
  const showFriendActivity = useAppStore(s => s.showFriendActivity);
  const setShowFriendActivity = useAppStore(s => s.setShowFriendActivity);
  const [lyricsEditorOpen, setLyricsEditorOpen] = useState(false);
  const [discoverRefreshKey, setDiscoverRefreshKey] = useState(0);
  const [karaokeMode, setKaraokeMode] = useState(false);
  const [pollActive, setPollActive] = useState(false);

  // Local state
  const [allTracks, setAllTracks] = useState<Track[]>([]);
  const [playlists, setPlaylists] = useState<Playlist[]>([]);
  const [currentPlaylist, setCurrentPlaylist] = useState<Playlist | null>(null);
  const [playlistTracks, setPlaylistTracks] = useState<Track[]>([]);
  const [searchResults, setSearchResults] = useState<{ tracks: Track[]; playlists: Playlist[] }>({ tracks: [], playlists: [] });
  const [showLyrics, setShowLyrics] = useState(true);
  const [historyEntries, setHistoryEntries] = useState<PlayHistoryEntry[]>([]);
  const [artistTracks, setArtistTracks] = useState<Track[]>([]);
  const [albumTracks, setAlbumTracks] = useState<Track[]>([]);

  // Current track resolution
  const currentTrack = useMemo(() => allTracks.find(t => t.id === currentTrackId) || null, [allTracks, currentTrackId]);
  const nextTrack = useMemo(() => {
    const nextIdx = queueIndex + 1;
    if (nextIdx < queue.length) return allTracks.find(t => t.id === queue[nextIdx]) || null;
    return null;
  }, [allTracks, queue, queueIndex]);
  const queueTracks = useMemo(() => queue.map(id => allTracks.find(t => t.id === id)).filter(Boolean) as Track[], [queue, allTracks]);

  // Audio
  const [audioState, audioControls, audioRef] = useAudioPlayer(currentTrack?.audioUrl ?? null, volume, muted, playbackRate);

  // Audio analyzer for visualization
  const audioCtxRef = useRef<AudioContext | null>(null);
  const sourceNodeRef = useRef<MediaElementAudioSourceNode | null>(null);
  const [analyzerState, analyzerControls] = useAudioAnalyzer(audioRef, audioCtxRef, sourceNodeRef, 256);

  // Start/stop analyzer when playing state changes
  useEffect(() => {
    if (audioState.isPlaying) {
      analyzerControls.start();
    }
  }, [audioState.isPlaying, analyzerControls]);

  // Sync volume from store
  useEffect(() => {
    audioControls.setVolume(volume);
  }, [volume]);

  // Sync playing state to store
  useEffect(() => {
    useAppStore.getState().setCurrentTrack(currentTrackId);
    useAppStore.getState().setIsPlaying(audioState.isPlaying);
    useAppStore.getState().setCurrentTime(audioState.currentTime);
    useAppStore.getState().setDuration(audioState.duration);
  }, [currentTrackId, audioState.isPlaying, audioState.currentTime, audioState.duration]);

  // Load all tracks + playlists
  const loadAllTracks = useCallback(async () => {
    try {
      const res = await fetch("/api/tracks");
      const data = await res.json();
      setAllTracks(data.tracks || []);
    } catch (e) { console.error(e); }
  }, []);

  const loadPlaylists = useCallback(async () => {
    try {
      const res = await fetch("/api/playlists");
      const data = await res.json();
      setPlaylists(data.playlists || []);
    } catch (e) { console.error(e); }
  }, []);

  const loadPlaylistDetail = useCallback(async (id: string) => {
    try {
      const res = await fetch(`/api/playlists/${id}`);
      const data = await res.json();
      setCurrentPlaylist(data.playlist);
      setPlaylistTracks(data.playlist?.tracks || []);
    } catch (e) { console.error(e); }
  }, []);

  // Initial data load
  useEffect(() => {
    let cancelled = false;
    (async () => {
      await Promise.all([loadAllTracks(), loadPlaylists()]);
    })();
    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // (Share URL handling moved below — needs playTrackFromList)

  // When view changes
  useEffect(() => {
    let cancelled = false;
    (async () => {
      if (view.type === "playlist") {
        await loadPlaylistDetail(view.id);
      } else if (view.type === "liked") {
        try {
          const res = await fetch("/api/likes");
          const data = await res.json();
          if (!cancelled) {
            setCurrentPlaylist({
              id: "liked",
              name: "Liked Songs",
              description: "Your liked songs",
              coverUrl: null,
              isSystem: true,
              trackCount: data.tracks.length,
            });
            setPlaylistTracks(data.tracks);
          }
        } catch (e) { console.error(e); }
      } else if (view.type === "artist") {
        try {
          const res = await fetch(`/api/artists?name=${encodeURIComponent(view.name)}`);
          const data = await res.json();
          if (!cancelled && data.artist) {
            setArtistTracks(data.artist.tracks);
          }
        } catch (e) { console.error(e); }
      } else if (view.type === "album") {
        // Filter tracks by album name from already-loaded allTracks
        setAlbumTracks(allTracks.filter(t => t.album === view.name));
      }
    })();
    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [view, allTracks]);

  // Search
  useEffect(() => {
    if (view.type !== "search" || !searchQuery.trim()) {
      setSearchResults({ tracks: [], playlists: [] });
      return;
    }
    const id = setTimeout(async () => {
      try {
        const res = await fetch(`/api/search?q=${encodeURIComponent(searchQuery)}`);
        const data = await res.json();
        setSearchResults({ tracks: data.tracks || [], playlists: data.playlists || [] });
      } catch (e) { console.error(e); }
    }, 250);
    return () => clearTimeout(id);
  }, [view, searchQuery]);

  // Auto-advance on track end (with optional crossfade)
  const crossfadeRef = useRef<boolean>(false);
  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;
    const onEnded = () => {
      // Dispatch global event so sleep timer (and other listeners) can react,
      // even when repeat="one" (where the trackId doesn't change).
      window.dispatchEvent(new CustomEvent("bl-track-ended", { detail: { trackId: currentTrackId } }));

      if (repeat === "one") {
        audioControls.seek(0);
        setTimeout(() => audioControls.play(), 80);
        return;
      }
      const nextId = useAppStore.getState().nextInQueue();
      if (!nextId) return;

      // Crossfade: fade out current, then switch tracks and fade in
      const fadeMs = crossfadeDuration > 0 ? crossfadeDuration * 1000 : 0;
      if (fadeMs > 0 && !crossfadeRef.current) {
        crossfadeRef.current = true;
        audioControls.fadeOut(fadeMs).then(() => {
          useAppStore.getState().setCurrentTrack(nextId);
          const waitAndPlay = () => {
            const a = audioRef.current;
            if (!a) { crossfadeRef.current = false; return; }
            if (a.readyState >= 2) {
              audioControls.play();
              audioControls.fadeIn(fadeMs);
              crossfadeRef.current = false;
            } else {
              const onCanPlay = () => {
                audioControls.play();
                audioControls.fadeIn(fadeMs);
                crossfadeRef.current = false;
                a.removeEventListener("canplay", onCanPlay);
              };
              a.addEventListener("canplay", onCanPlay);
              setTimeout(() => {
                a.removeEventListener("canplay", onCanPlay);
                audioControls.play();
                audioControls.fadeIn(fadeMs);
                crossfadeRef.current = false;
              }, 2000);
            }
          };
          setTimeout(waitAndPlay, 100);
        });
      } else {
        useAppStore.getState().setCurrentTrack(nextId);
        const waitAndPlay = () => {
          const a = audioRef.current;
          if (!a) return;
          if (a.readyState >= 2) {
            audioControls.play();
          } else {
            a.addEventListener("canplay", () => audioControls.play(), { once: true });
          }
        };
        setTimeout(waitAndPlay, 100);
      }
    };
    audio.addEventListener("ended", onEnded);
    return () => audio.removeEventListener("ended", onEnded);
  }, [audioRef, currentTrackId, repeat, audioControls, crossfadeDuration]);

  // Actions
  const playTrackFromList = useCallback((track: Track, index: number, list: Track[]) => {
    const trackIds = list.map(t => t.id);
    useAppStore.getState().setQueue(trackIds, index);
    useAppStore.getState().setCurrentTrack(track.id);
    useAppStore.getState().addToHistory(track.id);
    fetch("/api/history", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ trackId: track.id }),
    }).catch(() => {});
    const waitAndPlay = () => {
      const a = audioRef.current;
      if (!a) return;
      if (a.readyState >= 2) {
        audioControls.play();
      } else {
        const onCanPlay = () => {
          audioControls.play();
          a.removeEventListener("canplay", onCanPlay);
        };
        a.addEventListener("canplay", onCanPlay);
        setTimeout(() => {
          a.removeEventListener("canplay", onCanPlay);
          audioControls.play();
        }, 2000);
      }
    };
    setTimeout(waitAndPlay, 80);
  }, [audioControls, audioRef]);

  const handlePrev = useCallback(() => {
    const prevId = useAppStore.getState().prevInQueue();
    if (prevId) {
      useAppStore.getState().setCurrentTrack(prevId);
      setTimeout(() => audioControls.play(), 100);
    } else {
      audioControls.seek(0);
    }
  }, [audioControls]);

  const handleNext = useCallback(() => {
    const nextId = useAppStore.getState().nextInQueue();
    if (nextId) {
      useAppStore.getState().setCurrentTrack(nextId);
      setTimeout(() => audioControls.play(), 100);
    }
  }, [audioControls]);

  // Poll integration: handle user commands and AI replies
  const handlePollUserCommand = useCallback((text: string) => {
    setPollActive(true);
    // Try to parse commands like "Play เศร้า by KRK"
    const playMatch = text.match(/(?:play|เปิด|เล่น)\s+(.+?)(?:\s+by\s+(.+))?$/i);
    if (playMatch) {
      const songName = playMatch[1].trim();
      const artistName = playMatch[2]?.trim();
      const found = allTracks.find(t => {
        const titleMatch = t.title.toLowerCase().includes(songName.toLowerCase());
        const artistMatch = !artistName || t.artists.some(a => a.toLowerCase().includes(artistName.toLowerCase()));
        return titleMatch && artistMatch;
      });
      if (found) {
        playTrackFromList(found, 0, allTracks);
        toast.success("Playing from poll", { description: found.title });
        return;
      }
    }
    // Try to find by just song name
    const found = allTracks.find(t => t.title.toLowerCase().includes(text.toLowerCase()));
    if (found) {
      playTrackFromList(found, 0, allTracks);
      toast.success("Playing from poll", { description: found.title });
    }
  }, [allTracks, playTrackFromList]);

  const handlePollAiReply = useCallback((text: string) => {
    toast.info("AI Reply", { description: text.slice(0, 100) });
  }, []);

  useChatPoll({
    onUserCommand: handlePollUserCommand,
    onAiReply: handlePollAiReply,
  });

  // Handle incoming share URL: ?share=track_ID or ?share=playlist_ID
  // Runs once after data is loaded.
  const shareHandledRef = useRef(false);
  useEffect(() => {
    if (shareHandledRef.current) return;
    if (allTracks.length === 0 && playlists.length === 0) return;
    if (typeof window === "undefined") return;

    const params = new URLSearchParams(window.location.search);
    const share = params.get("share");
    if (!share) {
      shareHandledRef.current = true;
      return;
    }

    // Normalize: support "track_ID", "playlist_ID", or "track/ID" forms
    const [type, id] = share.includes("_")
      ? share.split("_")
      : share.includes("/")
      ? share.split("/")
      : [null, null];

    if (type === "track" && id) {
      const tr = allTracks.find(t => t.id === id);
      if (tr) {
        playTrackFromList(tr, 0, allTracks);
        toast.success("Shared track loaded", { description: tr.title });
        window.history.replaceState({}, "", "/");
      }
    } else if (type === "playlist" && id) {
      const pl = playlists.find(p => p.id === id);
      if (pl) {
        setView({ type: "playlist", id });
        toast.success("Shared playlist loaded", { description: pl.name });
        window.history.replaceState({}, "", "/");
      } else if (id === "liked") {
        setView({ type: "liked" });
        window.history.replaceState({}, "", "/");
      }
    }
    shareHandledRef.current = true;
  }, [allTracks, playlists, playTrackFromList, setView]);

  // Listen for queue reorder events (dispatched by QueuePanel)
  useEffect(() => {
    const handler = (e: Event) => {
      const detail = (e as CustomEvent).detail;
      if (detail && typeof detail.from === "number" && typeof detail.to === "number") {
        useAppStore.getState().reorderQueue(detail.from, detail.to);
      }
    };
    window.addEventListener("bl-queue-reorder", handler as EventListener);
    return () => window.removeEventListener("bl-queue-reorder", handler as EventListener);
  }, []);

  const toggleLike = useCallback(async (trackId: string) => {
    const track = allTracks.find(t => t.id === trackId);
    if (!track) return;
    try {
      if (track.liked) {
        await fetch(`/api/likes?trackId=${trackId}`, { method: "DELETE" });
        toast.success(`Removed from Liked Songs`, { description: track.title });
      } else {
        await fetch("/api/likes", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ trackId }),
        });
        toast.success(`Added to Liked Songs`, { description: track.title });
      }
    } catch (e) {
      toast.error("Failed to update like");
    }
    const wasLiked = allTracks.find(t => t.id === trackId)?.liked;
    setAllTracks(prev => prev.map(t => t.id === trackId ? { ...t, liked: !t.liked } : t));
    setPlaylistTracks(prev => {
      if (wasLiked && view.type === "liked") {
        return prev.filter(t => t.id !== trackId).map(t => t.id === trackId ? { ...t, liked: false } : t);
      }
      return prev.map(t => t.id === trackId ? { ...t, liked: !t.liked } : t);
    });
    setArtistTracks(prev => prev.map(t => t.id === trackId ? { ...t, liked: !t.liked } : t));
    setSearchResults(prev => ({
      ...prev,
      tracks: prev.tracks.map(t => t.id === trackId ? { ...t, liked: !t.liked } : t),
    }));
    loadPlaylists();
  }, [allTracks, view.type, loadPlaylists]);

  // Keyboard shortcuts (after callback declarations to avoid TDZ)
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement;
      const isInput = t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.isContentEditable);
      if (isInput && e.code !== "Escape") return;

      // Escape closes any open dialog
      if (e.code === "Escape") {
        setShowMobileSidebar(false);
        setShowSleepTimer(false);
        setShowShareModal(false);
        setLyricsEditorOpen(false);
        setShowShortcutsHelp(false);
        setShowNowPlaying(false);
        return;
      }

      // Show shortcuts help on ?
      if (e.key === "?") {
        e.preventDefault();
        useAppStore.getState().setShowShortcutsHelp(true);
        return;
      }

      if (isInput) return;

      if (e.code === "Space") {
        e.preventDefault();
        audioControls.toggle();
      } else if (e.code === "ArrowRight" && !e.shiftKey) {
        e.preventDefault();
        audioControls.seek(audioState.currentTime + 5);
      } else if (e.code === "ArrowLeft" && !e.shiftKey) {
        e.preventDefault();
        audioControls.seek(audioState.currentTime - 5);
      } else if (e.code === "ArrowRight" && e.shiftKey) {
        e.preventDefault();
        handleNext();
      } else if (e.code === "ArrowLeft" && e.shiftKey) {
        e.preventDefault();
        handlePrev();
      } else if (e.code === "ArrowUp") {
        e.preventDefault();
        setVolume(Math.min(1, volume + 0.05));
      } else if (e.code === "ArrowDown") {
        e.preventDefault();
        setVolume(Math.max(0, volume - 0.05));
      } else if (e.key === "m" || e.key === "M") {
        setMuted(!muted);
      } else if (e.key === "l" || e.key === "L") {
        if (currentTrack) toggleLike(currentTrack.id);
      } else if (e.key === "s" || e.key === "S") {
        setShuffle(!shuffle);
      } else if (e.key === "r" || e.key === "R") {
        setRepeat(repeat === "off" ? "all" : repeat === "all" ? "one" : "off");
      } else if (e.key === "n" || e.key === "N") {
        setShowNowPlaying(!showNowPlaying);
      } else if (e.key === "q" || e.key === "Q") {
        useAppStore.getState().setShowQueue(!useAppStore.getState().showQueue);
      } else if (e.key === "f" || e.key === "F") {
        e.preventDefault();
        setView({ type: "search", query: "" });
        setTimeout(() => {
          const input = document.querySelector('input[placeholder*="What do you want"]') as HTMLInputElement;
          input?.focus();
        }, 50);
      } else if (e.key === "h" || e.key === "H") {
        setView({ type: "home" });
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [audioControls, audioState.currentTime, audioState.duration, volume, muted, shuffle, repeat, showNowPlaying, currentTrack, setVolume, setMuted, setShuffle, setRepeat, setShowNowPlaying, setView, toggleLike, handleNext, handlePrev, setShowMobileSidebar, setShowSleepTimer, setShowShareModal, setLyricsEditorOpen, setShowShortcutsHelp]);

  const handleCreatePlaylist = useCallback(async () => {
    const name = prompt("Playlist name:", `My Playlist #${playlists.length + 1}`);
    if (!name) return;
    try {
      const res = await fetch("/api/playlists", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name }),
      });
      if (res.ok) {
        const data = await res.json();
        await loadPlaylists();
        toast.success(`Playlist created`, { description: name });
        setView({ type: "playlist", id: data.playlist.id });
      }
    } catch (e) { console.error(e); toast.error("Failed to create playlist"); }
  }, [playlists.length, loadPlaylists, setView]);

  // Add track to existing playlist
  const handleAddToPlaylist = useCallback(async (playlistId: string, trackId: string): Promise<boolean> => {
    try {
      const res = await fetch(`/api/playlists/${playlistId}/tracks`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ trackId }),
      });
      if (res.ok) {
        const pl = playlists.find(p => p.id === playlistId);
        const tr = allTracks.find(t => t.id === trackId);
        toast.success(`Added to ${pl?.name || "playlist"}`, { description: tr?.title });
        loadPlaylists();
        return true;
      }
      return false;
    } catch (e) {
      toast.error("Failed to add to playlist");
      return false;
    }
  }, [playlists, allTracks, loadPlaylists]);

  // Create new playlist with a track
  const handleCreatePlaylistWithTrack = useCallback(async (name: string, trackId: string): Promise<string | null> => {
    try {
      const res = await fetch("/api/playlists", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name }),
      });
      if (!res.ok) return null;
      const data = await res.json();
      const playlistId = data.playlist.id;
      await fetch(`/api/playlists/${playlistId}/tracks`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ trackId }),
      });
      const tr = allTracks.find(t => t.id === trackId);
      toast.success(`Playlist created & track added`, { description: `${name} • ${tr?.title}` });
      loadPlaylists();
      return playlistId;
    } catch (e) {
      toast.error("Failed to create playlist");
      return null;
    }
  }, [allTracks, loadPlaylists]);

  const handleDeletePlaylist = useCallback(async (id: string) => {
    if (!confirm("Delete this playlist?")) return;
    try {
      await fetch(`/api/playlists/${id}`, { method: "DELETE" });
      await loadPlaylists();
      setView({ type: "home" });
      toast.success("Playlist deleted");
    } catch (e) { console.error(e); toast.error("Failed to delete playlist"); }
  }, [loadPlaylists, setView]);

  // Reorder tracks in a playlist (optimistic UI + persist to API)
  const handleReorderTracks = useCallback((tracks: Track[], from: number, to: number) => {
    if (from === to || from < 0 || to < 0 || from >= tracks.length || to >= tracks.length) return;
    const reordered = [...tracks];
    const [moved] = reordered.splice(from, 1);
    reordered.splice(to, 0, moved);
    setPlaylistTracks(reordered);

    // Persist to API (only if current view is a real playlist, not system)
    if (view.type === "playlist" && currentPlaylist && !currentPlaylist.isSystem) {
      const trackIds = reordered.map(t => t.id);
      fetch(`/api/playlists/${currentPlaylist.id}/reorder`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ trackIds }),
      }).then(() => {
        toast.success("Playlist reordered");
      }).catch(() => {
        toast.error("Failed to save reorder");
        setPlaylistTracks(tracks); // revert
      });
    }
  }, [view.type, currentPlaylist]);

  const likedTrackCount = playlists.find(p => p.isSystem && p.name === "Liked Songs")?.trackCount || 0;
  const recentlyPlayed = history.map(id => allTracks.find(t => t.id === id)).filter(Boolean) as Track[];

  // Load history entries from server
  const loadHistoryEntries = useCallback(async () => {
    try {
      const res = await fetch("/api/history");
      const data = await res.json();
      setHistoryEntries(data.history || []);
    } catch (e) { console.error(e); }
  }, []);

  useEffect(() => {
    if (view.type === "history" || view.type === "stats" || view.type === "discover" || view.type === "personality" || view.type === "radio") loadHistoryEntries();
  }, [view, loadHistoryEntries]);

  // Scroll main content to top when view changes
  const mainScrollRef = useRef<HTMLDivElement | null>(null);
  useEffect(() => {
    if (mainScrollRef.current) {
      mainScrollRef.current.scrollTop = 0;
    }
  }, [view]);

  // Derived artist data for sidebar
  const allArtists = useMemo(() => {
    const map = new Map<string, { name: string; coverUrl: string | null; trackCount: number }>();
    for (const t of allTracks) {
      for (const a of t.artists) {
        if (!map.has(a)) {
          map.set(a, { name: a, coverUrl: t.coverUrl, trackCount: 1 });
        } else {
          map.get(a)!.trackCount++;
        }
      }
    }
    return Array.from(map.values());
  }, [allTracks]);

  // Derived album data for sidebar
  const allAlbums = useMemo(() => {
    const map = new Map<string, { name: string; coverUrl: string | null; trackCount: number }>();
    for (const t of allTracks) {
      if (!t.album) continue;
      if (!map.has(t.album)) {
        map.set(t.album, { name: t.album, coverUrl: t.coverUrl, trackCount: 1 });
      } else {
        map.get(t.album)!.trackCount++;
      }
    }
    return Array.from(map.values()).sort((a, b) => b.trackCount - a.trackCount);
  }, [allTracks]);

  return (
    <div className="bl-app">
      <audio ref={audioRef} preload="auto" />

      {/* Top: Sidebar + Main + optional Queue + Explorer (right) */}
      <div className="bl-app-top">
        <Sidebar
          playlists={playlists}
          likedTrackCount={likedTrackCount}
          artists={allArtists}
          albums={allAlbums}
          currentTrack={currentTrack}
          isPlaying={isPlaying}
          pollActive={pollActive}
          onSelectPlaylist={(id) => setView({ type: "playlist", id })}
          onCreatePlaylist={handleCreatePlaylist}
          onGoHome={() => setView({ type: "home" })}
          onGoSearch={() => setView({ type: "search", query: "" })}
          onGoLiked={() => setView({ type: "liked" })}
          onGoHistory={() => setView({ type: "history" })}
          onGoStats={() => setView({ type: "stats" })}
          onGoDiscover={() => setView({ type: "discover" })}
          onGoRadio={() => setView({ type: "radio" })}
          onGoPersonality={() => setView({ type: "personality" })}
          onGoPodcasts={() => setView({ type: "podcasts" })}
          onGoEqualizer={() => setView({ type: "equalizer" })}
          onGoRecap={() => setView({ type: "recap" })}
          onSelectArtist={(name) => setView({ type: "artist", name })}
          onSelectAlbum={(name) => setView({ type: "album", name })}
          onUploadComplete={() => { loadAllTracks(); loadPlaylists(); }}
          onToggleFriendActivity={() => setShowFriendActivity(!showFriendActivity)}
          friendActivityActive={showFriendActivity}
        />

        <div className="grid min-h-0 overflow-hidden" style={{
          gridTemplateColumns: (() => {
            const cols = ["1fr"];
            if (showQueue) cols.push("280px");
            if (showLyrics && currentTrack?.lyricsUrl) cols.push("400px");
            if (showFriendActivity) cols.push("320px");
            return cols.join(" ");
          })(),
          gap: 8,
        }}>
          <main className="bl-main">
            <TopBar
              searchValue={searchQuery}
              onSearch={setSearchQuery}
              onBack={() => window.history.back()}
              onForward={() => window.history.forward()}
            />

            <TrackContextMenu
              tracks={view.type === "search" ? searchResults.tracks : view.type === "playlist" || view.type === "liked" ? playlistTracks : view.type === "artist" ? artistTracks : view.type === "album" ? albumTracks : allTracks}
              playlists={playlists}
              currentTrackId={currentTrackId}
              isPlaying={isPlaying}
              onSelectTrack={(t, i) => {
                const list = view.type === "search" ? searchResults.tracks : view.type === "playlist" || view.type === "liked" ? playlistTracks : view.type === "artist" ? artistTracks : view.type === "album" ? albumTracks : allTracks;
                playTrackFromList(t, i, list);
              }}
              onTogglePlay={audioControls.toggle}
              onToggleLike={toggleLike}
              onAddToPlaylist={handleAddToPlaylist}
              onCreatePlaylistWithTrack={handleCreatePlaylistWithTrack}
              onAddToQueue={(trackId) => {
                useAppStore.getState().addToQueueNext(trackId);
                const tr = allTracks.find(t => t.id === trackId);
                toast.success("Added to queue", { description: tr?.title });
              }}
              onSelectArtist={(name) => setView({ type: "artist", name })}
              onSelectAlbum={(name) => setView({ type: "album", name })}
              onShare={(track) => {
                setSharePayload({
                  type: "track",
                  id: track.id,
                  title: track.title,
                  subtitle: track.artists.join(", "),
                });
                setShowShareModal(true);
              }}
            >
            <div ref={mainScrollRef} className="bl-scroll flex-1">
              {view.type === "home" && (
                <HomeView
                  playlists={playlists}
                  recentlyPlayed={recentlyPlayed}
                  allTracks={allTracks}
                  likedTrackCount={likedTrackCount}
                  currentTrack={currentTrack}
                  isPlaying={isPlaying}
                  onSelectPlaylist={(id) => setView({ type: "playlist", id })}
                  onGoLiked={() => setView({ type: "liked" })}
                  onPlayTrack={(t) => playTrackFromList(t, 0, allTracks)}
                  onSelectArtist={(name) => setView({ type: "artist", name })}
                  onSelectAlbum={(name) => setView({ type: "album", name })}
                  onToggleLyrics={() => setShowLyrics(!showLyrics)}
                />
              )}

              {view.type === "playlist" && (
                <PlaylistView
                  playlist={currentPlaylist}
                  tracks={playlistTracks}
                  currentTrackId={currentTrackId}
                  isPlaying={isPlaying && playlistTracks.some(t => t.id === currentTrackId)}
                  isLikedPlaylist={false}
                  coverHue={currentPlaylist ? hashHue(currentPlaylist.id) : 280}
                  onPlay={() => {
                    if (playlistTracks.length === 0) return;
                    if (currentTrackId && playlistTracks.some(t => t.id === currentTrackId)) {
                      audioControls.toggle();
                    } else {
                      playTrackFromList(playlistTracks[0], 0, playlistTracks);
                    }
                  }}
                  onSelectTrack={(t, i) => playTrackFromList(t, i, playlistTracks)}
                  onToggleLike={toggleLike}
                  onDeletePlaylist={() => currentPlaylist && handleDeletePlaylist(currentPlaylist.id)}
                  allPlaylists={playlists}
                  onAddToPlaylist={handleAddToPlaylist}
                  onCreatePlaylistWithTrack={handleCreatePlaylistWithTrack}
                  onReorder={(from, to) => handleReorderTracks(playlistTracks, from, to)}
                  onAddToQueue={(trackId) => {
                    useAppStore.getState().addToQueueNext(trackId);
                    const tr = allTracks.find(t => t.id === trackId);
                    toast.success("Added to queue", { description: tr?.title });
                  }}
                />
              )}

              {view.type === "liked" && (
                <PlaylistView
                  playlist={currentPlaylist}
                  tracks={playlistTracks}
                  currentTrackId={currentTrackId}
                  isPlaying={isPlaying && playlistTracks.some(t => t.id === currentTrackId)}
                  isLikedPlaylist
                  coverHue={280}
                  onPlay={() => {
                    if (playlistTracks.length === 0) return;
                    if (currentTrackId && playlistTracks.some(t => t.id === currentTrackId)) {
                      audioControls.toggle();
                    } else {
                      playTrackFromList(playlistTracks[0], 0, playlistTracks);
                    }
                  }}
                  onSelectTrack={(t, i) => playTrackFromList(t, i, playlistTracks)}
                  onToggleLike={toggleLike}
                  allPlaylists={playlists}
                  onAddToPlaylist={handleAddToPlaylist}
                  onCreatePlaylistWithTrack={handleCreatePlaylistWithTrack}
                />
              )}

              {view.type === "search" && (
                <SearchViewEnhanced
                  searchQuery={searchQuery}
                  setSearchQuery={setSearchQuery}
                  searchResults={searchResults}
                  allTracks={allTracks}
                  currentTrackId={currentTrackId}
                  isPlaying={isPlaying}
                  onPlayTrack={(t, i, list) => playTrackFromList(t, i, list || searchResults.tracks)}
                  onTogglePlay={audioControls.toggle}
                  onToggleLike={toggleLike}
                  playlists={playlists}
                  onAddToPlaylist={handleAddToPlaylist}
                  onCreatePlaylistWithTrack={handleCreatePlaylistWithTrack}
                  onSelectArtist={(name) => setView({ type: "artist", name })}
                  onSelectAlbum={(name) => setView({ type: "album", name })}
                />
              )}

              {view.type === "history" && (
                <HistoryView
                  history={historyEntries}
                  currentTrackId={currentTrackId}
                  isPlaying={isPlaying}
                  onSelect={(t, i, list) => playTrackFromList(t, i, list)}
                  onTogglePlay={audioControls.toggle}
                  onToggleLike={toggleLike}
                />
              )}

              {view.type === "artist" && (
                <ArtistView
                  artistName={view.name}
                  tracks={artistTracks}
                  currentTrackId={currentTrackId}
                  isPlaying={isPlaying && artistTracks.some(t => t.id === currentTrackId)}
                  onSelectTrack={(t, i) => playTrackFromList(t, i, artistTracks)}
                  onTogglePlay={() => {
                    if (artistTracks.length === 0) return;
                    if (currentTrackId && artistTracks.some(t => t.id === currentTrackId)) {
                      audioControls.toggle();
                    } else {
                      playTrackFromList(artistTracks[0], 0, artistTracks);
                    }
                  }}
                  onToggleLike={toggleLike}
                />
              )}

              {view.type === "album" && (
                <AlbumView
                  albumName={view.name}
                  tracks={albumTracks}
                  currentTrackId={currentTrackId}
                  isPlaying={isPlaying && albumTracks.some(t => t.id === currentTrackId)}
                  onPlay={() => {
                    if (albumTracks.length === 0) return;
                    if (currentTrackId && albumTracks.some(t => t.id === currentTrackId)) {
                      audioControls.toggle();
                    } else {
                      playTrackFromList(albumTracks[0], 0, albumTracks);
                    }
                  }}
                  onSelectTrack={(t, i) => playTrackFromList(t, i, albumTracks)}
                  onToggleLike={toggleLike}
                  allPlaylists={playlists}
                  onAddToPlaylist={handleAddToPlaylist}
                  onCreatePlaylistWithTrack={handleCreatePlaylistWithTrack}
                  onAddToQueue={(trackId) => {
                    useAppStore.getState().addToQueueNext(trackId);
                    const tr = allTracks.find(t => t.id === trackId);
                    toast.success("Added to queue", { description: tr?.title });
                  }}
                />
              )}

              {view.type === "stats" && (
                <ListeningStatsView
                  history={historyEntries}
                  allTracks={allTracks}
                  likedTrackCount={likedTrackCount}
                  onSelectTrack={(t) => playTrackFromList(t, 0, allTracks)}
                  onSelectArtist={(name) => setView({ type: "artist", name })}
                  onSelectAlbum={(name) => setView({ type: "album", name })}
                />
              )}

              {view.type === "discover" && (
                <DiscoverWeekly
                  key={discoverRefreshKey}
                  allTracks={allTracks}
                  history={historyEntries}
                  likedTrackIds={allTracks.filter(t => t.liked).map(t => t.id)}
                  currentTrackId={currentTrackId}
                  isPlaying={isPlaying}
                  onPlayAll={(tracks) => {
                    if (tracks.length === 0) return;
                    playTrackFromList(tracks[0], 0, tracks);
                  }}
                  onSelectTrack={(t, i, list) => playTrackFromList(t, i, list)}
                  onToggleLike={toggleLike}
                  onRefresh={() => {
                    setDiscoverRefreshKey(k => k + 1);
                    toast.success("Recommendations refreshed");
                  }}
                  onSelectArtist={(name) => setView({ type: "artist", name })}
                />
              )}

              {view.type === "radio" && (
                <RadioStationView
                  allTracks={allTracks}
                  history={historyEntries}
                  likedTrackIds={allTracks.filter(t => t.liked).map(t => t.id)}
                  currentTrackId={currentTrackId}
                  isPlaying={isPlaying}
                  onPlayAll={(tracks) => {
                    if (tracks.length === 0) return;
                    playTrackFromList(tracks[0], 0, tracks);
                  }}
                  onSelectTrack={(t, i, list) => playTrackFromList(t, i, list)}
                  onToggleLike={toggleLike}
                  onSelectArtist={(name) => setView({ type: "artist", name })}
                />
              )}

              {view.type === "personality" && (
                <MusicPersonalityView
                  allTracks={allTracks}
                  history={historyEntries}
                  likedTrackIds={allTracks.filter(t => t.liked).map(t => t.id)}
                  onPlayTrack={(t) => playTrackFromList(t, 0, allTracks)}
                  onSelectArtist={(name) => setView({ type: "artist", name })}
                />
              )}

              {view.type === "podcasts" && (
                <PodcastsView
                  onPlayEpisode={(ep) => {
                    toast.success(`Now playing: ${ep.title}`, { description: ep.showTitle });
                  }}
                />
              )}

              {view.type === "equalizer" && (
                <EqualizerView
                  currentPresetId={eqPreset}
                  currentGains={(() => {
                    const p = getPresetById(eqPreset);
                    return p?.gains ?? [0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
                  })()}
                  currentVolume={muted ? 0 : volume}
                  currentSpeed={playbackRate}
                  onApplyPreset={(preset) => {
                    setEqPreset(preset.id);
                    preset.gains.forEach((gain, i) => audioControls.setEqBand(EQ_PRESETS[0].gains.length === 0 ? 0 : (EQ_FREQS_LOOKUP[i] ?? 0), gain));
                    toast.success(`Applied preset: ${preset.name}`);
                  }}
                  onGainChange={(index, gain) => {
                    audioControls.setEqBand(EQ_FREQS_LOOKUP[index] ?? 0, gain);
                  }}
                  onVolumeChange={(v) => { setVolume(v); setMuted(v === 0); }}
                  onSpeedChange={(r) => { setPlaybackRate(r); audioControls.setPlaybackRate(r); toast.success(`Playback speed: ${r}×`); }}
                  onResetEq={() => {
                    audioControls.resetEq();
                    setEqPreset("flat");
                    toast.success("Equalizer reset");
                  }}
                />
              )}

              {view.type === "recap" && (
                <YearlyRecapView
                  history={historyEntries}
                  allTracks={allTracks}
                  likedTrackCount={likedTrackCount}
                  onSelectTrack={(t) => playTrackFromList(t, 0, [t])}
                  onSelectArtist={(name) => setView({ type: "artist", name })}
                  onSelectAlbum={(name) => setView({ type: "album", name })}
                  onShare={() => {
                    setSharePayload({
                      type: "track",
                      id: "recap",
                      title: `${new Date().getFullYear()} Yearly Recap`,
                      subtitle: "My year in music",
                      coverUrl: null,
                    });
                    useAppStore.getState().setShowShareModal(true);
                  }}
                />
              )}
            </div>
            </TrackContextMenu>
          </main>

          {showQueue && (
            <QueuePanel
              queue={queueTracks}
              currentTrackId={currentTrackId}
              onClose={() => setShowQueue(false)}
              onSelect={(t) => {
                const idx = queue.findIndex(id => id === t.id);
                if (idx >= 0) {
                  useAppStore.getState().setQueue(queue, idx);
                  useAppStore.getState().setCurrentTrack(t.id);
                  setTimeout(() => audioControls.play(), 80);
                }
              }}
              onRemove={(trackId) => useAppStore.getState().removeFromQueue(trackId)}
              onClear={() => useAppStore.getState().clearQueue()}
            />
          )}

          {/* Lyrics panel */}
          {showLyrics && currentTrack?.lyricsUrl && (
            <aside className="bl-panel bl-lyrics-viewport relative overflow-hidden" style={{ width: "400px" }}>
              <button onClick={() => setShowLyrics(false)} className="absolute right-2 top-2 z-10 flex h-7 w-7 items-center justify-center rounded-full bg-white/10 text-white/70 backdrop-blur-md hover:bg-white/20 hover:text-white">
                <X size={12} />
              </button>
              <LyricsView key={currentTrack.lyricsUrl} lyricsUrl={currentTrack.lyricsUrl} />
            </aside>
          )}

          {/* Friend Activity panel */}
          {showFriendActivity && (
            <FriendActivity
              allTracks={allTracks}
              onClose={() => setShowFriendActivity(false)}
              onSelectTrack={(t) => playTrackFromList(t, 0, allTracks)}
              onSelectArtist={(name) => setView({ type: "artist", name })}
            />
          )}
        </div>
      </div>

      {/* Bottom: Player bar */}
      <PlayerBar
        track={currentTrack}
        currentTime={audioState.currentTime}
        duration={audioState.duration}
        isPlaying={audioState.isPlaying}
        volume={volume}
        muted={muted}
        shuffle={shuffle}
        repeat={repeat}
        isLiked={currentTrack ? !!currentTrack.liked : false}
        showQueue={showQueue}
        showNowPlaying={showNowPlaying}
        showLyrics={showLyrics}
        hasLyrics={!!currentTrack?.lyricsUrl}
        playbackRate={playbackRate}
        crossfadeDuration={crossfadeDuration}
        eqPreset={eqPreset}
        normalizeVolume={normalizeVolume}
        onToggle={audioControls.toggle}
        onSeek={audioControls.seek}
        onPrev={handlePrev}
        onNext={handleNext}
        onVolume={setVolume}
        onToggleMute={() => setMuted(!muted)}
        onToggleShuffle={() => setShuffle(!shuffle)}
        onToggleRepeat={() => setRepeat(repeat === "off" ? "all" : repeat === "all" ? "one" : "off")}
        onToggleLike={() => currentTrack && toggleLike(currentTrack.id)}
        onToggleQueue={() => setShowQueue(!showQueue)}
        onToggleNowPlaying={() => setShowNowPlaying(!showNowPlaying)}
        onToggleLyrics={() => setShowLyrics(!showLyrics)}
        onSetPlaybackRate={(r) => { setPlaybackRate(r); audioControls.setPlaybackRate(r); toast.success(`Playback speed: ${r}×`); }}
        onSetCrossfade={(s) => { setCrossfadeDuration(s); toast.success(s > 0 ? `Crossfade: ${s}s` : "Crossfade off"); }}
        onSetEqPreset={(presetId) => { setEqPreset(presetId); }}
        onToggleNormalize={(v) => { setNormalizeVolume(v); toast.success(v ? "Volume normalization on" : "Volume normalization off"); }}
        onOpenSleepTimer={() => setShowSleepTimer(true)}
        onOpenShare={() => {
          if (!currentTrack) return;
          setSharePayload({
            type: "track",
            id: currentTrack.id,
            title: currentTrack.title,
            subtitle: currentTrack.artists.join(", "),
          });
          setShowShareModal(true);
        }}
        onOpenLyricsEditor={() => setLyricsEditorOpen(true)}
        onOpenMiniPlayer={() => { setShowMiniPlayer(true); setShowNowPlaying(false); }}
        karaokeMode={karaokeMode}
        onToggleKaraoke={() => setKaraokeMode(!karaokeMode)}
        onSetEqBand={audioControls.setEqBand}
        onResetEq={audioControls.resetEq}
      />

      {/* Now Playing expanded view */}
      {showNowPlaying && (
        <NowPlayingView
          track={currentTrack}
          nextTrack={nextTrack}
          currentTime={audioState.currentTime}
          duration={audioState.duration}
          isPlaying={audioState.isPlaying}
          volume={volume}
          muted={muted}
          shuffle={shuffle}
          repeat={repeat}
          isLiked={currentTrack ? !!currentTrack.liked : false}
          onClose={() => setShowNowPlaying(false)}
          onToggle={audioControls.toggle}
          onSeek={audioControls.seek}
          onPrev={handlePrev}
          onNext={handleNext}
          onVolume={setVolume}
          onToggleMute={() => setMuted(!muted)}
          onToggleShuffle={() => setShuffle(!shuffle)}
          onToggleRepeat={() => setRepeat(repeat === "off" ? "all" : repeat === "all" ? "one" : "off")}
          onToggleLike={() => currentTrack && toggleLike(currentTrack.id)}
          frequencyData={analyzerState.frequencyData}
          waveformData={analyzerState.waveformData}
        />
      )}

      {/* AI Command Overlay */}
      <CommandOverlay />

      {/* Karaoke Mode overlay */}
      {karaokeMode && currentTrack && (
        <KaraokeMode
          track={currentTrack}
          isPlaying={audioState.isPlaying}
          currentTime={audioState.currentTime}
          duration={audioState.duration}
          onSeek={audioControls.seek}
          onClose={() => setKaraokeMode(false)}
        />
      )}

      {/* Sleep Timer modal */}
      <SleepTimer
        isOpen={showSleepTimer}
        onClose={() => setShowSleepTimer(false)}
        isPlaying={audioState.isPlaying}
        onPause={() => audioControls.pause()}
        currentTrackId={currentTrackId}
      />

      {/* Share modal */}
      <ShareModal />

      {/* Lyrics editor modal */}
      <LyricsEditor
        isOpen={lyricsEditorOpen}
        onClose={() => setLyricsEditorOpen(false)}
        track={currentTrack}
        onSaved={() => { loadAllTracks(); }}
      />

      {/* Keyboard shortcuts help */}
      <ShortcutsHelp />

      {/* Settings panel */}
      <SettingsPanel
        isOpen={useAppStore.getState().showSettings}
        onClose={() => useAppStore.getState().setShowSettings(false)}
        onOpenSleepTimer={() => setShowSleepTimer(true)}
        onOpenEqualizer={() => setView({ type: "equalizer" })}
        onOpenRecap={() => setView({ type: "recap" })}
      />

      {/* Mini Player (floating widget) */}
      {showMiniPlayer && (
        <MiniPlayer
          track={currentTrack}
          currentTime={audioState.currentTime}
          duration={audioState.duration}
          isPlaying={audioState.isPlaying}
          volume={volume}
          muted={muted}
          shuffle={shuffle}
          repeat={repeat}
          isLiked={currentTrack ? !!currentTrack.liked : false}
          onToggle={audioControls.toggle}
          onSeek={audioControls.seek}
          onPrev={handlePrev}
          onNext={handleNext}
          onVolume={setVolume}
          onToggleMute={() => setMuted(!muted)}
          onToggleShuffle={() => setShuffle(!shuffle)}
          onToggleRepeat={() => setRepeat(repeat === "off" ? "all" : repeat === "all" ? "one" : "off")}
          onToggleLike={() => currentTrack && toggleLike(currentTrack.id)}
          onClose={() => setShowMiniPlayer(false)}
          onExpand={() => { setShowMiniPlayer(false); setShowNowPlaying(true); }}
        />
      )}

      {/* Mobile sidebar overlay */}
      {showMobileSidebar && (
        <div
          className="fixed inset-0 z-[150] bg-black/60 backdrop-blur-sm lg:hidden bl-fade-in"
          onClick={() => setShowMobileSidebar(false)}
        >
          <div
            className="absolute left-0 top-0 h-full w-[300px] max-w-[85vw] overflow-y-auto bg-[var(--sp-base-2)] p-2 shadow-2xl bl-slide-right"
            onClick={e => e.stopPropagation()}
          >
            <Sidebar
              playlists={playlists}
              likedTrackCount={likedTrackCount}
              artists={allArtists}
              albums={allAlbums}
              currentTrack={currentTrack}
              isPlaying={isPlaying}
              pollActive={pollActive}
              onSelectPlaylist={(id) => { setView({ type: "playlist", id }); setShowMobileSidebar(false); }}
              onCreatePlaylist={handleCreatePlaylist}
              onGoHome={() => { setView({ type: "home" }); setShowMobileSidebar(false); }}
              onGoSearch={() => { setView({ type: "search", query: "" }); setShowMobileSidebar(false); }}
              onGoLiked={() => { setView({ type: "liked" }); setShowMobileSidebar(false); }}
              onGoHistory={() => { setView({ type: "history" }); setShowMobileSidebar(false); }}
              onGoStats={() => { setView({ type: "stats" }); setShowMobileSidebar(false); }}
              onGoDiscover={() => { setView({ type: "discover" }); setShowMobileSidebar(false); }}
              onGoRadio={() => { setView({ type: "radio" }); setShowMobileSidebar(false); }}
              onGoPersonality={() => { setView({ type: "personality" }); setShowMobileSidebar(false); }}
              onGoPodcasts={() => { setView({ type: "podcasts" }); setShowMobileSidebar(false); }}
              onGoEqualizer={() => { setView({ type: "equalizer" }); setShowMobileSidebar(false); }}
              onGoRecap={() => { setView({ type: "recap" }); setShowMobileSidebar(false); }}
              onSelectArtist={(name) => { setView({ type: "artist", name }); setShowMobileSidebar(false); }}
              onSelectAlbum={(name) => { setView({ type: "album", name }); setShowMobileSidebar(false); }}
              onUploadComplete={() => { loadAllTracks(); loadPlaylists(); }}
              onToggleFriendActivity={() => setShowFriendActivity(!showFriendActivity)}
              friendActivityActive={showFriendActivity}
            />
          </div>
        </div>
      )}

      {/* Mobile bottom navigation (visible on < 1024px) — Modern 5-button with center Radio */}
      <nav className="bl-mobile-nav-enhanced">
        <button
          onClick={() => setView({ type: "home" })}
          className={`bl-mobile-ripple flex flex-col items-center gap-1 px-2 py-1 ${view.type === "home" ? "text-white" : "text-[var(--sp-text-subdued)]"}`}
        >
          <HomeIcon size={20} />
          <span className="text-[10px]">Home</span>
        </button>
        <button
          onClick={() => setView({ type: "search", query: "" })}
          className={`bl-mobile-ripple flex flex-col items-center gap-1 px-2 py-1 ${view.type === "search" ? "text-white" : "text-[var(--sp-text-subdued)]"}`}
        >
          <SearchIcon size={20} />
          <span className="text-[10px]">Search</span>
        </button>
        <button
          onClick={() => setView({ type: "radio" })}
          className="bl-mobile-center-btn"
        >
          <div className={`bl-center-circle ${view.type === "radio" ? "active" : ""}`}>
            <RadioIcon size={24} className="text-white" />
          </div>
          <span className={`text-[10px] mt-0.5 ${view.type === "radio" ? "text-emerald-400" : "text-[var(--sp-text-subdued)]"}`}>Radio</span>
        </button>
        <button
          onClick={() => setShowMobileSidebar(true)}
          className={`bl-mobile-ripple flex flex-col items-center gap-1 px-2 py-1 ${showMobileSidebar ? "text-white" : "text-[var(--sp-text-subdued)]"}`}
        >
          <Menu size={20} />
          <span className="text-[10px]">Library</span>
        </button>
        <button
          onClick={() => setShowShortcutsHelp(true)}
          className={`bl-mobile-ripple flex flex-col items-center gap-1 px-2 py-1 text-[var(--sp-text-subdued)]`}
        >
          <UserIcon size={20} />
          <span className="text-[10px]">More</span>
        </button>
      </nav>
    </div>
  );
}

function hashHue(s: string): number {
  if (!s) return 280;
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0;
  return h % 360;
}

/* ============================================================
   Enhanced Search View with genre chips, recent searches, browse
   ============================================================ */
const BROWSE_GENRES = [
  { name: "Ambient", color: "from-teal-600 to-cyan-900", icon: "🌙" },
  { name: "Electronic", color: "from-blue-600 to-cyan-900", icon: "⚡" },
  { name: "Pop", color: "from-pink-600 to-rose-900", icon: "🎤" },
  { name: "Nature", color: "from-green-600 to-emerald-900", icon: "🌿" },
  { name: "Lo-fi", color: "from-amber-600 to-orange-900", icon: "🎧" },
  { name: "World", color: "from-yellow-600 to-amber-900", icon: "🌍" },
  { name: "Tropical", color: "from-emerald-600 to-lime-900", icon: "🌴" },
  { name: "Rock", color: "from-red-600 to-rose-900", icon: "🎸" },
  { name: "Indie", color: "from-violet-600 to-purple-900", icon: "🎵" },
  { name: "Space", color: "from-indigo-600 to-violet-900", icon: "🚀" },
  { name: "Classical", color: "from-stone-600 to-stone-900", icon: "🎻" },
  { name: "Jazz", color: "from-amber-700 to-yellow-900", icon: "🎷" },
];

function SearchViewEnhanced({
  searchQuery,
  setSearchQuery,
  searchResults,
  allTracks,
  currentTrackId,
  isPlaying,
  onPlayTrack,
  onTogglePlay,
  onToggleLike,
  playlists,
  onAddToPlaylist,
  onCreatePlaylistWithTrack,
  onSelectArtist,
  onSelectAlbum,
}: {
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  searchResults: { tracks: Track[]; playlists: Playlist[] };
  allTracks: Track[];
  currentTrackId: string | null;
  isPlaying: boolean;
  onPlayTrack: (t: Track, i: number, list?: Track[]) => void;
  onTogglePlay: () => void;
  onToggleLike: (id: string) => void;
  playlists: Playlist[];
  onAddToPlaylist: (playlistId: string, trackId: string) => Promise<boolean>;
  onCreatePlaylistWithTrack: (name: string, trackId: string) => Promise<string | null>;
  onSelectArtist: (name: string) => void;
  onSelectAlbum: (name: string) => void;
}) {
  // Extract available genres from all tracks
  const availableGenres = useMemo(() => {
    const map = new Map<string, number>();
    for (const t of allTracks) {
      if (t.genre) {
        map.set(t.genre, (map.get(t.genre) || 0) + 1);
      }
    }
    return Array.from(map.entries())
      .sort((a, b) => b[1] - a[1])
      .map(([name]) => name);
  }, [allTracks]);

  // Recent searches from localStorage - lazy initializer
  const [recentSearches, setRecentSearches] = useState<string[]>(() => {
    if (typeof window === "undefined") return [];
    try {
      const stored = localStorage.getItem("bl-recent-searches");
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch {}
    return [];
  });

  const saveSearch = useCallback((q: string) => {
    if (!q.trim()) return;
    setRecentSearches(prev => {
      const next = [q, ...prev.filter(s => s !== q)].slice(0, 8);
      try { localStorage.setItem("bl-recent-searches", JSON.stringify(next)); } catch {}
      return next;
    });
  }, []);

  // Save search when we get results
  const handleSearchSubmit = useCallback(() => {
    if (searchQuery.trim()) saveSearch(searchQuery.trim());
  }, [searchQuery, saveSearch]);

  const clearRecentSearches = useCallback(() => {
    setRecentSearches([]);
    try { localStorage.removeItem("bl-recent-searches"); } catch {}
  }, []);

  // Filter chips - genres available in the library
  const genreChips = availableGenres.slice(0, 8);

  return (
    <div className="bl-scroll flex-1 px-6 pb-32 bl-view-transition">
      {/* Search header */}
      <div className="pt-8 pb-4">
        <h2 className="text-2xl font-bold text-white">
          {searchQuery ? `Results for "${searchQuery}"` : "Search"}
        </h2>
      </div>

      {/* Genre filter chips */}
      {genreChips.length > 0 && (
        <div className="mb-4 flex flex-wrap gap-2">
          {genreChips.map(g => (
            <button
              key={g}
              onClick={() => setSearchQuery(g)}
              className={`rounded-full px-3 py-1.5 text-xs font-medium transition-all ${
                searchQuery.toLowerCase() === g.toLowerCase()
                  ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30"
                  : "bg-white/5 text-[var(--sp-text-subdued)] border border-white/10 hover:bg-white/10 hover:text-white"
              }`}
            >
              {g}
            </button>
          ))}
        </div>
      )}

      {/* Search results */}
      {searchQuery && searchResults.tracks.length > 0 && (
        <TrackTable
          tracks={searchResults.tracks}
          currentTrackId={currentTrackId}
          isPlaying={isPlaying}
          onSelect={(t, i) => onPlayTrack(t, i, searchResults.tracks)}
          onTogglePlay={onTogglePlay}
          onToggleLike={onToggleLike}
          playlists={playlists}
          onAddToPlaylist={onAddToPlaylist}
          onCreatePlaylistWithTrack={onCreatePlaylistWithTrack}
        />
      )}

      {/* No results */}
      {searchQuery && searchResults.tracks.length === 0 && (
        <div className="text-center py-12">
          <p className="text-[var(--sp-text-subdued)]">No results found for &quot;{searchQuery}&quot;</p>
          <p className="mt-2 text-xs text-white/40">Try different keywords or browse genres below</p>
        </div>
      )}

      {/* Recent searches (when no search query) */}
      {!searchQuery && recentSearches.length > 0 && (
        <section className="mt-2 bl-section-in">
          <div className="mb-4 flex items-center justify-between">
            <h3 className="text-lg font-bold text-white">Recent searches</h3>
            <button
              onClick={clearRecentSearches}
              className="text-xs font-medium text-[var(--sp-text-subdued)] hover:text-white transition-colors"
            >
              Clear all
            </button>
          </div>
          <div className="flex flex-wrap gap-2">
            {recentSearches.map(q => (
              <button
                key={q}
                onClick={() => setSearchQuery(q)}
                className="flex items-center gap-2 rounded-full bg-white/5 border border-white/10 px-3 py-2 text-sm text-white/80 hover:bg-white/10 transition-colors"
              >
                <ClockIcon size={14} className="text-white/40" />
                {q}
              </button>
            ))}
          </div>
        </section>
      )}

      {/* Browse all (when no search query) */}
      {!searchQuery && (
        <section className="mt-8 bl-section-in" style={{ animationDelay: "0.1s" }}>
          <h3 className="mb-4 text-lg font-bold text-white">Browse all</h3>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
            {BROWSE_GENRES.map(g => {
              const genreTrackCount = allTracks.filter(t => t.genre === g.name).length;
              return (
                <button
                  key={g.name}
                  onClick={() => setSearchQuery(g.name)}
                  className={`group relative flex h-24 items-center justify-between overflow-hidden rounded-xl bg-gradient-to-br ${g.color} p-4 transition-all hover:scale-[1.02] hover:shadow-lg active:scale-[0.98]`}
                >
                  <div className="text-left">
                    <div className="text-lg font-extrabold text-white">{g.name}</div>
                    <div className="text-xs text-white/60">{genreTrackCount > 0 ? `${genreTrackCount} ${genreTrackCount === 1 ? "track" : "tracks"}` : "Explore"}</div>
                  </div>
                  <span className="text-3xl opacity-60 group-hover:opacity-80 transition-opacity">{g.icon}</span>
                </button>
              );
            })}
          </div>
        </section>
      )}

      {/* Quick results when no search - show top tracks */}
      {!searchQuery && allTracks.length > 0 && (
        <section className="mt-8 bl-section-in" style={{ animationDelay: "0.2s" }}>
          <h3 className="mb-4 text-lg font-bold text-white">Quick picks</h3>
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 md:grid-cols-4">
            {allTracks.slice(0, 8).map(t => (
              <button
                key={t.id}
                onClick={() => onPlayTrack(t, 0, allTracks)}
                className="group flex items-center gap-3 overflow-hidden rounded-lg bg-white/5 hover:bg-white/10 transition-colors"
              >
                <div className="relative h-12 w-12 shrink-0">
                  {t.coverUrl ? (
                    <img src={t.coverUrl} alt="" className="h-full w-full object-cover rounded-l-lg" />
                  ) : (
                    <div className="flex h-full w-full items-center justify-center bg-white/10 rounded-l-lg">
                      <Music2 size={16} className="text-white/40" />
                    </div>
                  )}
                </div>
                <div className="min-w-0 flex-1 pr-2">
                  <div className="truncate text-sm font-medium text-white">{t.title}</div>
                  <div className="truncate text-xs text-[var(--sp-text-subdued)]">{t.artists.join(", ")}</div>
                </div>
              </button>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
