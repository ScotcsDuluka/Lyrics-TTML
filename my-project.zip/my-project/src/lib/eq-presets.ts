// Equalizer presets — gain values in dB for each frequency band
// Frequencies match EQ_FREQS in use-audio-player.ts:
// [60, 170, 310, 600, 1000, 3000, 6000, 12000, 14000, 16000]

export const EQ_FREQS = [60, 170, 310, 600, 1000, 3000, 6000, 12000, 14000, 16000] as const;

export interface EqPreset {
  id: string;
  name: string;
  description: string;
  gains: number[]; // length must match EQ_FREQS
  icon: string; // emoji or short label
  color: string; // tailwind gradient classes
}

export const EQ_PRESETS: EqPreset[] = [
  {
    id: "flat",
    name: "Flat",
    description: "No adjustments — pure original sound",
    gains: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    icon: "─",
    color: "from-slate-500/40 to-slate-700/40",
  },
  {
    id: "rock",
    name: "Rock",
    description: "Punchy bass + crisp highs for guitars & drums",
    gains: [5, 4, 3, 1, -1, 0, 2, 4, 5, 5],
    icon: "🎸",
    color: "from-red-500/40 to-orange-700/40",
  },
  {
    id: "pop",
    name: "Pop",
    description: "Vocal-forward with bright, polished highs",
    gains: [-1, 1, 3, 4, 3, 1, 0, -1, 1, 2],
    icon: "🎤",
    color: "from-pink-500/40 to-rose-700/40",
  },
  {
    id: "jazz",
    name: "Jazz",
    description: "Warm mids and smooth bass for live instruments",
    gains: [3, 2, 1, 2, -1, -1, 0, 1, 2, 3],
    icon: "🎷",
    color: "from-amber-500/40 to-yellow-700/40",
  },
  {
    id: "classical",
    name: "Classical",
    description: "Neutral, wide-range response for orchestral music",
    gains: [4, 3, 2, 0, 0, 0, -2, -3, -2, -1],
    icon: "🎻",
    color: "from-violet-500/40 to-purple-700/40",
  },
  {
    id: "bass-boost",
    name: "Bass Boost",
    description: "Deep, powerful low-end for electronic & hip-hop",
    gains: [8, 6, 4, 2, 0, 0, 0, 0, 1, 2],
    icon: "🔊",
    color: "from-emerald-500/40 to-teal-700/40",
  },
  {
    id: "vocal",
    name: "Vocal",
    description: "Bring voices to the front of the mix",
    gains: [-2, -1, 1, 3, 4, 4, 3, 1, 0, -1],
    icon: "💬",
    color: "from-cyan-500/40 to-blue-700/40",
  },
  {
    id: "electronic",
    name: "Electronic",
    description: "Tight bass, sparkly tops for EDM & dance",
    gains: [5, 4, 1, 0, -2, 2, 1, 4, 5, 6],
    icon: "⚡",
    color: "from-fuchsia-500/40 to-pink-700/40",
  },
  {
    id: "acoustic",
    name: "Acoustic",
    description: "Detailed, natural sound for unplugged sets",
    gains: [4, 4, 3, 1, 2, 2, 3, 4, 3, 2],
    icon: "🪕",
    color: "from-lime-500/40 to-green-700/40",
  },
];

export function getPresetById(id: string): EqPreset | undefined {
  return EQ_PRESETS.find(p => p.id === id);
}
