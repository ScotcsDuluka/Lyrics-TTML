import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { Prisma } from "@prisma/client";

type RawTrack = {
  id: string; title: string; artists: string; album: string; genre: string;
  audioUrl: string; lyricsUrl: string | null; coverUrl: string | null;
  duration: number | null;
};

/** Helper: fetch tracks by IDs using parameterized raw SQL (bypasses cached Prisma client) */
async function fetchTracksByIds(ids: string[]): Promise<RawTrack[]> {
  if (ids.length === 0) return [];
  const raw = await prisma.$queryRaw<RawTrack[]>(
    Prisma.sql`SELECT id, title, artists, album, genre, audioUrl, lyricsUrl, coverUrl, duration FROM Track WHERE id IN (${Prisma.join(ids)})`
  );
  return raw as unknown as RawTrack[];
}

/** Helper: fetch all tracks ordered by title */
async function fetchAllTracks(): Promise<RawTrack[]> {
  const raw = await prisma.$queryRaw<RawTrack[]>(
    Prisma.sql`SELECT id, title, artists, album, genre, audioUrl, lyricsUrl, coverUrl, duration FROM Track ORDER BY title ASC`
  );
  return raw as unknown as RawTrack[];
}

/** Helper: search tracks */
async function searchTracks(q: string): Promise<RawTrack[]> {
  const pattern = `%${q}%`;
  const raw = await prisma.$queryRaw<RawTrack[]>(
    Prisma.sql`SELECT id, title, artists, album, genre, audioUrl, lyricsUrl, coverUrl, duration FROM Track WHERE LOWER(title) LIKE ${pattern} OR LOWER(artists) LIKE ${pattern} OR LOWER(album) LIKE ${pattern} OR LOWER(genre) LIKE ${pattern} LIMIT 50`
  );
  return raw as unknown as RawTrack[];
}

/** Helper: format a raw track into the API response shape */
function formatTrack(t: RawTrack, likedTrackIds: Set<string>) {
  return {
    id: t.id,
    title: t.title,
    artists: JSON.parse(t.artists),
    album: t.album,
    genre: t.genre || "",
    audioUrl: t.audioUrl,
    lyricsUrl: t.lyricsUrl,
    coverUrl: t.coverUrl,
    duration: t.duration,
    liked: likedTrackIds.has(t.id),
  };
}

export { fetchTracksByIds, fetchAllTracks, searchTracks, formatTrack };
export type { RawTrack };
