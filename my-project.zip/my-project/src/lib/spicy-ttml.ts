/**
 * Client-side TTML parser — produces output matching spicy-lyrics' tools.ts types.
 *
 * Spacing system (mirrors spicy-lyrics source):
 *  - Each <span> becomes one syllable with IsPartOfWord flag.
 *  - Applyer-Syllable.ts renders: .word without IsPartOfWord gets ::after margin-right:0.32ch
 *    .word.PartOfWord gets NO margin (glued to next syllable in same word)
 *    .word.LastWordInLine gets NO margin
 *  - Word-group spans wrap consecutive PartOfWord syllables.
 *
 * TTML `itunes:timing="Word"` (Apple Music style):
 *  - Each span = 1 complete word, NOT a syllable.
 *  - Therefore IsPartOfWord should be FALSE for all spans (each is its own word).
 *  - We detect this via the root element's itunes:timing attribute.
 *
 * TTML without `itunes:timing` (AMLL syllable style):
 *  - Each span = 1 syllable, multiple spans form a word.
 *  - IsPartOfWord detection: look at trailing whitespace of current span
 *    and leading whitespace of next span. If no boundary, glue them.
 *  - NOTE: real AMLL TTML embeds whitespace INSIDE spans (e.g. "<span>lo </span>")
 *    so we must NOT trim text before passing to detectIsPartOfWord.
 */

export interface SpicySyllable { Text: string; IsPartOfWord?: boolean; StartTime?: number; EndTime?: number; }
export interface SpicyLeadVocal { Syllables: SpicySyllable[]; StartTime?: number; EndTime: number; }
export interface SpicyBackgroundVocal { Syllables: SpicySyllable[]; StartTime: number; EndTime: number; }
export interface SpicyVocalContent { Type: "Vocal"; Lead?: SpicyLeadVocal; Background?: SpicyBackgroundVocal[]; }
export interface SpicyLine { StartTime: number; EndTime: number; Content: SpicyVocalContent[]; IsInterlude?: boolean; }
export interface SpicyParsedLyrics { Type: "Syllable"; title: string; artists: string[]; album: string; Content: SpicyLine[]; duration: number; }

const TIME_REGEX = /^(?:(\d{2,}):)?(\d{1,2}):(\d{1,2}(?:\.\d+)?)$/;
export function parseTime(value: string | null | undefined): number | null {
  if (!value) return null;
  const m = value.trim().match(TIME_REGEX);
  if (!m) { const n = parseFloat(value); return isNaN(n) ? null : n; }
  return (m[1] ? parseInt(m[1]) : 0) * 3600 + parseInt(m[2]) * 60 + parseFloat(m[3]);
}
const NS = {
  tt: "http://www.w3.org/ns/ttml",
  amll: "http://www.example.com/ns/amll",
  ttm: "http://www.w3.org/ns/ttml#metadata",
  itunes: "http://music.apple.com/lyric-ttml-internal",
};

function getDirectText(el: Element): string {
  let out = "";
  for (const c of Array.from(el.childNodes)) {
    if (c.nodeType === 3) out += c.nodeValue ?? "";
  }
  return out;
}

function parseMeta(root: Element) {
  const r = { title: "", artists: [] as string[], album: "" };
  const ms = root.getElementsByTagNameNS(NS.amll, "meta");
  for (let i = 0; i < ms.length; i++) {
    const m = ms[i];
    const k = m.getAttribute("key"), v = m.getAttribute("value");
    if (!k || !v) continue;
    if (k === "musicName" && !r.title) r.title = v;
    else if (k === "artists") r.artists.push(v);
    else if (k === "album" && !r.album) r.album = v;
  }
  return r;
}

/**
 * Get ONLY direct child <span> elements of a <p> (not nested).
 * This prevents double-counting nested bg-vocal spans.
 */
function getDirectSpans(p: Element): Element[] {
  return Array.from(p.children).filter(c => c.tagName === "span" || c.localName === "span");
}

/**
 * Detect whether a span is a background vocal (x-bg role or v2 agent).
 */
function isBackgroundSpan(span: Element): boolean {
  const role = span.getAttribute("ttm:role") || span.getAttributeNS(NS.ttm, "role");
  return role === "x-bg";
}

/**
 * Check if a line <p> is a background vocal line (agent=v2).
 */
function isBackgroundLine(p: Element): boolean {
  const agent = p.getAttribute("ttm:agent") || p.getAttributeNS(NS.ttm, "agent");
  return agent === "v2";
}

/**
 * IsPartOfWord detection for SYLLABLE-timing TTML.
 * Uses the RAW (untrimmed) text of current and next syllable:
 *  - If current ends with whitespace → false (boundary already exists)
 *  - If next starts with whitespace → false (boundary already exists)
 *  - If next starts with punctuation → false (sentence boundary)
 *  - If current ends with lowercase Latin and next starts with uppercase Latin → false (new word)
 *  - Otherwise → true (glue syllables into one word, e.g. "beau"+"ti"+"ful")
 */
function detectIsPartOfWordSyllable(currentRaw: string, nextRaw: string | null): boolean {
  if (!nextRaw) return false;
  if (/\s$/.test(currentRaw) || /\u00A0$/.test(currentRaw)) return false;
  if (/^\s/.test(nextRaw) || /^\u00A0/.test(nextRaw)) return false;
  if (/^[.,!?;:、，。！？；：）)」』]/.test(nextRaw)) return false;
  if (/[a-z]$/.test(currentRaw) && /^[A-Z]/.test(nextRaw)) return false;
  return true;
}

/**
 * Trim leading/trailing whitespace but PRESERVE internal whitespace.
 * For Word-timing TTML, spans may contain trailing space ("1 ", "นาที ")
 * which IS the word separator — we keep it in Text so the renderer
 * shows the space correctly.
 *
 * However, for matching spicy-lyrics behavior, we trim and rely on
 * the .word::after margin-right:0.32ch for spacing. So we trim here.
 */
function cleanText(raw: string): string {
  // Trim but collapse internal whitespace to single space
  return raw.replace(/\s+/g, " ").trim();
}

export function parseSpicyTTML(ttml: string): SpicyParsedLyrics {
  const doc = new DOMParser().parseFromString(ttml, "application/xml");
  const root = doc.documentElement;

  // Detect timing mode from root attribute
  const timingAttr = root.getAttributeNS(NS.itunes, "timing") || root.getAttribute("itunes:timing");
  const isWordTiming = timingAttr === "Word";

  const meta = parseMeta(root);
  const body = root.getElementsByTagNameNS(NS.tt, "body")[0];
  let bodyDur = 0;
  if (body) {
    const d = parseTime(body.getAttribute("dur"));
    if (d) bodyDur = d;
  }
  const div = root.getElementsByTagNameNS(NS.tt, "div")[0];
  const lines: SpicyLine[] = [];

  if (div) {
    for (const p of Array.from(div.getElementsByTagNameNS(NS.tt, "p"))) {
      const pBegin = parseTime(p.getAttribute("begin")) ?? 0;
      const pEnd = parseTime(p.getAttribute("end")) ?? pBegin;
      const isBgLine = isBackgroundLine(p);

      // Get ONLY direct spans (not nested)
      const directSpans = getDirectSpans(p);

      const leadSyllables: SpicySyllable[] = [];
      const bgSyllableGroups: SpicySyllable[][] = [];

      for (const span of directSpans) {
        const rawText = getDirectText(span);
        if (!rawText) continue;

        const isBg = isBackgroundSpan(span);
        const cleaned = cleanText(rawText);
        if (!cleaned) continue;

        const syllable: SpicySyllable = {
          Text: cleaned,
          StartTime: parseTime(span.getAttribute("begin")) ?? pBegin,
          EndTime: parseTime(span.getAttribute("end")) ?? pEnd,
        };

        if (isBg) {
          // Background syllables form their own group
          bgSyllableGroups.push([syllable]);
        } else {
          leadSyllables.push(syllable);
        }
      }

      // Set IsPartOfWord based on timing mode
      if (isWordTiming) {
        // Word-timing: each span is a complete word → IsPartOfWord = false for all
        leadSyllables.forEach(s => { s.IsPartOfWord = false; });
        bgSyllableGroups.forEach(group => group.forEach(s => { s.IsPartOfWord = false; }));
      } else {
        // Syllable-timing: detect via look-ahead
        for (let i = 0; i < leadSyllables.length; i++) {
          const cur = leadSyllables[i];
          const next = i + 1 < leadSyllables.length ? leadSyllables[i + 1] : null;
          cur.IsPartOfWord = detectIsPartOfWordSyllable(cur.Text, next?.Text ?? null);
        }
        bgSyllableGroups.forEach(group => {
          for (let i = 0; i < group.length; i++) {
            const cur = group[i];
            const next = i + 1 < group.length ? group[i + 1] : null;
            cur.IsPartOfWord = detectIsPartOfWordSyllable(cur.Text, next?.Text ?? null);
          }
        });
      }

      leadSyllables.sort((a, b) => (a.StartTime ?? 0) - (b.StartTime ?? 0));
      const ls = leadSyllables.length ? leadSyllables[0].StartTime! : pBegin;
      const le = leadSyllables.length ? leadSyllables[leadSyllables.length - 1].EndTime! : pEnd;

      const content: SpicyVocalContent[] = [];
      if (leadSyllables.length > 0) {
        content.push({
          Type: "Vocal",
          Lead: { Syllables: leadSyllables, StartTime: ls, EndTime: le },
        });
      }
      if (bgSyllableGroups.length > 0) {
        const bgVocals: SpicyBackgroundVocal[] = bgSyllableGroups.map(group => {
          const s = group[0].StartTime ?? pBegin;
          const e = group[group.length - 1].EndTime ?? pEnd;
          return { Syllables: group, StartTime: s, EndTime: e };
        });
        if (content.length > 0) {
          content[0].Background = bgVocals;
        } else {
          // Line with only background vocals
          content.push({
            Type: "Vocal",
            Background: bgVocals,
          });
        }
      }

      if (content.length === 0) {
        // Empty line → interlude marker
        lines.push({
          StartTime: pBegin,
          EndTime: pEnd,
          Content: [],
          IsInterlude: true,
        });
      } else {
        lines.push({
          StartTime: ls,
          EndTime: le,
          Content: content,
          IsInterlude: false,
        });
      }
    }
  }

  lines.sort((a, b) => a.StartTime - b.StartTime);

  // Insert interlude lines between distant lyrics lines
  const withInterludes: SpicyLine[] = [];
  const THRESHOLD = 3;
  for (let i = 0; i < lines.length; i++) {
    if (i > 0 && lines[i].StartTime - lines[i - 1].EndTime >= THRESHOLD) {
      withInterludes.push({
        StartTime: lines[i - 1].EndTime,
        EndTime: lines[i].StartTime,
        Content: [],
        IsInterlude: true,
      });
    }
    withInterludes.push(lines[i]);
  }
  if (withInterludes.length > 0 && withInterludes[0].StartTime >= THRESHOLD) {
    withInterludes.unshift({
      StartTime: 0,
      EndTime: withInterludes[0].StartTime,
      Content: [],
      IsInterlude: true,
    });
  }

  const lastEnd = withInterludes.length
    ? withInterludes[withInterludes.length - 1].EndTime
    : 0;

  return {
    Type: "Syllable",
    title: meta.title,
    artists: meta.artists,
    album: meta.album,
    Content: withInterludes,
    duration: Math.max(bodyDur, lastEnd),
  };
}
