"use client";
import { create } from "zustand";
import type { RepeatMode, View } from "./types";

const PERSIST_KEY = "bl-spotify-state-v1";

interface PersistedState {
  volume: number;
  muted: boolean;
  shuffle: boolean;
  repeat: RepeatMode;
  activePlaylistId: string | null;
  playbackRate: number;
  crossfadeDuration: number; // seconds, 0 = off, max 12
  eqPreset: string;
  normalizeVolume: boolean;
  showFriendActivity: boolean;
}

const DEFAULT_PERSISTED: PersistedState = {
  volume: 0.7,
  muted: false,
  shuffle: false,
  repeat: "off",
  activePlaylistId: null,
  playbackRate: 1,
  crossfadeDuration: 0,
  eqPreset: "flat",
  normalizeVolume: false,
  showFriendActivity: false,
};

function loadPersisted(): Partial<PersistedState> {
  if (typeof window === "undefined") return {};
  try {
    const raw = window.localStorage.getItem(PERSIST_KEY);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

function savePersisted(state: PersistedState) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(PERSIST_KEY, JSON.stringify(state));
  } catch {}
}

interface AppStore extends PersistedState {
  // Player state (not persisted)
  currentTrackId: string | null;
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  queue: string[]; // track IDs
  queueIndex: number;
  history: string[]; // recently played track IDs

  // UI state
  view: View;
  searchQuery: string;
  showQueue: boolean;
  showRightPanel: boolean;
  sidebarCollapsed: boolean;
  showNowPlaying: boolean;
  showMobileSidebar: boolean;
  showMiniPlayer: boolean;
  showSleepTimer: boolean;
  showShareModal: boolean;
  showShortcutsHelp: boolean;
  showSettings: boolean;
  sharePayload: { type: "track" | "playlist"; id: string; title: string; subtitle?: string } | null;
  sleepTimer: { endsAt: number; trackId: string | null } | null;

  // Setters
  setVolume: (v: number) => void;
  setMuted: (v: boolean) => void;
  setShuffle: (v: boolean) => void;
  setRepeat: (v: RepeatMode) => void;
  setActivePlaylistId: (id: string | null) => void;
  setPlaybackRate: (rate: number) => void;
  setCrossfadeDuration: (s: number) => void;
  setEqPreset: (p: string) => void;
  setNormalizeVolume: (v: boolean) => void;
  setShowFriendActivity: (v: boolean) => void;

  setView: (v: View) => void;
  setSearchQuery: (q: string) => void;
  setShowQueue: (v: boolean) => void;
  setShowRightPanel: (v: boolean) => void;
  setSidebarCollapsed: (v: boolean) => void;
  setShowNowPlaying: (v: boolean) => void;
  setShowMobileSidebar: (v: boolean) => void;
  setShowMiniPlayer: (v: boolean) => void;
  setShowSleepTimer: (v: boolean) => void;
  setShowShareModal: (v: boolean) => void;
  setShowShortcutsHelp: (v: boolean) => void;
  setShowSettings: (v: boolean) => void;
  setSharePayload: (p: AppStore["sharePayload"]) => void;
  setSleepTimer: (t: AppStore["sleepTimer"]) => void;

  setCurrentTrack: (id: string | null) => void;
  setIsPlaying: (v: boolean) => void;
  setCurrentTime: (t: number) => void;
  setDuration: (d: number) => void;

  setQueue: (ids: string[], startIndex?: number) => void;
  nextInQueue: () => string | null;
  prevInQueue: () => string | null;
  addToHistory: (id: string) => void;
  removeFromQueue: (trackId: string) => void;
  clearQueue: () => void;
  reorderQueue: (fromIndex: number, toIndex: number) => void;
  addToQueueNext: (trackId: string) => void;

  reset: () => void;
}

export const useAppStore = create<AppStore>((set, get) => ({
  ...DEFAULT_PERSISTED,
  ...loadPersisted(),

  currentTrackId: null,
  isPlaying: false,
  currentTime: 0,
  duration: 0,
  queue: [],
  queueIndex: -1,
  history: [],

  view: { type: "home" },
  searchQuery: "",
  showQueue: false,
  showRightPanel: true,
  sidebarCollapsed: false,
  showNowPlaying: false,
  showMobileSidebar: false,
  showMiniPlayer: false,
  showSleepTimer: false,
  showShareModal: false,
  showShortcutsHelp: false,
  showSettings: false,
  sharePayload: null,
  sleepTimer: null,

  setVolume: (v) => { set({ volume: v }); persist(get()); },
  setMuted: (v) => { set({ muted: v }); persist(get()); },
  setShuffle: (v) => { set({ shuffle: v }); persist(get()); },
  setRepeat: (v) => { set({ repeat: v }); persist(get()); },
  setActivePlaylistId: (id) => { set({ activePlaylistId: id }); persist(get()); },
  setPlaybackRate: (rate) => { set({ playbackRate: rate }); persist(get()); },
  setCrossfadeDuration: (s) => { set({ crossfadeDuration: Math.max(0, Math.min(12, s)) }); persist(get()); },
  setEqPreset: (p) => { set({ eqPreset: p }); persist(get()); },
  setNormalizeVolume: (v) => { set({ normalizeVolume: v }); persist(get()); },
  setShowFriendActivity: (v) => { set({ showFriendActivity: v }); persist(get()); },

  setView: (v) => set({ view: v }),
  setSearchQuery: (q) => set({ searchQuery: q }),
  setShowQueue: (v) => set({ showQueue: v }),
  setShowRightPanel: (v) => set({ showRightPanel: v }),
  setSidebarCollapsed: (v) => set({ sidebarCollapsed: v }),
  setShowNowPlaying: (v) => set({ showNowPlaying: v }),
  setShowMobileSidebar: (v) => set({ showMobileSidebar: v }),
  setShowMiniPlayer: (v) => set({ showMiniPlayer: v }),
  setShowSleepTimer: (v) => set({ showSleepTimer: v }),
  setShowShareModal: (v) => set({ showShareModal: v }),
  setShowShortcutsHelp: (v) => set({ showShortcutsHelp: v }),
  setShowSettings: (v) => set({ showSettings: v }),
  setSharePayload: (p) => set({ sharePayload: p }),
  setSleepTimer: (t) => set({ sleepTimer: t }),

  setCurrentTrack: (id) => set({ currentTrackId: id }),
  setIsPlaying: (v) => set({ isPlaying: v }),
  setCurrentTime: (t) => set({ currentTime: t }),
  setDuration: (d) => set({ duration: d }),

  setQueue: (ids, startIndex = 0) => set({ queue: ids, queueIndex: startIndex }),
  nextInQueue: () => {
    const s = get();
    if (s.shuffle && s.queue.length > 1) {
      let r = s.queueIndex;
      while (r === s.queueIndex) r = Math.floor(Math.random() * s.queue.length);
      set({ queueIndex: r });
      return s.queue[r];
    }
    if (s.queueIndex + 1 < s.queue.length) {
      const next = s.queueIndex + 1;
      set({ queueIndex: next });
      return s.queue[next];
    }
    if (s.repeat === "all" && s.queue.length > 0) {
      set({ queueIndex: 0 });
      return s.queue[0];
    }
    return null;
  },
  prevInQueue: () => {
    const s = get();
    if (s.queueIndex > 0) {
      const prev = s.queueIndex - 1;
      set({ queueIndex: prev });
      return s.queue[prev];
    }
    return null;
  },
  addToHistory: (id) => {
    const s = get();
    const filtered = s.history.filter(h => h !== id);
    set({ history: [id, ...filtered].slice(0, 50) });
  },
  removeFromQueue: (trackId) => {
    const s = get();
    const idx = s.queue.indexOf(trackId);
    if (idx < 0) return;
    const newQueue = s.queue.filter(id => id !== trackId);
    let newIndex = s.queueIndex;
    if (idx < s.queueIndex) newIndex = s.queueIndex - 1;
    else if (idx === s.queueIndex) newIndex = Math.max(0, s.queueIndex - 1);
    if (newIndex >= newQueue.length) newIndex = newQueue.length - 1;
    set({ queue: newQueue, queueIndex: newQueue.length === 0 ? -1 : newIndex });
  },
  clearQueue: () => {
    const s = get();
    const current = s.queueIndex >= 0 && s.queueIndex < s.queue.length ? [s.queue[s.queueIndex]] : [];
    set({ queue: current, queueIndex: current.length > 0 ? 0 : -1 });
  },
  reorderQueue: (fromIndex, toIndex) => {
    const s = get();
    if (fromIndex < 0 || fromIndex >= s.queue.length) return;
    if (toIndex < 0 || toIndex >= s.queue.length) return;
    if (fromIndex === toIndex) return;
    const newQueue = [...s.queue];
    const [moved] = newQueue.splice(fromIndex, 1);
    newQueue.splice(toIndex, 0, moved);
    let newIndex = s.queueIndex;
    if (fromIndex === s.queueIndex) newIndex = toIndex;
    else if (fromIndex < s.queueIndex && toIndex >= s.queueIndex) newIndex = s.queueIndex - 1;
    else if (fromIndex > s.queueIndex && toIndex <= s.queueIndex) newIndex = s.queueIndex + 1;
    set({ queue: newQueue, queueIndex: newIndex });
  },
  addToQueueNext: (trackId) => {
    const s = get();
    if (s.queue.includes(trackId)) return;
    const insertAt = s.queueIndex + 1;
    const newQueue = [...s.queue];
    newQueue.splice(insertAt, 0, trackId);
    set({ queue: newQueue });
  },

  reset: () => {
    set({ ...DEFAULT_PERSISTED });
    savePersisted(DEFAULT_PERSISTED);
  },
}));

function persist(state: AppStore) {
  const persisted: PersistedState = {
    volume: state.volume,
    muted: state.muted,
    shuffle: state.shuffle,
    repeat: state.repeat,
    activePlaylistId: state.activePlaylistId,
    playbackRate: state.playbackRate,
    crossfadeDuration: state.crossfadeDuration,
    eqPreset: state.eqPreset,
    normalizeVolume: state.normalizeVolume,
    showFriendActivity: state.showFriendActivity,
  };
  savePersisted(persisted);
}

let pt: any;
useAppStore.subscribe(() => {
  if (pt) clearTimeout(pt);
  pt = setTimeout(() => persist(useAppStore.getState()), 600);
});

if (typeof window !== "undefined") {
  (window as any).__useAppStore = useAppStore;
}
