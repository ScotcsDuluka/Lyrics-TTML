"use client";
import { useEffect, useRef, useState, useCallback } from "react";

interface AudioAnalyzerState {
  frequencyData: Uint8Array;
  waveformData: Uint8Array;
  isActive: boolean;
}

interface AudioAnalyzerControls {
  start: () => void;
  stop: () => void;
  analyserNode: AnalyserNode | null;
}

export function useAudioAnalyzer(
  audioRef: React.RefObject<HTMLAudioElement | null>,
  audioCtxRef: React.RefObject<AudioContext | null>,
  sourceNodeRef: React.RefObject<MediaElementAudioSourceNode | null>,
  fftSize: number = 256
): [AudioAnalyzerState, AudioAnalyzerControls] {
  const [state, setState] = useState<AudioAnalyzerState>({
    frequencyData: new Uint8Array(fftSize / 2),
    waveformData: new Uint8Array(fftSize / 2),
    isActive: false,
  });

  const analyserNodeRef = useRef<AnalyserNode | null>(null);
  const animationFrameRef = useRef<number | null>(null);
  const tickRef = useRef<() => void>(() => {});

  // Lazily initialize the AnalyserNode and connect it to the audio graph
  const ensureAnalyser = useCallback((): AnalyserNode | null => {
    if (analyserNodeRef.current) return analyserNodeRef.current;

    const audioCtx = audioCtxRef.current;
    const sourceNode = sourceNodeRef.current;

    if (!audioCtx || !sourceNode) return null;

    const analyser = audioCtx.createAnalyser();
    analyser.fftSize = fftSize;
    analyser.smoothingTimeConstant = 0.8;

    // Connect: source -> analyser -> destination
    sourceNode.connect(analyser);
    analyser.connect(audioCtx.destination);

    analyserNodeRef.current = analyser;

    // Resize our data arrays to match the new analyser
    const bufferLength = analyser.frequencyBinCount;
    setState((prev) => ({
      ...prev,
      frequencyData: new Uint8Array(bufferLength),
      waveformData: new Uint8Array(bufferLength),
    }));

    return analyser;
  }, [audioCtxRef, sourceNodeRef, fftSize]);

  // Animation loop that reads frequency and waveform data at ~60fps
  const tick = useCallback(() => {
    const analyser = analyserNodeRef.current;
    if (!analyser) return;

    const bufferLength = analyser.frequencyBinCount;
    const frequencyData = new Uint8Array(bufferLength);
    const waveformData = new Uint8Array(bufferLength);

    analyser.getByteFrequencyData(frequencyData);
    analyser.getByteTimeDomainData(waveformData);

    setState((prev) => ({
      ...prev,
      frequencyData,
      waveformData,
    }));

    animationFrameRef.current = requestAnimationFrame(tickRef.current);
  }, []);

  // Keep tickRef in sync
  useEffect(() => {
    tickRef.current = tick;
  }, [tick]);

  const start = useCallback(() => {
    // Only start if not already running
    if (animationFrameRef.current !== null) return;

    const analyser = ensureAnalyser();
    if (!analyser) return;

    setState((prev) => ({ ...prev, isActive: true }));
    animationFrameRef.current = requestAnimationFrame(tickRef.current);
  }, [ensureAnalyser]);

  const stop = useCallback(() => {
    if (animationFrameRef.current !== null) {
      cancelAnimationFrame(animationFrameRef.current);
      animationFrameRef.current = null;
    }
    setState((prev) => ({ ...prev, isActive: false }));
  }, []);

  // Cleanup on unmount: cancel animation frame and disconnect analyser
  useEffect(() => {
    return () => {
      if (animationFrameRef.current !== null) {
        cancelAnimationFrame(animationFrameRef.current);
        animationFrameRef.current = null;
      }

      if (analyserNodeRef.current) {
        analyserNodeRef.current.disconnect();
        analyserNodeRef.current = null;
      }
    };
  }, []);

  return [
    state,
    {
      start,
      stop,
      get analyserNode() { return analyserNodeRef.current; },
    },
  ];
}
