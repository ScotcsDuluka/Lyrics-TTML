"use client";
import { useMemo, useState } from "react";
import {
  Podcast, Play, Pause, Headphones, BookOpen, Mic, Radio, Clock,
  Heart, Download, MoreHorizontal, Search, TrendingUp, Flame, Sparkles,
  ChevronRight, Bookmark, Star, Plus
} from "lucide-react";

/* ------------------------------------------------------------------ */
/*  Types & mock data                                                  */
/* ------------------------------------------------------------------ */

interface PodcastShow {
  id: string;
  title: string;
  author: string;
  description: string;
  category: string;
  coverGradient: string;
  episodes: number;
  rating: number;
  subscribed: boolean;
  trending?: boolean;
  newEpisodes?: number;
}

interface PodcastEpisode {
  id: string;
  showId: string;
  showTitle: string;
  showAuthor: string;
  coverGradient: string;
  title: string;
  description: string;
  durationSec: number;
  publishedAt: string; // ISO
  category: string;
  played?: boolean;
  inProgress?: number; // 0-1 progress
}

const CATEGORIES = [
  { id: "all", label: "All", icon: <Sparkles size={14} /> },
  { id: "tech", label: "Technology", icon: <TrendingUp size={14} /> },
  { id: "business", label: "Business", icon: <Flame size={14} /> },
  { id: "science", label: "Science", icon: <BookOpen size={14} /> },
  { id: "culture", label: "Culture", icon: <Mic size={14} /> },
  { id: "stories", label: "Stories", icon: <Radio size={14} /> },
];

const SHOWS: PodcastShow[] = [
  {
    id: "s1",
    title: "Tech Frontiers Daily",
    author: "Aria Chen",
    description: "Daily 15-minute dives into the technology shaping tomorrow — from AI breakthroughs to quantum computing.",
    category: "tech",
    coverGradient: "from-violet-600 via-purple-700 to-fuchsia-800",
    episodes: 245,
    rating: 4.8,
    subscribed: true,
    trending: true,
    newEpisodes: 3,
  },
  {
    id: "s2",
    title: "Founder Stories",
    author: "Marcus Reed",
    description: "Unfiltered conversations with the founders building the next generation of unicorn startups.",
    category: "business",
    coverGradient: "from-amber-500 via-orange-600 to-red-700",
    episodes: 132,
    rating: 4.9,
    subscribed: true,
    newEpisodes: 1,
  },
  {
    id: "s3",
    title: "The Lab Notebook",
    author: "Dr. Priya Iyer",
    description: "Science made simple. Each week, we break down one peer-reviewed paper into a 30-minute story.",
    category: "science",
    coverGradient: "from-emerald-500 via-teal-600 to-cyan-800",
    episodes: 87,
    rating: 4.7,
    subscribed: false,
    trending: true,
  },
  {
    id: "s4",
    title: "Sound & Vision",
    author: "Lena Park",
    description: "Cultural commentary on music, film, and the artists redefining the creative landscape.",
    category: "culture",
    coverGradient: "from-pink-500 via-rose-600 to-fuchsia-800",
    episodes: 198,
    rating: 4.6,
    subscribed: true,
    newEpisodes: 2,
  },
  {
    id: "s5",
    title: "Midnight Tales",
    author: "Cole Reeves",
    description: "Original short fiction stories narrated for late-night listening. New tale every Friday.",
    category: "stories",
    coverGradient: "from-indigo-600 via-blue-800 to-violet-900",
    episodes: 76,
    rating: 4.9,
    subscribed: false,
  },
  {
    id: "s6",
    title: "Code & Coffee",
    author: "Sam Wittevrongel",
    description: "Two developers, one coffee, and the programming topics you wish your team would discuss.",
    category: "tech",
    coverGradient: "from-cyan-500 via-sky-700 to-blue-900",
    episodes: 154,
    rating: 4.5,
    subscribed: false,
    trending: true,
  },
  {
    id: "s7",
    title: "Market Movers",
    author: "Diana Wells",
    description: "Weekly analysis of the markets, deals, and economic shifts driving global business.",
    category: "business",
    coverGradient: "from-yellow-500 via-amber-700 to-orange-900",
    episodes: 110,
    rating: 4.4,
    subscribed: false,
  },
  {
    id: "s8",
    title: "Untold Histories",
    author: "Aaron Mendoza",
    description: "The stories your textbooks skipped — forgotten revolutions, hidden figures, and untold moments.",
    category: "culture",
    coverGradient: "from-rose-500 via-red-700 to-rose-900",
    episodes: 64,
    rating: 4.8,
    subscribed: false,
  },
];

const EPISODES: PodcastEpisode[] = [
  {
    id: "e1", showId: "s1", showTitle: "Tech Frontiers Daily", showAuthor: "Aria Chen",
    coverGradient: "from-violet-600 via-purple-700 to-fuchsia-800",
    title: "Why LLMs Hit a Wall — and What Comes Next",
    description: "Aria unpacks the recent plateau in large-language-model scaling and surveys the post-LLM architectures researchers are betting on.",
    durationSec: 912, publishedAt: "2025-07-29T08:00:00Z", category: "tech",
    inProgress: 0.34,
  },
  {
    id: "e2", showId: "s2", showTitle: "Founder Stories", showAuthor: "Marcus Reed",
    coverGradient: "from-amber-500 via-orange-600 to-red-700",
    title: "From Garage to Global: The Nimbus AI Origin Story",
    description: "Nimbus co-founder Jess Lim shares the painful early years, the pivot that saved them, and the lesson every founder should hear.",
    durationSec: 2734, publishedAt: "2025-07-28T16:00:00Z", category: "business",
  },
  {
    id: "e3", showId: "s4", showTitle: "Sound & Vision", showAuthor: "Lena Park",
    coverGradient: "from-pink-500 via-rose-600 to-fuchsia-800",
    title: "The Vinyl Revival Was Never About Vinyl",
    description: "Why physical media sales keep climbing in an all-streaming world — and what it tells us about music listeners in 2025.",
    durationSec: 1845, publishedAt: "2025-07-27T14:00:00Z", category: "culture",
    inProgress: 0.72,
  },
  {
    id: "e4", showId: "s3", showTitle: "The Lab Notebook", showAuthor: "Dr. Priya Iyer",
    coverGradient: "from-emerald-500 via-teal-600 to-cyan-800",
    title: "CRISPR's Next Decade: Editing Beyond Disease",
    description: "Dr. Iyer walks through a landmark Nature paper on the future of gene editing in agriculture and ecology.",
    durationSec: 2106, publishedAt: "2025-07-26T09:00:00Z", category: "science",
  },
  {
    id: "e5", showId: "s5", showTitle: "Midnight Tales", showAuthor: "Cole Reeves",
    coverGradient: "from-indigo-600 via-blue-800 to-violet-900",
    title: "The Lighthouse Keeper's Last Letter",
    description: "A 28-minute gothic short story about a lighthouse keeper who receives a message from a ship that vanished 50 years ago.",
    durationSec: 1680, publishedAt: "2025-07-25T22:00:00Z", category: "stories",
  },
  {
    id: "e6", showId: "s6", showTitle: "Code & Coffee", showAuthor: "Sam Wittevrongel",
    coverGradient: "from-cyan-500 via-sky-700 to-blue-900",
    title: "Bun, Deno, Node: A Speed Test Reality Check",
    description: "Sam and Dev run real-world workloads through three JavaScript runtimes and discover the numbers don't match the hype.",
    durationSec: 3420, publishedAt: "2025-07-24T12:00:00Z", category: "tech",
  },
  {
    id: "e7", showId: "s1", showTitle: "Tech Frontiers Daily", showAuthor: "Aria Chen",
    coverGradient: "from-violet-600 via-purple-700 to-fuchsia-800",
    title: "Inside the OpenAI-vs-Anthropic Talent War",
    description: "Why top researchers are jumping ship between the two leading AI labs — and what it means for the rest of us.",
    durationSec: 1080, publishedAt: "2025-07-23T08:00:00Z", category: "tech",
    played: true,
  },
  {
    id: "e8", showId: "s8", showTitle: "Untold Histories", showAuthor: "Aaron Mendoza",
    coverGradient: "from-rose-500 via-red-700 to-rose-900",
    title: "The Queen Who Invented WiFi (Almost)",
    description: "The 1940s Hollywood actress whose frequency-hopping patent laid the groundwork for modern wireless.",
    durationSec: 1950, publishedAt: "2025-07-22T17:00:00Z", category: "culture",
  },
];

/* ------------------------------------------------------------------ */
/*  Helpers                                                            */
/* ------------------------------------------------------------------ */

function formatDuration(sec: number): string {
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  if (h > 0) return `${h}h ${m}m`;
  return `${m}m`;
}

function relativeTime(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime();
  const day = 24 * 60 * 60 * 1000;
  const days = Math.floor(diff / day);
  if (days === 0) return "Today";
  if (days === 1) return "Yesterday";
  if (days < 7) return `${days}d ago`;
  const weeks = Math.floor(days / 7);
  if (weeks < 5) return `${weeks}w ago`;
  return new Date(iso).toLocaleDateString("en-US", { month: "short", day: "numeric" });
}

/* ------------------------------------------------------------------ */
/*  Component                                                          */
/* ------------------------------------------------------------------ */

interface Props {
  onPlayEpisode?: (episode: PodcastEpisode) => void;
}

export function PodcastsView({ onPlayEpisode }: Props) {
  const [category, setCategory] = useState<string>("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [playingId, setPlayingId] = useState<string | null>(null);
  const [subscribedFilter, setSubscribedFilter] = useState(false);
  const [bookmarkedIds, setBookmarkedIds] = useState<Set<string>>(new Set(["e2", "e5"]));

  const togglePlay = (ep: PodcastEpisode) => {
    if (playingId === ep.id) {
      setPlayingId(null);
    } else {
      setPlayingId(ep.id);
      onPlayEpisode?.(ep);
    }
  };

  const toggleBookmark = (id: string) => {
    setBookmarkedIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const filteredShows = useMemo(() => {
    let list = SHOWS;
    if (category !== "all") list = list.filter(s => s.category === category);
    if (subscribedFilter) list = list.filter(s => s.subscribed);
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      list = list.filter(s => s.title.toLowerCase().includes(q) || s.author.toLowerCase().includes(q));
    }
    return list;
  }, [category, subscribedFilter, searchQuery]);

  const filteredEpisodes = useMemo(() => {
    let list = EPISODES;
    if (category !== "all") list = list.filter(e => e.category === category);
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      list = list.filter(e => e.title.toLowerCase().includes(q) || e.showTitle.toLowerCase().includes(q));
    }
    return list;
  }, [category, searchQuery]);

  const subscribedShows = SHOWS.filter(s => s.subscribed);
  const trendingShows = SHOWS.filter(s => s.trending);
  const continueEpisodes = EPISODES.filter(e => e.inProgress && e.inProgress < 1);
  const newEpisodes = EPISODES.filter(e => !e.played && !e.inProgress).slice(0, 4);

  const totalSubscribedTime = subscribedShows.reduce((sum, s) => sum + s.episodes * 25 * 60, 0);
  const totalHours = Math.floor(totalSubscribedTime / 3600);

  return (
    <div className="bl-scroll flex-1 px-6 pb-10 bl-view-transition">
      {/* Hero header */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-indigo-900/60 via-purple-900/40 to-fuchsia-900/30 px-6 pt-10 pb-8 mb-6">
        <div className="pointer-events-none absolute inset-0 -z-10 opacity-50">
          <div className="absolute -top-20 -left-20 h-60 w-60 rounded-full bg-purple-500/30 blur-3xl" />
          <div className="absolute -bottom-20 -right-20 h-60 w-60 rounded-full bg-fuchsia-500/30 blur-3xl" />
        </div>
        <div className="flex items-center gap-4">
          <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-purple-500 to-fuchsia-600 shadow-lg shadow-purple-500/30">
            <Podcast size={32} className="text-white" />
          </div>
          <div>
            <div className="text-xs font-bold uppercase tracking-wider text-white/70">Podcasts & Shows</div>
            <h1 className="mt-1 text-3xl font-extrabold tracking-tight text-white sm:text-4xl bl-gradient-text">
              Podcasts & Audiobooks
            </h1>
            <p className="mt-1 text-sm text-white/70">
              {subscribedShows.length} subscriptions • {EPISODES.length} episodes • ~{totalHours}h of content
            </p>
          </div>
        </div>
      </div>

      {/* Search bar */}
      <div className="mb-4 flex items-center gap-3">
        <div className="relative flex-1">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--sp-text-subdued)]" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search podcasts, episodes, or hosts"
            className="w-full rounded-full border border-white/10 bg-white/5 py-2 pl-9 pr-4 text-sm text-white placeholder:text-[var(--sp-text-subdued)] focus:border-purple-500/40 focus:outline-none focus:ring-2 focus:ring-purple-500/20"
          />
        </div>
        <button
          onClick={() => setSubscribedFilter(v => !v)}
          className={`rounded-full px-4 py-2 text-xs font-bold transition-all ${
            subscribedFilter
              ? "bg-purple-500 text-white shadow-lg shadow-purple-500/30"
              : "bg-white/5 text-[var(--sp-text-subdued)] hover:bg-white/10 hover:text-white"
          }`}
        >
          Subscribed only
        </button>
      </div>

      {/* Category pills */}
      <div className="mb-6 flex flex-wrap gap-2">
        {CATEGORIES.map(cat => (
          <button
            key={cat.id}
            onClick={() => setCategory(cat.id)}
            className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-bold transition-all ${
              category === cat.id
                ? "bg-white text-black shadow-lg"
                : "bg-white/5 text-[var(--sp-text-subdued)] hover:bg-white/10 hover:text-white"
            }`}
          >
            {cat.icon}
            {cat.label}
          </button>
        ))}
      </div>

      {/* Continue listening */}
      {continueEpisodes.length > 0 && !searchQuery && (
        <section className="mb-8">
          <h2 className="mb-3 text-lg font-bold text-white">Continue listening</h2>
          <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
            {continueEpisodes.map(ep => (
              <EpisodeCard
                key={ep.id}
                episode={ep}
                isPlaying={playingId === ep.id}
                isBookmarked={bookmarkedIds.has(ep.id)}
                onTogglePlay={() => togglePlay(ep)}
                onToggleBookmark={() => toggleBookmark(ep.id)}
                showProgress
                progress={ep.inProgress}
                variant="large"
              />
            ))}
          </div>
        </section>
      )}

      {/* New episodes */}
      {newEpisodes.length > 0 && !searchQuery && (
        <section className="mb-8">
          <div className="mb-3 flex items-center justify-between">
            <h2 className="flex items-center gap-2 text-lg font-bold text-white">
              <Sparkles size={18} className="text-purple-400" />
              New episodes
            </h2>
            <span className="text-[10px] text-[var(--sp-text-subdued)]">From your subscriptions</span>
          </div>
          <div className="space-y-2">
            {newEpisodes.map(ep => (
              <EpisodeRow
                key={ep.id}
                episode={ep}
                isPlaying={playingId === ep.id}
                isBookmarked={bookmarkedIds.has(ep.id)}
                onTogglePlay={() => togglePlay(ep)}
                onToggleBookmark={() => toggleBookmark(ep.id)}
              />
            ))}
          </div>
        </section>
      )}

      {/* Trending shows */}
      {trendingShows.length > 0 && !searchQuery && (
        <section className="mb-8">
          <div className="mb-3 flex items-center gap-2">
            <TrendingUp size={18} className="text-emerald-400" />
            <h2 className="text-lg font-bold text-white">Trending now</h2>
          </div>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6">
            {trendingShows.map(show => (
              <ShowCard key={show.id} show={show} />
            ))}
          </div>
        </section>
      )}

      {/* All episodes (filtered) */}
      <section className="mb-8">
        <div className="mb-3 flex items-center justify-between">
          <h2 className="text-lg font-bold text-white">
            {searchQuery ? `Results for "${searchQuery}"` : "Latest episodes"}
          </h2>
          <span className="text-[10px] text-[var(--sp-text-subdued)]">{filteredEpisodes.length} episodes</span>
        </div>
        <div className="space-y-1.5">
          {filteredEpisodes.map(ep => (
            <EpisodeRow
              key={ep.id}
              episode={ep}
              isPlaying={playingId === ep.id}
              isBookmarked={bookmarkedIds.has(ep.id)}
              onTogglePlay={() => togglePlay(ep)}
              onToggleBookmark={() => toggleBookmark(ep.id)}
            />
          ))}
        </div>
      </section>

      {/* All shows (filtered) */}
      <section>
        <div className="mb-3 flex items-center justify-between">
          <h2 className="text-lg font-bold text-white">Browse shows</h2>
          <span className="text-[10px] text-[var(--sp-text-subdued)]">{filteredShows.length} shows</span>
        </div>
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
          {filteredShows.map(show => (
            <ShowCard key={show.id} show={show} detailed />
          ))}
        </div>
      </section>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Sub-components                                                     */
/* ------------------------------------------------------------------ */

function ShowCard({ show, detailed }: { show: PodcastShow; detailed?: boolean }) {
  return (
    <div className="group cursor-pointer rounded-xl bg-white/[0.03] p-3 transition-all hover:bg-white/[0.06] hover:shadow-lg">
      <div className={`relative mb-3 aspect-square w-full overflow-hidden rounded-lg bg-gradient-to-br ${show.coverGradient} shadow-lg`}>
        <div className="absolute inset-0 flex items-center justify-center">
          <Podcast size={36} className="text-white/80" />
        </div>
        {/* Overlay play button on hover */}
        <div className="absolute inset-0 flex items-end justify-end p-3 opacity-0 transition-opacity group-hover:opacity-100">
          <div className="flex h-11 w-11 items-center justify-center rounded-full bg-emerald-500 text-black shadow-xl shadow-emerald-500/40 transition-transform group-hover:translate-y-0 translate-y-2">
            <Play size={20} fill="currentColor" className="ml-0.5" />
          </div>
        </div>
        {/* NEW badge */}
        {show.newEpisodes && show.newEpisodes > 0 && (
          <div className="absolute left-2 top-2 rounded-full bg-rose-500 px-2 py-0.5 text-[9px] font-bold text-white shadow-lg">
            {show.newEpisodes} NEW
          </div>
        )}
        {show.trending && !show.newEpisodes && (
          <div className="absolute left-2 top-2 rounded-full bg-emerald-500 px-2 py-0.5 text-[9px] font-bold text-white shadow-lg">
            TRENDING
          </div>
        )}
      </div>
      <h3 className="truncate text-sm font-bold text-white">{show.title}</h3>
      <p className="truncate text-xs text-[var(--sp-text-subdued)]">{show.author}</p>
      {detailed && (
        <div className="mt-2 flex items-center gap-2 text-[10px] text-[var(--sp-text-subdued)]">
          <span className="inline-flex items-center gap-0.5">
            <Star size={10} className="text-amber-400" fill="currentColor" />
            {show.rating}
          </span>
          <span>•</span>
          <span>{show.episodes} eps</span>
          {show.subscribed && (
            <>
              <span>•</span>
              <span className="font-bold text-emerald-400">Subscribed</span>
            </>
          )}
        </div>
      )}
    </div>
  );
}

function EpisodeRow({
  episode, isPlaying, isBookmarked, onTogglePlay, onToggleBookmark,
}: {
  episode: PodcastEpisode;
  isPlaying: boolean;
  isBookmarked: boolean;
  onTogglePlay: () => void;
  onToggleBookmark: () => void;
}) {
  return (
    <div className="group flex items-center gap-3 rounded-lg p-2 transition-colors hover:bg-white/5">
      {/* Cover with play button */}
      <button
        onClick={onTogglePlay}
        className={`relative h-14 w-14 shrink-0 overflow-hidden rounded-lg bg-gradient-to-br ${episode.coverGradient} shadow-md`}
      >
        <div className="absolute inset-0 flex items-center justify-center">
          <Podcast size={20} className="text-white/80" />
        </div>
        <div className="absolute inset-0 flex items-center justify-center bg-black/50 opacity-0 transition-opacity group-hover:opacity-100">
          {isPlaying ? <Pause size={18} className="text-white" /> : <Play size={18} fill="currentColor" className="ml-0.5 text-white" />}
        </div>
        {isPlaying && (
          <div className="absolute bottom-1 right-1 flex h-4 w-4 items-center justify-center rounded-full bg-emerald-500">
            <div className="flex items-end gap-[2px] h-2">
              <div className="bl-eq-bar w-[2px] bg-white" style={{ animationDelay: "0ms", height: "60%" }} />
              <div className="bl-eq-bar w-[2px] bg-white" style={{ animationDelay: "150ms", height: "100%" }} />
              <div className="bl-eq-bar w-[2px] bg-white" style={{ animationDelay: "300ms", height: "40%" }} />
            </div>
          </div>
        )}
      </button>

      {/* Info */}
      <div className="min-w-0 flex-1">
        <div className="truncate text-[10px] font-bold uppercase tracking-wider text-purple-400">{episode.showTitle}</div>
        <div className={`truncate text-sm font-medium ${episode.played ? "text-[var(--sp-text-subdued)]" : "text-white"}`}>
          {episode.title}
        </div>
        <div className="mt-0.5 truncate text-xs text-[var(--sp-text-subdued)]">
          {episode.description}
        </div>
        {episode.inProgress && (
          <div className="mt-1.5 h-0.5 w-full overflow-hidden rounded-full bg-white/10">
            <div
              className="h-full rounded-full bg-gradient-to-r from-purple-500 to-fuchsia-400"
              style={{ width: `${episode.inProgress * 100}%` }}
            />
          </div>
        )}
      </div>

      {/* Actions */}
      <div className="flex shrink-0 items-center gap-1">
        <button
          onClick={onToggleBookmark}
          className={`rounded-full p-2 transition-all hover:bg-white/10 ${
            isBookmarked ? "text-amber-400" : "text-[var(--sp-text-subdued)] hover:text-white opacity-0 group-hover:opacity-100"
          }`}
          aria-label="Bookmark"
        >
          <Bookmark size={14} fill={isBookmarked ? "currentColor" : "none"} />
        </button>
        <button
          className="rounded-full p-2 text-[var(--sp-text-subdued)] transition-all hover:bg-white/10 hover:text-white opacity-0 group-hover:opacity-100"
          aria-label="Download"
        >
          <Download size={14} />
        </button>
        <button
          className="rounded-full p-2 text-[var(--sp-text-subdued)] transition-all hover:bg-white/10 hover:text-white opacity-0 group-hover:opacity-100"
          aria-label="More"
        >
          <MoreHorizontal size={14} />
        </button>
        <span className="ml-1 shrink-0 text-xs text-[var(--sp-text-subdued)] tabular-nums">
          {formatDuration(episode.durationSec)}
        </span>
      </div>
    </div>
  );
}

function EpisodeCard({
  episode, isPlaying, isBookmarked, onTogglePlay, onToggleBookmark, showProgress, progress, variant,
}: {
  episode: PodcastEpisode;
  isPlaying: boolean;
  isBookmarked: boolean;
  onTogglePlay: () => void;
  onToggleBookmark: () => void;
  showProgress?: boolean;
  progress?: number;
  variant?: "large";
}) {
  return (
    <div className={`group relative overflow-hidden rounded-xl border border-white/5 bg-gradient-to-br ${episode.coverGradient} p-0.5 shadow-lg`}>
      <div className="rounded-[10px] bg-black/50 backdrop-blur-xl p-4">
        <div className="flex items-start gap-3">
          <button
            onClick={onTogglePlay}
            className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-white text-black shadow-xl transition-transform hover:scale-105"
          >
            {isPlaying ? <Pause size={20} fill="currentColor" /> : <Play size={20} fill="currentColor" className="ml-0.5" />}
          </button>
          <div className="min-w-0 flex-1">
            <div className="truncate text-[10px] font-bold uppercase tracking-wider text-white/70">{episode.showTitle}</div>
            <h3 className="truncate text-base font-bold text-white">{episode.title}</h3>
            <p className="mt-1 line-clamp-2 text-xs text-white/70">{episode.description}</p>
            <div className="mt-2 flex items-center gap-2 text-[10px] text-white/60">
              <Clock size={10} />
              <span>{formatDuration(episode.durationSec)}</span>
              <span>•</span>
              <span>{relativeTime(episode.publishedAt)}</span>
            </div>
          </div>
          <button
            onClick={onToggleBookmark}
            className={`shrink-0 rounded-full p-1.5 transition-all hover:bg-white/10 ${isBookmarked ? "text-amber-400" : "text-white/60"}`}
            aria-label="Bookmark"
          >
            <Bookmark size={14} fill={isBookmarked ? "currentColor" : "none"} />
          </button>
        </div>
        {showProgress && progress !== undefined && (
          <div className="mt-3">
            <div className="mb-1 flex items-center justify-between text-[10px] text-white/70">
              <span>{Math.round(progress * 100)}% complete</span>
              <span>{formatDuration(Math.floor(episode.durationSec * (1 - progress)))} left</span>
            </div>
            <div className="h-1 w-full overflow-hidden rounded-full bg-white/20">
              <div
                className="h-full rounded-full bg-gradient-to-r from-emerald-400 to-teal-300"
                style={{ width: `${progress * 100}%` }}
              />
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
