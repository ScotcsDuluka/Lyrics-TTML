"use client";
import { useState } from "react";
import {
  Play, Pause, SkipForward, SkipBack, X, ChevronDown, ChevronUp,
  Volume2, VolumeX, Heart, Maximize2, ListMusic,
} from "lucide-react";
import type { Track, RepeatMode } from "@/lib/types";

interface Props {
  track: Track | null;
  currentTime: number;
  duration: number;
  isPlaying: boolean;
  volume: number;
  muted: boolean;
  shuffle: boolean;
  repeat: RepeatMode;
  isLiked: boolean;
  onToggle: () => void;
  onSeek: (s: number) => void;
  onPrev: () => void;
  onNext: () => void;
  onVolume: (v: number) => void;
  onToggleMute: () => void;
  onToggleShuffle: () => void;
  onToggleRepeat: () => void;
  onToggleLike: () => void;
  onClose: () => void;
  onExpand: () => void;
}

function fmt(s: number): string {
  if (!isFinite(s) || s < 0) return "0:00";
  const t = Math.floor(s);
  return `${Math.floor(t/60)}:${(t%60).toString().padStart(2,"0")}`;
}

export function MiniPlayer(p: Props) {
  const [expanded, setExpanded] = useState(false);
  const noTrack = !p.track;
  const pct = p.duration > 0 ? (p.currentTime / p.duration) * 100 : 0;

  if (noTrack) return null;

  return (
    <div
      className={`fixed bottom-4 right-4 z-[180] overflow-hidden rounded-xl border border-white/15 bg-black/90 shadow-2xl backdrop-blur-2xl bl-scale-in transition-all duration-300 ${
        expanded ? "w-[340px]" : "w-[300px]"
      }`}
    >
      {/* Progress bar at top */}
      <div className="relative h-0.5 w-full bg-white/10">
        <div
          className="absolute inset-y-0 left-0 bg-gradient-to-r from-emerald-500 to-teal-400"
          style={{ width: `${pct}%` }}
        />
        <input
          type="range"
          min={0}
          max={p.duration > 0 ? p.duration : 1}
          step={0.05}
          value={p.currentTime}
          onChange={e => p.onSeek(parseFloat(e.target.value))}
          className="absolute inset-0 w-full cursor-pointer opacity-0"
          aria-label="Seek"
        />
      </div>

      {/* Track info */}
      <div className="flex items-center gap-3 p-3">
        <div className="relative h-12 w-12 shrink-0 overflow-hidden rounded-md">
          {p.track?.coverUrl ? (
            <img src={p.track.coverUrl} alt="" className="h-full w-full object-cover" />
          ) : (
            <div className="h-full w-full bg-white/10" />
          )}
          {p.isPlaying && (
            <div className="absolute inset-0 flex items-end justify-center gap-0.5 bg-black/40 pb-1">
              <span className="bl-eq-bar inline-flex items-end gap-0.5">
                {[0,1,2,3].map(j => (
                  <span key={j} style={{
                    animationDelay: `${j*0.15}s`,
                    animationDuration: "0.8s",
                    height: `${[50,80,60,90][j]}%`,
                  }} />
                ))}
              </span>
            </div>
          )}
        </div>
        <div className="min-w-0 flex-1">
          <div className="truncate text-sm font-medium text-white">{p.track?.title}</div>
          <div className="truncate text-xs text-[var(--sp-text-subdued)]">
            {p.track?.artists.join(", ")}
          </div>
          <div className="mt-0.5 flex items-center gap-1 text-[10px] tabular-nums text-[var(--sp-text-subdued)]">
            <span>{fmt(p.currentTime)}</span>
            <span>/</span>
            <span>{fmt(p.duration)}</span>
          </div>
        </div>
        <button
          onClick={() => setExpanded(v => !v)}
          className="rounded-full p-1 text-white/50 hover:bg-white/10 hover:text-white"
          title={expanded ? "Collapse" : "Expand"}
        >
          {expanded ? <ChevronDown size={14} /> : <ChevronUp size={14} />}
        </button>
      </div>

      {/* Controls (always visible) */}
      <div className="flex items-center justify-center gap-3 px-3 pb-2">
        <button
          onClick={p.onPrev}
          className="text-white/60 hover:text-white"
          title="Previous"
        >
          <SkipBack size={16} fill="currentColor" />
        </button>
        <button
          onClick={p.onToggle}
          className="flex h-8 w-8 items-center justify-center rounded-full bg-white text-black transition-transform hover:scale-105 active:scale-95"
        >
          {p.isPlaying ? <Pause size={14} fill="currentColor" /> : <Play size={14} fill="currentColor" className="ml-0.5" />}
        </button>
        <button
          onClick={p.onNext}
          className="text-white/60 hover:text-white"
          title="Next"
        >
          <SkipForward size={16} fill="currentColor" />
        </button>
      </div>

      {/* Expanded controls */}
      {expanded && (
        <div className="space-y-3 border-t border-white/10 p-3 bl-fade-in">
          {/* Like + shuffle + repeat */}
          <div className="flex items-center justify-between">
            <button
              onClick={p.onToggleLike}
              className={`rounded-full p-1.5 transition-colors ${
                p.isLiked ? "text-emerald-400" : "text-white/60 hover:text-white"
              }`}
            >
              <Heart size={14} fill={p.isLiked ? "currentColor" : "none"} />
            </button>
            <div className="flex items-center gap-2">
              <button
                onClick={p.onToggleShuffle}
                className={`rounded-full p-1.5 text-xs transition-colors ${
                  p.shuffle ? "text-emerald-400" : "text-white/60 hover:text-white"
                }`}
              >
                <ListMusic size={14} />
              </button>
              <button
                onClick={p.onToggleRepeat}
                className={`rounded-full p-1.5 text-xs transition-colors ${
                  p.repeat !== "off" ? "text-emerald-400" : "text-white/60 hover:text-white"
                }`}
              >
                <span className="text-[10px] font-bold">{p.repeat === "one" ? "1×" : "∞"}</span>
              </button>
            </div>
          </div>

          {/* Volume */}
          <div className="flex items-center gap-2">
            <button onClick={p.onToggleMute} className="text-white/60 hover:text-white">
              {p.muted || p.volume === 0 ? <VolumeX size={14} /> : <Volume2 size={14} />}
            </button>
            <input
              type="range"
              min={0}
              max={1}
              step={0.01}
              value={p.muted ? 0 : p.volume}
              onChange={e => p.onVolume(parseFloat(e.target.value))}
              className="bl-slider flex-1"
              style={{ "--progress": `${(p.muted ? 0 : p.volume) * 100}%` } as React.CSSProperties}
              aria-label="Volume"
            />
          </div>

          {/* Actions */}
          <div className="flex items-center gap-2">
            <button
              onClick={p.onExpand}
              className="flex flex-1 items-center justify-center gap-1.5 rounded-lg border border-white/10 bg-white/5 px-3 py-1.5 text-xs font-medium text-white/80 hover:bg-white/10"
            >
              <Maximize2 size={12} />
              Full view
            </button>
            <button
              onClick={p.onClose}
              className="rounded-lg border border-red-500/30 bg-red-500/10 px-3 py-1.5 text-xs font-medium text-red-400 hover:bg-red-500/20"
            >
              <X size={12} />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
