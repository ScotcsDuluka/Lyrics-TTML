"use client";
import { useState, useRef, useEffect } from "react";
import { ListPlus, Check, Plus, X, ListMusic, ChevronUp } from "lucide-react";
import type { Playlist } from "@/lib/types";

interface Props {
  trackId: string;
  playlists: Playlist[];
  onAddToPlaylist: (playlistId: string, trackId: string) => Promise<boolean>;
  onCreatePlaylist: (name: string, trackId: string) => Promise<string | null>;
  onAddToQueue?: (trackId: string) => void;
}

export function AddToPlaylistButton({ trackId, playlists, onAddToPlaylist, onCreatePlaylist, onAddToQueue }: Props) {
  const [open, setOpen] = useState(false);
  const [added, setAdded] = useState<Set<string>>(new Set());
  const [addedToQueue, setAddedToQueue] = useState(false);
  const [creating, setCreating] = useState(false);
  const [newName, setNewName] = useState("");
  const ref = useRef<HTMLDivElement | null>(null);
  const inputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    const onClick = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setOpen(false);
        setCreating(false);
      }
    };
    if (open) document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, [open]);

  useEffect(() => {
    if (creating) inputRef.current?.focus();
  }, [creating]);

  const handleAdd = async (playlistId: string) => {
    const ok = await onAddToPlaylist(playlistId, trackId);
    if (ok) {
      setAdded(prev => new Set(prev).add(playlistId));
    }
  };

  const handleAddToQueue = () => {
    if (onAddToQueue) {
      onAddToQueue(trackId);
      setAddedToQueue(true);
      setTimeout(() => setAddedToQueue(false), 1500);
    }
  };

  const handleCreate = async () => {
    const name = newName.trim();
    if (!name) return;
    const id = await onCreatePlaylist(name, trackId);
    if (id) {
      setAdded(prev => new Set(prev).add(id));
      setCreating(false);
      setNewName("");
      setOpen(false);
    }
  };

  const userPlaylists = playlists.filter(p => !p.isSystem || p.name !== "Liked Songs");

  return (
    <div ref={ref} className="relative">
      <button
        onClick={(e) => { e.stopPropagation(); setOpen(v => !v); }}
        className="rounded p-1 text-[var(--sp-text-subdued)] opacity-0 transition-opacity hover:bg-white/10 hover:text-white group-hover:opacity-100"
        title="Add to playlist"
      >
        <ListPlus size={16} />
      </button>

      {open && (
        <div className="absolute bottom-full right-0 mb-2 z-30 w-64 rounded-lg border border-white/10 bg-[#1a1a1a] py-2 shadow-2xl backdrop-blur-xl bl-msg-in">
          {/* Header */}
          <div className="flex items-center justify-between px-3 pb-2 border-b border-white/10">
            <span className="text-sm font-bold text-white">Add to</span>
            <button onClick={() => setOpen(false)} className="rounded p-0.5 text-white/40 hover:text-white">
              <X size={14} />
            </button>
          </div>

          {/* Add to queue (if available) */}
          {onAddToQueue && (
            <button
              onClick={handleAddToQueue}
              className="flex w-full items-center gap-3 px-3 py-2 text-sm text-white hover:bg-white/10 border-b border-white/5"
            >
              <div className="flex h-8 w-8 items-center justify-center rounded bg-gradient-to-br from-emerald-500/30 to-teal-700/30">
                {addedToQueue ? <Check size={16} className="text-emerald-400" /> : <ChevronUp size={16} className="text-emerald-400" />}
              </div>
              <span className="font-medium">{addedToQueue ? "Added to queue" : "Add to queue"}</span>
            </button>
          )}

          {/* Create new */}
          {creating ? (
            <div className="px-3 py-2 border-b border-white/10">
              <div className="flex gap-2">
                <input
                  ref={inputRef}
                  value={newName}
                  onChange={e => setNewName(e.target.value)}
                  onKeyDown={e => { if (e.key === "Enter") handleCreate(); if (e.key === "Escape") setCreating(false); }}
                  placeholder="Playlist name"
                  className="flex-1 rounded bg-white/10 px-2 py-1 text-sm text-white placeholder:text-white/40 focus:bg-white/15 focus:outline-none"
                />
                <button onClick={handleCreate} className="rounded bg-emerald-500 px-2 py-1 text-xs font-bold text-black hover:bg-emerald-400">
                  Create
                </button>
              </div>
            </div>
          ) : (
            <button
              onClick={() => setCreating(true)}
              className="flex w-full items-center gap-3 px-3 py-2 text-sm text-white hover:bg-white/10"
            >
              <div className="flex h-8 w-8 items-center justify-center rounded bg-white/10">
                <Plus size={16} className="text-white/70" />
              </div>
              <span>New playlist</span>
            </button>
          )}

          {/* Playlist list */}
          <div className="max-h-64 overflow-y-auto bl-scroll py-1">
            <div className="px-3 py-1 text-[10px] font-bold uppercase tracking-wider text-white/40">
              Save to playlist
            </div>
            {userPlaylists.length === 0 ? (
              <div className="px-3 py-3 text-center text-xs text-white/40">
                <ListMusic size={24} className="mx-auto mb-1 opacity-30" />
                No playlists yet
              </div>
            ) : (
              userPlaylists.map(pl => (
                <button
                  key={pl.id}
                  onClick={() => handleAdd(pl.id)}
                  className="flex w-full items-center gap-3 px-3 py-2 text-left hover:bg-white/10"
                >
                  <div className="h-8 w-8 shrink-0 overflow-hidden rounded bg-white/10">
                    {pl.coverUrl ? (
                      <img src={pl.coverUrl} alt="" className="h-full w-full object-cover" />
                    ) : (
                      <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-emerald-500/40 to-teal-700/40">
                        <ListPlus size={12} className="text-white/60" />
                      </div>
                    )}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="truncate text-sm text-white">{pl.name}</div>
                    <div className="truncate text-xs text-white/50">{pl.trackCount} songs</div>
                  </div>
                  {added.has(pl.id) && <Check size={14} className="text-emerald-400" />}
                </button>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
}
