"use client";
import { useEffect, useState } from "react";
import { Moon, X, Timer, Music2, Clock, Play, Pause } from "lucide-react";
import { useAppStore } from "@/lib/store";
import { toast } from "sonner";

interface Props {
  isOpen: boolean;
  onClose: () => void;
  isPlaying: boolean;
  onPause: () => void;
  currentTrackId: string | null;
}

const PRESETS = [
  { label: "5 min", value: 5 * 60 },
  { label: "10 min", value: 10 * 60 },
  { label: "15 min", value: 15 * 60 },
  { label: "30 min", value: 30 * 60 },
  { label: "45 min", value: 45 * 60 },
  { label: "1 hour", value: 60 * 60 },
  { label: "End of track", value: -1 },
];

export function SleepTimer({ isOpen, onClose, isPlaying, onPause, currentTrackId }: Props) {
  const sleepTimer = useAppStore(s => s.sleepTimer);
  const setSleepTimer = useAppStore(s => s.setSleepTimer);

  const [remaining, setRemaining] = useState<number>(0);
  const [customMin, setCustomMin] = useState("");

  // Tick down the timer
  useEffect(() => {
    if (!sleepTimer) {
      setRemaining(0);
      return;
    }
    if (sleepTimer.trackId !== null) return; // end-of-track mode

    const tick = () => {
      const now = Date.now();
      const left = Math.max(0, sleepTimer.endsAt - now);
      setRemaining(left);
      if (left <= 0) {
        onPause();
        setSleepTimer(null);
        toast.info("Sleep timer ended", { description: "Playback paused" });
      }
    };
    tick();
    const id = setInterval(tick, 500);
    return () => clearInterval(id);
  }, [sleepTimer, onPause, setSleepTimer]);

  // Watch for end-of-track — listens to global "track-ended" event
  // so it works even when repeat="one" (where trackId doesn't change)
  useEffect(() => {
    if (!sleepTimer || sleepTimer.trackId === null) return;
    const onTrackEnded = (e: Event) => {
      const detail = (e as CustomEvent).detail;
      // Pause if the ended track matches the one we set the timer on
      if (!detail || detail.trackId === sleepTimer.trackId) {
        onPause();
        setSleepTimer(null);
        toast.info("Sleep timer ended", { description: "Track finished" });
      }
    };
    window.addEventListener("bl-track-ended", onTrackEnded as EventListener);
    return () => window.removeEventListener("bl-track-ended", onTrackEnded as EventListener);
  }, [sleepTimer, onPause, setSleepTimer]);

  // Also handle the case where the track changes (e.g., user skips)
  useEffect(() => {
    if (!sleepTimer || sleepTimer.trackId === null) return;
    if (currentTrackId && currentTrackId !== sleepTimer.trackId) {
      onPause();
      setSleepTimer(null);
      toast.info("Sleep timer ended", { description: "Track finished" });
    }
  }, [currentTrackId, sleepTimer, onPause, setSleepTimer]);

  if (!isOpen) return null;

  const startTimer = (seconds: number) => {
    if (seconds === -1) {
      // End of current track
      if (!currentTrackId) {
        toast.error("No track playing");
        return;
      }
      setSleepTimer({ endsAt: 0, trackId: currentTrackId });
      toast.success("Sleep timer set", { description: "Will pause after current track" });
    } else {
      setSleepTimer({ endsAt: Date.now() + seconds * 1000, trackId: null });
      const mins = Math.floor(seconds / 60);
      toast.success("Sleep timer set", { description: `Pauses in ${mins} minute${mins !== 1 ? "s" : ""}` });
    }
  };

  const cancelTimer = () => {
    setSleepTimer(null);
    setRemaining(0);
    toast.success("Sleep timer cancelled");
  };

  const applyCustom = () => {
    const mins = parseInt(customMin, 10);
    if (!mins || mins < 1 || mins > 600) {
      toast.error("Enter a value between 1 and 600 minutes");
      return;
    }
    startTimer(mins * 60);
    setCustomMin("");
  };

  const fmt = (ms: number) => {
    const totalSec = Math.ceil(ms / 1000);
    const m = Math.floor(totalSec / 60);
    const s = totalSec % 60;
    return `${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
  };

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center bg-black/70 backdrop-blur-sm bl-fade-in" onClick={onClose}>
      <div
        className="relative w-[440px] max-w-[92vw] overflow-hidden rounded-2xl border border-white/15 bg-gradient-to-b from-[#1a1a1a] to-[#0a0a0a] shadow-2xl bl-scale-in"
        onClick={e => e.stopPropagation()}
      >
        {/* Header with gradient */}
        <div className="relative overflow-hidden px-6 pb-4 pt-6">
          <div className="absolute -right-12 -top-12 h-40 w-40 rounded-full bg-indigo-500/20 blur-3xl" />
          <div className="absolute -left-12 -top-12 h-40 w-40 rounded-full bg-purple-500/20 blur-3xl" />
          <div className="relative flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-br from-indigo-500 to-purple-700 shadow-lg shadow-indigo-500/30">
                <Moon size={18} className="text-white" />
              </div>
              <div>
                <h2 className="text-lg font-bold text-white">Sleep Timer</h2>
                <p className="text-xs text-[var(--sp-text-subdued)]">Pause playback automatically</p>
              </div>
            </div>
            <button onClick={onClose} className="rounded-full p-1.5 text-white/60 hover:bg-white/10 hover:text-white">
              <X size={18} />
            </button>
          </div>
        </div>

        {/* Active timer display */}
        {sleepTimer && (
          <div className="mx-6 mb-4 rounded-xl border border-emerald-500/30 bg-emerald-500/10 p-4 bl-scale-in">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="relative">
                  <Timer size={28} className="text-emerald-400" />
                  {isPlaying && (
                    <span className="absolute -right-1 -top-1 h-2 w-2 animate-ping rounded-full bg-emerald-400" />
                  )}
                </div>
                <div>
                  <div className="text-xs uppercase tracking-wider text-emerald-400/70">
                    {sleepTimer.trackId !== null ? "End of track" : "Time remaining"}
                  </div>
                  <div className="font-mono text-2xl font-bold text-white tabular-nums">
                    {sleepTimer.trackId !== null ? (
                      <span className="flex items-center gap-2 text-base">
                        <Music2 size={16} className="text-emerald-400" />
                        Waiting for track to end
                      </span>
                    ) : fmt(remaining)}
                  </div>
                </div>
              </div>
              <button
                onClick={cancelTimer}
                className="rounded-full bg-white/10 px-3 py-1.5 text-xs font-medium text-white hover:bg-white/20"
              >
                Cancel
              </button>
            </div>
          </div>
        )}

        {/* Presets */}
        {!sleepTimer && (
          <>
            <div className="px-6 pb-3">
              <div className="mb-2 text-xs font-semibold uppercase tracking-wider text-[var(--sp-text-subdued)]">
                Quick presets
              </div>
              <div className="grid grid-cols-3 gap-2">
                {PRESETS.map(p => (
                  <button
                    key={p.label}
                    onClick={() => startTimer(p.value)}
                    className="group relative flex flex-col items-center justify-center gap-1 overflow-hidden rounded-xl border border-white/10 bg-white/[0.03] p-3 transition-all hover:border-white/20 hover:bg-white/[0.08]"
                  >
                    <div className="absolute inset-0 bg-gradient-to-br from-indigo-500/0 to-purple-500/0 transition-opacity group-hover:from-indigo-500/10 group-hover:to-purple-500/10" />
                    {p.value === -1 ? (
                      <Music2 size={18} className="relative text-white/80" />
                    ) : (
                      <Clock size={18} className="relative text-white/80" />
                    )}
                    <span className="relative text-xs font-medium text-white">{p.label}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Custom time */}
            <div className="px-6 pb-6">
              <div className="mb-2 text-xs font-semibold uppercase tracking-wider text-[var(--sp-text-subdued)]">
                Custom time
              </div>
              <div className="flex gap-2">
                <input
                  type="number"
                  min={1}
                  max={600}
                  placeholder="Minutes (1-600)"
                  value={customMin}
                  onChange={e => setCustomMin(e.target.value)}
                  onKeyDown={e => e.key === "Enter" && applyCustom()}
                  className="flex-1 rounded-lg border border-white/10 bg-black/40 px-3 py-2 text-sm text-white placeholder:text-white/30 focus:border-indigo-500/50 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                />
                <button
                  onClick={applyCustom}
                  className="rounded-lg bg-gradient-to-r from-indigo-500 to-purple-600 px-4 py-2 text-sm font-semibold text-white shadow-lg shadow-indigo-500/30 transition-all hover:shadow-indigo-500/50 hover:brightness-110"
                >
                  Start
                </button>
              </div>
            </div>
          </>
        )}

        {sleepTimer && (
          <div className="px-6 pb-6 pt-2">
            <p className="text-center text-xs text-[var(--sp-text-subdued)]">
              {isPlaying ? (
                <span className="flex items-center justify-center gap-1.5">
                  <span className="bl-eq-bar inline-flex items-end gap-0.5">
                    {[0,1,2,3].map(j => (
                      <span key={j} style={{
                        animationDelay: `${j*0.15}s`,
                        animationDuration: "0.8s",
                        height: `${[60,100,70,90][j]}%`,
                      }} />
                    ))}
                  </span>
                  Playback will pause automatically
                </span>
              ) : (
                "Playback paused"
              )}
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
