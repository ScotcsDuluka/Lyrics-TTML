"use client";
import { Keyboard, X } from "lucide-react";
import { useAppStore } from "@/lib/store";

const SHORTCUTS = [
  { keys: ["Space"], desc: "Play / Pause" },
  { keys: ["→"], desc: "Seek forward 5s" },
  { keys: ["←"], desc: "Seek back 5s" },
  { keys: ["Shift", "→"], desc: "Next track" },
  { keys: ["Shift", "←"], desc: "Previous track" },
  { keys: ["↑"], desc: "Volume up" },
  { keys: ["↓"], desc: "Volume down" },
  { keys: ["M"], desc: "Mute / Unmute" },
  { keys: ["L"], desc: "Like / Unlike current track" },
  { keys: ["S"], desc: "Toggle shuffle" },
  { keys: ["R"], desc: "Cycle repeat mode" },
  { keys: ["N"], desc: "Toggle Now Playing view" },
  { keys: ["Q"], desc: "Toggle Queue" },
  { keys: ["F"], desc: "Focus search" },
  { keys: ["H"], desc: "Go to Home" },
  { keys: ["Ctrl", "K"], desc: "Open Command Overlay (AI)" },
  { keys: ["?"], desc: "Show this help" },
  { keys: ["Esc"], desc: "Close dialogs" },
];

export function ShortcutsHelp() {
  const show = useAppStore(s => s.showShortcutsHelp);
  const setShow = useAppStore(s => s.setShowShortcutsHelp);

  if (!show) return null;

  return (
    <div
      className="fixed inset-0 z-[200] flex items-center justify-center bg-black/70 backdrop-blur-sm bl-fade-in"
      onClick={() => setShow(false)}
    >
      <div
        className="relative w-[560px] max-w-[92vw] overflow-hidden rounded-2xl border border-white/15 bg-gradient-to-b from-[#1a1a1a] to-[#0a0a0a] shadow-2xl bl-scale-in"
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="relative overflow-hidden border-b border-white/10 px-6 pb-4 pt-6">
          <div className="absolute -right-12 -top-12 h-40 w-40 rounded-full bg-amber-500/20 blur-3xl" />
          <div className="absolute -left-12 -top-12 h-40 w-40 rounded-full bg-orange-500/20 blur-3xl" />
          <div className="relative flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-br from-amber-500 to-orange-700 shadow-lg shadow-amber-500/30">
                <Keyboard size={18} className="text-white" />
              </div>
              <div>
                <h2 className="text-lg font-bold text-white">Keyboard Shortcuts</h2>
                <p className="text-xs text-[var(--sp-text-subdued)]">Speed up your music experience</p>
              </div>
            </div>
            <button onClick={() => setShow(false)} className="rounded-full p-1.5 text-white/60 hover:bg-white/10 hover:text-white">
              <X size={18} />
            </button>
          </div>
        </div>

        {/* Shortcuts list */}
        <div className="grid max-h-[60vh] grid-cols-1 gap-x-6 gap-y-1 overflow-y-auto p-4 bl-scroll sm:grid-cols-2">
          {SHORTCUTS.map((s, i) => (
            <div
              key={i}
              className="flex items-center justify-between rounded-lg px-2 py-1.5 transition-colors hover:bg-white/5"
            >
              <span className="text-xs text-white/70">{s.desc}</span>
              <div className="flex items-center gap-1">
                {s.keys.map((k, j) => (
                  <kbd
                    key={j}
                    className="min-w-[24px] rounded border border-white/15 bg-white/5 px-1.5 py-0.5 text-center font-mono text-[10px] font-semibold text-white/80 shadow-sm"
                  >
                    {k}
                  </kbd>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="border-t border-white/10 px-6 py-3 text-center">
          <p className="text-[10px] text-white/30">
            Press <kbd className="rounded border border-white/15 bg-white/5 px-1.5 py-0.5 font-mono text-[10px]">?</kbd> anytime to open this dialog
          </p>
        </div>
      </div>
    </div>
  );
}
