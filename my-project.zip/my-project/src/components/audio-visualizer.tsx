"use client";

import { useRef, useEffect, useCallback } from "react";

interface AudioVisualizerProps {
  frequencyData: Uint8Array;
  waveformData: Uint8Array;
  isPlaying: boolean;
  mode?: "bars" | "wave" | "circular";
  color?: string;
  width?: number;
  height?: number;
  className?: string;
}

// ── Color utilities ──────────────────────────────────────────────────────────

function hexToRgb(hex: string): { r: number; g: number; b: number } {
  const h = hex.replace("#", "");
  return {
    r: parseInt(h.substring(0, 2), 16),
    g: parseInt(h.substring(2, 4), 16),
    b: parseInt(h.substring(4, 6), 16),
  };
}

function rgbToHsl(r: number, g: number, b: number): { h: number; s: number; l: number } {
  r /= 255;
  g /= 255;
  b /= 255;
  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  const l = (max + min) / 2;
  let h = 0;
  let s = 0;

  if (max !== min) {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    switch (max) {
      case r:
        h = ((g - b) / d + (g < b ? 6 : 0)) / 6;
        break;
      case g:
        h = ((b - r) / d + 2) / 6;
        break;
      case b:
        h = ((r - g) / d + 4) / 6;
        break;
    }
  }

  return { h: h * 360, s: s * 100, l: l * 100 };
}

function lightenColor(hex: string, amount: number): string {
  const { r, g, b } = hexToRgb(hex);
  const { h, s, l } = rgbToHsl(r, g, b);
  const newL = Math.min(100, l + amount);
  return `hsl(${h}, ${s}%, ${newL}%)`;
}

function complementaryColor(hex: string): string {
  const { r, g, b } = hexToRgb(hex);
  const { h, s, l } = rgbToHsl(r, g, b);
  const newH = (h + 180) % 360;
  return `hsl(${newH}, ${s}%, ${l}%)`;
}

function colorWithAlpha(hex: string, alpha: number): string {
  const { r, g, b } = hexToRgb(hex);
  return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}

// ── Interpolation helpers ────────────────────────────────────────────────────

const LERP_FACTOR = 0.12;

function lerp(a: number, b: number, t: number): number {
  return a + (b - a) * t;
}

// ── Component ────────────────────────────────────────────────────────────────

export function AudioVisualizer({
  frequencyData,
  waveformData,
  isPlaying,
  mode = "bars",
  color = "#1db954",
  width,
  height,
  className,
}: AudioVisualizerProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animFrameRef = useRef<number>(0);
  const prevBarsRef = useRef<Float32Array | null>(null);
  const prevWaveRef = useRef<Float32Array | null>(null);
  const prevCircularRef = useRef<Float32Array | null>(null);
  const rotationRef = useRef(0);
  const idlePhaseRef = useRef(0);
  const timeRef = useRef(0);

  // ── Bars mode ────────────────────────────────────────────────────────────

  const drawBars = useCallback(
    (
      ctx: CanvasRenderingContext2D,
      w: number,
      h: number,
      freq: Uint8Array,
      playing: boolean,
      accent: string,
      time: number,
    ) => {
      const barCount = Math.min(64, Math.max(16, Math.floor(w / 10)));
      const gap = 3;
      const barWidth = (w - gap * (barCount - 1)) / barCount;
      const maxBarHeight = h * 0.65;
      const reflectionHeight = h * 0.2;
      const baseY = h * 0.68;

      // Initialize or resize prev array
      if (!prevBarsRef.current || prevBarsRef.current.length !== barCount) {
        prevBarsRef.current = new Float32Array(barCount).fill(0);
      }
      const prev = prevBarsRef.current;

      // Sample frequency data into barCount bins
      const targetValues = new Float32Array(barCount);
      if (playing && freq.length > 0) {
        const step = freq.length / barCount;
        for (let i = 0; i < barCount; i++) {
          let sum = 0;
          const start = Math.floor(i * step);
          const end = Math.floor((i + 1) * step);
          for (let j = start; j < end; j++) {
            sum += freq[j] ?? 0;
          }
          targetValues[i] = (sum / (end - start || 1)) / 255;
        }
      } else {
        // Idle breathing animation
        for (let i = 0; i < barCount; i++) {
          const phase = time * 1.5 + i * 0.15;
          targetValues[i] =
            0.04 + Math.sin(phase) * 0.03 + Math.sin(phase * 0.7) * 0.02;
        }
      }

      // Smooth interpolation
      for (let i = 0; i < barCount; i++) {
        prev[i] = lerp(prev[i], targetValues[i], LERP_FACTOR);
      }

      const lightAccent = lightenColor(accent, 25);

      for (let i = 0; i < barCount; i++) {
        const val = prev[i];
        const barH = Math.max(2, val * maxBarHeight);
        const x = i * (barWidth + gap);
        const y = baseY - barH;

        // Glow behind bar
        ctx.save();
        ctx.shadowColor = colorWithAlpha(accent, 0.35 + val * 0.3);
        ctx.shadowBlur = 12 + val * 18;
        ctx.shadowOffsetY = 0;

        // Gradient fill
        const grad = ctx.createLinearGradient(x, baseY, x, y);
        grad.addColorStop(0, accent);
        grad.addColorStop(0.6, lightAccent);
        grad.addColorStop(1, lightenColor(accent, 40));

        ctx.fillStyle = grad;
        ctx.beginPath();
        const radius = Math.min(barWidth / 2, 4);
        ctx.moveTo(x, baseY);
        ctx.lineTo(x, y + radius);
        ctx.quadraticCurveTo(x, y, x + radius, y);
        ctx.lineTo(x + barWidth - radius, y);
        ctx.quadraticCurveTo(x + barWidth, y, x + barWidth, y + radius);
        ctx.lineTo(x + barWidth, baseY);
        ctx.closePath();
        ctx.fill();
        ctx.restore();

        // Reflection / glow below
        const reflGrad = ctx.createLinearGradient(x, baseY, x, baseY + reflectionHeight);
        reflGrad.addColorStop(0, colorWithAlpha(accent, 0.18 * val));
        reflGrad.addColorStop(1, colorWithAlpha(accent, 0));
        ctx.fillStyle = reflGrad;
        ctx.fillRect(x, baseY + 2, barWidth, reflectionHeight * val);
      }
    },
    [],
  );

  // ── Wave mode ────────────────────────────────────────────────────────────

  const drawWave = useCallback(
    (
      ctx: CanvasRenderingContext2D,
      w: number,
      h: number,
      wave: Uint8Array,
      playing: boolean,
      accent: string,
      time: number,
    ) => {
      const points = 128;
      const midY = h * 0.5;

      // Initialize or resize prev array
      if (!prevWaveRef.current || prevWaveRef.current.length !== points) {
        prevWaveRef.current = new Float32Array(points).fill(128);
      }
      const prev = prevWaveRef.current;

      // Target values
      const targetValues = new Float32Array(points);
      if (playing && wave.length > 0) {
        const step = wave.length / points;
        for (let i = 0; i < points; i++) {
          targetValues[i] = wave[Math.floor(i * step)] ?? 128;
        }
      } else {
        // Idle gentle wave
        for (let i = 0; i < points; i++) {
          const t = i / points;
          targetValues[i] =
            128 +
            Math.sin(time * 1.2 + t * Math.PI * 4) * 8 +
            Math.sin(time * 0.8 + t * Math.PI * 6) * 4;
        }
      }

      // Smooth interpolation
      for (let i = 0; i < points; i++) {
        prev[i] = lerp(prev[i], targetValues[i], LERP_FACTOR);
      }

      // Build bezier path
      const pts: { x: number; y: number }[] = [];
      for (let i = 0; i < points; i++) {
        const x = (i / (points - 1)) * w;
        const y = midY + ((prev[i] - 128) / 128) * (h * 0.35);
        pts.push({ x, y });
      }

      // Glow line
      ctx.save();
      ctx.shadowColor = colorWithAlpha(accent, 0.6);
      ctx.shadowBlur = 16;
      ctx.strokeStyle = accent;
      ctx.lineWidth = 2.5;
      ctx.lineJoin = "round";
      ctx.lineCap = "round";

      ctx.beginPath();
      ctx.moveTo(pts[0].x, pts[0].y);
      for (let i = 1; i < pts.length - 1; i++) {
        const cpx = (pts[i].x + pts[i + 1].x) / 2;
        const cpy = (pts[i].y + pts[i + 1].y) / 2;
        ctx.quadraticCurveTo(pts[i].x, pts[i].y, cpx, cpy);
      }
      const last = pts[pts.length - 1];
      ctx.lineTo(last.x, last.y);
      ctx.stroke();
      ctx.restore();

      // Gradient fill below curve
      const fillGrad = ctx.createLinearGradient(0, midY - h * 0.35, 0, h);
      fillGrad.addColorStop(0, colorWithAlpha(accent, 0.25));
      fillGrad.addColorStop(0.5, colorWithAlpha(accent, 0.08));
      fillGrad.addColorStop(1, colorWithAlpha(accent, 0));

      ctx.beginPath();
      ctx.moveTo(pts[0].x, pts[0].y);
      for (let i = 1; i < pts.length - 1; i++) {
        const cpx = (pts[i].x + pts[i + 1].x) / 2;
        const cpy = (pts[i].y + pts[i + 1].y) / 2;
        ctx.quadraticCurveTo(pts[i].x, pts[i].y, cpx, cpy);
      }
      ctx.lineTo(last.x, last.y);
      ctx.lineTo(w, h);
      ctx.lineTo(0, h);
      ctx.closePath();
      ctx.fillStyle = fillGrad;
      ctx.fill();

      // Second subtle glow pass
      ctx.save();
      ctx.shadowColor = colorWithAlpha(accent, 0.35);
      ctx.shadowBlur = 30;
      ctx.strokeStyle = colorWithAlpha(accent, 0.3);
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.moveTo(pts[0].x, pts[0].y);
      for (let i = 1; i < pts.length - 1; i++) {
        const cpx = (pts[i].x + pts[i + 1].x) / 2;
        const cpy = (pts[i].y + pts[i + 1].y) / 2;
        ctx.quadraticCurveTo(pts[i].x, pts[i].y, cpx, cpy);
      }
      ctx.lineTo(last.x, last.y);
      ctx.stroke();
      ctx.restore();
    },
    [],
  );

  // ── Circular mode ────────────────────────────────────────────────────────

  const drawCircular = useCallback(
    (
      ctx: CanvasRenderingContext2D,
      w: number,
      h: number,
      freq: Uint8Array,
      playing: boolean,
      accent: string,
      time: number,
      rotation: number,
    ) => {
      const cx = w / 2;
      const cy = h / 2;
      const innerRadius = Math.min(w, h) * 0.12;
      const maxBarLen = Math.min(w, h) * 0.32;
      const barCount = 90;

      const compColor = complementaryColor(accent);

      if (!prevCircularRef.current || prevCircularRef.current.length !== barCount) {
        prevCircularRef.current = new Float32Array(barCount).fill(0);
      }
      const prev = prevCircularRef.current;

      // Target values
      const targetValues = new Float32Array(barCount);
      if (playing && freq.length > 0) {
        const step = freq.length / barCount;
        for (let i = 0; i < barCount; i++) {
          let sum = 0;
          const start = Math.floor(i * step);
          const end = Math.floor((i + 1) * step);
          for (let j = start; j < end; j++) {
            sum += freq[j] ?? 0;
          }
          targetValues[i] = (sum / (end - start || 1)) / 255;
        }
      } else {
        // Idle breathing ring
        for (let i = 0; i < barCount; i++) {
          const phase = time * 1.2 + (i / barCount) * Math.PI * 2;
          targetValues[i] =
            0.06 + Math.sin(phase) * 0.04 + Math.sin(phase * 1.3 + 1) * 0.02;
        }
      }

      // Smooth interpolation
      for (let i = 0; i < barCount; i++) {
        prev[i] = lerp(prev[i], targetValues[i], LERP_FACTOR);
      }

      // Inner glow circle
      const innerGlow = ctx.createRadialGradient(cx, cy, 0, cx, cy, innerRadius * 1.5);
      innerGlow.addColorStop(0, colorWithAlpha(accent, 0.08));
      innerGlow.addColorStop(0.6, colorWithAlpha(accent, 0.03));
      innerGlow.addColorStop(1, colorWithAlpha(accent, 0));
      ctx.fillStyle = innerGlow;
      ctx.beginPath();
      ctx.arc(cx, cy, innerRadius * 1.5, 0, Math.PI * 2);
      ctx.fill();

      // Draw bars
      for (let i = 0; i < barCount; i++) {
        const val = prev[i];
        const barLen = Math.max(2, val * maxBarLen);
        const angle = (i / barCount) * Math.PI * 2 + rotation;

        const x1 = cx + Math.cos(angle) * innerRadius;
        const y1 = cy + Math.sin(angle) * innerRadius;
        const x2 = cx + Math.cos(angle) * (innerRadius + barLen);
        const y2 = cy + Math.sin(angle) * (innerRadius + barLen);

        // Gradient along the bar from accent to complementary
        const grad = ctx.createLinearGradient(x1, y1, x2, y2);
        grad.addColorStop(0, accent);
        grad.addColorStop(0.5, lightenColor(accent, 15));
        grad.addColorStop(1, compColor);

        // Glow
        ctx.save();
        ctx.shadowColor = colorWithAlpha(accent, 0.3 + val * 0.4);
        ctx.shadowBlur = 8 + val * 14;
        ctx.strokeStyle = grad;
        ctx.lineWidth = Math.max(2, (Math.PI * 2 * innerRadius) / barCount * 0.5);
        ctx.lineCap = "round";
        ctx.beginPath();
        ctx.moveTo(x1, y1);
        ctx.lineTo(x2, y2);
        ctx.stroke();
        ctx.restore();
      }

      // Outer ring glow
      ctx.save();
      ctx.strokeStyle = colorWithAlpha(accent, 0.06);
      ctx.lineWidth = 2;
      ctx.shadowColor = colorWithAlpha(accent, 0.15);
      ctx.shadowBlur = 20;
      ctx.beginPath();
      ctx.arc(cx, cy, innerRadius - 2, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();
    },
    [],
  );

  // ── Animation loop ────────────────────────────────────────────────────────

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d", { alpha: true });
    if (!ctx) return;

    let lastTime = performance.now();

    const animate = (now: number) => {
      const dt = (now - lastTime) / 1000;
      lastTime = now;
      timeRef.current += dt;

      const dpr = window.devicePixelRatio || 1;
      const rect = canvas.getBoundingClientRect();
      const displayW = width ?? rect.width;
      const displayH = height ?? rect.height;

      // Only resize canvas buffer if dimensions changed
      if (
        canvas.width !== Math.round(displayW * dpr) ||
        canvas.height !== Math.round(displayH * dpr)
      ) {
        canvas.width = Math.round(displayW * dpr);
        canvas.height = Math.round(displayH * dpr);
      }

      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, displayW, displayH);

      // Update rotation for circular mode
      if (isPlaying) {
        rotationRef.current += dt * 0.15;
      } else {
        rotationRef.current += dt * 0.03;
      }

      switch (mode) {
        case "bars":
          drawBars(ctx, displayW, displayH, frequencyData, isPlaying, color, timeRef.current);
          break;
        case "wave":
          drawWave(ctx, displayW, displayH, waveformData, isPlaying, color, timeRef.current);
          break;
        case "circular":
          drawCircular(
            ctx,
            displayW,
            displayH,
            frequencyData,
            isPlaying,
            color,
            timeRef.current,
            rotationRef.current,
          );
          break;
      }

      animFrameRef.current = requestAnimationFrame(animate);
    };

    animFrameRef.current = requestAnimationFrame(animate);

    return () => {
      if (animFrameRef.current) {
        cancelAnimationFrame(animFrameRef.current);
      }
    };
  }, [frequencyData, waveformData, isPlaying, mode, color, width, height, drawBars, drawWave, drawCircular]);

  // ── Render ────────────────────────────────────────────────────────────────

  const style: React.CSSProperties = {
    display: "block",
    width: width ?? "100%",
    height: height ?? "100%",
  };

  return (
    <canvas
      ref={canvasRef}
      className={className}
      style={style}
    />
  );
}
