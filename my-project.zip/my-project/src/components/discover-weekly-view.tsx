"use client";
import { useMemo } from "react";
import { Sparkles, Play, Clock, TrendingUp, Heart, RefreshCw, Flame, Music2, User } from "lucide-react";
import type { Track, PlayHistoryEntry } from "@/lib/types";

interface Props {
  allTracks: Track[];
  history: PlayHistoryEntry[];
  likedTrackIds: string[];
  currentTrackId: string | null;
  isPlaying: boolean;
  onPlayAll: (tracks: Track[]) => void;
  onSelectTrack: (track: Track, index: number, list: Track[]) => void;
  onToggleLike: (trackId: string) => void;
  onRefresh: () => void;
  onSelectArtist: (name: string) => void;
}

interface Recommendation {
  track: Track;
  reason: string;
  score: number;
}

const REASON_TEMPLATES = {
  sameArtist: (n: string) => `Because you listened to ${n}`,
  sameGenre: (g: string) => `More ${g.toLowerCase()} tracks you might like`,
  sameAlbum: (a: string) => `From the album "${a}"`,
  trending: () => `Trending in your library`,
  newDiscovery: () => `New discovery for you`,
  similarMood: () => `Matches your listening mood`,
};

export function DiscoverWeekly({ allTracks, history, likedTrackIds, currentTrackId, isPlaying, onPlayAll, onSelectTrack, onToggleLike, onRefresh, onSelectArtist }: Props) {
  // Determine the user's top genres/artists from history
  const userProfile = useMemo(() => {
    const genreCounts = new Map<string, number>();
    const artistCounts = new Map<string, number>();
    const albumCounts = new Map<string, number>();

    for (const h of history) {
      if (h.track.genre) genreCounts.set(h.track.genre, (genreCounts.get(h.track.genre) ?? 0) + 1);
      for (const a of h.track.artists) artistCounts.set(a, (artistCounts.get(a) ?? 0) + 1);
      if (h.track.album) albumCounts.set(h.track.album, (albumCounts.get(h.track.album) ?? 0) + 1);
    }

    return {
      topGenres: Array.from(genreCounts.entries()).sort((a, b) => b[1] - a[1]).slice(0, 3).map(([g]) => g),
      topArtists: Array.from(artistCounts.entries()).sort((a, b) => b[1] - a[1]).slice(0, 3).map(([a]) => a),
      topAlbums: Array.from(albumCounts.entries()).sort((a, b) => b[1] - a[1]).slice(0, 3).map(([a]) => a),
    };
  }, [history]);

  // Generate recommendations
  const recommendations = useMemo<Recommendation[]>(() => {
    const seen = new Set<string>();
    const likedSet = new Set(likedTrackIds);
    const historySet = new Set(history.map(h => h.trackId));
    const recs: Recommendation[] = [];

    // 1. Tracks from liked artists not yet played
    for (const artist of userProfile.topArtists) {
      for (const t of allTracks) {
        if (seen.has(t.id)) continue;
        if (historySet.has(t.id)) continue;
        if (t.artists.includes(artist)) {
          seen.add(t.id);
          recs.push({ track: t, reason: REASON_TEMPLATES.sameArtist(artist), score: 95 });
        }
      }
    }

    // 2. Tracks from liked genres not yet played
    for (const genre of userProfile.topGenres) {
      for (const t of allTracks) {
        if (seen.has(t.id)) continue;
        if (historySet.has(t.id)) continue;
        if (t.genre === genre) {
          seen.add(t.id);
          recs.push({ track: t, reason: REASON_TEMPLATES.sameGenre(genre), score: 85 });
        }
      }
    }

    // 3. Tracks from liked albums not yet played
    for (const album of userProfile.topAlbums) {
      for (const t of allTracks) {
        if (seen.has(t.id)) continue;
        if (historySet.has(t.id)) continue;
        if (t.album === album) {
          seen.add(t.id);
          recs.push({ track: t, reason: REASON_TEMPLATES.sameAlbum(album), score: 75 });
        }
      }
    }

    // 4. Add liked tracks as recommendations (you might enjoy again)
    for (const t of allTracks) {
      if (seen.has(t.id)) continue;
      if (likedSet.has(t.id)) {
        seen.add(t.id);
        recs.push({ track: t, reason: REASON_TEMPLATES.similarMood(), score: 70 });
      }
    }

    // 5. Fill with random tracks
    for (const t of allTracks) {
      if (seen.has(t.id)) continue;
      seen.add(t.id);
      const reasons = [REASON_TEMPLATES.trending(), REASON_TEMPLATES.newDiscovery(), REASON_TEMPLATES.similarMood()];
      recs.push({ track: t, reason: reasons[Math.floor(Math.random() * reasons.length)], score: 50 });
    }

    return recs.slice(0, 10);
  }, [allTracks, history, likedTrackIds, userProfile]);

  const totalDuration = recommendations.reduce((sum, r) => sum + (r.track.duration ?? 0), 0);
  const totalMinutes = Math.floor(totalDuration / 60);

  // Hour of day for "refresh" greeting
  const hour = new Date().getHours();
  const greeting = hour < 12 ? "Good morning" : hour < 18 ? "Good afternoon" : "Good evening";

  return (
    <div className="bl-scroll flex-1 bl-view-transition">
      {/* Hero header with gradient */}
      <div className="bl-discover-hero relative overflow-hidden px-6 pt-12 pb-6">
        <div className="pointer-events-none absolute inset-0 -z-10 opacity-60">
          <div className="bl-ambient-orb bl-ambient-orb-1" />
          <div className="bl-ambient-orb bl-ambient-orb-2" />
        </div>

        <div className="flex items-end gap-6">
          {/* Playlist cover */}
          <div className="bl-discover-cover relative flex h-44 w-44 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br from-violet-600 via-fuchsia-600 to-pink-600 shadow-2xl">
            <Sparkles size={64} className="text-white/90" />
            <div className="absolute inset-0 rounded-2xl bg-gradient-to-t from-black/30 to-transparent" />
          </div>

          <div className="flex-1 pb-2">
            <div className="text-xs font-bold uppercase tracking-wider text-white/70">Made for you • Updated daily</div>
            <h1 className="mt-2 text-5xl font-extrabold tracking-tight text-white bl-gradient-text">Discover Weekly</h1>
            <p className="mt-3 max-w-xl text-sm text-white/70">
              Your weekly mixtape of fresh music. Enjoy new discoveries and some old favorites, handpicked based on your listening history.
            </p>
            <div className="mt-3 flex items-center gap-2 text-xs text-white/60">
              <Clock size={12} />
              <span>{recommendations.length} tracks • {totalMinutes} min</span>
            </div>
          </div>
        </div>
      </div>

      {/* Action bar */}
      <div className="flex items-center gap-4 px-6 py-4">
        <button
          onClick={() => onPlayAll(recommendations.map(r => r.track))}
          className="flex h-14 w-14 items-center justify-center rounded-full bg-emerald-500 text-black shadow-xl shadow-emerald-500/30 transition-all hover:scale-105 hover:bg-emerald-400"
          aria-label="Play all"
        >
          <Play size={26} fill="currentColor" />
        </button>
        <button
          onClick={onRefresh}
          className="flex h-10 w-10 items-center justify-center rounded-full text-white/70 transition-all hover:bg-white/10 hover:text-white"
          aria-label="Refresh recommendations"
          title="Refresh recommendations"
        >
          <RefreshCw size={18} />
        </button>
        <div className="ml-auto flex items-center gap-2 rounded-full bg-white/5 px-3 py-1.5 text-xs text-white/70">
          <TrendingUp size={12} className="text-emerald-400" />
          <span>{greeting}! Based on your last {history.length} plays</span>
        </div>
      </div>

      {/* Track list */}
      <div className="px-6 pb-10">
        {/* Header row */}
        <div className="grid grid-cols-[16px_4fr_2.5fr_2.5fr_60px_60px] items-center gap-3 border-b border-white/10 px-2 pb-2 text-[10px] font-bold uppercase tracking-wider text-[var(--sp-text-subdued)]">
          <span>#</span>
          <span>Title</span>
          <span>Album</span>
          <span>Why we picked it</span>
          <span className="text-right">Likes</span>
          <span className="text-right"><Clock size={12} className="inline" /></span>
        </div>

        {/* Tracks */}
        <ol className="mt-2 flex flex-col gap-0.5">
          {recommendations.map((rec, i) => {
            const track = rec.track;
            const isCurrent = currentTrackId === track.id;
            const isCurrentPlaying = isCurrent && isPlaying;
            return (
              <li
                key={track.id}
                data-track-id={track.id}
                data-track-index={i}
                className={`bl-track-row group grid grid-cols-[16px_4fr_2.5fr_2.5fr_60px_60px] items-center gap-3 rounded-lg px-2 py-2 transition-colors hover:bg-white/5 ${isCurrent ? "active" : ""}`}
              >
                {/* Index / Play button */}
                <button
                  onClick={() => onSelectTrack(track, i, recommendations.map(r => r.track))}
                  className="flex h-4 w-4 items-center justify-center text-xs text-[var(--sp-text-subdued)] group-hover:text-white"
                >
                  {isCurrentPlaying ? (
                    <div className="flex items-end gap-[2px] h-3">
                      <div className="bl-eq-bar w-[2px] bg-emerald-400" style={{ animationDelay: "0ms", height: "60%" }} />
                      <div className="bl-eq-bar w-[2px] bg-emerald-400" style={{ animationDelay: "150ms", height: "100%" }} />
                      <div className="bl-eq-bar w-[2px] bg-emerald-400" style={{ animationDelay: "300ms", height: "40%" }} />
                    </div>
                  ) : (
                    <>
                      <span className="group-hover:hidden">{i + 1}</span>
                      <Play size={10} fill="currentColor" className="hidden group-hover:block text-white" />
                    </>
                  )}
                </button>

                {/* Title + artist */}
                <div
                  onClick={() => onSelectTrack(track, i, recommendations.map(r => r.track))}
                  className="flex min-w-0 items-center gap-3 text-left cursor-pointer"
                >
                  {track.coverUrl ? (
                    <img src={track.coverUrl} alt="" className="h-10 w-10 rounded object-cover" />
                  ) : (
                    <div className="flex h-10 w-10 items-center justify-center rounded bg-gradient-to-br from-emerald-500/40 to-teal-700/40">
                      <Music2 size={14} className="text-white/60" />
                    </div>
                  )}
                  <div className="min-w-0">
                    <div className={`truncate text-sm font-medium ${isCurrent ? "text-emerald-400" : "text-white"}`}>{track.title}</div>
                    <span
                      role="button"
                      tabIndex={0}
                      onClick={(e) => { e.stopPropagation(); track.artists[0] && onSelectArtist(track.artists[0]); }}
                      onKeyDown={(e) => { if (e.key === 'Enter') { e.stopPropagation(); track.artists[0] && onSelectArtist(track.artists[0]); } }}
                      className="block truncate text-xs text-[var(--sp-text-subdued)] hover:text-white hover:underline"
                    >
                      {track.artists.join(", ")}
                    </span>
                  </div>
                </div>

                {/* Album */}
                <span className="truncate text-xs text-[var(--sp-text-subdued)]" title={track.album}>{track.album}</span>

                {/* Reason (with tooltip on hover via title) */}
                <span className="flex items-center gap-1.5 min-w-0" title={rec.reason}>
                  <Sparkles size={10} className="shrink-0 text-emerald-400/80" />
                  <span className="truncate text-xs text-emerald-300/80">{rec.reason}</span>
                </span>

                {/* Like */}
                <button
                  onClick={() => onToggleLike(track.id)}
                  className={`flex items-center justify-end gap-1 text-xs transition-colors ${track.liked ? "text-rose-400" : "text-[var(--sp-text-subdued)] hover:text-white"}`}
                >
                  {track.liked ? <Heart size={12} fill="currentColor" /> : <Heart size={12} />}
                </button>

                {/* Duration */}
                <span className="text-right text-xs text-[var(--sp-text-subdued)] tabular-nums">
                  {track.duration ? `${Math.floor(track.duration / 60)}:${String(Math.floor(track.duration % 60)).padStart(2, "0")}` : "--:--"}
                </span>
              </li>
            );
          })}
        </ol>

        {/* Footer info card */}
        <div className="mt-8 rounded-xl border border-white/5 bg-gradient-to-br from-white/5 to-transparent p-5">
          <div className="flex items-start gap-4">
            <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-violet-500 to-pink-600">
              <Flame size={20} className="text-white" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">Why these tracks?</h3>
              <p className="mt-1 text-xs text-[var(--sp-text-subdued)]">
                Your Discover Weekly refreshes based on your listening activity. The more you listen, the better we get at picking tracks you'll love.
                {userProfile.topGenres.length > 0 && (
                  <span className="mt-2 block">
                    <span className="font-semibold text-white/80">Top genres detected:</span>{" "}
                    {userProfile.topGenres.join(", ")}
                  </span>
                )}
                {userProfile.topArtists.length > 0 && (
                  <span className="mt-1 block">
                    <span className="font-semibold text-white/80">Top artists:</span>{" "}
                    {userProfile.topArtists.join(", ")}
                  </span>
                )}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
