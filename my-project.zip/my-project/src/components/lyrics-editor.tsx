"use client";
import { useEffect, useState } from "react";
import { PenLine, X, Save, FileText, Eye, Trash2, Loader2, Music2 } from "lucide-react";
import type { Track } from "@/lib/types";
import { toast } from "sonner";

interface Props {
  isOpen: boolean;
  onClose: () => void;
  track: Track | null;
  onSaved: () => void;
}

type Mode = "edit" | "preview";

export function LyricsEditor({ isOpen, onClose, track, onSaved }: Props) {
  const [content, setContent] = useState("");
  const [originalContent, setOriginalContent] = useState("");
  const [mode, setMode] = useState<Mode>("edit");
  const [saving, setSaving] = useState(false);
  const [loading, setLoading] = useState(false);
  const [hasLyrics, setHasLyrics] = useState(false);

  useEffect(() => {
    if (!isOpen || !track) return;
    setLoading(true);
    setMode("edit");
    setContent("");
    setOriginalContent("");

    (async () => {
      if (!track.lyricsUrl) {
        setHasLyrics(false);
        setContent("");
        setOriginalContent("");
        setLoading(false);
        return;
      }
      try {
        const res = await fetch(track.lyricsUrl);
        if (res.ok) {
          const text = await res.text();
          setContent(text);
          setOriginalContent(text);
          setHasLyrics(true);
        } else {
          setHasLyrics(false);
        }
      } catch {
        setHasLyrics(false);
      } finally {
        setLoading(false);
      }
    })();
  }, [isOpen, track]);

  if (!isOpen || !track) return null;

  const dirty = content !== originalContent;

  const save = async () => {
    if (!dirty) return;
    setSaving(true);
    try {
      const res = await fetch(`/api/tracks/${track.id}/lyrics`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ lyrics: content }),
      });
      if (res.ok) {
        const data = await res.json();
        setOriginalContent(content);
        setHasLyrics(true);
        toast.success("Lyrics saved", { description: track.title });
        onSaved();
      } else {
        toast.error("Failed to save lyrics");
      }
    } catch {
      toast.error("Failed to save lyrics");
    } finally {
      setSaving(false);
    }
  };

  const remove = async () => {
    if (!hasLyrics) return;
    if (!confirm("Remove lyrics for this track?")) return;
    setSaving(true);
    try {
      const res = await fetch(`/api/tracks/${track.id}/lyrics`, { method: "DELETE" });
      if (res.ok) {
        setContent("");
        setOriginalContent("");
        setHasLyrics(false);
        toast.success("Lyrics removed");
        onSaved();
      } else {
        toast.error("Failed to remove lyrics");
      }
    } catch {
      toast.error("Failed to remove lyrics");
    } finally {
      setSaving(false);
    }
  };

  const lineCount = content ? content.split("\n").filter(l => l.trim()).length : 0;
  const charCount = content.length;

  return (
    <div
      className="fixed inset-0 z-[200] flex items-center justify-center bg-black/70 backdrop-blur-sm bl-fade-in"
      onClick={onClose}
    >
      <div
        className="relative flex h-[640px] max-h-[90vh] w-[720px] max-w-[94vw] flex-col overflow-hidden rounded-2xl border border-white/15 bg-gradient-to-b from-[#1a1a1a] to-[#0a0a0a] shadow-2xl bl-scale-in"
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="relative flex items-center justify-between border-b border-white/10 px-5 py-4">
          <div className="absolute -right-12 -top-12 h-32 w-32 rounded-full bg-rose-500/20 blur-3xl" />
          <div className="relative flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-full bg-gradient-to-br from-rose-500 to-pink-700 shadow-lg shadow-rose-500/30">
              <PenLine size={16} className="text-white" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">Lyrics Editor</h2>
              <p className="text-[11px] text-[var(--sp-text-subdued)]">
                {track.title} • {track.artists.join(", ")}
              </p>
            </div>
          </div>
          <div className="relative flex items-center gap-2">
            {/* Mode toggle */}
            <div className="flex rounded-lg border border-white/10 bg-black/40 p-0.5">
              <button
                onClick={() => setMode("edit")}
                className={`flex items-center gap-1 rounded-md px-2.5 py-1 text-xs font-medium transition-all ${
                  mode === "edit" ? "bg-white/15 text-white" : "text-white/60 hover:text-white"
                }`}
              >
                <PenLine size={12} />
                Edit
              </button>
              <button
                onClick={() => setMode("preview")}
                className={`flex items-center gap-1 rounded-md px-2.5 py-1 text-xs font-medium transition-all ${
                  mode === "preview" ? "bg-white/15 text-white" : "text-white/60 hover:text-white"
                }`}
              >
                <Eye size={12} />
                Preview
              </button>
            </div>
            <button onClick={onClose} className="rounded-full p-1.5 text-white/60 hover:bg-white/10 hover:text-white">
              <X size={18} />
            </button>
          </div>
        </div>

        {/* Body */}
        <div className="relative flex-1 overflow-hidden">
          {loading ? (
            <div className="flex h-full items-center justify-center">
              <Loader2 size={24} className="animate-spin text-white/40" />
            </div>
          ) : mode === "edit" ? (
            <textarea
              value={content}
              onChange={e => setContent(e.target.value)}
              placeholder={`Write lyrics for "${track.title}"...\n\nTips:\n• One line per row\n• Use [Verse], [Chorus], [Bridge] for sections\n• Use [00:12.34] for synced lyrics (LRC format)\n• Blank lines separate sections`}
              spellCheck={false}
              className="h-full w-full resize-none bg-transparent px-5 py-4 font-mono text-sm leading-relaxed text-white/90 placeholder:text-white/30 focus:outline-none bl-scroll"
            />
          ) : (
            <div className="h-full overflow-y-auto px-5 py-4 bl-scroll bl-fade-in">
              {content ? (
                <PreviewLyrics content={content} />
              ) : (
                <div className="flex h-full flex-col items-center justify-center gap-3 text-center">
                  <FileText size={48} className="text-white/20" />
                  <p className="text-sm text-[var(--sp-text-subdued)]">No lyrics to preview yet</p>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between border-t border-white/10 bg-black/30 px-5 py-3">
          <div className="flex items-center gap-4 text-[11px] text-[var(--sp-text-subdued)]">
            <span className="flex items-center gap-1">
              <Music2 size={11} />
              {lineCount} lines
            </span>
            <span>{charCount} chars</span>
            {hasLyrics && (
              <span className="flex items-center gap-1 text-emerald-400">
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" />
                Has lyrics
              </span>
            )}
            {dirty && (
              <span className="flex items-center gap-1 text-amber-400">
                <span className="h-1.5 w-1.5 rounded-full bg-amber-400 animate-pulse" />
                Unsaved
              </span>
            )}
          </div>
          <div className="flex items-center gap-2">
            {hasLyrics && (
              <button
                onClick={remove}
                disabled={saving}
                className="flex items-center gap-1.5 rounded-lg border border-red-500/30 bg-red-500/10 px-3 py-1.5 text-xs font-medium text-red-400 hover:bg-red-500/20 disabled:opacity-40"
              >
                <Trash2 size={12} />
                Remove
              </button>
            )}
            <button
              onClick={save}
              disabled={!dirty || saving}
              className={`flex items-center gap-1.5 rounded-lg px-4 py-1.5 text-xs font-semibold transition-all ${
                dirty && !saving
                  ? "bg-gradient-to-r from-rose-500 to-pink-600 text-white shadow-lg shadow-rose-500/30 hover:brightness-110"
                  : "bg-white/5 text-white/40"
              }`}
            >
              {saving ? <Loader2 size={12} className="animate-spin" /> : <Save size={12} />}
              Save
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function PreviewLyrics({ content }: { content: string }) {
  const lines = content.split("\n");
  return (
    <div className="space-y-1">
      {lines.map((line, i) => {
        const trimmed = line.trim();
        // Section header like [Verse], [Chorus]
        const sectionMatch = trimmed.match(/^\[(.+)\]$/);
        if (sectionMatch && !sectionMatch[1].match(/^\d/)) {
          return (
            <div key={i} className="pt-4 pb-1">
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-400/80">
                {sectionMatch[1]}
              </span>
            </div>
          );
        }
        // LRC timestamp line [00:12.34] Lyrics text
        const lrcMatch = line.match(/^\[(\d+):(\d+\.\d+)\](.*)$/);
        if (lrcMatch) {
          const min = lrcMatch[1];
          const sec = lrcMatch[2];
          const text = lrcMatch[3] || "♪";
          return (
            <div key={i} className="group flex items-baseline gap-3">
              <span className="shrink-0 font-mono text-[10px] text-white/30 tabular-nums">
                {min}:{sec.padStart(5, "0")}
              </span>
              <span className="text-sm text-white/80">{text}</span>
            </div>
          );
        }
        if (!trimmed) {
          return <div key={i} className="h-2" />;
        }
        return (
          <div key={i} className="text-sm leading-relaxed text-white/80">
            {line}
          </div>
        );
      })}
    </div>
  );
}
