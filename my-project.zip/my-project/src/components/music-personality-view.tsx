"use client";
import { useEffect, useMemo, useState } from "react";
import {
  Music, Music2, Share2, Clock, Users, Disc3, Calendar,
  TrendingUp, Sparkles, Compass, Heart, Zap, Moon, Star,
  Headphones, Award, Crown
} from "lucide-react";
import type { Track, PlayHistoryEntry } from "@/lib/types";
import { useAppStore } from "@/lib/store";

/* ──────────────────────────── Props ──────────────────────────── */

interface Props {
  allTracks: Track[];
  history: PlayHistoryEntry[];
  likedTrackIds: string[];
  onPlayTrack: (track: Track) => void;
  onSelectArtist: (name: string) => void;
}

/* ──────────────────────────── Helpers ──────────────────────────── */

const GENRE_COLORS: Record<string, string> = {
  Pop: "#ec4899",
  Rock: "#f97316",
  HipHop: "#eab308",
  RnB: "#a855f7",
  Electronic: "#06b6d4",
  Jazz: "#22c55e",
  Classical: "#3b82f6",
  Country: "#d97706",
  Metal: "#6b7280",
  Folk: "#84cc16",
  Blues: "#6366f1",
  Reggae: "#10b981",
  Latin: "#f43f5e",
  Indie: "#8b5cf6",
  Alternative: "#14b8a6",
  Punk: "#ef4444",
  Soul: "#c084fc",
  Funk: "#fb923c",
  Ambient: "#67e8f9",
  LoFi: "#a3e635",
};

function getGenreColor(genre: string): string {
  return GENRE_COLORS[genre] ?? "#8b5cf6";
}

/* ──────────────────────────── Personality Types ──────────────────────────── */

interface PersonalityType {
  name: string;
  icon: React.ReactNode;
  description: string;
  gradient: string;
  badgeColor: string;
}

const PERSONALITIES: Record<string, PersonalityType> = {
  explorer: {
    name: "The Explorer",
    icon: <Compass size={20} />,
    description:
      "You're always seeking new sounds and undiscovered artists. Your playlists are a journey through genres, and you'd rather take the road less traveled than replay the same hits. Music is your adventure.",
    gradient: "from-emerald-500 to-cyan-500",
    badgeColor: "from-emerald-500/30 to-cyan-500/30 border-emerald-500/40",
  },
  loyalist: {
    name: "The Loyalist",
    icon: <Heart size={20} />,
    description:
      "When you find a song you love, you play it on repeat — and you're not sorry about it. Your favorites list is sacred, and you know every word to your top tracks. Consistency is your superpower.",
    gradient: "from-rose-500 to-pink-500",
    badgeColor: "from-rose-500/30 to-pink-500/30 border-rose-500/40",
  },
  trendsetter: {
    name: "The Trendsetter",
    icon: <Star size={20} />,
    description:
      "You're ahead of the curve. You discover new releases before anyone else and your taste shapes what's next. Your friends always ask you for recommendations — and you always deliver.",
    gradient: "from-amber-500 to-orange-500",
    badgeColor: "from-amber-500/30 to-orange-500/30 border-amber-500/40",
  },
  nostalgic: {
    name: "The Nostalgic",
    icon: <Moon size={20} />,
    description:
      "Your music is a time machine. You find comfort in the songs that shaped your past, and your playlists are full of memories. Every track tells a story you've lived through.",
    gradient: "from-violet-500 to-purple-500",
    badgeColor: "from-violet-500/30 to-purple-500/30 border-violet-500/40",
  },
  eclectic: {
    name: "The Eclectic",
    icon: <Zap size={20} />,
    description:
      "Your taste defies categories. One minute you're vibing to jazz, the next you're headbanging to rock. You see music as one big canvas and you paint with every color available.",
    gradient: "from-fuchsia-500 to-violet-500",
    badgeColor: "from-fuchsia-500/30 to-violet-500/30 border-fuchsia-500/40",
  },
};

/* ──────────────────────────── Floating Note ──────────────────────────── */

function FloatingNote({ delay, left, size }: { delay: number; left: string; size: number }) {
  return (
    <div
      className="pointer-events-none absolute text-white/20"
      style={{
        left,
        bottom: "-20px",
        animation: `bl-float-note ${6 + Math.random() * 4}s ease-in-out ${delay}s infinite`,
        fontSize: `${size}px`,
      }}
    >
      <Music />
    </div>
  );
}

/* ──────────────────────────── Main Component ──────────────────────────── */

export function MusicPersonalityView({
  allTracks,
  history,
  likedTrackIds,
  onPlayTrack,
  onSelectArtist,
}: Props) {
  const [mounted, setMounted] = useState(false);
  const setShowShareModal = useAppStore(s => s.setShowShareModal);
  const setSharePayload = useAppStore(s => s.setSharePayload);

  useEffect(() => {
    const t = setTimeout(() => setMounted(true), 100);
    return () => clearTimeout(t);
  }, []);

  /* ── Computed stats ── */

  const totalMinutes = useMemo(() => {
    const secs = history.reduce((s, h) => s + (h.track.duration ?? 0), 0);
    return Math.round(secs / 60);
  }, [history]);

  const uniqueArtists = useMemo(() => {
    const set = new Set<string>();
    for (const h of history) for (const a of h.track.artists) set.add(a);
    return set.size;
  }, [history]);

  const topGenres = useMemo(() => {
    const counts = new Map<string, number>();
    for (const h of history) {
      const g = h.track.genre;
      if (g) counts.set(g, (counts.get(g) ?? 0) + 1);
    }
    return Array.from(counts.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5);
  }, [history]);

  const topGenreName = topGenres.length > 0 ? topGenres[0][0] : "—";
  const topGenrePct =
    history.length > 0 && topGenres.length > 0
      ? Math.round((topGenres[0][1] / history.length) * 100)
      : 0;

  const topTracks = useMemo(() => {
    const counts = new Map<string, number>();
    for (const h of history) {
      counts.set(h.track.id, (counts.get(h.track.id) ?? 0) + 1);
    }
    return Array.from(counts.entries())
      .map(([id, count]) => {
        const track = allTracks.find(t => t.id === id);
        return track ? { track, count } : null;
      })
      .filter(Boolean)
      .sort((a, b) => b!.count - a!.count)
      .slice(0, 5) as { track: Track; count: number }[];
  }, [history, allTracks]);

  const topArtists = useMemo(() => {
    const counts = new Map<string, number>();
    for (const h of history) {
      for (const a of h.track.artists) {
        counts.set(a, (counts.get(a) ?? 0) + 1);
      }
    }
    return Array.from(counts.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5);
  }, [history]);

  // Longest session: consecutive plays within 30 min of each other
  const longestSessionMinutes = useMemo(() => {
    if (history.length === 0) return 0;
    const sorted = [...history].sort(
      (a, b) => new Date(a.playedAt).getTime() - new Date(b.playedAt).getTime()
    );
    let best = 0;
    let start = 0;
    for (let i = 1; i < sorted.length; i++) {
      const gap =
        new Date(sorted[i].playedAt).getTime() -
        new Date(sorted[i - 1].playedAt).getTime();
      if (gap > 30 * 60 * 1000) {
        // session ended
        const sessionSecs = sorted
          .slice(start, i)
          .reduce((s, h) => s + (h.track.duration ?? 0), 0);
        best = Math.max(best, Math.round(sessionSecs / 60));
        start = i;
      }
    }
    const lastSecs = sorted
      .slice(start)
      .reduce((s, h) => s + (h.track.duration ?? 0), 0);
    best = Math.max(best, Math.round(lastSecs / 60));
    return best;
  }, [history]);

  // Most active day of week
  const mostActiveDay = useMemo(() => {
    if (history.length === 0) return "—";
    const dayNames = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
    const counts = new Array(7).fill(0);
    for (const h of history) {
      counts[new Date(h.playedAt).getDay()]++;
    }
    const maxIdx = counts.indexOf(Math.max(...counts));
    return dayNames[maxIdx];
  }, [history]);

  // Discovery rate: unique tracks vs total plays
  const discoveryRate = useMemo(() => {
    if (history.length === 0) return 0;
    const uniqueIds = new Set(history.map(h => h.track.id));
    return Math.round((uniqueIds.size / history.length) * 100);
  }, [history]);

  /* ── Personality determination ── */

  const genreCount = topGenres.length;
  const uniqueTrackIds = new Set(history.map(h => h.track.id));
  const repeatRatio = history.length > 0 ? 1 - uniqueTrackIds.size / history.length : 0;

  // Adventurous: genre diversity + unique tracks ratio
  const adventurousScore = Math.min(
    100,
    Math.round((genreCount / 5) * 60 + (uniqueTrackIds.size / Math.max(1, history.length)) * 40)
  );
  // Loyal: repeat ratio
  const loyalScore = Math.min(100, Math.round(repeatRatio * 100));
  // Energetic: based on genre energy (electronic, rock, hip-hop, metal, punk)
  const energeticGenres = new Set(["Electronic", "Rock", "HipHop", "Metal", "Punk", "Dance"]);
  const energeticPlays = history.filter(h => energeticGenres.has(h.track.genre)).length;
  const energeticScore = history.length > 0 ? Math.min(100, Math.round((energeticPlays / history.length) * 150)) : 30;
  // Mellow: opposite of energetic
  const mellowScore = Math.max(0, 100 - energeticScore);

  const personalityKey = useMemo(() => {
    if (genreCount >= 4 && adventurousScore > 60) return "eclectic";
    if (adventurousScore > 65) return "explorer";
    if (loyalScore > 60) return "loyalist";
    if (discoveryRate > 70) return "trendsetter";
    return "nostalgic";
  }, [genreCount, adventurousScore, loyalScore, discoveryRate]);

  const personality = PERSONALITIES[personalityKey];

  // Aura gradient based on top genres
  const auraColors = useMemo(() => {
    if (topGenres.length === 0) return ["#a855f7", "#ec4899"];
    const c1 = getGenreColor(topGenres[0][0]);
    const c2 = topGenres.length > 1 ? getGenreColor(topGenres[1][0]) : c1;
    return [c1, c2];
  }, [topGenres]);

  /* ── Share handler ── */

  const handleShare = () => {
    const summary = `🎵 My Music Personality: ${personality.name}\n\n` +
      `${personality.description}\n\n` +
      `📊 ${totalMinutes} min listened · ${uniqueArtists} artists · Top genre: ${topGenreName}\n` +
      `🔥 Adventurous: ${adventurousScore}% · Loyal: ${loyalScore}% · Energetic: ${energeticScore}% · Mellow: ${mellowScore}%`;

    setSharePayload({
      type: "track",
      id: "personality-2025",
      title: `${personality.name} — 2025 Music Personality`,
      subtitle: summary,
    });
    setShowShareModal(true);
  };

  /* ── Render ── */

  const maxGenreCount = Math.max(1, ...topGenres.map(g => g[1]));
  const maxArtistCount = Math.max(1, ...topArtists.map(a => a[1]));

  // Floating notes config
  const notes = useMemo(
    () =>
      Array.from({ length: 12 }, (_, i) => ({
        delay: i * 0.8,
        left: `${5 + Math.random() * 90}%`,
        size: 16 + Math.floor(Math.random() * 16),
      })),
    []
  );

  return (
    <div className="bl-scroll flex-1 overflow-y-auto pb-10">
      {/* ═══════════════════════ Hero Section ═══════════════════════ */}
      <div className="bl-personality-hero relative flex flex-col items-center px-6 pt-16 pb-12 text-center">
        {/* Floating music notes */}
        {notes.map((n, i) => (
          <FloatingNote key={i} delay={n.delay} left={n.left} size={n.size} />
        ))}

        {/* Year badge */}
        <div className="relative z-10 mb-4 inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/10 px-4 py-1.5 text-sm font-bold text-white/90 backdrop-blur-sm">
          <Sparkles size={14} className="text-amber-300" />
          2025
        </div>

        {/* Title */}
        <h1
          className="relative z-10 mb-6 text-4xl font-extrabold tracking-tight sm:text-5xl md:text-6xl"
          style={{
            background: "linear-gradient(135deg, #e9d5ff, #fbcfe8, #fde68a, #a5f3fc)",
            WebkitBackgroundClip: "text",
            WebkitTextFillColor: "transparent",
            backgroundClip: "text",
          }}
        >
          Your Music Personality
        </h1>

        {/* Listening Aura Radial Visualization */}
        <div className="relative z-10 mb-4">
          <AuraRadialViz
            topGenres={topGenres}
            auraColors={auraColors}
            adventurousScore={adventurousScore}
            loyalScore={loyalScore}
            energeticScore={energeticScore}
            mellowScore={mellowScore}
          />
        </div>
        <p className="relative z-10 text-sm font-medium text-white/60">
          Your Listening Aura
        </p>
      </div>

      {/* ═══════════════════════ Personality Card ═══════════════════════ */}
      <div className="px-4 sm:px-6">
        <div
          className={`relative mx-auto max-w-2xl overflow-hidden rounded-2xl border border-white/10 bg-gradient-to-br from-[#1a1a2e]/80 to-[#0d0d1a]/80 p-6 backdrop-blur-xl sm:p-8 transition-all duration-700 ${
            mounted ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"
          }`}
        >
          {/* Glow */}
          <div
            className="pointer-events-none absolute -top-20 -right-20 h-60 w-60 rounded-full opacity-20 blur-3xl"
            style={{ background: `linear-gradient(135deg, ${auraColors[0]}, ${auraColors[1]})` }}
          />

          {/* Personality badge */}
          <div
            className={`bl-personality-badge mb-4 border ${personality.badgeColor}`}
            style={{
              background: `linear-gradient(135deg, ${auraColors[0]}33, ${auraColors[1]}33)`,
              borderColor: `${auraColors[0]}66`,
            }}
          >
            {personality.icon}
            <span>{personality.name}</span>
          </div>

          {/* Personality name */}
          <h2
            className="mb-3 text-3xl font-extrabold tracking-tight sm:text-4xl"
            style={{
              background: `linear-gradient(135deg, ${auraColors[0]}, ${auraColors[1]})`,
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
              backgroundClip: "text",
            }}
          >
            {personality.name}
          </h2>

          {/* Description */}
          <p className="mb-6 text-sm leading-relaxed text-white/70 sm:text-base">
            {personality.description}
          </p>

          {/* Trait bars */}
          <div className="space-y-3">
            <TraitBar label="Adventurous" value={adventurousScore} color={auraColors[0]} delay={0} />
            <TraitBar label="Loyal" value={loyalScore} color="#ec4899" delay={0.15} />
            <TraitBar label="Energetic" value={energeticScore} color="#f97316" delay={0.3} />
            <TraitBar label="Mellow" value={mellowScore} color="#06b6d4" delay={0.45} />
          </div>

          {/* Share button */}
          <button
            onClick={handleShare}
            className="mt-6 inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-purple-500 to-pink-500 px-6 py-2.5 text-sm font-bold text-white shadow-lg shadow-purple-500/25 transition-all hover:shadow-xl hover:shadow-purple-500/40 hover:brightness-110"
          >
            <Share2 size={16} />
            Share your personality
          </button>
        </div>
      </div>

      {/* ═══════════════════════ Listening Highlights ═══════════════════════ */}
      <div className="px-4 sm:px-6 mt-10">
        <h2 className="mb-4 text-xl font-bold text-white sm:text-2xl">Listening Highlights</h2>
        <div className="grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-3">
          <HighlightCard
            icon={<Headphones size={18} />}
            label="Minutes Listened"
            value={totalMinutes >= 60 ? `${(totalMinutes / 60).toFixed(1)}h` : `${totalMinutes}m`}
            sublabel={`${totalMinutes} total minutes`}
            gradient="from-purple-500 to-fuchsia-500"
            delay={0}
          />
          <HighlightCard
            icon={<Users size={18} />}
            label="Artists Discovered"
            value={uniqueArtists.toString()}
            sublabel="Unique artists"
            gradient="from-cyan-500 to-teal-500"
            delay={0.1}
          />
          <HighlightCard
            icon={<Disc3 size={18} />}
            label="Top Genre"
            value={topGenreName}
            sublabel={`${topGenrePct}% of plays`}
            gradient="from-rose-500 to-pink-500"
            delay={0.2}
          />
          <HighlightCard
            icon={<Clock size={18} />}
            label="Longest Session"
            value={longestSessionMinutes >= 60 ? `${(longestSessionMinutes / 60).toFixed(1)}h` : `${longestSessionMinutes}m`}
            sublabel="Non-stop listening"
            gradient="from-amber-500 to-orange-500"
            delay={0.3}
          />
          <HighlightCard
            icon={<Calendar size={18} />}
            label="Most Active Day"
            value={mostActiveDay}
            sublabel="Your music day"
            gradient="from-emerald-500 to-green-500"
            delay={0.4}
          />
          <HighlightCard
            icon={<TrendingUp size={18} />}
            label="Discovery Rate"
            value={`${discoveryRate}%`}
            sublabel="New vs repeated"
            gradient="from-violet-500 to-indigo-500"
            delay={0.5}
          />
        </div>
      </div>

      {/* ═══════════════════════ Top 5 Lists ═══════════════════════ */}
      <div className="px-4 sm:px-6 mt-10">
        <h2 className="mb-4 text-xl font-bold text-white sm:text-2xl">Your Top 5</h2>
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
          {/* Top 5 Tracks */}
          <div className="bl-highlight-card">
            <div className="mb-4 flex items-center gap-2">
              <Crown size={16} className="text-amber-400" />
              <h3 className="text-sm font-bold text-white">Top Tracks</h3>
            </div>
            {topTracks.length === 0 ? (
              <EmptyState text="Start listening to see your top tracks" />
            ) : (
              <ol className="flex flex-col gap-2">
                {topTracks.map((item, i) => (
                  <li key={item.track.id}>
                    <button
                      onClick={() => onPlayTrack(item.track)}
                      className="group flex w-full items-center gap-3 rounded-lg p-2 text-left transition-colors hover:bg-white/5"
                    >
                      <span
                        className={`w-6 text-center text-sm font-extrabold ${
                          i === 0
                            ? "text-amber-400"
                            : i === 1
                            ? "text-zinc-300"
                            : i === 2
                            ? "text-amber-700"
                            : "text-white/30"
                        }`}
                      >
                        {i + 1}
                      </span>
                      {item.track.coverUrl ? (
                        <img
                          src={item.track.coverUrl}
                          alt=""
                          className="h-10 w-10 rounded object-cover"
                        />
                      ) : (
                        <div className="flex h-10 w-10 items-center justify-center rounded bg-gradient-to-br from-purple-500/40 to-fuchsia-700/40">
                          <Music2 size={14} className="text-white/60" />
                        </div>
                      )}
                      <div className="min-w-0 flex-1">
                        <div className="truncate text-sm font-medium text-white group-hover:text-purple-300">
                          {item.track.title}
                        </div>
                        <div className="truncate text-xs text-[var(--sp-text-subdued)]">
                          {item.track.artists.join(", ")}
                        </div>
                      </div>
                      <span className="shrink-0 rounded-full bg-purple-500/10 px-2 py-0.5 text-[10px] font-bold text-purple-300">
                        {item.count}×
                      </span>
                    </button>
                  </li>
                ))}
              </ol>
            )}
          </div>

          {/* Top 5 Artists */}
          <div className="bl-highlight-card">
            <div className="mb-4 flex items-center gap-2">
              <Award size={16} className="text-cyan-400" />
              <h3 className="text-sm font-bold text-white">Top Artists</h3>
            </div>
            {topArtists.length === 0 ? (
              <EmptyState text="Start listening to see your top artists" />
            ) : (
              <ul className="flex flex-col gap-2">
                {topArtists.map(([name, count], i) => (
                  <li key={name}>
                    <button
                      onClick={() => onSelectArtist(name)}
                      className="group flex w-full items-center gap-3 rounded-lg p-2 text-left transition-colors hover:bg-white/5"
                    >
                      <span
                        className={`w-6 text-center text-sm font-extrabold ${
                          i === 0 ? "text-cyan-400" : "text-white/30"
                        }`}
                      >
                        {i + 1}
                      </span>
                      <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-br from-cyan-500/40 to-blue-700/40">
                        <Users size={14} className="text-white/70" />
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="truncate text-sm font-medium text-white group-hover:text-cyan-300">
                          {name}
                        </div>
                        <div className="mt-1 h-1 w-full overflow-hidden rounded-full bg-white/5">
                          <div
                            className="h-full rounded-full bg-gradient-to-r from-cyan-500 to-blue-400"
                            style={{ width: `${(count / maxArtistCount) * 100}%` }}
                          />
                        </div>
                      </div>
                      <span className="shrink-0 text-[10px] font-bold text-[var(--sp-text-subdued)]">
                        {count} plays
                      </span>
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </div>

          {/* Top 5 Genres */}
          <div className="bl-highlight-card">
            <div className="mb-4 flex items-center gap-2">
              <Disc3 size={16} className="text-rose-400" />
              <h3 className="text-sm font-bold text-white">Top Genres</h3>
            </div>
            {topGenres.length === 0 ? (
              <EmptyState text="Start listening to see your top genres" />
            ) : (
              <ul className="flex flex-col gap-3">
                {topGenres.map(([genre, count], i) => {
                  const pct = Math.round((count / Math.max(1, history.length)) * 100);
                  const color = getGenreColor(genre);
                  return (
                    <li key={genre}>
                      <div className="flex items-center justify-between text-sm">
                        <span className="font-medium text-white">{genre}</span>
                        <span className="text-[10px] font-bold text-[var(--sp-text-subdued)]">
                          {pct}% · {count} plays
                        </span>
                      </div>
                      <div className="mt-1 bl-trait-bar">
                        <div
                          className="bl-trait-bar-fill"
                          style={{
                            width: `${(count / maxGenreCount) * 100}%`,
                            background: `linear-gradient(90deg, ${color}, ${color}cc)`,
                            animationDelay: `${i * 0.15}s`,
                          }}
                        />
                      </div>
                    </li>
                  );
                })}
              </ul>
            )}
          </div>
        </div>
      </div>

      {/* ═══════════════════════ Music DNA Strand ═══════════════════════ */}
      <div className="px-4 sm:px-6 mt-10 mb-8">
        <h2 className="mb-4 text-xl font-bold text-white sm:text-2xl">Your Music DNA</h2>
        <div className="bl-highlight-card">
          <div className="mb-4 flex items-center gap-2">
            <Music size={16} className="text-fuchsia-400" />
            <h3 className="text-sm font-bold text-white">Genre Distribution</h3>
            <span className="ml-auto text-[10px] text-[var(--sp-text-subdued)]">
              Based on {history.length} plays
            </span>
          </div>

          {/* DNA bar */}
          {topGenres.length === 0 ? (
            <EmptyState text="Start listening to build your DNA" />
          ) : (
            <>
              <div className="bl-dna-bar">
                {topGenres.map(([genre, count], i) => {
                  const pct = (count / history.length) * 100;
                  const color = getGenreColor(genre);
                  return (
                    <div
                      key={genre}
                      className="bl-dna-bar-segment flex items-center justify-center"
                      style={{
                        width: `${pct}%`,
                        background: `linear-gradient(180deg, ${color}, ${color}bb)`,
                        animationDelay: `${i * 0.2}s`,
                        minWidth: pct > 5 ? undefined : "8px",
                      }}
                      title={`${genre}: ${Math.round(pct)}%`}
                    >
                      {pct > 12 && (
                        <span className="text-[10px] font-bold text-white/90 drop-shadow">
                          {genre}
                        </span>
                      )}
                    </div>
                  );
                })}
              </div>

              {/* Legend */}
              <div className="mt-3 flex flex-wrap gap-3">
                {topGenres.map(([genre, count]) => {
                  const pct = Math.round((count / history.length) * 100);
                  const color = getGenreColor(genre);
                  return (
                    <div key={genre} className="flex items-center gap-1.5">
                      <div
                        className="h-2.5 w-2.5 rounded-full"
                        style={{ background: color }}
                      />
                      <span className="text-[11px] text-white/70">
                        {genre} <span className="text-white/40">{pct}%</span>
                      </span>
                    </div>
                  );
                })}
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

/* ──────────────────────────── Sub-components ──────────────────────────── */

function TraitBar({
  label,
  value,
  color,
  delay,
}: {
  label: string;
  value: number;
  color: string;
  delay: number;
}) {
  return (
    <div>
      <div className="mb-1 flex items-center justify-between text-xs">
        <span className="font-medium text-white/80">{label}</span>
        <span className="font-bold text-white/60">{value}%</span>
      </div>
      <div className="bl-trait-bar">
        <div
          className="bl-trait-bar-fill"
          style={{
            width: `${value}%`,
            background: `linear-gradient(90deg, ${color}, ${color}aa)`,
            animationDelay: `${delay}s`,
          }}
        />
      </div>
    </div>
  );
}

function HighlightCard({
  icon,
  label,
  value,
  sublabel,
  gradient,
  delay,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  sublabel: string;
  gradient: string;
  delay: number;
}) {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setVisible(true), delay * 1000 + 300);
    return () => clearTimeout(t);
  }, [delay]);

  return (
    <div
      className={`bl-highlight-card transition-all duration-700 ${
        visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"
      }`}
    >
      <div className={`absolute inset-0 bg-gradient-to-br ${gradient} opacity-10 transition-opacity hover:opacity-20`} />
      <div className="relative">
        <div className={`mb-3 inline-flex rounded-lg bg-gradient-to-br ${gradient} p-2 text-white shadow-lg`}>
          {icon}
        </div>
        <div className="text-2xl font-extrabold text-white">{value}</div>
        <div className="mt-0.5 text-xs font-medium text-white/70">{label}</div>
        <div className="mt-1 text-[10px] text-[var(--sp-text-subdued)]">{sublabel}</div>
      </div>
    </div>
  );
}

function EmptyState({ text }: { text: string }) {
  return (
    <div className="flex h-32 items-center justify-center text-xs text-[var(--sp-text-subdued)]">
      {text}
    </div>
  );
}

/* ──────────────────────────── AuraRadialViz ──────────────────────────── */

interface AuraRadialVizProps {
  topGenres: [string, number][];
  auraColors: string[];
  adventurousScore: number;
  loyalScore: number;
  energeticScore: number;
  mellowScore: number;
}

function AuraRadialViz({ topGenres, auraColors, adventurousScore, loyalScore, energeticScore, mellowScore }: AuraRadialVizProps) {
  const SIZE = 240;
  const CENTER = SIZE / 2;
  const OUTER_R = 110;
  const INNER_R = 60;

  // Build radial bars (one per genre, scaled by count)
  const totalPlays = topGenres.reduce((s, [, c]) => s + c, 0);
  const genreBars = topGenres.slice(0, 8).map(([genre, count], i) => {
    const color = getGenreColor(genre);
    const length = totalPlays > 0 ? count / totalPlays : 0; // 0-1 ratio of plays
    return { genre, count, color, length, index: i };
  });

  // Personality trait radial segments (4 quadrants)
  const traits = [
    { label: "Adv", value: adventurousScore, color: auraColors[0] },
    { label: "Loyal", value: loyalScore, color: "#ec4899" },
    { label: "Energy", value: energeticScore, color: "#f97316" },
    { label: "Mellow", value: mellowScore, color: "#06b6d4" },
  ];

  return (
    <div className="relative" style={{ width: SIZE, height: SIZE }}>
      {/* Outer rotating conic-gradient ring (aura glow) */}
      <div
        className="bl-aura-orb absolute inset-0"
        style={{
          background: `conic-gradient(from 0deg, ${auraColors[0]}, ${auraColors[1]}, ${auraColors[0]})`,
          filter: "blur(8px)",
          opacity: 0.5,
          animation: "bl-aura-pulse 4s ease-in-out infinite",
        }}
      />

      {/* SVG visualization */}
      <svg viewBox={`0 0 ${SIZE} ${SIZE}`} width={SIZE} height={SIZE} className="relative">
        <defs>
          <radialGradient id="auraCore" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="rgba(255,255,255,0.15)" />
            <stop offset="60%" stopColor="rgba(0,0,0,0.4)" />
            <stop offset="100%" stopColor="rgba(0,0,0,0.9)" />
          </radialGradient>
          <filter id="glow">
            <feGaussianBlur stdDeviation="2" result="coloredBlur" />
            <feMerge>
              <feMergeNode in="coloredBlur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        </defs>

        {/* Outer guide ring */}
        <circle cx={CENTER} cy={CENTER} r={OUTER_R + 6} fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth="1" />
        <circle cx={CENTER} cy={CENTER} r={INNER_R - 4} fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth="1" />

        {/* Personality trait arcs (4 quadrants inside inner ring) */}
        {traits.map((trait, i) => {
          const arcSpan = 80; // degrees per trait quadrant (4 × 80 = 320, leaving 4×10 gap)
          const gap = 10;
          const startAngle = i * (arcSpan + gap) - 90 + gap / 2;
          const endAngle = startAngle + (trait.value / 100) * arcSpan;
          const startRad = (startAngle * Math.PI) / 180;
          const endRad = (endAngle * Math.PI) / 180;
          const r = INNER_R - 8;
          const x1 = CENTER + r * Math.cos(startRad);
          const y1 = CENTER + r * Math.sin(startRad);
          const x2 = CENTER + r * Math.cos(endRad);
          const y2 = CENTER + r * Math.sin(endRad);
          const largeArc = endAngle - startAngle > 180 ? 1 : 0;
          return (
            <g key={i}>
              {/* Background arc */}
              <path
                d={`M ${CENTER + r * Math.cos((startAngle * Math.PI) / 180)} ${CENTER + r * Math.sin((startAngle * Math.PI) / 180)} A ${r} ${r} 0 1 1 ${CENTER + r * Math.cos(((startAngle + arcSpan) * Math.PI) / 180)} ${CENTER + r * Math.sin(((startAngle + arcSpan) * Math.PI) / 180)}`}
                fill="none"
                stroke="rgba(255,255,255,0.04)"
                strokeWidth="6"
                strokeLinecap="round"
              />
              {/* Value arc */}
              <path
                d={`M ${x1} ${y1} A ${r} ${r} 0 ${largeArc} 1 ${x2} ${y2}`}
                fill="none"
                stroke={trait.color}
                strokeWidth="6"
                strokeLinecap="round"
                filter="url(#glow)"
                style={{
                  transformOrigin: `${CENTER}px ${CENTER}px`,
                  animation: `bl-trait-fill 1.4s ${0.2 + i * 0.15}s ease-out both`,
                }}
              >
                <title>{trait.label}: {trait.value}%</title>
              </path>
            </g>
          );
        })}

        {/* Genre radial bars (outside inner ring) */}
        {genreBars.length === 0 && (
          <text x={CENTER} y={CENTER - 4} textAnchor="middle" fill="#9ca3af" fontSize="11" fontWeight="bold">
            No data yet
          </text>
        )}
        {genreBars.map((bar, i) => {
          const angleStep = 360 / Math.max(1, genreBars.length);
          const angle = i * angleStep - 90;
          const angleRad = (angle * Math.PI) / 180;
          const barLen = 12 + bar.length * (OUTER_R - INNER_R - 16); // 12px min, rest scaled
          const x1 = CENTER + INNER_R * Math.cos(angleRad);
          const y1 = CENTER + INNER_R * Math.sin(angleRad);
          const x2 = CENTER + (INNER_R + barLen) * Math.cos(angleRad);
          const y2 = CENTER + (INNER_R + barLen) * Math.sin(angleRad);
          return (
            <g key={i}>
              <line
                x1={x1}
                y1={y1}
                x2={x2}
                y2={y2}
                stroke={bar.color}
                strokeWidth="4"
                strokeLinecap="round"
                filter="url(#glow)"
                opacity={0.85}
                style={{
                  transformOrigin: `${CENTER}px ${CENTER}px`,
                  animation: `bl-trait-fill 1s ${0.5 + i * 0.08}s ease-out both`,
                }}
              >
                <title>{bar.genre}: {bar.count} plays</title>
              </line>
              {/* Bar endpoint dot */}
              <circle cx={x2} cy={y2} r="3" fill={bar.color} filter="url(#glow)" />
            </g>
          );
        })}

        {/* Inner core */}
        <circle cx={CENTER} cy={CENTER} r={INNER_R - 14} fill="url(#auraCore)" />

        {/* Center text: personality abbreviation or icon */}
        <text x={CENTER} y={CENTER - 6} textAnchor="middle" fill="#fff" fontSize="11" fontWeight="bold" opacity="0.9">
          YOUR
        </text>
        <text x={CENTER} y={CENTER + 10} textAnchor="middle" fill="#fff" fontSize="13" fontWeight="bold" opacity="0.95">
          AURA
        </text>
        <text x={CENTER} y={CENTER + 26} textAnchor="middle" fill="#9ca3af" fontSize="9">
          {topGenres.length} genres • {totalPlays} plays
        </text>
      </svg>

      {/* Floating particle dots around the aura */}
      {Array.from({ length: 8 }).map((_, i) => {
        const angle = (i / 8) * 360;
        const delay = i * 0.5;
        return (
          <div
            key={i}
            className="bl-aura-particle"
            style={{
              left: "50%",
              top: "50%",
              transform: `rotate(${angle}deg) translateY(-${OUTER_R + 10}px)`,
              animationDelay: `${delay}s`,
              background: auraColors[i % 2],
            }}
          />
        );
      })}
    </div>
  );
}
