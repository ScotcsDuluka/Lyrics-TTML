"use client";
import { Play, Pause, Heart, Music2, User } from "lucide-react";
import type { Track } from "@/lib/types";

interface ArtistViewProps {
  artistName: string;
  tracks: Track[];
  currentTrackId: string | null;
  isPlaying: boolean;
  onSelectTrack: (track: Track, index: number) => void;
  onTogglePlay: () => void;
  onToggleLike: (trackId: string) => void;
}

/** Hash a string to a number 0-360 for use as a hue */
function hashToHue(str: string): number {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = str.charCodeAt(i) + ((hash << 5) - hash);
    hash = hash & hash; // Convert to 32-bit int
  }
  return ((hash % 360) + 360) % 360;
}

function fmtDuration(s?: number | null): string {
  if (!s || !isFinite(s)) return "--:--";
  const t = Math.floor(s);
  const m = Math.floor(t / 60);
  const sec = t % 60;
  return `${m}:${sec.toString().padStart(2, "0")}`;
}

export function ArtistView({
  artistName,
  tracks,
  currentTrackId,
  isPlaying,
  onSelectTrack,
  onTogglePlay,
  onToggleLike,
}: ArtistViewProps) {
  const hue = hashToHue(artistName);
  const artistImage = tracks[0]?.coverUrl ?? null;

  const totalDuration = tracks.reduce((sum, t) => sum + (t.duration ?? 0), 0);
  const totalMinutes = Math.round(totalDuration / 60);

  // Auto-generate a description from the track data
  const albums = [...new Set(tracks.map((t) => t.album).filter(Boolean))];
  const description =
    tracks.length === 0
      ? `${artistName} is an artist on Beautiful Lyrics. No tracks available yet.`
      : `${artistName} is an artist on Beautiful Lyrics with ${tracks.length} track${tracks.length !== 1 ? "s" : ""}${albums.length > 0 ? ` across ${albums.length} album${albums.length !== 1 ? "s" : ""}` : ""}${totalMinutes > 0 ? `, totalling about ${totalMinutes} minutes of music` : ""}. ${albums.length > 0 ? `Albums include ${albums.slice(0, 3).join(", ")}${albums.length > 3 ? " and more" : ""}.` : ""}`;

  return (
    <div className="bl-scroll flex-1">
      {/* Header — Spotify-style gradient with artist info */}
      <div
        className="px-6 pb-8 pt-12"
        style={{
          background: `linear-gradient(to bottom, hsl(${hue}, 50%, 25%) 0%, hsl(${hue}, 40%, 15%) 50%, transparent 100%)`,
        }}
      >
        <div className="flex items-end gap-6">
          {/* Artist avatar — large circle */}
          <div className="h-52 w-52 shrink-0 overflow-hidden rounded-full shadow-2xl">
            {artistImage ? (
              <img
                src={artistImage}
                alt={artistName}
                className="h-full w-full object-cover"
              />
            ) : (
              <div
                className="flex h-full w-full items-center justify-center"
                style={{
                  background: `linear-gradient(135deg, hsl(${hue}, 40%, 35%), hsl(${hue}, 30%, 20%))`,
                }}
              >
                <User size={80} className="text-white/40" />
              </div>
            )}
          </div>

          {/* Artist info */}
          <div className="min-w-0 flex-1 pb-2">
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-white/80">
              <Music2 size={12} />
              <span>Artist</span>
            </div>
            <h1 className="mt-3 truncate text-6xl font-extrabold tracking-tight text-white md:text-7xl">
              {artistName}
            </h1>
            <div className="mt-4 flex items-center gap-1 text-sm text-white/70">
              <span>
                {tracks.length} track{tracks.length !== 1 ? "s" : ""}
              </span>
              {totalMinutes > 0 && (
                <>
                  <span>•</span>
                  <span>about {totalMinutes} min</span>
                </>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Toolbar with play button */}
      <div className="bg-black/20 px-6 py-4">
        <div className="flex items-center gap-6">
          <button
            onClick={onTogglePlay}
            disabled={tracks.length === 0}
            className="flex h-14 w-14 items-center justify-center rounded-full bg-emerald-500 text-black shadow-lg transition-all hover:scale-105 hover:bg-emerald-400 active:scale-95 disabled:opacity-40"
          >
            {isPlaying ? (
              <Pause size={24} fill="currentColor" />
            ) : (
              <Play size={24} fill="currentColor" className="ml-1" />
            )}
          </button>
        </div>
      </div>

      {/* Popular tracks section */}
      <div className="px-6 pb-2">
        <h2 className="mb-4 text-2xl font-bold text-white">Popular</h2>
      </div>

      {tracks.length === 0 ? (
        <div className="px-6 py-12 text-center text-[var(--sp-text-subdued)]">
          <Music2 size={48} className="mx-auto mb-4 opacity-30" />
          <div className="text-lg">No tracks available</div>
        </div>
      ) : (
        <div className="px-6 pb-6">
          {/* Column header */}
          <div className="grid grid-cols-[16px_4fr_minmax(80px,1fr)_minmax(60px,auto)] items-center gap-4 border-b border-white/10 px-4 py-2 text-xs uppercase tracking-wider text-[var(--sp-text-subdued)]">
            <div className="text-center">#</div>
            <div>Title</div>
            <div className="hidden md:block">Plays</div>
            <div className="text-right">Duration</div>
          </div>

          {/* Track rows */}
          <div>
            {tracks.map((t, i) => {
              const active = t.id === currentTrackId;
              return (
                <div
                  key={t.id}
                  onDoubleClick={() => onSelectTrack(t, i)}
                  className={`bl-track-row group grid grid-cols-[16px_4fr_minmax(80px,1fr)_minmax(60px,auto)] items-center gap-4 rounded-md px-4 py-2 ${active ? "active" : ""}`}
                >
                  {/* Index / Play button */}
                  <div className="text-center text-sm tabular-nums text-[var(--sp-text-subdued)]">
                    {active && isPlaying ? (
                      <>
                        <span className="text-emerald-400 group-hover:hidden">
                          <span className="bl-eq-bar">
                            {[0, 1, 2, 3].map((j) => (
                              <span
                                key={j}
                                style={{
                                  animationDelay: `${j * 0.15}s`,
                                  animationDuration: "0.8s",
                                  height: `${[60, 100, 70, 90][j]}%`,
                                }}
                              />
                            ))}
                          </span>
                        </span>
                        <button
                          onClick={onTogglePlay}
                          className="hidden text-white group-hover:block"
                        >
                          <Pause size={14} fill="currentColor" />
                        </button>
                      </>
                    ) : (
                      <>
                        <span className="group-hover:hidden">
                          {active ? (
                            <span className="text-emerald-400">{i + 1}</span>
                          ) : (
                            i + 1
                          )}
                        </span>
                        <button
                          onClick={() => onSelectTrack(t, i)}
                          className="hidden text-white group-hover:block"
                        >
                          <Play size={14} fill="currentColor" />
                        </button>
                      </>
                    )}
                  </div>

                  {/* Title + cover */}
                  <div className="flex min-w-0 items-center gap-3">
                    <div className="h-10 w-10 shrink-0 overflow-hidden rounded">
                      {t.coverUrl ? (
                        <img
                          src={t.coverUrl}
                          alt=""
                          className="h-full w-full object-cover"
                        />
                      ) : (
                        <div className="flex h-full w-full items-center justify-center bg-white/10">
                          <Music2 size={14} className="text-white/30" />
                        </div>
                      )}
                    </div>
                    <div className="min-w-0">
                      <div
                        className={`truncate text-sm font-medium ${active ? "text-emerald-400" : "text-white"}`}
                      >
                        {t.title}
                      </div>
                      <div className="truncate text-xs text-[var(--sp-text-subdued)]">
                        {t.album || "—"}
                      </div>
                    </div>
                  </div>

                  {/* Play count (derived from id) */}
                  <div className="hidden text-sm text-[var(--sp-text-subdued)] md:block">
                    {(parseInt(t.id.slice(-4), 36) % 999 + 1).toLocaleString()}
                  </div>

                  {/* Like + duration */}
                  <div className="flex items-center justify-end gap-3">
                    <button
                      onClick={() => onToggleLike(t.id)}
                      className={`transition-opacity ${t.liked ? "text-emerald-400 opacity-100" : "text-[var(--sp-text-subdued)] opacity-0 group-hover:opacity-100 hover:text-white"}`}
                    >
                      <Heart
                        size={14}
                        fill={t.liked ? "currentColor" : "none"}
                      />
                    </button>
                    <span className="text-sm tabular-nums text-[var(--sp-text-subdued)]">
                      {fmtDuration(t.duration)}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* About section */}
      <div className="px-6 pb-12">
        <h2 className="mb-4 text-2xl font-bold text-white">About</h2>
        <div
          className="overflow-hidden rounded-lg p-6"
          style={{
            background: `linear-gradient(135deg, hsl(${hue}, 30%, 18%), hsl(${hue}, 20%, 10%))`,
          }}
        >
          <div className="flex items-start gap-4">
            {/* Small artist avatar in about card */}
            <div className="h-20 w-20 shrink-0 overflow-hidden rounded-full">
              {artistImage ? (
                <img
                  src={artistImage}
                  alt={artistName}
                  className="h-full w-full object-cover"
                />
              ) : (
                <div
                  className="flex h-full w-full items-center justify-center"
                  style={{
                    background: `linear-gradient(135deg, hsl(${hue}, 40%, 35%), hsl(${hue}, 30%, 20%))`,
                  }}
                >
                  <User size={32} className="text-white/40" />
                </div>
              )}
            </div>
            <div className="min-w-0 flex-1">
              <div className="text-lg font-bold text-white">{artistName}</div>
              <p className="mt-2 text-sm leading-relaxed text-white/70">
                {description}
              </p>
              <div className="mt-4 flex items-center gap-4 text-xs text-[var(--sp-text-subdued)]">
                <span>{tracks.length} tracks</span>
                {albums.length > 0 && (
                  <span>{albums.length} album{albums.length !== 1 ? "s" : ""}</span>
                )}
                {totalMinutes > 0 && <span>{totalMinutes} min total</span>}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
