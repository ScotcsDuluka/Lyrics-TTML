"use client";
import { useState, useEffect, useRef, useCallback } from "react";
import {
  Play, Pause, Heart, ListPlus, Share2, User, Disc3,
  SkipForward, Queue, Trash2, Copy, ExternalLink, Music2
} from "lucide-react";
import type { Track, Playlist } from "@/lib/types";

interface ContextMenuState {
  x: number;
  y: number;
  track: Track;
  trackIndex: number;
}

interface Props {
  tracks: Track[];
  playlists: Playlist[];
  currentTrackId: string | null;
  isPlaying: boolean;
  onSelectTrack: (track: Track, index: number) => void;
  onTogglePlay: () => void;
  onToggleLike: (trackId: string) => void;
  onAddToPlaylist: (playlistId: string, trackId: string) => Promise<boolean>;
  onCreatePlaylistWithTrack: (name: string, trackId: string) => Promise<string | null>;
  onAddToQueue?: (trackId: string) => void;
  onSelectArtist?: (name: string) => void;
  onSelectAlbum?: (name: string) => void;
  onShare?: (track: Track) => void;
  onDelete?: (trackId: string) => void;
  children: React.ReactNode;
}

export function TrackContextMenu({
  tracks,
  playlists,
  currentTrackId,
  isPlaying,
  onSelectTrack,
  onTogglePlay,
  onToggleLike,
  onAddToPlaylist,
  onCreatePlaylistWithTrack,
  onAddToQueue,
  onSelectArtist,
  onSelectAlbum,
  onShare,
  onDelete,
  children,
}: Props) {
  const [menu, setMenu] = useState<ContextMenuState | null>(null);
  const [showPlaylistSub, setShowPlaylistSub] = useState(false);
  const menuRef = useRef<HTMLDivElement | null>(null);
  const [newPlaylistName, setNewPlaylistName] = useState("");
  const [showNewPlaylist, setShowNewPlaylist] = useState(false);

  const handleContextMenu = useCallback((e: React.MouseEvent) => {
    // Find the closest track row
    const target = (e.target as HTMLElement).closest("[data-track-id]");
    if (!target) return;

    e.preventDefault();
    const trackId = target.getAttribute("data-track-id");
    const trackIndex = parseInt(target.getAttribute("data-track-index") || "0", 10);
    const track = tracks.find(t => t.id === trackId);
    if (!track) return;

    // Calculate position, keeping menu within viewport
    const x = Math.min(e.clientX, window.innerWidth - 260);
    const y = Math.min(e.clientY, window.innerHeight - 400);

    setMenu({ x, y, track, trackIndex });
    setShowPlaylistSub(false);
    setShowNewPlaylist(false);
  }, [tracks]);

  const close = useCallback(() => {
    setMenu(null);
    setShowPlaylistSub(false);
    setShowNewPlaylist(false);
  }, []);

  // Close on click outside
  useEffect(() => {
    if (!menu) return;
    const onClick = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        close();
      }
    };
    const onEsc = (e: KeyboardEvent) => {
      if (e.key === "Escape") close();
    };
    document.addEventListener("mousedown", onClick);
    document.addEventListener("keydown", onEsc);
    return () => {
      document.removeEventListener("mousedown", onClick);
      document.removeEventListener("keydown", onEsc);
    };
  }, [menu, close]);

  // Close on scroll
  useEffect(() => {
    if (!menu) return;
    const onScroll = () => close();
    window.addEventListener("scroll", onScroll, true);
    return () => window.removeEventListener("scroll", onScroll, true);
  }, [menu, close]);

  if (!menu) {
    return (
      <div onContextMenu={handleContextMenu}>
        {children}
      </div>
    );
  }

  const { track, trackIndex } = menu;
  const isActive = track.id === currentTrackId;

  return (
    <div onContextMenu={handleContextMenu}>
      {children}

      {/* Backdrop */}
      <div className="fixed inset-0 z-[9995]" onClick={close} />

      {/* Context menu */}
      <div
        ref={menuRef}
        className="fixed z-[9996] min-w-[220px] rounded-xl border border-white/15 bg-black/95 p-1.5 shadow-2xl backdrop-blur-xl bl-scale-in"
        style={{ left: menu.x, top: menu.y }}
      >
        {/* Track info header */}
        <div className="flex items-center gap-3 border-b border-white/10 px-3 py-2 mb-1">
          <div className="h-10 w-10 shrink-0 overflow-hidden rounded">
            {track.coverUrl ? (
              <img src={track.coverUrl} alt="" className="h-full w-full object-cover" />
            ) : (
              <div className="flex h-full w-full items-center justify-center bg-white/10">
                <Music2 size={14} className="text-white/40" />
              </div>
            )}
          </div>
          <div className="min-w-0 flex-1">
            <div className="truncate text-sm font-medium text-white">{track.title}</div>
            <div className="truncate text-xs text-[var(--sp-text-subdued)]">{track.artists.join(", ")}</div>
          </div>
        </div>

        {/* Play/Pause */}
        <MenuItem
          icon={isActive && isPlaying ? <Pause size={16} /> : <Play size={16} />}
          label={isActive && isPlaying ? "Pause" : "Play"}
          onClick={() => {
            if (isActive) {
              onTogglePlay();
            } else {
              onSelectTrack(track, trackIndex);
            }
            close();
          }}
        />

        {/* Add to queue */}
        {onAddToQueue && (
          <MenuItem
            icon={<SkipForward size={16} />}
            label="Add to queue"
            onClick={() => {
              onAddToQueue(track.id);
              close();
            }}
          />
        )}

        {/* Like/Unlike */}
        <MenuItem
          icon={<Heart size={16} fill={track.liked ? "currentColor" : "none"} />}
          label={track.liked ? "Remove from Liked Songs" : "Save to Liked Songs"}
          color={track.liked ? "text-emerald-400" : undefined}
          onClick={() => {
            onToggleLike(track.id);
            close();
          }}
        />

        <div className="my-1 h-px bg-white/10" />

        {/* Add to playlist */}
        <div className="relative">
          <MenuItem
            icon={<ListPlus size={16} />}
            label="Add to playlist"
            suffix="›"
            onClick={() => setShowPlaylistSub(!showPlaylistSub)}
          />

          {showPlaylistSub && (
            <div className="absolute left-full top-0 ml-1 min-w-[200px] rounded-xl border border-white/15 bg-black/95 p-1.5 shadow-2xl backdrop-blur-xl bl-scale-in" style={{ zIndex: 9997 }}>
              <div className="px-3 py-1.5 text-[10px] font-bold uppercase tracking-wider text-white/40">Add to playlist</div>
              {playlists.filter(p => !p.isSystem).map(pl => (
                <button
                  key={pl.id}
                  onClick={async () => {
                    await onAddToPlaylist(pl.id, track.id);
                    close();
                  }}
                  className="flex w-full items-center gap-2 rounded-md px-3 py-2 text-left text-sm text-white/80 transition-colors hover:bg-white/10"
                >
                  <Music2 size={14} className="text-white/40" />
                  <span className="truncate">{pl.name}</span>
                  <span className="ml-auto text-[10px] text-white/40">{pl.trackCount}</span>
                </button>
              ))}
              <div className="my-1 h-px bg-white/10" />
              {showNewPlaylist ? (
                <div className="flex items-center gap-2 px-3 py-2">
                  <input
                    type="text"
                    value={newPlaylistName}
                    onChange={e => setNewPlaylistName(e.target.value)}
                    placeholder="Playlist name"
                    className="flex-1 rounded bg-white/10 px-2 py-1 text-xs text-white outline-none placeholder:text-white/30"
                    autoFocus
                    onKeyDown={async e => {
                      if (e.key === "Enter" && newPlaylistName.trim()) {
                        await onCreatePlaylistWithTrack(newPlaylistName.trim(), track.id);
                        setNewPlaylistName("");
                        close();
                      }
                    }}
                  />
                  <button
                    onClick={async () => {
                      if (newPlaylistName.trim()) {
                        await onCreatePlaylistWithTrack(newPlaylistName.trim(), track.id);
                        setNewPlaylistName("");
                        close();
                      }
                    }}
                    className="rounded bg-emerald-500 px-2 py-1 text-xs font-bold text-black"
                  >
                    Create
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => setShowNewPlaylist(true)}
                  className="flex w-full items-center gap-2 rounded-md px-3 py-2 text-left text-sm text-emerald-400 transition-colors hover:bg-white/10"
                >
                  <ListPlus size={14} />
                  New playlist
                </button>
              )}
            </div>
          )}
        </div>

        {/* Go to artist */}
        {onSelectArtist && track.artists.length > 0 && (
          <MenuItem
            icon={<User size={16} />}
            label={track.artists.length > 1 ? "Go to artists" : "Go to artist"}
            onClick={() => {
              onSelectArtist(track.artists[0]);
              close();
            }}
          />
        )}

        {/* Go to album */}
        {onSelectAlbum && track.album && (
          <MenuItem
            icon={<Disc3 size={16} />}
            label="Go to album"
            onClick={() => {
              onSelectAlbum(track.album);
              close();
            }}
          />
        )}

        <div className="my-1 h-px bg-white/10" />

        {/* Share */}
        {onShare && (
          <MenuItem
            icon={<Share2 size={16} />}
            label="Share"
            onClick={() => {
              onShare(track);
              close();
            }}
          />
        )}

        {/* Copy link */}
        <MenuItem
          icon={<Copy size={16} />}
          label="Copy track link"
          onClick={() => {
            const url = `${window.location.origin}?share=track_${track.id}`;
            navigator.clipboard.writeText(url);
            close();
          }}
        />

        {/* Open in new tab */}
        <MenuItem
          icon={<ExternalLink size={16} />}
          label="Open in new tab"
          onClick={() => {
            window.open(`${window.location.origin}?share=track_${track.id}`, "_blank");
            close();
          }}
        />

        {/* Delete */}
        {onDelete && (
          <>
            <div className="my-1 h-px bg-white/10" />
            <MenuItem
              icon={<Trash2 size={16} />}
              label="Remove from playlist"
              color="text-red-400"
              onClick={() => {
                onDelete(track.id);
                close();
              }}
            />
          </>
        )}
      </div>
    </div>
  );
}

function MenuItem({ icon, label, color, suffix, onClick }: {
  icon: React.ReactNode;
  label: string;
  color?: string;
  suffix?: string;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className={`flex w-full items-center gap-3 rounded-md px-3 py-2 text-left text-sm transition-colors hover:bg-white/10 ${
        color || "text-white/80"
      }`}
    >
      <span className="text-[var(--sp-text-subdued)]">{icon}</span>
      <span className="flex-1">{label}</span>
      {suffix && <span className="text-[var(--sp-text-subdued)]">{suffix}</span>}
    </button>
  );
}
