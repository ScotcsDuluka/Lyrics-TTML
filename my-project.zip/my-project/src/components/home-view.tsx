"use client";
import { useState, useEffect, useRef } from "react";
import { Play, Pause, Heart, Clock, Music2, Sparkles, User, TrendingUp, Flame, Disc3, Tag, Radio, ChevronRight, Volume2, Mic2 } from "lucide-react";
import type { Playlist, Track } from "@/lib/types";

interface Props {
  playlists: Playlist[];
  recentlyPlayed: Track[];
  allTracks: Track[];
  likedTrackCount: number;
  currentTrack: Track | null;
  isPlaying: boolean;
  onSelectPlaylist: (id: string) => void;
  onGoLiked: () => void;
  onPlayTrack: (track: Track) => void;
  onSelectArtist: (name: string) => void;
  onSelectAlbum: (name: string) => void;
  onToggleLyrics: () => void;
}

// Genre color map for visual distinction
const GENRE_COLORS: Record<string, string> = {
  Ambient: "from-teal-500/60 to-cyan-800/60",
  Electronic: "from-blue-500/60 to-cyan-800/60",
  Pop: "from-pink-500/60 to-rose-800/60",
  Nature: "from-green-500/60 to-emerald-800/60",
  "Lo-fi": "from-amber-500/60 to-orange-800/60",
  World: "from-yellow-500/60 to-amber-800/60",
  Tropical: "from-emerald-500/60 to-lime-800/60",
  Rock: "from-red-500/60 to-rose-800/60",
  Indie: "from-violet-500/60 to-purple-800/60",
  Space: "from-indigo-500/60 to-violet-800/60",
};

const GENRE_ICONS: Record<string, string> = {
  Ambient: "🌙",
  Electronic: "⚡",
  Pop: "🎤",
  Nature: "🌿",
  "Lo-fi": "🎧",
  World: "🌍",
  Tropical: "🌴",
  Rock: "🎸",
  Indie: "🎵",
  Space: "🚀",
};

export function HomeView({ playlists, recentlyPlayed, allTracks, likedTrackCount, currentTrack, isPlaying, onSelectPlaylist, onGoLiked, onPlayTrack, onSelectArtist, onSelectAlbum, onToggleLyrics }: Props) {
  const greeting = () => {
    const h = new Date().getHours();
    if (h < 12) return "Good morning";
    if (h < 18) return "Good afternoon";
    return "Good evening";
  };

  // Generate "Made for You" playlists based on genres/moods
  const madeForYou = generateMadeForYou(allTracks);

  // Extract unique artists from all tracks
  const artists = extractArtists(allTracks);

  // Extract unique albums from all tracks
  const albums = extractAlbums(allTracks);

  // Extract unique genres from all tracks
  const genres = extractGenres(allTracks);

  // Recently added: tracks sorted by ID (newest first by createdAt implicit)
  const recentlyAdded = [...allTracks].slice(0, 10);

  // "Your Top Tracks" — derive play count from ID hash for stability
  const topTracks = [...allTracks]
    .map(t => ({ ...t, plays: parseInt(t.id.slice(-4), 36) % 999 + 1 }))
    .sort((a, b) => b.plays - a.plays)
    .slice(0, 6);

  // Featured playlist (first non-system playlist)
  const featuredPlaylist = playlists.find(p => !p.isSystem) || playlists[0];

  // Quick picks: top tracks shown as small rectangular cards
  const quickPicks = topTracks.slice(0, 6);

  // Quick links — fill the grid with multiple shortcuts (Liked + Recent + Top + Made-For-You)
  const quickLinks = [
    { id: "liked", label: "Liked Songs", count: likedTrackCount, onClick: onGoLiked, gradient: "from-purple-500 to-pink-600", icon: <Heart size={20} fill="currentColor" className="text-white" /> },
    ...(recentlyPlayed[0] ? [{ id: "recent1", label: recentlyPlayed[0].title, count: 1, onClick: () => onPlayTrack(recentlyPlayed[0]), gradient: "from-emerald-500 to-teal-600", icon: <Clock size={20} className="text-white" /> }] : []),
    ...(madeForYou[0] ? [{ id: "mfy1", label: madeForYou[0].title, count: madeForYou[0].tracks.length, onClick: () => madeForYou[0].tracks[0] && onPlayTrack(madeForYou[0].tracks[0]), gradient: madeForYou[0].gradient, icon: <Sparkles size={20} className="text-white" /> }] : []),
    ...(topTracks[0] ? [{ id: "top1", label: topTracks[0].title, count: 1, onClick: () => onPlayTrack(topTracks[0]), gradient: "from-amber-500 to-orange-600", icon: <TrendingUp size={20} className="text-white" /> }] : []),
    ...(recentlyPlayed[1] ? [{ id: "recent2", label: recentlyPlayed[1].title, count: 1, onClick: () => onPlayTrack(recentlyPlayed[1]), gradient: "from-cyan-500 to-blue-600", icon: <Clock size={20} className="text-white" /> }] : []),
    ...(madeForYou[1] ? [{ id: "mfy2", label: madeForYou[1].title, count: madeForYou[1].tracks.length, onClick: () => madeForYou[1].tracks[0] && onPlayTrack(madeForYou[1].tracks[0]), gradient: madeForYou[1].gradient, icon: <Sparkles size={20} className="text-white" /> }] : []),
  ];

  // Show all state per section
  const [showAllSections, setShowAllSections] = useState<Record<string, boolean>>({});

  const toggleShowAll = (key: string) => {
    setShowAllSections(prev => ({ ...prev, [key]: !prev[key] }));
  };

  // Section entrance animation stagger
  const sectionIndex = useRef(0);

  // Thai tracks: tracks with lyricsUrl (TTML synced lyrics)
  const thaiTracks = allTracks.filter(t => t.lyricsUrl);
  const recentlyPlayedThai = recentlyPlayed.filter(t => t.lyricsUrl);
  const newReleases = thaiTracks.slice(0, 10); // Newest Thai songs

  return (
    <div className="bl-scroll flex-1 px-6 pb-6 bl-view-transition">
      {/* Ambient gradient background */}
      <div className="pointer-events-none fixed inset-0 -z-10 overflow-hidden opacity-30">
        <div className="bl-ambient-orb bl-ambient-orb-1" />
        <div className="bl-ambient-orb bl-ambient-orb-2" />
      </div>

      {/* Now Playing Banner */}
      {currentTrack && (
        <div className="bl-now-playing-banner bl-section-in" style={{ animationDelay: "0ms" }}>
          <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-emerald-600/30 via-teal-800/20 to-black/40 p-4 backdrop-blur-sm">
            {/* Background cover art (blurred) */}
            {currentTrack.coverUrl && (
              <div className="absolute inset-0 -z-10">
                <img src={currentTrack.coverUrl} alt="" className="h-full w-full object-cover opacity-20 blur-xl scale-110" />
                <div className="absolute inset-0 bg-gradient-to-r from-emerald-900/60 via-black/40 to-black/80" />
              </div>
            )}
            <div className="flex items-center gap-4">
              <div className="relative h-16 w-16 shrink-0 overflow-hidden rounded-xl shadow-lg shadow-emerald-500/20 bl-now-playing-cover">
                {currentTrack.coverUrl ? (
                  <img src={currentTrack.coverUrl} alt="" className="h-full w-full object-cover" />
                ) : (
                  <div className="flex h-full w-full items-center justify-center bg-white/10">
                    <Music2 size={24} className="text-white/40" />
                  </div>
                )}
                {isPlaying && (
                  <div className="absolute inset-0 flex items-center justify-center bg-black/20 rounded-xl">
                    <div className="bl-eq-bar-mini">
                      {[0,1,2].map(j => (
                        <span key={j} style={{ animationDelay: `${j*0.2}s`, animationDuration: "0.6s" }} />
                      ))}
                    </div>
                  </div>
                )}
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-bold uppercase tracking-widest text-emerald-400">Now Playing</span>
                  {isPlaying && <span className="bl-pulse-dot" />}
                </div>
                <div className="truncate text-lg font-bold text-white">{currentTrack.title}</div>
                <div className="truncate text-sm text-white/60">{currentTrack.artists.join(", ")}</div>
              </div>
              <div className="flex items-center gap-2">
                {currentTrack.lyricsUrl && (
                  <button
                    onClick={onToggleLyrics}
                    className="flex items-center gap-1.5 rounded-full border border-white/10 bg-white/5 px-3 py-1.5 text-xs font-medium text-white/80 transition-all hover:border-emerald-400/30 hover:bg-emerald-500/10 hover:text-emerald-400"
                    title="Open Lyrics"
                  >
                    <Mic2 size={14} />
                    <span className="hidden sm:inline">Lyrics</span>
                  </button>
                )}
                <button
                  onClick={() => onPlayTrack(currentTrack)}
                  className="flex h-10 w-10 items-center justify-center rounded-full bg-emerald-500 text-black shadow-lg shadow-emerald-500/30 transition-all hover:scale-110 active:scale-95"
                >
                  {isPlaying ? <Pause size={18} fill="currentColor" /> : <Play size={18} fill="currentColor" className="ml-0.5" />}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Greeting header (Spotify style) */}
      <div className="pt-8 pb-6">
        <h1 className="text-3xl font-extrabold tracking-tight text-white bl-gradient-text">
          {greeting()}
        </h1>
        <p className="mt-1 text-sm text-[var(--sp-text-subdued)]">
          {allTracks.length} tracks • {albums.length} albums • {artists.length} artists
        </p>
      </div>

      {/* Featured Hero Card */}
      {featuredPlaylist && (
        <section className="bl-section-in" style={{ animationDelay: "0ms" }}>
          <FeaturedHeroCard
            playlist={featuredPlaylist}
            onClick={() => onSelectPlaylist(featuredPlaylist.id)}
            onPlay={() => {
              // Play first track from all tracks
              if (allTracks.length > 0) onPlayTrack(allTracks[0]);
            }}
          />
        </section>
      )}

      {/* Quick access grid */}
      <div className="grid grid-cols-1 gap-2 sm:grid-cols-2 lg:grid-cols-3 mt-6 bl-section-in" style={{ animationDelay: "100ms" }}>
        {quickLinks.map(q => (
          <button
            key={q.id}
            onClick={q.onClick}
            className="group flex items-center gap-4 overflow-hidden rounded-lg bg-white/10 hover:bg-white/20 transition-all hover:translate-x-1"
          >
            <div className={`flex h-16 w-16 shrink-0 items-center justify-center bg-gradient-to-br ${q.gradient}`}>
              {q.icon}
            </div>
            <div className="min-w-0 flex-1 truncate text-left text-sm font-bold text-white">{q.label}</div>
            <div className="pr-4 opacity-0 transition-opacity group-hover:opacity-100">
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-emerald-500 text-black shadow-lg bl-float">
                <Play size={18} fill="currentColor" className="ml-0.5" />
              </div>
            </div>
          </button>
        ))}
      </div>

      {/* Quick Picks row */}
      {quickPicks.length > 0 && (
        <Section title="Quick Picks" icon={<Sparkles size={20} className="text-emerald-400" />} sectionKey="quick-picks" showAll={showAllSections["quick-picks"]} onToggleShowAll={toggleShowAll} animationDelay="200ms">
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6">
            {quickPicks.map(t => (
              <QuickPickCard key={`qp-${t.id}`} track={t} onClick={() => onPlayTrack(t)} />
            ))}
          </div>
        </Section>
      )}

      {/* Genre browse section */}
      {genres.length > 0 && (
        <Section title="Browse by Genre" icon={<Tag size={20} className="text-emerald-400" />} sectionKey="genre" showAll={showAllSections["genre"]} onToggleShowAll={toggleShowAll} animationDelay="300ms">
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
            {genres.slice(0, showAllSections["genre"] ? undefined : 5).map(g => (
              <GenreCard
                key={g.name}
                genre={g.name}
                trackCount={g.trackCount}
                gradient={GENRE_COLORS[g.name] || "from-gray-500/60 to-gray-800/60"}
                icon={GENRE_ICONS[g.name] || "🎵"}
                onClick={() => {
                  const genreTracks = allTracks.filter(t => t.genre === g.name);
                  if (genreTracks.length > 0) onPlayTrack(genreTracks[0]);
                }}
              />
            ))}
          </div>
        </Section>
      )}

      {/* New Releases — Thai songs */}
      {newReleases.length > 0 && (
        <Section title="🇹🇭 New Releases" icon={<Flame size={20} className="text-emerald-400" />} sectionKey="new-releases" showAll={showAllSections["new-releases"]} onToggleShowAll={toggleShowAll} animationDelay="350ms">
          <CardGrid>
            {newReleases.slice(0, showAllSections["new-releases"] ? undefined : 10).map((t, i) => (
              <TrackCard key={`nr-${i}-${t.id}`} track={t} onClick={() => onPlayTrack(t)} />
            ))}
          </CardGrid>
        </Section>
      )}

      {/* Recently Played Thai — recently played Thai tracks */}
      {recentlyPlayedThai.length > 0 && (
        <Section title="🇹🇭 Recently Played Thai" icon={<Clock size={20} className="text-emerald-400" />} sectionKey="recently-played-thai" showAll={showAllSections["recently-played-thai"]} onToggleShowAll={toggleShowAll} animationDelay="375ms">
          <CardGrid>
            {recentlyPlayedThai.slice(0, showAllSections["recently-played-thai"] ? undefined : 10).map((t, i) => (
              <TrackCard key={`rpt-${i}-${t.id}`} track={t} onClick={() => onPlayTrack(t)} />
            ))}
          </CardGrid>
        </Section>
      )}

      {/* Jump back in — recently played with larger cards */}
      {recentlyPlayed.length > 0 && (
        <Section title="Jump back in" icon={<Clock size={20} className="text-emerald-400" />} sectionKey="jump-back" showAll={showAllSections["jump-back"]} onToggleShowAll={toggleShowAll} animationDelay="400ms">
          <CardGrid>
            {recentlyPlayed.slice(0, showAllSections["jump-back"] ? undefined : 10).map((t, i) => (
              <TrackCard key={`jp-${i}-${t.id}`} track={t} onClick={() => onPlayTrack(t)} />
            ))}
          </CardGrid>
        </Section>
      )}

      {/* Albums section */}
      {albums.length > 0 && (
        <Section title="Albums" icon={<Disc3 size={20} className="text-emerald-400" />} sectionKey="albums" showAll={showAllSections["albums"]} onToggleShowAll={toggleShowAll} animationDelay="500ms">
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
            {albums.slice(0, showAllSections["albums"] ? undefined : 10).map(a => (
              <AlbumCard
                key={a.name}
                name={a.name}
                artist={a.artist}
                coverUrl={a.coverUrl}
                trackCount={a.trackCount}
                genre={a.genre}
                onClick={() => onSelectAlbum(a.name)}
              />
            ))}
          </div>
        </Section>
      )}

      {/* Made for You */}
      {madeForYou.length > 0 && (
        <Section title="Made for you" icon={<Sparkles size={20} className="text-emerald-400" />} sectionKey="made-for-you" showAll={showAllSections["made-for-you"]} onToggleShowAll={toggleShowAll} animationDelay="600ms">
          <CardGrid>
            {madeForYou.slice(0, showAllSections["made-for-you"] ? undefined : 6).map(m => (
              <MoodCard key={m.id} title={m.title} description={m.description} gradient={m.gradient} tracks={m.tracks} onPlay={() => {
                if (m.tracks.length > 0) onPlayTrack(m.tracks[0]);
              }} />
            ))}
          </CardGrid>
        </Section>
      )}

      {/* Your Top Tracks */}
      {topTracks.length > 0 && (
        <Section title="Your Top Tracks" icon={<TrendingUp size={20} className="text-emerald-400" />} sectionKey="top-tracks" showAll={showAllSections["top-tracks"]} onToggleShowAll={toggleShowAll} animationDelay="700ms">
          <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
            {topTracks.slice(0, showAllSections["top-tracks"] ? undefined : 6).map((t, i) => (
              <TopTrackRow key={`top-${i}-${t.id}`} track={t} rank={i + 1} onClick={() => onPlayTrack(t)} />
            ))}
          </div>
        </Section>
      )}

      {/* Recently Added */}
      {recentlyAdded.length > 0 && (
        <Section title="Recently Added" icon={<Disc3 size={20} className="text-emerald-400" />} sectionKey="recently-added" showAll={showAllSections["recently-added"]} onToggleShowAll={toggleShowAll} animationDelay="800ms">
          <CardGrid>
            {recentlyAdded.slice(0, showAllSections["recently-added"] ? undefined : 10).map((t, i) => (
              <TrackCard key={`ra-${i}-${t.id}`} track={t} onClick={() => onPlayTrack(t)} />
            ))}
          </CardGrid>
        </Section>
      )}

      {/* Popular Artists */}
      {artists.length > 0 && (
        <Section title="Popular Artists" icon={<Radio size={20} className="text-emerald-400" />} sectionKey="artists" showAll={showAllSections["artists"]} onToggleShowAll={toggleShowAll} animationDelay="900ms">
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
            {artists.slice(0, showAllSections["artists"] ? undefined : 10).map(a => (
              <ArtistCard key={a.name} name={a.name} coverUrl={a.coverUrl} trackCount={a.trackCount} onClick={() => onSelectArtist(a.name)} />
            ))}
          </div>
        </Section>
      )}

      {/* All tracks */}
      {allTracks.length > 0 && (
        <Section title="All tracks" sectionKey="all-tracks" showAll={showAllSections["all-tracks"]} onToggleShowAll={toggleShowAll} animationDelay="1000ms">
          <CardGrid>
            {allTracks.slice(0, showAllSections["all-tracks"] ? undefined : 15).map((t, i) => (
              <TrackCard key={`all-${i}-${t.id}`} track={t} onClick={() => onPlayTrack(t)} />
            ))}
          </CardGrid>
        </Section>
      )}

      {/* Playlists — with TTML badge for Thai playlists */}
      {playlists.filter(p => !p.isSystem).length > 0 && (
        <Section title="Your playlists" sectionKey="playlists" showAll={showAllSections["playlists"]} onToggleShowAll={toggleShowAll} animationDelay="1100ms">
          <CardGrid>
            {playlists.filter(p => !p.isSystem).map(pl => {
              // Check if playlist has tracks with TTML lyrics
              const hasTTML = pl.name.includes("Thai") || pl.name.includes("🇹🇭") || pl.name.includes("เศร้า") || pl.name.includes("ซึม");
              return (
                <PlaylistCard key={pl.id} playlist={pl} hasTTML={hasTTML} onClick={() => onSelectPlaylist(pl.id)} />
              );
            })}
          </CardGrid>
        </Section>
      )}
    </div>
  );
}

function FeaturedHeroCard({ playlist, onClick, onPlay }: { playlist: Playlist; onClick: () => void; onPlay: () => void }) {
  const gradients = [
    "from-emerald-600/40 via-teal-800/30 to-black",
    "from-violet-600/40 via-purple-800/30 to-black",
    "from-pink-600/40 via-rose-800/30 to-black",
    "from-amber-600/40 via-orange-800/30 to-black",
    "from-cyan-600/40 via-teal-800/30 to-black",
  ];
  // Pick a gradient based on playlist id
  const gradientIndex = playlist.id.split("").reduce((a, c) => a + c.charCodeAt(0), 0) % gradients.length;
  const gradient = gradients[gradientIndex];

  return (
    <button
      onClick={onClick}
      className={`group relative flex h-48 w-full items-end overflow-hidden rounded-2xl bg-gradient-to-br ${gradient} p-6 transition-all hover:scale-[1.01] hover:shadow-2xl sm:h-56 sm:col-span-2`}
    >
      {/* Background cover art (blurred) */}
      {playlist.coverUrl && (
        <div className="absolute inset-0 -z-10">
          <img src={playlist.coverUrl} alt="" className="h-full w-full object-cover opacity-30 blur-sm scale-110" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent" />
        </div>
      )}

      {/* Content */}
      <div className="relative z-10 flex w-full items-end justify-between gap-4">
        <div className="min-w-0 flex-1">
          <div className="mb-1 text-xs font-bold uppercase tracking-widest text-emerald-400/80">Featured</div>
          <h2 className="truncate text-2xl font-extrabold text-white sm:text-3xl">{playlist.name}</h2>
          <p className="mt-1 text-sm text-white/60">{playlist.trackCount} songs</p>
        </div>
        <div className="shrink-0 translate-y-2 opacity-0 transition-all duration-300 group-hover:translate-y-0 group-hover:opacity-100">
          <div className="flex h-14 w-14 items-center justify-center rounded-full bg-emerald-500 text-black shadow-xl shadow-emerald-500/30">
            <Play size={24} fill="currentColor" className="ml-1" />
          </div>
        </div>
      </div>
    </button>
  );
}

function QuickPickCard({ track, onClick }: { track: Track; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="group flex items-center gap-3 overflow-hidden rounded-lg bg-white/5 hover:bg-white/10 transition-all"
    >
      <div className="relative h-16 w-16 shrink-0">
        {track.coverUrl ? (
          <img src={track.coverUrl} alt="" className="h-full w-full object-cover rounded-l-lg" />
        ) : (
          <div className="flex h-full w-full items-center justify-center bg-white/10 rounded-l-lg">
            <Music2 size={20} className="text-white/40" />
          </div>
        )}
      </div>
      <div className="min-w-0 flex-1 pr-2">
        <div className="truncate text-sm font-bold text-white">{track.title}</div>
        <div className="truncate text-xs text-[var(--sp-text-subdued)]">{track.artists.join(", ")}</div>
      </div>
      <div className="shrink-0 pr-3 opacity-0 transition-opacity group-hover:opacity-100">
        <div className="flex h-8 w-8 items-center justify-center rounded-full bg-emerald-500 text-black shadow-lg">
          <Play size={14} fill="currentColor" className="ml-0.5" />
        </div>
      </div>
    </button>
  );
}

function extractArtists(tracks: Track[]) {
  const map = new Map<string, { name: string; coverUrl: string | null; trackCount: number }>();
  for (const t of tracks) {
    for (const a of t.artists) {
      if (!map.has(a)) {
        map.set(a, { name: a, coverUrl: t.coverUrl, trackCount: 1 });
      } else {
        map.get(a)!.trackCount++;
      }
    }
  }
  return Array.from(map.values()).sort((a, b) => b.trackCount - a.trackCount);
}

function extractAlbums(tracks: Track[]) {
  const map = new Map<string, { name: string; artist: string; coverUrl: string | null; trackCount: number; genre: string }>();
  for (const t of tracks) {
    if (!t.album) continue;
    if (!map.has(t.album)) {
      map.set(t.album, { name: t.album, artist: t.artists.join(", "), coverUrl: t.coverUrl, trackCount: 1, genre: t.genre || "" });
    } else {
      map.get(t.album)!.trackCount++;
    }
  }
  return Array.from(map.values()).sort((a, b) => b.trackCount - a.trackCount);
}

function extractGenres(tracks: Track[]) {
  const map = new Map<string, { name: string; trackCount: number }>();
  for (const t of tracks) {
    if (!t.genre) continue;
    if (!map.has(t.genre)) {
      map.set(t.genre, { name: t.genre, trackCount: 1 });
    } else {
      map.get(t.genre)!.trackCount++;
    }
  }
  return Array.from(map.values()).sort((a, b) => b.trackCount - a.trackCount);
}

function generateMadeForYou(tracks: Track[]) {
  const moods = [
    { id: "chill", title: "Chill Vibes", description: "Relax and unwind", gradient: "from-teal-500/60 to-cyan-900/60" },
    { id: "energy", title: "Energy Boost", description: "Get pumped up", gradient: "from-orange-500/60 to-red-900/60" },
    { id: "focus", title: "Deep Focus", description: "Stay in the zone", gradient: "from-indigo-500/60 to-violet-900/60" },
    { id: "mood", title: "Mood Booster", description: "Lift your spirits", gradient: "from-yellow-500/60 to-amber-900/60" },
    { id: "evening", title: "Evening Calm", description: "Wind down your day", gradient: "from-purple-500/60 to-pink-900/60" },
    { id: "discover", title: "Discover Mix", description: "Something different", gradient: "from-emerald-500/60 to-green-900/60" },
  ];

  return moods.map(m => ({
    ...m,
    tracks: tracks.length > 0 ? [...tracks].sort(() => {
      const seed = m.id.split("").reduce((a, c) => a + c.charCodeAt(0), 0);
      return ((seed % 3) - 1);
    }).slice(0, 5) : [],
  }));
}

function Section({ title, children, icon, sectionKey, showAll, onToggleShowAll, animationDelay }: { title: string; children: React.ReactNode; icon?: React.ReactNode; sectionKey?: string; showAll?: boolean; onToggleShowAll?: (key: string) => void; animationDelay?: string }) {
  return (
    <section className="mt-8 bl-section-in" style={animationDelay ? { animationDelay: animationDelay } : undefined}>
      <div className="mb-4 flex items-center justify-between">
        <h2 className="flex items-center gap-2 text-2xl font-bold text-white">
          {icon}
          {title}
        </h2>
        {sectionKey && onToggleShowAll && (
          <button
            onClick={() => onToggleShowAll(sectionKey)}
            className="flex items-center gap-1 rounded-full px-3 py-1 text-xs font-bold uppercase tracking-wider text-[var(--sp-text-subdued)] transition-colors hover:bg-white/5 hover:text-white"
          >
            {showAll ? "Show less" : "Show all"}
            <ChevronRight size={14} className={`transition-transform ${showAll ? "rotate-90" : ""}`} />
          </button>
        )}
      </div>
      {children}
    </section>
  );
}

function CardGrid({ children }: { children: React.ReactNode }) {
  return (
    <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
      {children}
    </div>
  );
}

function TrackCard({ track, onClick }: { track: Track; onClick: () => void }) {
  return (
    <button onClick={onClick} className="bl-card group">
      <div className="relative">
        {track.coverUrl ? (
          <img src={track.coverUrl} alt="" className="bl-card-cover" />
        ) : (
          <div className="bl-card-cover flex items-center justify-center bg-white/10">
            <Music2 size={40} className="text-white/40" />
          </div>
        )}
        <div className="absolute bottom-2 right-2 h-10 w-10 translate-y-2 opacity-0 transition-all group-hover:translate-y-0 group-hover:opacity-100">
          <div className="flex h-full w-full items-center justify-center rounded-full bg-emerald-500 text-black shadow-lg">
            <Play size={18} fill="currentColor" className="ml-0.5" />
          </div>
        </div>
      </div>
      <div className="truncate text-sm font-bold text-white">{track.title}</div>
      <div className="mt-1 flex items-center gap-1.5">
        <span className="truncate text-xs text-[var(--sp-text-subdued)]">
          {track.artists.join(", ")}
        </span>
        {track.genre && (
          <span className="shrink-0 rounded bg-white/10 px-1.5 py-0.5 text-[9px] font-bold text-emerald-400/80">{track.genre}</span>
        )}
      </div>
    </button>
  );
}

function TopTrackRow({ track, rank, onClick }: { track: Track; rank: number; onClick: () => void }) {
  const plays = parseInt(track.id.slice(-4), 36) % 999 + 1;
  return (
    <button
      onClick={onClick}
      className="group flex items-center gap-3 rounded-lg p-2 text-left transition-colors hover:bg-white/5"
    >
      <span className={`w-6 text-center text-lg font-extrabold ${
        rank === 1 ? "text-emerald-400" : rank === 2 ? "text-teal-400" : rank === 3 ? "text-cyan-400" : "text-white/40"
      }`}>
        {rank}
      </span>
      <div className="relative h-12 w-12 shrink-0 overflow-hidden rounded">
        {track.coverUrl ? (
          <img src={track.coverUrl} alt="" className="h-full w-full object-cover" />
        ) : (
          <div className="flex h-full w-full items-center justify-center bg-white/10">
            <Music2 size={16} className="text-white/40" />
          </div>
        )}
      </div>
      <div className="min-w-0 flex-1">
        <div className="truncate text-sm font-medium text-white">{track.title}</div>
        <div className="flex items-center gap-1.5">
          <span className="truncate text-xs text-[var(--sp-text-subdued)]">{track.artists.join(", ")}</span>
          {track.genre && (
            <span className="shrink-0 rounded bg-white/10 px-1.5 py-0.5 text-[9px] font-bold text-emerald-400/80">{track.genre}</span>
          )}
        </div>
      </div>
      <div className="hidden items-center gap-1 text-xs text-[var(--sp-text-subdued)] sm:flex">
        <Flame size={12} className="text-orange-400/70" />
        {plays.toLocaleString()} plays
      </div>
      <div className="opacity-0 transition-opacity group-hover:opacity-100">
        <div className="flex h-8 w-8 items-center justify-center rounded-full bg-emerald-500 text-black">
          <Play size={14} fill="currentColor" className="ml-0.5" />
        </div>
      </div>
    </button>
  );
}

function PlaylistCard({ playlist, hasTTML, onClick }: { playlist: Playlist; hasTTML?: boolean; onClick: () => void }) {
  return (
    <button onClick={onClick} className="bl-card group">
      <div className="relative">
        {playlist.coverUrl ? (
          <img src={playlist.coverUrl} alt="" className="bl-card-cover" />
        ) : (
          <div className="bl-card-cover flex items-center justify-center bg-gradient-to-br from-emerald-500/40 to-teal-700/40">
            <Music2 size={40} className="text-white/40" />
          </div>
        )}
        <div className="absolute bottom-2 right-2 h-10 w-10 translate-y-2 opacity-0 transition-all group-hover:translate-y-0 group-hover:opacity-100">
          <div className="flex h-full w-full items-center justify-center rounded-full bg-emerald-500 text-black shadow-lg">
            <Play size={18} fill="currentColor" className="ml-0.5" />
          </div>
        </div>
      </div>
      <div className="flex items-center gap-2">
        <div className="truncate text-sm font-bold text-white">{playlist.name}</div>
        {hasTTML && (
          <span className="shrink-0 rounded-full bg-emerald-500/20 px-2 py-0.5 text-[9px] font-bold text-emerald-400 border border-emerald-500/30">🎵 TTML</span>
        )}
      </div>
      <div className="mt-1 truncate text-xs text-[var(--sp-text-subdued)]">
        Playlist • {playlist.trackCount} songs
      </div>
    </button>
  );
}

function AlbumCard({ name, artist, coverUrl, trackCount, genre, onClick }: { name: string; artist: string; coverUrl: string | null; trackCount: number; genre: string; onClick: () => void }) {
  return (
    <button onClick={onClick} className="bl-card group">
      <div className="relative">
        {coverUrl ? (
          <img src={coverUrl} alt="" className="bl-card-cover" />
        ) : (
          <div className="bl-card-cover flex items-center justify-center bg-gradient-to-br from-violet-500/40 to-fuchsia-700/40">
            <Disc3 size={40} className="text-white/40" />
          </div>
        )}
        <div className="absolute bottom-2 right-2 h-10 w-10 translate-y-2 opacity-0 transition-all group-hover:translate-y-0 group-hover:opacity-100">
          <div className="flex h-full w-full items-center justify-center rounded-full bg-emerald-500 text-black shadow-lg">
            <Play size={18} fill="currentColor" className="ml-0.5" />
          </div>
        </div>
      </div>
      <div className="truncate text-sm font-bold text-white">{name}</div>
      <div className="mt-1 flex items-center gap-1.5">
        <span className="truncate text-xs text-[var(--sp-text-subdued)]">{artist}</span>
        {genre && (
          <span className="shrink-0 rounded bg-white/10 px-1.5 py-0.5 text-[9px] font-bold text-emerald-400/80">{genre}</span>
        )}
      </div>
    </button>
  );
}

function ArtistCard({ name, coverUrl, trackCount, onClick }: { name: string; coverUrl: string | null; trackCount: number; onClick: () => void }) {
  return (
    <button onClick={onClick} className="bl-card group">
      <div className="relative">
        {coverUrl ? (
          <img src={coverUrl} alt="" className="bl-card-cover rounded-full" />
        ) : (
          <div className="bl-card-cover flex items-center justify-center rounded-full bg-gradient-to-br from-violet-500/40 to-fuchsia-700/40">
            <User size={40} className="text-white/40" />
          </div>
        )}
        <div className="absolute bottom-2 right-2 h-10 w-10 translate-y-2 opacity-0 transition-all group-hover:translate-y-0 group-hover:opacity-100">
          <div className="flex h-full w-full items-center justify-center rounded-full bg-emerald-500 text-black shadow-lg">
            <Play size={18} fill="currentColor" className="ml-0.5" />
          </div>
        </div>
      </div>
      <div className="truncate text-sm font-bold text-white">{name}</div>
      <div className="mt-1 truncate text-xs text-[var(--sp-text-subdued)]">
        Artist
      </div>
    </button>
  );
}

function MoodCard({ title, description, gradient, tracks, onPlay }: { title: string; description: string; gradient: string; tracks: Track[]; onPlay: () => void }) {
  return (
    <button onClick={onPlay} className="bl-card group">
      <div className="relative">
        <div className={`bl-card-cover flex items-center justify-center bg-gradient-to-br ${gradient}`}>
          <Sparkles size={40} className="text-white/40" />
        </div>
        <div className="absolute bottom-2 right-2 h-10 w-10 translate-y-2 opacity-0 transition-all group-hover:translate-y-0 group-hover:opacity-100">
          <div className="flex h-full w-full items-center justify-center rounded-full bg-emerald-500 text-black shadow-lg">
            <Play size={18} fill="currentColor" className="ml-0.5" />
          </div>
        </div>
      </div>
      <div className="truncate text-sm font-bold text-white">{title}</div>
      <div className="mt-1 truncate text-xs text-[var(--sp-text-subdued)]">
        {description}
      </div>
    </button>
  );
}

function GenreCard({ genre, trackCount, gradient, icon, onClick }: { genre: string; trackCount: number; gradient: string; icon: string; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className={`group relative flex h-24 items-center justify-between overflow-hidden rounded-xl bg-gradient-to-br ${gradient} p-4 transition-all hover:scale-[1.02] hover:shadow-lg active:scale-[0.98]`}
    >
      <div className="text-left">
        <div className="text-lg font-extrabold text-white">{genre}</div>
        <div className="text-xs text-white/60">{trackCount} track{trackCount !== 1 ? "s" : ""}</div>
      </div>
      <span className="text-3xl opacity-60 group-hover:opacity-80 transition-opacity">{icon}</span>
      {/* Hover play button */}
      <div className="absolute bottom-2 right-2 h-8 w-8 translate-y-2 opacity-0 transition-all group-hover:translate-y-0 group-hover:opacity-100">
        <div className="flex h-full w-full items-center justify-center rounded-full bg-emerald-500 text-black shadow-lg">
          <Play size={14} fill="currentColor" className="ml-0.5" />
        </div>
      </div>
    </button>
  );
}
