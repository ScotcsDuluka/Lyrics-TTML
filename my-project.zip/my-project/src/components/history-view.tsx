"use client";
import { Clock, Play, Music2 } from "lucide-react";
import type { PlayHistoryEntry, Track } from "@/lib/types";
import { TrackTable } from "./track-table";

interface Props {
  history: PlayHistoryEntry[];
  currentTrackId: string | null;
  isPlaying: boolean;
  onSelect: (track: Track, index: number) => void;
  onTogglePlay: () => void;
  onToggleLike: (trackId: string) => void;
}

export function HistoryView({ history, currentTrackId, isPlaying, onSelect, onTogglePlay, onToggleLike }: Props) {
  const tracks = history.map(h => h.track);

  // Build a 4-cover collage from the most recent unique covers
  const collageCovers = Array.from(
    new Map(history.slice(0, 12).map(h => [h.track.coverUrl || h.track.id, h.track.coverUrl])).values()
  ).slice(0, 4);

  // Group history by day label
  const groupedHistory = (() => {
    const groups: { label: string; items: PlayHistoryEntry[] }[] = [];
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);

    for (const h of history) {
      const d = new Date(h.playedAt);
      d.setHours(0, 0, 0, 0);
      let label: string;
      if (d.getTime() === today.getTime()) label = "Today";
      else if (d.getTime() === yesterday.getTime()) label = "Yesterday";
      else label = d.toLocaleDateString("en-US", { weekday: "long", month: "short", day: "numeric" });

      let g = groups.find(g => g.label === label);
      if (!g) {
        g = { label, items: [] };
        groups.push(g);
      }
      g.items.push(h);
    }
    return groups;
  })();

  return (
    <div className="bl-scroll flex-1">
      {/* Hero with collage */}
      <div className="bg-gradient-to-b from-amber-900/40 via-orange-900/20 to-transparent px-6 pb-6 pt-6">
        <div className="flex items-end gap-6">
          {/* Collage cover (2x2) */}
          <div className="grid h-48 w-48 shrink-0 grid-cols-2 grid-rows-2 gap-0.5 overflow-hidden rounded-md shadow-2xl ring-1 ring-white/10">
            {collageCovers.length === 0 && (
              <div className="col-span-2 row-span-2 flex items-center justify-center bg-gradient-to-br from-amber-600/60 to-orange-900/60">
                <Clock size={64} className="text-white/80" />
              </div>
            )}
            {collageCovers.slice(0, 4).map((cover, i) => (
              <div key={i} className="overflow-hidden">
                {cover ? (
                  <img src={cover} alt="" className="h-full w-full object-cover" />
                ) : (
                  <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-amber-600/60 to-orange-900/60">
                    <Music2 size={20} className="text-white/50" />
                  </div>
                )}
              </div>
            ))}
            {/* Fill empty slots */}
            {Array.from({ length: Math.max(0, 4 - collageCovers.length) }).map((_, i) => (
              <div key={`fill-${i}`} className="bg-gradient-to-br from-amber-600/40 to-orange-900/40" />
            ))}
          </div>

          <div className="min-w-0 flex-1 pb-4">
            <div className="text-xs font-bold uppercase tracking-wider text-white/70">History</div>
            <h1 className="mt-2 text-5xl font-extrabold tracking-tight text-white sm:text-6xl md:text-7xl">
              Recently Played
            </h1>
            <p className="mt-4 text-sm text-white/70">Your listening history</p>
            <div className="mt-2 flex items-center gap-1 text-sm text-white/80">
              <span className="font-bold text-white">Beautiful Lyrics</span>
              <span>•</span>
              <span>{history.length} plays</span>
              {groupedHistory.length > 0 && (
                <>
                  <span>•</span>
                  <span>{groupedHistory.length} active {groupedHistory.length === 1 ? "day" : "days"}</span>
                </>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="px-6 pb-6">
        {history.length === 0 ? (
          <div className="py-16 text-center">
            <Clock size={48} className="mx-auto mb-4 opacity-30" />
            <div className="text-lg text-[var(--sp-text-subdued)]">No listening history yet</div>
            <p className="mt-1 text-sm text-[var(--sp-text-subdued)]">Play some tracks to see them here</p>
          </div>
        ) : (
          <>
            {/* Timeline grouped by day */}
            {groupedHistory.map(group => (
              <div key={group.label} className="mb-8 mt-6 first:mt-4">
                <div className="mb-3 flex items-center gap-2">
                  <h2 className="text-lg font-bold text-white">{group.label}</h2>
                  <span className="rounded-full bg-white/5 px-2 py-0.5 text-[10px] font-bold text-[var(--sp-text-subdued)]">
                    {group.items.length} {group.items.length === 1 ? "play" : "plays"}
                  </span>
                  <div className="ml-auto h-px flex-1 bg-white/5" />
                </div>
                <div className="space-y-1">
                  {group.items.slice(0, 20).map((h, i) => (
                    <div
                      key={h.id}
                      className="group flex items-center gap-3 rounded-md p-2 hover:bg-white/5 cursor-pointer"
                      onClick={() => onSelect(h.track, i, tracks)}
                    >
                      <div className="relative h-12 w-12 shrink-0 overflow-hidden rounded">
                        {h.track.coverUrl ? (
                          <img src={h.track.coverUrl} alt="" className="h-full w-full object-cover" />
                        ) : (
                          <div className="h-full w-full bg-white/10" />
                        )}
                        <div className="absolute inset-0 flex items-center justify-center bg-black/40 opacity-0 transition-opacity group-hover:opacity-100">
                          <Play size={18} fill="currentColor" className="text-white ml-0.5" />
                        </div>
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className={`truncate text-sm font-medium ${h.track.id === currentTrackId ? "text-emerald-400" : "text-white"}`}>
                          {h.track.title}
                        </div>
                        <div className="truncate text-xs text-[var(--sp-text-subdued)]">
                          {h.track.artists.join(", ")} • {h.track.album}
                        </div>
                      </div>
                      {h.track.genre && (
                        <span className="hidden rounded-full bg-white/5 px-2 py-0.5 text-[10px] font-bold text-[var(--sp-text-subdued)] sm:inline">
                          {h.track.genre}
                        </span>
                      )}
                      <span className="shrink-0 text-xs text-[var(--sp-text-subdued)] tabular-nums">
                        {new Date(h.playedAt).toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" })}
                      </span>
                    </div>
                  ))}
                  {group.items.length > 20 && (
                    <div className="pt-2 text-center text-[10px] text-[var(--sp-text-subdued)]">
                      +{group.items.length - 20} more plays on {group.label}
                    </div>
                  )}
                </div>
              </div>
            ))}

            {history.length > 10 && (
              <>
                <h2 className="mb-3 mt-8 text-lg font-bold text-white">All plays</h2>
                <TrackTable
                  tracks={tracks}
                  currentTrackId={currentTrackId}
                  isPlaying={isPlaying}
                  onSelect={onSelect}
                  onTogglePlay={onTogglePlay}
                  onToggleLike={onToggleLike}
                />
              </>
            )}
          </>
        )}
      </div>
    </div>
  );
}
