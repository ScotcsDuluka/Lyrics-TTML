"use client";
import { ChevronLeft, ChevronRight, Search, Bell, User, Keyboard, Menu, Settings } from "lucide-react";
import { useAppStore } from "@/lib/store";

interface Props {
  searchValue: string;
  onSearch: (q: string) => void;
  onBack: () => void;
  onForward: () => void;
}

export function TopBar({ searchValue, onSearch, onBack, onForward }: Props) {
  const view = useAppStore(s => s.view);
  const setShowShortcutsHelp = useAppStore(s => s.setShowShortcutsHelp);
  const setShowMobileSidebar = useAppStore(s => s.setShowMobileSidebar);
  const setShowSettings = useAppStore(s => s.setShowSettings);

  return (
    <header className="flex shrink-0 items-center justify-between px-4 py-3 sm:px-6">
      {/* Left: navigation arrows + mobile menu */}
      <div className="flex items-center gap-2">
        <button
          onClick={() => setShowMobileSidebar(true)}
          className="flex h-8 w-8 items-center justify-center rounded-full bg-black/40 text-white/70 hover:bg-black/60 lg:hidden"
          title="Open library"
        >
          <Menu size={18} />
        </button>
        <button
          onClick={onBack}
          className="flex h-8 w-8 items-center justify-center rounded-full bg-black/40 text-white/70 transition-colors hover:bg-black/60 hover:text-white"
          title="Back"
        >
          <ChevronLeft size={20} />
        </button>
        <button
          onClick={onForward}
          className="flex h-8 w-8 items-center justify-center rounded-full bg-black/40 text-white/70 transition-colors hover:bg-black/60 hover:text-white"
          title="Forward"
        >
          <ChevronRight size={20} />
        </button>

        {/* Search bar (visible on search view) */}
        {view.type === "search" && (
          <div className="relative ml-4 flex-1">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-black/60" />
            <input
              type="text"
              value={searchValue}
              onChange={e => onSearch(e.target.value)}
              placeholder="What do you want to play?"
              className="w-full max-w-md rounded-full bg-white py-2 pl-9 pr-4 text-sm text-black placeholder:text-black/50 focus:outline-none focus:ring-2 focus:ring-emerald-400"
              autoFocus
            />
          </div>
        )}
      </div>

      {/* Right: keyboard shortcuts + settings + user menu */}
      <div className="flex items-center gap-2 sm:gap-3">
        <button
          onClick={() => setShowShortcutsHelp(true)}
          className="hidden items-center gap-1.5 rounded-full bg-black/40 px-3 py-2 text-xs font-medium text-white/70 transition-all hover:bg-black/60 hover:text-white sm:flex"
          title="Keyboard shortcuts (?)"
        >
          <Keyboard size={14} />
          <span className="hidden md:inline">Shortcuts</span>
        </button>
        <button
          onClick={() => setShowSettings(true)}
          className="rounded-full bg-black/40 p-2 text-white/70 transition-colors hover:bg-black/60 hover:text-white hover:rotate-90 duration-300"
          title="Settings"
          aria-label="Settings"
        >
          <Settings size={16} />
        </button>
        <button
          className="hidden sm:flex rounded-full bg-black/40 p-2 text-white/70 transition-colors hover:bg-black/60 hover:text-white"
          aria-label="Notifications"
        >
          <Bell size={16} />
        </button>
        <button
          className="flex h-8 w-8 items-center justify-center rounded-full bg-gradient-to-br from-emerald-400 to-teal-600 text-black transition-transform hover:scale-105 active:scale-95"
          title="Profile"
        >
          <User size={16} />
        </button>
      </div>
    </header>
  );
}
