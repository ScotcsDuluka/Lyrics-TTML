"use client"

import { Toaster as Sonner, ToasterProps } from "sonner"

const Toaster = ({ ...props }: ToasterProps) => {
  return (
    <Sonner
      theme="dark"
      className="toaster group"
      position="bottom-right"
      style={
        {
          "--normal-bg": "rgba(20,20,20,0.95)",
          "--normal-text": "#fff",
          "--normal-border": "rgba(255,255,255,0.1)",
        } as React.CSSProperties
      }
      toastOptions={{
        style: {
          background: "rgba(20,20,20,0.95)",
          border: "1px solid rgba(255,255,255,0.1)",
          color: "#fff",
          backdropFilter: "blur(12px)",
        },
      }}
      {...props}
    />
  )
}

export { Toaster }
