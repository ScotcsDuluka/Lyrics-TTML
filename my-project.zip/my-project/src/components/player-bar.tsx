"use client";
import { useState, useEffect, useRef } from "react";
import {
  Pause, Play, SkipBack, SkipForward, Volume2, VolumeX, Volume1,
  Repeat, Repeat1, Shuffle, ListMusic, Mic2, SlidersHorizontal,
  Heart, Maximize2, Minimize2, Monitor, X, Moon, Gauge, Share2, PenLine,
  PictureInPicture2, Keyboard, Wand2, Activity, Sparkles, Mic,
} from "lucide-react";
import type { Track } from "@/lib/types";
import type { RepeatMode } from "@/lib/types";
import { useAppStore } from "@/lib/store";
import { EQ_FREQS } from "@/hooks/use-audio-player";
import { EQ_PRESETS } from "@/lib/eq-presets";

interface Props {
  track: Track | null;
  currentTime: number;
  duration: number;
  isPlaying: boolean;
  volume: number;
  muted: boolean;
  shuffle: boolean;
  repeat: RepeatMode;
  isLiked: boolean;
  showQueue: boolean;
  showNowPlaying: boolean;
  showLyrics: boolean;
  hasLyrics: boolean;
  playbackRate: number;
  crossfadeDuration: number;
  eqPreset: string;
  normalizeVolume: boolean;
  onToggle: () => void;
  onSeek: (s: number) => void;
  onPrev: () => void;
  onNext: () => void;
  onVolume: (v: number) => void;
  onToggleMute: () => void;
  onToggleShuffle: () => void;
  onToggleRepeat: () => void;
  onToggleLike: () => void;
  onToggleQueue: () => void;
  onToggleNowPlaying: () => void;
  onToggleLyrics: () => void;
  onSetPlaybackRate: (r: number) => void;
  onSetCrossfade: (s: number) => void;
  onSetEqPreset: (p: string, gains: number[]) => void;
  onToggleNormalize: (v: boolean) => void;
  onOpenSleepTimer: () => void;
  onOpenShare: () => void;
  onOpenLyricsEditor: () => void;
  onOpenMiniPlayer: () => void;
  karaokeMode: boolean;
  onToggleKaraoke: () => void;
  onSetEqBand?: (freq: number, gain: number) => void;
  onResetEq?: () => void;
}

function fmt(s: number): string {
  if (!isFinite(s) || s < 0) return "0:00";
  const t = Math.floor(s);
  return `${Math.floor(t/60)}:${(t%60).toString().padStart(2,"0")}`;
}

export function PlayerBar(p: Props) {
  const [showEq, setShowEq] = useState(false);
  const [showSpeed, setShowSpeed] = useState(false);
  const [showAudio, setShowAudio] = useState(false);
  const [eqGains, setEqGains] = useState<Record<number, number>>({});
  const sleepTimer = useAppStore(s => s.sleepTimer);
  const pct = p.duration > 0 ? (p.currentTime / p.duration) * 100 : 0;
  const noTrack = !p.track;

  // Track cover art flash animation - use track id as key to trigger re-animation
  const coverFlashKey = p.track?.id ?? "no-track";

  // Close popups on outside click
  const eqRef = useRef<HTMLDivElement | null>(null);
  const speedRef = useRef<HTMLDivElement | null>(null);
  const audioRef = useRef<HTMLDivElement | null>(null);
  useEffect(() => {
    const onClick = (e: MouseEvent) => {
      if (eqRef.current && !eqRef.current.contains(e.target as Node)) setShowEq(false);
      if (speedRef.current && !speedRef.current.contains(e.target as Node)) setShowSpeed(false);
      if (audioRef.current && !audioRef.current.contains(e.target as Node)) setShowAudio(false);
    };
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, []);

  return (
    <footer className={`relative grid grid-cols-3 items-center gap-4 bg-[var(--player-bg)] px-4 py-3 bl-playing-glow ${p.isPlaying && !noTrack ? "is-playing" : ""}`} style={{ height: "90px" }}>
      {/* LEFT — Now playing */}
      <div className="flex min-w-0 items-center gap-3">
        <div key={coverFlashKey} className={`relative h-14 w-14 shrink-0 overflow-hidden rounded bl-cover-flash ${noTrack ? "" : "bl-glow-pulse"}`}>
          {p.track?.coverUrl ? (
            <img src={p.track.coverUrl} alt="" className="h-full w-full object-cover" />
          ) : (
            <div className="h-full w-full bg-white/10" />
          )}
        </div>
        <div className="min-w-0">
          <div className={`truncate text-sm font-medium ${noTrack ? "text-[var(--sp-text-subdued)]" : "text-white"}`}>
            {p.track?.title || "Not playing"}
          </div>
          <div className="truncate text-xs text-[var(--sp-text-subdued)]">
            {p.track?.artists.join(", ") || ""}
          </div>
        </div>
        {!noTrack && (
          <button
            onClick={p.onToggleLike}
            className={`ml-2 shrink-0 rounded-full p-1 transition-all duration-200 ${
              p.isLiked ? "text-emerald-400 scale-110" : "text-[var(--sp-text-subdued)] hover:text-white"
            }`}
          >
            <Heart size={16} fill={p.isLiked ? "currentColor" : "none"} />
          </button>
        )}
      </div>

      {/* CENTER — Controls + Seek */}
      <div className="flex flex-col items-center gap-2">
        <div className="flex items-center gap-4">
          <button
            onClick={p.onToggleShuffle}
            className={`relative transition-colors ${p.shuffle ? "text-emerald-400" : "text-[var(--sp-text-subdued)] hover:text-white"}`}
            title="Shuffle"
          >
            <Shuffle size={16} />
            {p.shuffle && (
              <span className="absolute -bottom-1.5 left-1/2 h-1 w-1 -translate-x-1/2 rounded-full bg-emerald-400" />
            )}
          </button>
          <button onClick={p.onPrev} disabled={noTrack} className="text-[var(--sp-text-subdued)] hover:text-white transition-colors disabled:opacity-30">
            <SkipBack size={20} fill="currentColor" />
          </button>
          <button
            onClick={p.onToggle}
            disabled={noTrack}
            className={`flex h-9 w-9 items-center justify-center rounded-full bg-white text-black transition-all duration-200 hover:scale-110 active:scale-95 disabled:opacity-30 shadow-lg shadow-white/10 ${p.isPlaying && !noTrack ? "bl-play-pulse" : ""}`}
          >
            {p.isPlaying ? <Pause size={16} fill="currentColor" /> : <Play size={16} fill="currentColor" className="ml-0.5" />}
          </button>
          <button onClick={p.onNext} disabled={noTrack} className="text-[var(--sp-text-subdued)] hover:text-white transition-colors disabled:opacity-30">
            <SkipForward size={20} fill="currentColor" />
          </button>
          <button
            onClick={p.onToggleRepeat}
            className={`relative transition-colors ${p.repeat !== "off" ? "text-emerald-400" : "text-[var(--sp-text-subdued)] hover:text-white"}`}
            title="Repeat"
          >
            {p.repeat === "one" ? <Repeat1 size={16} className="bl-repeat-one-spin" /> : <Repeat size={16} />}
            {p.repeat !== "off" && (
              <span className={`absolute -bottom-1.5 left-1/2 h-1 w-1 -translate-x-1/2 rounded-full bg-emerald-400 ${p.repeat === "one" ? "bl-pulse-dot-sm" : ""}`} />
            )}
          </button>
        </div>
        <div className="flex w-full max-w-[600px] items-center gap-2">
          <span className="w-10 shrink-0 text-right text-[10px] tabular-nums text-[var(--sp-text-subdued)]">
            {fmt(p.currentTime)}
          </span>
          <input
            type="range"
            min={0}
            max={p.duration > 0 ? p.duration : 1}
            step={0.05}
            value={p.currentTime}
            disabled={p.duration === 0}
            onChange={e => p.onSeek(parseFloat(e.target.value))}
            className={`bl-slider bl-seek bl-progress-gradient flex-1 ${p.duration === 0 ? "opacity-50 cursor-not-allowed" : ""}`}
            style={{ "--progress": `${pct}%` } as React.CSSProperties}
            aria-label="Seek"
          />
          <span className="w-10 shrink-0 text-[10px] tabular-nums text-[var(--sp-text-subdued)]">
            {fmt(p.duration)}
          </span>
        </div>
      </div>

      {/* RIGHT — Volume + extras */}
      <div className="flex items-center justify-end gap-1">
        {/* Sleep timer */}
        <button
          onClick={p.onOpenSleepTimer}
          className={`relative hidden rounded p-1.5 transition-colors lg:block ${sleepTimer ? "text-indigo-400" : "text-[var(--sp-text-subdued)] hover:text-white"}`}
          title="Sleep timer"
        >
          <Moon size={16} />
          {sleepTimer && (
            <span className="absolute -right-0.5 -top-0.5 h-2 w-2 animate-pulse rounded-full bg-indigo-400" />
          )}
        </button>

        {/* Lyrics editor */}
        <button
          onClick={p.onOpenLyricsEditor}
          disabled={noTrack}
          className={`hidden rounded p-1.5 transition-colors lg:block ${noTrack ? "text-[var(--sp-text-subdued)] opacity-40" : "text-[var(--sp-text-subdued)] hover:text-white"}`}
          title="Edit lyrics"
        >
          <PenLine size={16} />
        </button>

        {/* Share */}
        <button
          onClick={p.onOpenShare}
          disabled={noTrack}
          className={`hidden rounded p-1.5 transition-colors lg:block ${noTrack ? "text-[var(--sp-text-subdued)] opacity-40" : "text-[var(--sp-text-subdued)] hover:text-white"}`}
          title="Share"
        >
          <Share2 size={16} />
        </button>

        {/* Playback speed */}
        <div className="relative hidden lg:block" ref={speedRef}>
          <button
            onClick={() => setShowSpeed(v => !v)}
            disabled={noTrack}
            className={`flex items-center gap-1 rounded px-1.5 py-1 text-[10px] font-bold tabular-nums transition-colors ${
              p.playbackRate !== 1
                ? "text-emerald-400"
                : noTrack
                ? "text-[var(--sp-text-subdued)] opacity-40"
                : "text-[var(--sp-text-subdued)] hover:text-white"
            }`}
            title="Playback speed"
          >
            <Gauge size={14} />
            {p.playbackRate}×
          </button>
          {showSpeed && (
            <div className="absolute bottom-full right-0 mb-2 flex flex-col rounded-xl border border-white/15 bg-black/95 p-2 shadow-2xl backdrop-blur-xl bl-msg-in" style={{ zIndex: 50, minWidth: "120px" }}>
              <div className="mb-1 px-1 text-[10px] font-bold uppercase tracking-wider text-white/50">Speed</div>
              {[0.5, 0.75, 1, 1.25, 1.5, 1.75, 2].map(r => (
                <button
                  key={r}
                  onClick={() => { p.onSetPlaybackRate(r); setShowSpeed(false); }}
                  className={`flex items-center justify-between rounded px-2 py-1 text-xs font-medium transition-colors ${
                    p.playbackRate === r ? "bg-emerald-500/20 text-emerald-400" : "text-white/80 hover:bg-white/10"
                  }`}
                >
                  <span>{r}×</span>
                  {r === 1 && <span className="text-[9px] text-white/40">Normal</span>}
                  {r === 1.5 && <span className="text-[9px] text-white/40">Fast</span>}
                  {r === 2 && <span className="text-[9px] text-white/40">Max</span>}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Mini player */}
        <button
          onClick={p.onOpenMiniPlayer}
          disabled={noTrack}
          className={`hidden rounded p-1.5 transition-colors lg:block ${noTrack ? "text-[var(--sp-text-subdued)] opacity-40" : "text-[var(--sp-text-subdued)] hover:text-white"}`}
          title="Mini player"
        >
          <PictureInPicture2 size={16} />
        </button>

        {/* Karaoke mode toggle */}
        <button
          onClick={p.onToggleKaraoke}
          disabled={!p.hasLyrics}
          className={`hidden rounded p-1.5 transition-colors lg:block ${
            p.karaokeMode
              ? "text-emerald-400"
              : p.hasLyrics
              ? "text-[var(--sp-text-subdued)] hover:text-white"
              : "text-[var(--sp-text-subdued)] opacity-40"
          }`}
          title="Karaoke mode"
        >
          <Mic size={16} />
        </button>

        {/* Lyrics toggle button */}
        <button
          onClick={p.onToggleLyrics}
          disabled={!p.hasLyrics}
          className={`hidden rounded p-1.5 transition-colors lg:block ${
            p.showLyrics
              ? "text-emerald-400"
              : p.hasLyrics
              ? "text-[var(--sp-text-subdued)] hover:text-white"
              : "text-[var(--sp-text-subdued)] opacity-40"
          }`}
          title="Lyrics"
        >
          <Mic2 size={16} />
        </button>
        <button
          onClick={p.onToggleNowPlaying}
          className={`hidden rounded p-1.5 transition-colors lg:block ${p.showNowPlaying ? "text-emerald-400" : "text-[var(--sp-text-subdued)] hover:text-white"}`}
          title="Now playing view"
        >
          <Mic2 size={16} />
        </button>
        <button
          onClick={p.onToggleQueue}
          className={`hidden rounded p-1.5 transition-colors lg:block ${p.showQueue ? "text-emerald-400" : "text-[var(--sp-text-subdued)] hover:text-white"}`}
          title="Queue"
        >
          <ListMusic size={16} />
        </button>
        <div className="relative hidden lg:block" ref={eqRef}>
          <button
            onClick={() => setShowEq(v => !v)}
            className={`rounded p-1.5 transition-colors ${showEq ? "text-emerald-400" : "text-[var(--sp-text-subdued)] hover:text-white"}`}
            title="Equalizer"
          >
            <SlidersHorizontal size={16} />
          </button>
        </div>
        {/* Audio settings: crossfade + normalize */}
        <div className="relative hidden lg:block" ref={audioRef}>
          <button
            onClick={() => setShowAudio(v => !v)}
            className={`rounded p-1.5 transition-colors ${
              showAudio || p.crossfadeDuration > 0 || p.normalizeVolume
                ? "text-emerald-400"
                : "text-[var(--sp-text-subdued)] hover:text-white"
            }`}
            title="Audio settings"
          >
            <Wand2 size={16} />
          </button>
          {showAudio && (
            <div className="absolute bottom-full right-0 mb-2 w-72 rounded-xl border border-white/15 bg-black/95 p-4 shadow-2xl backdrop-blur-xl bl-msg-in" style={{ zIndex: 50 }}>
              <div className="mb-3 flex items-center justify-between">
                <span className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-white/70">
                  <Sparkles size={12} /> Audio settings
                </span>
                <button onClick={() => setShowAudio(false)} className="rounded p-0.5 text-white/40 hover:text-white"><X size={14} /></button>
              </div>

              {/* Crossfade */}
              <div className="mb-4">
                <div className="mb-1.5 flex items-center justify-between">
                  <span className="flex items-center gap-1.5 text-xs font-medium text-white/80">
                    <Activity size={12} className="text-emerald-400" />
                    Crossfade
                  </span>
                  <span className="text-[10px] tabular-nums text-white/60">
                    {p.crossfadeDuration > 0 ? `${p.crossfadeDuration}s` : "Off"}
                  </span>
                </div>
                <input
                  type="range" min={0} max={12} step={1}
                  value={p.crossfadeDuration}
                  onChange={e => p.onSetCrossfade(parseInt(e.target.value))}
                  className="bl-slider w-full"
                  style={{ "--progress": `${(p.crossfadeDuration / 12) * 100}%` } as React.CSSProperties}
                  aria-label="Crossfade duration"
                />
                <p className="mt-1 text-[10px] text-white/40">
                  Smooth transitions between tracks
                </p>
              </div>

              {/* Normalize */}
              <button
                onClick={() => p.onToggleNormalize(!p.normalizeVolume)}
                className={`flex w-full items-center justify-between rounded-lg border px-3 py-2 text-xs transition-colors ${
                  p.normalizeVolume
                    ? "border-emerald-500/30 bg-emerald-500/10 text-emerald-400"
                    : "border-white/10 bg-white/5 text-white/70 hover:bg-white/10"
                }`}
              >
                <span className="flex items-center gap-2">
                  <Volume2 size={12} />
                  Normalize volume
                </span>
                <span className={`flex h-4 w-7 items-center rounded-full p-0.5 transition-colors ${p.normalizeVolume ? "bg-emerald-500" : "bg-white/20"}`}>
                  <span className={`h-3 w-3 rounded-full bg-white transition-transform ${p.normalizeVolume ? "translate-x-3" : ""}`} />
                </span>
              </button>
              <p className="mt-1 text-[10px] text-white/40">
                Auto-adjust volume between tracks
              </p>
            </div>
          )}
        </div>
        <button onClick={p.onToggleMute} className="rounded p-1.5 text-[var(--sp-text-subdued)] hover:text-white transition-colors">
          {p.muted || p.volume === 0 ? (
            <VolumeX size={16} />
          ) : p.volume < 0.5 ? (
            <Volume1 size={16} />
          ) : (
            <Volume2 size={16} />
          )}
        </button>
        <input
          type="range"
          min={0}
          max={1}
          step={0.01}
          value={p.muted ? 0 : p.volume}
          onChange={e => p.onVolume(parseFloat(e.target.value))}
          className="bl-slider w-24"
          style={{ "--progress": `${(p.muted ? 0 : p.volume) * 100}%` } as React.CSSProperties}
          aria-label="Volume"
        />
      </div>

      {/* EQ Panel */}
      {showEq && p.onSetEqBand && (
        <div className="absolute bottom-full right-4 mb-2 flex flex-col rounded-xl border border-white/15 bg-black/95 p-4 shadow-2xl backdrop-blur-xl bl-msg-in" style={{ width: "420px", zIndex: 50 }}>
          <div className="mb-3 flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-white/70">Equalizer</span>
            <div className="flex gap-2">
              <button
                onClick={() => {
                  EQ_FREQS.forEach(f => { setEqGains(g => ({ ...g, [f]: 0 })); });
                  p.onResetEq?.();
                  p.onSetEqPreset("flat", EQ_FREQS.map(() => 0));
                }}
                className="rounded bg-white/10 px-2 py-0.5 text-[10px] text-white/70 hover:bg-white/20"
              >
                Reset
              </button>
              <button onClick={() => setShowEq(false)} className="rounded p-0.5 text-white/40 hover:text-white"><X size={14} /></button>
            </div>
          </div>

          {/* Presets */}
          <div className="mb-3">
            <div className="mb-1.5 text-[10px] font-bold uppercase tracking-wider text-white/40">Presets</div>
            <div className="grid grid-cols-3 gap-1.5">
              {EQ_PRESETS.map(preset => (
                <button
                  key={preset.id}
                  onClick={() => {
                    const gainsObj: Record<number, number> = {};
                    EQ_FREQS.forEach((f, i) => {
                      gainsObj[f] = preset.gains[i];
                      p.onSetEqBand?.(f, preset.gains[i]);
                    });
                    setEqGains(gainsObj);
                    p.onSetEqPreset(preset.id, preset.gains);
                  }}
                  className={`group flex items-center gap-2 rounded-lg border px-2 py-1.5 text-left transition-all ${
                    p.eqPreset === preset.id
                      ? "border-emerald-500/40 bg-emerald-500/15 text-white"
                      : "border-white/10 bg-white/[0.03] text-white/70 hover:border-white/20 hover:bg-white/[0.08]"
                  }`}
                  title={preset.description}
                >
                  <span className="text-sm">{preset.icon}</span>
                  <span className="truncate text-[11px] font-medium">{preset.name}</span>
                </button>
              ))}
            </div>
          </div>

          <div className="mb-2 h-px bg-white/10" />

          {/* Frequency bands */}
          <div className="flex justify-between gap-1" style={{ height: "120px" }}>
            {EQ_FREQS.map(freq => (
              <div key={freq} className="flex flex-1 flex-col items-center gap-1">
                <span className="text-[9px] tabular-nums text-white/40">{eqGains[freq] ? (eqGains[freq] > 0 ? "+" : "") + eqGains[freq].toFixed(0) : "0"}</span>
                <input type="range" min={-12} max={12} step={1} value={eqGains[freq] ?? 0}
                  onChange={e => {
                    const v = parseFloat(e.target.value);
                    setEqGains(g => ({ ...g, [freq]: v }));
                    p.onSetEqBand?.(freq, v);
                    // Mark as "custom" preset when manually adjusted
                    p.onSetEqPreset("custom", []);
                  }}
                  className="bl-eq-slider" style={{ "--eq-val": `${((eqGains[freq] ?? 0) + 12) / 24 * 100}%` } as React.CSSProperties} />
                <span className="text-[9px] text-white/50">{freq >= 1000 ? `${freq/1000}k` : freq}</span>
              </div>
            ))}
          </div>
          <p className="mt-2 text-[10px] text-white/40">
            {p.eqPreset === "flat" || p.eqPreset === "custom"
              ? "Adjust individual bands to fine-tune"
              : `Active: ${EQ_PRESETS.find(x => x.id === p.eqPreset)?.name || "Custom"}`}
          </p>
        </div>
      )}
    </footer>
  );
}
