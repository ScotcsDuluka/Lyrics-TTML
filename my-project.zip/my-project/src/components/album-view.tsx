"use client";
import { Play, Music2, Heart, Clock, Disc3 } from "lucide-react";
import type { Track, Playlist } from "@/lib/types";

interface Props {
  albumName: string;
  tracks: Track[];
  currentTrackId: string | null;
  isPlaying: boolean;
  onPlay: () => void;
  onSelectTrack: (track: Track, index: number) => void;
  onToggleLike: (trackId: string) => void;
  allPlaylists?: Playlist[];
  onAddToPlaylist?: (playlistId: string, trackId: string) => Promise<boolean>;
  onCreatePlaylistWithTrack?: (name: string, trackId: string) => Promise<string | null>;
  onAddToQueue?: (trackId: string) => void;
}

export function AlbumView({ albumName, tracks, currentTrackId, isPlaying, onPlay, onSelectTrack, onToggleLike, allPlaylists, onAddToPlaylist, onCreatePlaylistWithTrack, onAddToQueue }: Props) {
  const coverUrl = tracks[0]?.coverUrl || null;
  const albumGenre = tracks[0]?.genre || "";
  const albumArtist = tracks[0]?.artists.join(", ") || "";
  const totalDuration = tracks.reduce((sum, t) => sum + (t.duration || 0), 0);
  const year = tracks[0]?.id ? "2025" : "";

  const fmtDuration = (s: number) => {
    if (s < 60) return `${Math.floor(s)} sec`;
    if (s < 3600) return `${Math.floor(s / 60)} min`;
    const h = Math.floor(s / 3600);
    const m = Math.floor((s % 3600) / 60);
    return `${h} hr ${m} min`;
  };

  return (
    <div className="bl-view-transition px-6 pb-6">
      {/* Album header */}
      <div className="relative mb-8">
        <div className="absolute inset-0 -z-10 overflow-hidden opacity-20">
          {coverUrl ? (
            <img src={coverUrl} alt="" className="h-[300px] w-full object-cover blur-3xl scale-150" />
          ) : (
            <div className="h-[300px] w-full bg-gradient-to-br from-violet-900/60 to-black" />
          )}
        </div>

        <div className="flex items-end gap-6 pt-12 pb-4">
          <div className="relative h-56 w-56 shrink-0 overflow-hidden rounded-xl shadow-2xl bl-np-cover">
            {coverUrl ? (
              <img src={coverUrl} alt={albumName} className="h-full w-full object-cover" />
            ) : (
              <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-violet-500/40 to-fuchsia-700/40">
                <Disc3 size={64} className="text-white/30" />
              </div>
            )}
          </div>
          <div className="min-w-0 flex-1">
            <div className="text-xs font-bold uppercase tracking-wider text-white/60">Album</div>
            <h1 className="mt-1 text-4xl font-extrabold tracking-tight text-white bl-gradient-text">{albumName}</h1>
            <div className="mt-2 flex items-center gap-2 text-sm text-white/70">
              <span className="font-medium text-white">{albumArtist}</span>
              {albumGenre && (
                <span className="rounded-full bg-emerald-500/20 px-2 py-0.5 text-xs font-bold text-emerald-400">{albumGenre}</span>
              )}
              <span>•</span>
              <span>{year}</span>
              <span>•</span>
              <span>{tracks.length} songs, {fmtDuration(totalDuration)}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Action bar */}
      <div className="flex items-center gap-4 mb-6">
        <button
          onClick={onPlay}
          className="flex h-14 w-14 items-center justify-center rounded-full bg-emerald-500 text-black shadow-lg shadow-emerald-500/30 hover:scale-105 active:scale-95 transition-transform bl-float"
        >
          <Play size={24} fill="currentColor" className="ml-1" />
        </button>
        <button
          onClick={() => {
            // Like all tracks in album
            tracks.forEach(t => {
              if (!t.liked) onToggleLike(t.id);
            });
          }}
          className="rounded-full p-2 text-[var(--sp-text-subdued)] hover:text-white transition-colors"
          title="Like all songs"
        >
          <Heart size={24} />
        </button>
        {onAddToQueue && (
          <button
            onClick={() => {
              tracks.forEach(t => onAddToQueue?.(t.id));
            }}
            className="rounded-full p-2 text-[var(--sp-text-subdued)] hover:text-white transition-colors"
            title="Add all to queue"
          >
            <Clock size={24} />
          </button>
        )}
      </div>

      {/* Track list */}
      <div className="space-y-0">
        {tracks.map((t, i) => {
          const active = t.id === currentTrackId;
          return (
            <div
              key={`album-track-${i}-${t.id}`}
              className={`bl-track-row group flex items-center gap-4 rounded-md px-4 py-2 transition-colors ${
                active ? "active" : ""
              }`}
              onDoubleClick={() => onSelectTrack(t, i)}
            >
              <div className="w-8 text-center text-sm tabular-nums text-[var(--sp-text-subdued)]">
                {active && isPlaying ? (
                  <span className="text-emerald-400">
                    <span className="bl-eq-bar">
                      {[0,1,2,3].map(j => (
                        <span key={j} style={{
                          animationDelay: `${j*0.15}s`,
                          animationDuration: "0.8s",
                          height: `${[60,100,70,90][j]}%`,
                        }} />
                      ))}
                    </span>
                  </span>
                ) : (
                  <span className="group-hover:hidden">{i + 1}</span>
                )}
                {!active && (
                  <button
                    onClick={() => onSelectTrack(t, i)}
                    className="hidden text-white group-hover:inline-flex items-center justify-center"
                  >
                    <Play size={14} fill="currentColor" />
                  </button>
                )}
              </div>
              <div className="h-10 w-10 shrink-0 overflow-hidden rounded">
                {t.coverUrl ? (
                  <img src={t.coverUrl} alt="" className="h-full w-full object-cover" />
                ) : (
                  <div className="h-full w-full bg-white/10" />
                )}
              </div>
              <div className="min-w-0 flex-1">
                <div className={`truncate text-sm font-medium ${active ? "text-emerald-400" : "text-white"}`}>
                  {t.title}
                </div>
                <div className="truncate text-xs text-[var(--sp-text-subdued)]">
                  {t.artists.join(", ")}
                  {t.genre && (
                    <span className="ml-2 rounded bg-white/10 px-1.5 py-0.5 text-[10px] font-bold text-white/50">{t.genre}</span>
                  )}
                </div>
              </div>
              <button
                onClick={() => onToggleLike(t.id)}
                className={`transition-opacity ${t.liked ? "text-emerald-400 opacity-100" : "text-[var(--sp-text-subdued)] opacity-0 group-hover:opacity-100 hover:text-white"}`}
              >
                <Heart size={14} fill={t.liked ? "currentColor" : "none"} />
              </button>
              <span className="text-sm tabular-nums text-[var(--sp-text-subdued)]">
                {t.duration ? `${Math.floor(t.duration/60)}:${(Math.floor(t.duration)%60).toString().padStart(2,"0")}` : "--:--"}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}
