"use client";

import { useState, useRef, useCallback } from "react";
import { Upload, X, Music2, FileAudio, CheckCircle2 } from "lucide-react";
import { toast } from "sonner";

interface TrackUploadProps {
  onUploadComplete: () => void;
}

interface FileWithMetadata {
  file: File;
  title: string;
  artist: string;
  album: string;
}

const ACCEPTED_TYPES = [
  "audio/mpeg",
  "audio/wav",
  "audio/ogg",
  "audio/mp4",
  "audio/x-m4a",
  "audio/flac",
  "audio/x-flac",
];

const ACCEPTED_EXTENSIONS = [".mp3", ".wav", ".ogg", ".m4a", ".flac"];

function formatFileSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function getFileNameWithoutExtension(filename: string): string {
  const lastDot = filename.lastIndexOf(".");
  return lastDot > 0 ? filename.substring(0, lastDot) : filename;
}

function isValidAudioFile(file: File): boolean {
  if (ACCEPTED_TYPES.includes(file.type)) return true;
  const name = file.name.toLowerCase();
  return ACCEPTED_EXTENSIONS.some((ext) => name.endsWith(ext));
}

export function TrackUpload({ onUploadComplete }: TrackUploadProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const [files, setFiles] = useState<FileWithMetadata[]>([]);
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [currentUploadingIndex, setCurrentUploadingIndex] = useState(0);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const dragCounterRef = useRef(0);

  const openModal = useCallback(() => {
    setIsOpen(true);
    setFiles([]);
    setUploadProgress(0);
    setUploading(false);
    setCurrentUploadingIndex(0);
  }, []);

  const closeModal = useCallback(() => {
    if (uploading) return;
    setIsOpen(false);
    setFiles([]);
    setUploadProgress(0);
  }, [uploading]);

  const addFiles = useCallback((fileList: FileList | File[]) => {
    const newFiles: FileWithMetadata[] = Array.from(fileList)
      .filter(isValidAudioFile)
      .map((file) => ({
        file,
        title: getFileNameWithoutExtension(file.name),
        artist: "",
        album: "",
      }));

    if (newFiles.length === 0) {
      toast.error("No valid audio files selected");
      return;
    }

    setFiles((prev) => [...prev, ...newFiles]);
  }, []);

  const handleDragEnter = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      e.stopPropagation();
      dragCounterRef.current += 1;
      if (dragCounterRef.current === 1) {
        setIsDragging(true);
      }
    },
    []
  );

  const handleDragLeave = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      e.stopPropagation();
      dragCounterRef.current -= 1;
      if (dragCounterRef.current === 0) {
        setIsDragging(false);
      }
    },
    []
  );

  const handleDragOver = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      e.stopPropagation();
    },
    []
  );

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      e.stopPropagation();
      dragCounterRef.current = 0;
      setIsDragging(false);
      if (e.dataTransfer.files.length > 0) {
        addFiles(e.dataTransfer.files);
      }
    },
    [addFiles]
  );

  const handleFileInputChange = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      if (e.target.files && e.target.files.length > 0) {
        addFiles(e.target.files);
        e.target.value = "";
      }
    },
    [addFiles]
  );

  const updateFileMetadata = useCallback(
    (index: number, field: "title" | "artist" | "album", value: string) => {
      setFiles((prev) =>
        prev.map((f, i) => (i === index ? { ...f, [field]: value } : f))
      );
    },
    []
  );

  const removeFile = useCallback((index: number) => {
    setFiles((prev) => prev.filter((_, i) => i !== index));
  }, []);

  const handleUpload = useCallback(async () => {
    if (files.length === 0) return;

    setUploading(true);
    setUploadProgress(0);

    const totalFiles = files.length;

    for (let i = 0; i < totalFiles; i++) {
      setCurrentUploadingIndex(i);
      const { file, title, artist, album } = files[i];

      const formData = new FormData();
      formData.append("file", file);
      formData.append("title", title);
      formData.append("artist", artist);
      formData.append("album", album);

      try {
        await new Promise<void>((resolve, reject) => {
          const xhr = new XMLHttpRequest();

          xhr.upload.onprogress = (event) => {
            if (event.lengthComputable) {
              const fileProgress = event.loaded / event.total;
              const overallProgress = ((i + fileProgress) / totalFiles) * 100;
              setUploadProgress(Math.round(overallProgress));
            }
          };

          xhr.onload = () => {
            if (xhr.status >= 200 && xhr.status < 300) {
              resolve();
            } else {
              reject(new Error(`Upload failed: ${xhr.statusText}`));
            }
          };

          xhr.onerror = () => reject(new Error("Network error during upload"));

          xhr.open("POST", "/api/tracks/upload");
          xhr.send(formData);
        });
      } catch (error) {
        const message =
          error instanceof Error ? error.message : "Upload failed";
        toast.error(`Failed to upload "${title}": ${message}`);
        setUploading(false);
        setUploadProgress(0);
        return;
      }
    }

    setUploadProgress(100);
    setUploading(false);
    toast.success("Track(s) uploaded successfully!", {
      icon: <CheckCircle2 className="h-4 w-4 text-emerald-400" />,
    });
    onUploadComplete();
    closeModal();
  }, [files, onUploadComplete, closeModal]);

  return (
    <>
      {/* Trigger button */}
      <button
        onClick={openModal}
        className="inline-flex items-center gap-2 rounded-full bg-emerald-400 px-4 py-2 text-sm font-semibold text-black transition-all hover:bg-emerald-300 hover:scale-105 active:scale-95"
      >
        <Upload className="h-4 w-4" />
        Upload
      </button>

      {/* Modal overlay */}
      {isOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm animate-in fade-in duration-200"
          onClick={(e) => {
            if (e.target === e.currentTarget) closeModal();
          }}
        >
          {/* Modal card */}
          <div className="relative w-full max-w-lg mx-4 rounded-xl bg-[#181818] border border-white/10 shadow-2xl animate-in zoom-in-95 slide-in-from-bottom-4 duration-300">
            {/* Header */}
            <div className="flex items-center justify-between border-b border-white/10 px-6 py-4">
              <h2 className="text-lg font-semibold text-white">
                Upload Audio Files
              </h2>
              {!uploading && (
                <button
                  onClick={closeModal}
                  className="rounded-full p-1 text-neutral-400 transition-colors hover:text-white hover:bg-white/10"
                >
                  <X className="h-5 w-5" />
                </button>
              )}
            </div>

            {/* Body */}
            <div className="px-6 py-5 space-y-5 max-h-[70vh] overflow-y-auto">
              {/* Drag and drop area */}
              {files.length === 0 ? (
                <div
                  onDragEnter={handleDragEnter}
                  onDragLeave={handleDragLeave}
                  onDragOver={handleDragOver}
                  onDrop={handleDrop}
                  className={`flex flex-col items-center justify-center rounded-lg border-2 border-dashed p-10 transition-all duration-200 cursor-pointer ${
                    isDragging
                      ? "border-emerald-400 bg-emerald-400/10 scale-[1.02]"
                      : "border-neutral-600 bg-neutral-900/50 hover:border-neutral-400 hover:bg-neutral-900/80"
                  }`}
                  onClick={() => fileInputRef.current?.click()}
                >
                  <div
                    className={`mb-4 rounded-full p-4 transition-colors duration-200 ${
                      isDragging ? "bg-emerald-400/20" : "bg-neutral-800"
                    }`}
                  >
                    <Music2
                      className={`h-8 w-8 transition-colors duration-200 ${
                        isDragging ? "text-emerald-400" : "text-neutral-400"
                      }`}
                    />
                  </div>
                  <p className="mb-1 text-base font-medium text-white">
                    Drag and drop audio files here
                  </p>
                  <p className="mb-4 text-sm text-neutral-400">
                    MP3, WAV, OGG, M4A, FLAC
                  </p>
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      fileInputRef.current?.click();
                    }}
                    className="rounded-full bg-white/10 px-5 py-2 text-sm font-medium text-white transition-all hover:bg-white/20 hover:scale-105 active:scale-95"
                  >
                    Browse files
                  </button>
                </div>
              ) : (
                <>
                  {/* File list with metadata */}
                  <div className="space-y-4">
                    {files.map((f, index) => (
                      <div
                        key={`${f.file.name}-${index}`}
                        className="rounded-lg bg-neutral-900/80 border border-white/5 p-4 space-y-3"
                      >
                        {/* File info row */}
                        <div className="flex items-center gap-3">
                          <div className="flex-shrink-0 rounded-md bg-emerald-400/10 p-2">
                            <FileAudio className="h-5 w-5 text-emerald-400" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium text-white truncate">
                              {f.file.name}
                            </p>
                            <p className="text-xs text-neutral-400">
                              {formatFileSize(f.file.size)}
                            </p>
                          </div>
                          {!uploading && (
                            <button
                              onClick={() => removeFile(index)}
                              className="rounded-full p-1 text-neutral-400 transition-colors hover:text-white hover:bg-white/10"
                            >
                              <X className="h-4 w-4" />
                            </button>
                          )}
                        </div>

                        {/* Metadata fields */}
                        <div className="grid grid-cols-1 gap-2">
                          <input
                            type="text"
                            value={f.title}
                            onChange={(e) =>
                              updateFileMetadata(index, "title", e.target.value)
                            }
                            placeholder="Title"
                            disabled={uploading}
                            className="w-full rounded-md bg-neutral-800 border border-white/10 px-3 py-2 text-sm text-white placeholder-neutral-500 outline-none transition-colors focus:border-emerald-400 focus:ring-1 focus:ring-emerald-400/50 disabled:opacity-50"
                          />
                          <div className="grid grid-cols-2 gap-2">
                            <input
                              type="text"
                              value={f.artist}
                              onChange={(e) =>
                                updateFileMetadata(
                                  index,
                                  "artist",
                                  e.target.value
                                )
                              }
                              placeholder="Artist"
                              disabled={uploading}
                              className="w-full rounded-md bg-neutral-800 border border-white/10 px-3 py-2 text-sm text-white placeholder-neutral-500 outline-none transition-colors focus:border-emerald-400 focus:ring-1 focus:ring-emerald-400/50 disabled:opacity-50"
                            />
                            <input
                              type="text"
                              value={f.album}
                              onChange={(e) =>
                                updateFileMetadata(
                                  index,
                                  "album",
                                  e.target.value
                                )
                              }
                              placeholder="Album"
                              disabled={uploading}
                              className="w-full rounded-md bg-neutral-800 border border-white/10 px-3 py-2 text-sm text-white placeholder-neutral-500 outline-none transition-colors focus:border-emerald-400 focus:ring-1 focus:ring-emerald-400/50 disabled:opacity-50"
                            />
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Add more files */}
                  {!uploading && (
                    <button
                      onClick={() => fileInputRef.current?.click()}
                      className="flex items-center gap-2 text-sm text-neutral-400 transition-colors hover:text-white"
                    >
                      <Upload className="h-3.5 w-3.5" />
                      Add more files
                    </button>
                  )}
                </>
              )}

              {/* Upload progress */}
              {uploading && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-neutral-400">
                      Uploading {currentUploadingIndex + 1} of {files.length}
                      ...
                    </span>
                    <span className="text-emerald-400 font-medium">
                      {uploadProgress}%
                    </span>
                  </div>
                  <div className="h-1.5 w-full overflow-hidden rounded-full bg-neutral-800">
                    <div
                      className="h-full rounded-full bg-emerald-400 transition-all duration-300 ease-out"
                      style={{ width: `${uploadProgress}%` }}
                    />
                  </div>
                </div>
              )}
            </div>

            {/* Footer */}
            <div className="flex items-center justify-end gap-3 border-t border-white/10 px-6 py-4">
              {!uploading && (
                <>
                  <button
                    onClick={closeModal}
                    className="rounded-full px-5 py-2 text-sm font-medium text-neutral-300 transition-colors hover:text-white"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleUpload}
                    disabled={files.length === 0}
                    className="inline-flex items-center gap-2 rounded-full bg-emerald-400 px-6 py-2 text-sm font-semibold text-black transition-all hover:bg-emerald-300 hover:scale-105 active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100"
                  >
                    <Upload className="h-4 w-4" />
                    Upload{files.length > 1 ? ` ${files.length} tracks` : ""}
                  </button>
                </>
              )}
              {uploading && (
                <div className="flex items-center gap-2 text-sm text-neutral-400">
                  <div className="h-4 w-4 animate-spin rounded-full border-2 border-neutral-600 border-t-emerald-400" />
                  Uploading...
                </div>
              )}
            </div>
          </div>

          {/* Hidden file input */}
          <input
            ref={fileInputRef}
            type="file"
            accept=".mp3,.wav,.ogg,.m4a,.flac,audio/*"
            multiple
            onChange={handleFileInputChange}
            className="hidden"
          />
        </div>
      )}
    </>
  );
}
