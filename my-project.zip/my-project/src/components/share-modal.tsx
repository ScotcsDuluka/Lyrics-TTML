"use client";
import { useEffect, useState } from "react";
import { Share2, X, Copy, Check, Link2, Twitter, Facebook, MessageCircle, Mail } from "lucide-react";
import { useAppStore } from "@/lib/store";
import { toast } from "sonner";

export function ShareModal() {
  const showShareModal = useAppStore(s => s.showShareModal);
  const setShowShareModal = useAppStore(s => s.setShowShareModal);
  const sharePayload = useAppStore(s => s.sharePayload);

  const [copied, setCopied] = useState(false);
  const [embedCopied, setEmbedCopied] = useState(false);

  useEffect(() => {
    if (!showShareModal) {
      queueMicrotask(() => {
        setCopied(false);
        setEmbedCopied(false);
      });
    }
  }, [showShareModal]);

  if (!showShareModal || !sharePayload) return null;

  const baseUrl = typeof window !== "undefined" ? window.location.origin : "";
  const shareUrl = `${baseUrl}/?share=${sharePayload.type}_${sharePayload.id}`;
  const embedCode = `<iframe src="${baseUrl}/embed/${sharePayload.type}/${sharePayload.id}" width="100%" height="${sharePayload.type === "track" ? "152" : "380"}" frameborder="0" allowfullscreen></iframe>`;

  const copyLink = async () => {
    try {
      await navigator.clipboard.writeText(shareUrl);
      setCopied(true);
      toast.success("Link copied to clipboard");
      setTimeout(() => setCopied(false), 2000);
    } catch {
      toast.error("Failed to copy link");
    }
  };

  const copyEmbed = async () => {
    try {
      await navigator.clipboard.writeText(embedCode);
      setEmbedCopied(true);
      toast.success("Embed code copied");
      setTimeout(() => setEmbedCopied(false), 2000);
    } catch {
      toast.error("Failed to copy embed code");
    }
  };

  const shareToSocial = (platform: string) => {
    const text = encodeURIComponent(`Check out ${sharePayload.title}${sharePayload.subtitle ? ` by ${sharePayload.subtitle}` : ""} on Run Poll!`);
    const url = encodeURIComponent(shareUrl);
    const links: Record<string, string> = {
      twitter: `https://twitter.com/intent/tweet?text=${text}&url=${url}`,
      facebook: `https://www.facebook.com/sharer/sharer.php?u=${url}`,
      whatsapp: `https://wa.me/?text=${text}%20${url}`,
      telegram: `https://t.me/share/url?url=${url}&text=${text}`,
      email: `mailto:?subject=${text}&body=${url}`,
    };
    if (links[platform]) {
      window.open(links[platform], "_blank", "width=600,height=400");
    }
  };

  const platforms = [
    { id: "twitter", label: "Twitter", icon: Twitter, color: "hover:bg-sky-500/20 hover:text-sky-400" },
    { id: "facebook", label: "Facebook", icon: Facebook, color: "hover:bg-blue-500/20 hover:text-blue-400" },
    { id: "whatsapp", label: "WhatsApp", icon: MessageCircle, color: "hover:bg-emerald-500/20 hover:text-emerald-400" },
    { id: "telegram", label: "Telegram", icon: MessageCircle, color: "hover:bg-cyan-500/20 hover:text-cyan-400" },
    { id: "email", label: "Email", icon: Mail, color: "hover:bg-amber-500/20 hover:text-amber-400" },
  ];

  return (
    <div
      className="fixed inset-0 z-[200] flex items-center justify-center bg-black/70 backdrop-blur-sm bl-fade-in"
      onClick={() => setShowShareModal(false)}
    >
      <div
        className="relative w-[480px] max-w-[92vw] overflow-hidden rounded-2xl border border-white/15 bg-gradient-to-b from-[#1a1a1a] to-[#0a0a0a] shadow-2xl bl-scale-in"
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="relative overflow-hidden border-b border-white/10 px-6 pb-4 pt-6">
          <div className="absolute -right-12 -top-12 h-40 w-40 rounded-full bg-emerald-500/20 blur-3xl" />
          <div className="absolute -left-12 -top-12 h-40 w-40 rounded-full bg-teal-500/20 blur-3xl" />
          <div className="relative flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-br from-emerald-500 to-teal-700 shadow-lg shadow-emerald-500/30">
                <Share2 size={18} className="text-white" />
              </div>
              <div>
                <h2 className="text-lg font-bold text-white">Share</h2>
                <p className="text-xs text-[var(--sp-text-subdued)]">{sharePayload.type === "track" ? "Track" : "Playlist"}</p>
              </div>
            </div>
            <button onClick={() => setShowShareModal(false)} className="rounded-full p-1.5 text-white/60 hover:bg-white/10 hover:text-white">
              <X size={18} />
            </button>
          </div>
        </div>

        {/* Content preview */}
        <div className="border-b border-white/10 px-6 py-4">
          <div className="text-sm text-white">
            <span className="font-bold">{sharePayload.title}</span>
            {sharePayload.subtitle && (
              <span className="text-[var(--sp-text-subdued)]"> — {sharePayload.subtitle}</span>
            )}
          </div>
        </div>

        {/* Link */}
        <div className="px-6 py-4">
          <div className="mb-2 text-xs font-semibold uppercase tracking-wider text-[var(--sp-text-subdued)]">
            Share link
          </div>
          <div className="flex gap-2">
            <div className="flex flex-1 items-center gap-2 rounded-lg border border-white/10 bg-black/40 px-3 py-2">
              <Link2 size={14} className="shrink-0 text-white/40" />
              <input
                readOnly
                value={shareUrl}
                className="flex-1 bg-transparent text-xs text-white/80 outline-none"
                onFocus={e => e.target.select()}
              />
            </div>
            <button
              onClick={copyLink}
              className={`flex items-center gap-1.5 rounded-lg px-3 py-2 text-xs font-semibold transition-all ${
                copied
                  ? "bg-emerald-500 text-white"
                  : "bg-white/10 text-white hover:bg-white/20"
              }`}
            >
              {copied ? <Check size={14} /> : <Copy size={14} />}
              {copied ? "Copied" : "Copy"}
            </button>
          </div>
        </div>

        {/* Social platforms */}
        <div className="px-6 pb-4">
          <div className="mb-2 text-xs font-semibold uppercase tracking-wider text-[var(--sp-text-subdued)]">
            Share to
          </div>
          <div className="grid grid-cols-5 gap-2">
            {platforms.map(p => (
              <button
                key={p.id}
                onClick={() => shareToSocial(p.id)}
                className={`flex flex-col items-center gap-1.5 rounded-xl border border-white/10 bg-white/[0.03] p-3 transition-all hover:border-white/20 ${p.color}`}
              >
                <p.icon size={18} />
                <span className="text-[10px] text-white/70">{p.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Embed code */}
        <div className="border-t border-white/10 px-6 py-4">
          <button
            onClick={copyEmbed}
            className="flex w-full items-center justify-between rounded-lg border border-white/10 bg-white/[0.03] px-3 py-2 text-left transition-all hover:border-white/20 hover:bg-white/[0.06]"
          >
            <div className="flex items-center gap-2">
              {embedCopied ? <Check size={14} className="text-emerald-400" /> : <Copy size={14} className="text-white/60" />}
              <span className="text-xs text-white/80">Copy embed code</span>
            </div>
            <span className="text-[10px] text-white/40">&lt;iframe&gt;</span>
          </button>
        </div>

        <div className="border-t border-white/10 px-6 py-3 text-center">
          <p className="text-[10px] text-white/30">
            Anyone with the link can preview this {sharePayload.type}
          </p>
        </div>
      </div>
    </div>
  );
}
