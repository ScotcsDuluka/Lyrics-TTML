"use client";
import { useMemo, useState, useEffect, useRef } from "react";
import {
  Sparkles, Play, Heart, Music2, Clock, TrendingUp, Disc3, User,
  Flame, Award, Headphones, Calendar, Star, Crown, Zap, Moon, Sunrise, Sunset, Sun,
  ChevronLeft, ChevronRight, Share2, Download
} from "lucide-react";
import type { Track, PlayHistoryEntry } from "@/lib/types";

interface Props {
  history: PlayHistoryEntry[];
  allTracks: Track[];
  likedTrackCount: number;
  onSelectTrack: (track: Track) => void;
  onSelectArtist: (name: string) => void;
  onSelectAlbum: (name: string) => void;
  onShare?: () => void;
}

// Color palettes for the recap "slides"
const SLIDE_GRADIENTS = [
  "from-emerald-600 via-teal-700 to-cyan-900",
  "from-fuchsia-600 via-purple-700 to-indigo-900",
  "from-amber-500 via-orange-600 to-rose-800",
  "from-cyan-500 via-blue-600 to-indigo-800",
  "from-rose-500 via-pink-600 to-purple-800",
  "from-lime-500 via-emerald-600 to-teal-800",
  "from-violet-500 via-fuchsia-600 to-pink-800",
];

const GENRE_COLORS = [
  "#10b981", "#a855f7", "#f97316", "#06b6d4", "#ec4899",
  "#eab308", "#3b82f6", "#ef4444", "#84cc16", "#6366f1",
];

export function YearlyRecapView({
  history, allTracks, likedTrackCount, onSelectTrack, onSelectArtist, onSelectAlbum, onShare
}: Props) {
  // Filter to "this year" history
  const yearHistory = useMemo(() => {
    const year = new Date().getFullYear();
    return history.filter(h => new Date(h.playedAt).getFullYear() === year);
  }, [history]);

  const currentYear = new Date().getFullYear();

  // Aggregate stats
  const stats = useMemo(() => {
    const totalPlays = yearHistory.length;
    const totalSeconds = yearHistory.reduce((s, h) => s + (h.track.duration ?? 0), 0);
    const totalMinutes = Math.round(totalSeconds / 60);
    const totalHours = (totalMinutes / 60).toFixed(1);

    // Top tracks
    const trackCounts = new Map<string, number>();
    const trackMinutes = new Map<string, number>();
    for (const h of yearHistory) {
      trackCounts.set(h.trackId, (trackCounts.get(h.trackId) ?? 0) + 1);
      trackMinutes.set(h.trackId, (trackMinutes.get(h.trackId) ?? 0) + (h.track.duration ?? 0));
    }
    const topTracks = Array.from(trackCounts.entries())
      .map(([id, count]) => {
        const track = allTracks.find(t => t.id === id);
        return track ? { track, count, minutes: trackMinutes.get(id) ?? 0 } : null;
      })
      .filter(Boolean)
      .sort((a, b) => b!.count - a!.count)
      .slice(0, 5) as { track: Track; count: number; minutes: number }[];

    // Top artists
    const artistCounts = new Map<string, number>();
    for (const h of yearHistory) {
      for (const a of h.track.artists) {
        artistCounts.set(a, (artistCounts.get(a) ?? 0) + 1);
      }
    }
    const topArtists = Array.from(artistCounts.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5);

    // Top genres
    const genreCounts = new Map<string, number>();
    for (const h of yearHistory) {
      const g = h.track.genre;
      if (g) genreCounts.set(g, (genreCounts.get(g) ?? 0) + 1);
    }
    const topGenres = Array.from(genreCounts.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, 6);

    // Top albums
    const albumCounts = new Map<string, number>();
    for (const h of yearHistory) {
      const a = h.track.album;
      if (a) albumCounts.set(a, (albumCounts.get(a) ?? 0) + 1);
    }
    const topAlbums = Array.from(albumCounts.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, 3);

    // Unique track count
    const uniqueTrackIds = new Set(yearHistory.map(h => h.trackId));
    const uniqueArtists = new Set<string>();
    for (const h of yearHistory) {
      for (const a of h.track.artists) uniqueArtists.add(a);
    }

    // Day-of-week distribution
    const dayOfWeek = new Array(7).fill(0);
    for (const h of yearHistory) {
      dayOfWeek[new Date(h.playedAt).getDay()]++;
    }
    const dayLabels = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
    const maxDay = Math.max(1, ...dayOfWeek);
    const peakDayIdx = dayOfWeek.indexOf(maxDay);

    // Hour distribution (peak listening time)
    const hourBuckets = new Array(24).fill(0);
    for (const h of yearHistory) {
      hourBuckets[new Date(h.playedAt).getHours()]++;
    }
    const peakHour = hourBuckets.indexOf(Math.max(...hourBuckets));

    // Month distribution
    const monthBuckets = new Array(12).fill(0);
    for (const h of yearHistory) {
      monthBuckets[new Date(h.playedAt).getMonth()]++;
    }
    const monthLabels = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    const maxMonth = Math.max(1, ...monthBuckets);

    // Listening personality (Spotify Wrapped-style)
    let personality = "The Explorer";
    let personalityDesc = "You love discovering new music across genres and moods.";
    let personalityIcon = <Sparkles size={32} className="text-white" />;
    if (topGenres.length > 0) {
      const topGenreCount = topGenres[0][1];
      const ratio = topGenreCount / Math.max(1, totalPlays);
      if (ratio > 0.5) {
        personality = "The Specialist";
        personalityDesc = `You're devoted to ${topGenres[0][0]} — it defined your year.`;
        personalityIcon = <Crown size={32} className="text-amber-300" />;
      } else if (totalPlays > 50) {
        personality = "The Devotee";
        personalityDesc = "Your listening is consistent and loyal — music is your daily ritual.";
        personalityIcon = <Heart size={32} className="text-rose-300" />;
      } else if (uniqueArtists.size > 8) {
        personality = "The Explorer";
        personalityDesc = "You cast a wide net, jumping between artists and styles.";
        personalityIcon = <Sparkles size={32} className="text-emerald-300" />;
      }
    }
    if (totalPlays === 0) {
      personality = "The Beginner";
      personalityDesc = "Your journey has just begun — press play to start your story.";
      personalityIcon = <Music2 size={32} className="text-white/80" />;
    }

    return {
      totalPlays, totalMinutes, totalHours,
      topTracks, topArtists, topGenres, topAlbums,
      uniqueTrackCount: uniqueTrackIds.size,
      uniqueArtists: uniqueArtists.size,
      dayOfWeek, dayLabels, maxDay, peakDayIdx,
      hourBuckets, peakHour,
      monthBuckets, monthLabels, maxMonth,
      personality, personalityDesc, personalityIcon,
    };
  }, [yearHistory, allTracks]);

  // Vibe by hour
  const vibeByHour = (hr: number) => {
    if (hr >= 5 && hr < 9) return { label: "Early bird", icon: <Sunrise size={12} />, color: "text-amber-400" };
    if (hr >= 9 && hr < 12) return { label: "Morning focus", icon: <Sun size={12} />, color: "text-yellow-400" };
    if (hr >= 12 && hr < 17) return { label: "Afternoon groove", icon: <Sun size={12} />, color: "text-orange-400" };
    if (hr >= 17 && hr < 22) return { label: "Evening unwind", icon: <Sunset size={12} />, color: "text-rose-400" };
    return { label: "Night owl", icon: <Moon size={12} />, color: "text-violet-400" };
  };

  // Slide navigation
  const totalSlides = 7;
  const [slide, setSlide] = useState(0);
  const slideRef = useRef<HTMLDivElement>(null);

  // Reset slide when nothing
  useEffect(() => { queueMicrotask(() => { setSlide(0); }); }, []);

  const goNext = () => setSlide(s => Math.min(totalSlides - 1, s + 1));
  const goPrev = () => setSlide(s => Math.max(0, s - 1));

  // Keyboard navigation
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === "ArrowRight") goNext();
      else if (e.key === "ArrowLeft") goPrev();
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, []);

  if (yearHistory.length === 0) {
    return (
      <div className="bl-scroll flex-1 flex items-center justify-center px-6 pb-32 bl-view-transition">
        <div className="text-center max-w-md">
          <div className="mx-auto mb-4 flex h-20 w-20 items-center justify-center rounded-full bg-gradient-to-br from-emerald-500 to-teal-700 shadow-xl shadow-emerald-500/30">
            <Sparkles size={36} className="text-white" />
          </div>
          <h2 className="text-2xl font-extrabold text-white">Your {currentYear} Recap is brewing</h2>
          <p className="mt-2 text-sm text-[var(--sp-text-subdued)]">
            Play a few tracks and your personalized year-in-review will appear here — complete with your top artists, genres, listening personality, and more.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="bl-scroll flex-1 px-6 pb-32 bl-view-transition">
      {/* Hero header */}
      <div className="relative overflow-hidden rounded-3xl mb-6 mt-4">
        <div className={`absolute inset-0 bg-gradient-to-br ${SLIDE_GRADIENTS[0]}`} />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/30 to-transparent" />
        {/* Floating shapes */}
        <div className="pointer-events-none absolute inset-0 overflow-hidden">
          <div className="absolute -top-12 -right-12 h-40 w-40 rounded-full bg-white/10 blur-3xl" />
          <div className="absolute -bottom-12 -left-12 h-40 w-40 rounded-full bg-white/10 blur-3xl" />
          <div className="absolute top-1/2 left-1/3 h-32 w-32 rounded-full bg-white/5 blur-2xl" />
        </div>

        <div className="relative px-8 py-12 sm:px-12 sm:py-16">
          <div className="flex items-center gap-2 mb-3">
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-white/15 backdrop-blur-sm">
              <Sparkles size={16} className="text-white" />
            </div>
            <span className="text-xs font-bold uppercase tracking-widest text-white/80">{currentYear} Wrapped</span>
          </div>
          <h1 className="text-5xl sm:text-7xl font-extrabold tracking-tighter text-white drop-shadow-lg">
            Your Year<br />
            <span className="bg-gradient-to-r from-white via-emerald-100 to-cyan-200 bg-clip-text text-transparent">
              In Music
            </span>
          </h1>
          <p className="mt-4 max-w-lg text-sm sm:text-base text-white/80">
            {stats.totalPlays} plays • {stats.totalHours} hours • {stats.uniqueArtists} artists • {stats.uniqueTrackCount} unique tracks
          </p>
          <div className="mt-6 flex flex-wrap gap-3">
            <button
              onClick={() => setSlide(0)}
              className="inline-flex items-center gap-2 rounded-full bg-white px-5 py-2.5 text-sm font-bold text-black shadow-xl transition-all hover:scale-105"
            >
              <Play size={14} fill="currentColor" /> Start Recap
            </button>
            {onShare && (
              <button
                onClick={onShare}
                className="inline-flex items-center gap-2 rounded-full bg-white/10 px-5 py-2.5 text-sm font-bold text-white backdrop-blur-sm transition-all hover:bg-white/20"
              >
                <Share2 size={14} /> Share
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Slide navigation indicator */}
      <div className="mb-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          {Array.from({ length: totalSlides }).map((_, i) => (
            <button
              key={i}
              onClick={() => setSlide(i)}
              className={`h-1.5 rounded-full transition-all ${
                i === slide ? "w-8 bg-emerald-500" : "w-4 bg-white/20 hover:bg-white/40"
              }`}
              aria-label={`Go to slide ${i + 1}`}
            />
          ))}
        </div>
        <div className="flex items-center gap-1">
          <button
            onClick={goPrev}
            disabled={slide === 0}
            className="rounded-full bg-white/5 p-2 text-white/70 transition-all hover:bg-white/10 hover:text-white disabled:opacity-30 disabled:hover:bg-white/5"
            aria-label="Previous slide"
          >
            <ChevronLeft size={16} />
          </button>
          <button
            onClick={goNext}
            disabled={slide === totalSlides - 1}
            className="rounded-full bg-white/5 p-2 text-white/70 transition-all hover:bg-white/10 hover:text-white disabled:opacity-30 disabled:hover:bg-white/5"
            aria-label="Next slide"
          >
            <ChevronRight size={16} />
          </button>
        </div>
      </div>

      {/* Slides */}
      <div ref={slideRef} className="relative">
        {/* Slide 1: Top stats overview */}
        {slide === 0 && (
          <RecapSlide gradient={SLIDE_GRADIENTS[0]} index={1}>
            <div className="grid grid-cols-2 gap-4 sm:grid-cols-4 mb-6">
              <BigStat icon={<Headphones size={20} />} value={stats.totalPlays.toString()} label="Total Plays" />
              <BigStat icon={<Clock size={20} />} value={stats.totalHours + "h"} label="Hours Listened" />
              <BigStat icon={<User size={20} />} value={stats.uniqueArtists.toString()} label="Artists" />
              <BigStat icon={<Music2 size={20} />} value={stats.uniqueTrackCount.toString()} label="Unique Tracks" />
            </div>
            <p className="text-center text-sm text-white/80">
              You spent <span className="font-bold text-white">{stats.totalHours} hours</span> listening to music this year —
              that's <span className="font-bold text-white">{stats.totalMinutes} minutes</span> of pure sound.
            </p>
          </RecapSlide>
        )}

        {/* Slide 2: Top Artists */}
        {slide === 1 && (
          <RecapSlide gradient={SLIDE_GRADIENTS[1]} index={2} title="Your Top Artists" subtitle="The voices that defined your year">
            <div className="space-y-3">
              {stats.topArtists.map(([name, count], i) => (
                <button
                  key={name}
                  onClick={() => onSelectArtist(name)}
                  className="group flex w-full items-center gap-4 rounded-2xl bg-white/10 p-3 text-left transition-all hover:bg-white/15 hover:translate-x-1"
                >
                  <div className={`flex h-10 w-10 items-center justify-center rounded-full font-extrabold text-white ${
                    i === 0 ? "bg-gradient-to-br from-amber-300 to-orange-500" :
                    i === 1 ? "bg-gradient-to-br from-slate-300 to-slate-500" :
                    i === 2 ? "bg-gradient-to-br from-amber-700 to-orange-900" :
                    "bg-white/20"
                  }`}>
                    {i + 1}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="truncate font-bold text-white">{name}</div>
                    <div className="text-xs text-white/60">{count} plays</div>
                  </div>
                  {i === 0 && <Crown size={20} className="text-amber-300" />}
                </button>
              ))}
            </div>
          </RecapSlide>
        )}

        {/* Slide 3: Top Tracks */}
        {slide === 2 && (
          <RecapSlide gradient={SLIDE_GRADIENTS[2]} index={3} title="Your Top Tracks" subtitle="The songs on repeat">
            <div className="space-y-3">
              {stats.topTracks.map(({ track, count }, i) => (
                <button
                  key={track.id}
                  onClick={() => onSelectTrack(track)}
                  className="group flex w-full items-center gap-3 rounded-2xl bg-white/10 p-3 text-left transition-all hover:bg-white/15 hover:translate-x-1"
                >
                  <div className="relative h-14 w-14 shrink-0">
                    {track.coverUrl ? (
                      <img src={track.coverUrl} alt="" className="h-full w-full rounded-lg object-cover" />
                    ) : (
                      <div className="flex h-full w-full items-center justify-center rounded-lg bg-white/10">
                        <Music2 size={18} className="text-white/60" />
                      </div>
                    )}
                    <div className={`absolute -top-2 -left-2 flex h-7 w-7 items-center justify-center rounded-full text-xs font-extrabold text-white shadow-lg ${
                      i === 0 ? "bg-gradient-to-br from-amber-300 to-orange-500" :
                      i === 1 ? "bg-gradient-to-br from-slate-300 to-slate-500" :
                      i === 2 ? "bg-gradient-to-br from-amber-700 to-orange-900" :
                      "bg-white/30"
                    }`}>
                      {i + 1}
                    </div>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className={`truncate font-bold ${i === 0 ? "text-amber-200" : "text-white"}`}>{track.title}</div>
                    <div className="truncate text-xs text-white/60">{track.artists.join(", ")}</div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm font-bold text-white">{count}</div>
                    <div className="text-[10px] uppercase tracking-wider text-white/50">plays</div>
                  </div>
                </button>
              ))}
            </div>
          </RecapSlide>
        )}

        {/* Slide 4: Top Genres */}
        {slide === 3 && (
          <RecapSlide gradient={SLIDE_GRADIENTS[3]} index={4} title="Your Top Genres" subtitle="The flavors of your year">
            <div className="space-y-2.5">
              {stats.topGenres.map(([genre, count], i) => {
                const pct = Math.round((count / Math.max(1, stats.totalPlays)) * 100);
                const barWidth = (count / Math.max(1, stats.topGenres[0][1])) * 100;
                return (
                  <div key={genre} className="rounded-2xl bg-white/10 p-3">
                    <div className="mb-2 flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="text-lg font-bold text-white/40">#{i + 1}</span>
                        <span className="font-bold text-white">{genre}</span>
                      </div>
                      <span className="text-xs font-bold text-white/70">{count} plays • {pct}%</span>
                    </div>
                    <div className="h-2 overflow-hidden rounded-full bg-black/30">
                      <div
                        className="h-full rounded-full transition-all duration-700"
                        style={{
                          width: `${barWidth}%`,
                          background: `linear-gradient(to right, ${GENRE_COLORS[i % GENRE_COLORS.length]}, ${GENRE_COLORS[(i + 1) % GENRE_COLORS.length]})`,
                          boxShadow: `0 0 12px ${GENRE_COLORS[i % GENRE_COLORS.length]}80`,
                        }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </RecapSlide>
        )}

        {/* Slide 5: Listening Personality */}
        {slide === 4 && (
          <RecapSlide gradient={SLIDE_GRADIENTS[4]} index={5}>
            <div className="text-center py-6">
              <div className="text-xs font-bold uppercase tracking-widest text-white/60 mb-4">Your Listening Personality</div>
              <div className="mx-auto mb-6 flex h-28 w-28 items-center justify-center rounded-full bg-white/10 backdrop-blur-sm shadow-2xl">
                {stats.personalityIcon}
              </div>
              <h2 className="text-4xl sm:text-5xl font-extrabold text-white drop-shadow-lg">
                {stats.personality}
              </h2>
              <p className="mt-4 max-w-md mx-auto text-sm text-white/80">
                {stats.personalityDesc}
              </p>
              <div className="mt-6 inline-flex items-center gap-2 rounded-full bg-white/10 px-4 py-2 text-xs font-bold text-white/90">
                <Star size={12} className="text-amber-300" fill="currentColor" />
                {stats.uniqueArtists} unique artists • {stats.uniqueTrackCount} unique tracks
              </div>
            </div>
          </RecapSlide>
        )}

        {/* Slide 6: Listening Patterns */}
        {slide === 5 && (
          <RecapSlide gradient={SLIDE_GRADIENTS[5]} index={6} title="Your Patterns" subtitle="When the music moves you">
            <div className="space-y-5">
              {/* Peak hour */}
              <div className="rounded-2xl bg-white/10 p-4">
                <div className="mb-2 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Clock size={16} className="text-white/70" />
                    <span className="text-sm font-bold text-white">Peak Listening Time</span>
                  </div>
                  <span className={`inline-flex items-center gap-1 text-xs font-bold ${vibeByHour(stats.peakHour).color}`}>
                    {vibeByHour(stats.peakHour).icon} {vibeByHour(stats.peakHour).label}
                  </span>
                </div>
                <div className="text-3xl font-extrabold text-white">
                  {String(stats.peakHour).padStart(2, "0")}:00
                </div>
                {/* Hour visualization */}
                <div className="mt-3 flex h-12 items-end gap-px">
                  {stats.hourBuckets.map((c, i) => {
                    const max = Math.max(1, ...stats.hourBuckets);
                    const h = (c / max) * 100;
                    return (
                      <div
                        key={i}
                        className="flex-1 rounded-t-sm transition-all"
                        style={{
                          height: `${Math.max(2, h)}%`,
                          background: i === stats.peakHour
                            ? "linear-gradient(to top, #10b981, #6ee7b7)"
                            : "rgba(255,255,255,0.2)",
                        }}
                        title={`${i}:00 - ${c} plays`}
                      />
                    );
                  })}
                </div>
              </div>

              {/* Day of week */}
              <div className="rounded-2xl bg-white/10 p-4">
                <div className="mb-3 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Calendar size={16} className="text-white/70" />
                    <span className="text-sm font-bold text-white">Top Day of Week</span>
                  </div>
                  <span className="text-xs font-bold text-white/70">{stats.dayLabels[stats.peakDayIdx]}</span>
                </div>
                <div className="flex items-end justify-between gap-2">
                  {stats.dayOfWeek.map((c, i) => {
                    const h = (c / stats.maxDay) * 100;
                    return (
                      <div key={i} className="flex flex-1 flex-col items-center gap-1">
                        <div
                          className="w-full rounded-t-md transition-all"
                          style={{
                            height: `${Math.max(4, h) * 0.8}px`,
                            background: i === stats.peakDayIdx
                              ? "linear-gradient(to top, #f59e0b, #fbbf24)"
                              : "rgba(255,255,255,0.15)",
                          }}
                        />
                        <span className="text-[10px] font-medium text-white/60">{stats.dayLabels[i]}</span>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Month trend */}
              <div className="rounded-2xl bg-white/10 p-4">
                <div className="mb-3 flex items-center gap-2">
                  <TrendingUp size={16} className="text-white/70" />
                  <span className="text-sm font-bold text-white">Monthly Trend</span>
                </div>
                <svg viewBox="0 0 600 80" className="w-full" style={{ height: 60 }} preserveAspectRatio="none">
                  <defs>
                    <linearGradient id="monthArea" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#10b981" stopOpacity="0.6" />
                      <stop offset="100%" stopColor="#10b981" stopOpacity="0" />
                    </linearGradient>
                  </defs>
                  {(() => {
                    const W = 600, H = 70, pad = 4;
                    const step = (W - pad * 2) / Math.max(1, stats.monthBuckets.length - 1);
                    const points = stats.monthBuckets.map((c, i) => ({
                      x: pad + i * step,
                      y: H - pad - (c / stats.maxMonth) * (H - pad * 2),
                    }));
                    let path = `M ${points[0].x} ${points[0].y}`;
                    for (let i = 1; i < points.length; i++) {
                      const prev = points[i - 1];
                      const curr = points[i];
                      const cx = (prev.x + curr.x) / 2;
                      path += ` Q ${cx} ${prev.y} ${cx} ${(prev.y + curr.y) / 2} T ${curr.x} ${curr.y}`;
                    }
                    const area = path + ` L ${points[points.length - 1].x} ${H - pad} L ${points[0].x} ${H - pad} Z`;
                    return (
                      <>
                        <path d={area} fill="url(#monthArea)" />
                        <path d={path} fill="none" stroke="#10b981" strokeWidth="2" strokeLinecap="round" />
                        {points.map((p, i) => (
                          <circle key={i} cx={p.x} cy={p.y} r="3" fill="#10b981" stroke="#0a0a0a" strokeWidth="1" />
                        ))}
                      </>
                    );
                  })()}
                </svg>
              </div>
            </div>
          </RecapSlide>
        )}

        {/* Slide 7: Top Albums + Recap summary */}
        {slide === 6 && (
          <RecapSlide gradient={SLIDE_GRADIENTS[6]} index={7} title="Your Top Albums" subtitle="The records that played on">
            <div className="space-y-3 mb-6">
              {stats.topAlbums.map(([album, count], i) => {
                const track = allTracks.find(t => t.album === album);
                return (
                  <button
                    key={album}
                    onClick={() => onSelectAlbum(album)}
                    className="group flex w-full items-center gap-4 rounded-2xl bg-white/10 p-3 text-left transition-all hover:bg-white/15 hover:translate-x-1"
                  >
                    <div className="relative h-14 w-14 shrink-0">
                      {track?.coverUrl ? (
                        <img src={track.coverUrl} alt="" className="h-full w-full rounded-lg object-cover" />
                      ) : (
                        <div className="flex h-full w-full items-center justify-center rounded-lg bg-white/10">
                          <Disc3 size={20} className="text-white/60" />
                        </div>
                      )}
                      <div className={`absolute -top-2 -left-2 flex h-7 w-7 items-center justify-center rounded-full text-xs font-extrabold text-white shadow-lg ${
                        i === 0 ? "bg-gradient-to-br from-amber-300 to-orange-500" : "bg-white/30"
                      }`}>
                        {i + 1}
                      </div>
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="truncate font-bold text-white">{album}</div>
                      <div className="truncate text-xs text-white/60">{track?.artists.join(", ")}</div>
                    </div>
                    <div className="text-right">
                      <div className="text-sm font-bold text-white">{count}</div>
                      <div className="text-[10px] uppercase tracking-wider text-white/50">plays</div>
                    </div>
                  </button>
                );
              })}
            </div>
            {/* Final summary card */}
            <div className="rounded-2xl border border-white/20 bg-gradient-to-br from-white/10 to-transparent p-5 text-center">
              <Award size={28} className="mx-auto mb-2 text-amber-300" />
              <div className="text-sm font-bold text-white mb-1">Thanks for listening</div>
              <p className="text-xs text-white/70">
                You played <span className="font-bold text-white">{stats.totalPlays}</span> tracks across{" "}
                <span className="font-bold text-white">{stats.uniqueArtists}</span> artists in {currentYear}.
                See you next year!
              </p>
            </div>
          </RecapSlide>
        )}
      </div>

      {/* Bottom CTA hint */}
      <div className="mt-6 text-center text-xs text-[var(--sp-text-subdued)]">
        Use ← → arrow keys to navigate • Slide {slide + 1} of {totalSlides}
      </div>
    </div>
  );
}

// Helper: Big stat card for slide 1
function BigStat({ icon, value, label }: { icon: React.ReactNode; value: string; label: string }) {
  return (
    <div className="rounded-2xl bg-white/10 p-4 text-center backdrop-blur-sm">
      <div className="mx-auto mb-2 flex h-10 w-10 items-center justify-center rounded-full bg-white/15">
        {icon}
      </div>
      <div className="text-2xl font-extrabold text-white tabular-nums">{value}</div>
      <div className="text-[10px] uppercase tracking-wider text-white/60">{label}</div>
    </div>
  );
}

// Helper: Slide wrapper with gradient background
function RecapSlide({
  gradient, index, title, subtitle, children
}: {
  gradient: string;
  index: number;
  title?: string;
  subtitle?: string;
  children: React.ReactNode;
}) {
  return (
    <div className={`relative overflow-hidden rounded-3xl bg-gradient-to-br ${gradient} p-6 sm:p-8 bl-scale-in shadow-2xl`}>
      {/* Decorative orbs */}
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute -top-16 -right-16 h-48 w-48 rounded-full bg-white/10 blur-3xl" />
        <div className="absolute -bottom-16 -left-16 h-48 w-48 rounded-full bg-black/10 blur-3xl" />
      </div>
      <div className="relative">
        {/* Slide number badge */}
        <div className="mb-4 inline-flex items-center gap-1.5 rounded-full bg-black/20 px-3 py-1 text-[10px] font-bold uppercase tracking-widest text-white/80">
          <span className="rounded-full bg-white/20 px-1.5 py-0.5">{index}</span>
          of 7
        </div>
        {title && (
          <div className="mb-5">
            <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white drop-shadow">{title}</h2>
            {subtitle && <p className="mt-1 text-sm text-white/70">{subtitle}</p>}
          </div>
        )}
        {children}
      </div>
    </div>
  );
}
