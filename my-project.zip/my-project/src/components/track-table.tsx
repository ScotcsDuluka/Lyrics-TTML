"use client";
import { useState, useRef } from "react";
import { Play, Pause, Heart, Clock, GripVertical } from "lucide-react";
import type { Track, Playlist } from "@/lib/types";
import { AddToPlaylistButton } from "./add-to-playlist";

interface Props {
  tracks: Track[];
  currentTrackId: string | null;
  isPlaying: boolean;
  onSelect: (track: Track, index: number) => void;
  onTogglePlay: () => void;
  onToggleLike: (trackId: string) => void;
  playlists?: Playlist[];
  onAddToPlaylist?: (playlistId: string, trackId: string) => Promise<boolean>;
  onCreatePlaylistWithTrack?: (name: string, trackId: string) => Promise<string | null>;
  onReorder?: (fromIndex: number, toIndex: number) => void;
  canReorder?: boolean;
  onAddToQueue?: (trackId: string) => void;
}

function fmtDuration(s?: number | null): string {
  if (!s || !isFinite(s)) return "--:--";
  const t = Math.floor(s);
  const m = Math.floor(t / 60);
  const sec = t % 60;
  return `${m}:${sec.toString().padStart(2, "0")}`;
}

export function TrackTable({ tracks, currentTrackId, isPlaying, onSelect, onTogglePlay, onToggleLike, playlists, onAddToPlaylist, onCreatePlaylistWithTrack, onReorder, canReorder, onAddToQueue }: Props) {
  const [dragIndex, setDragIndex] = useState<number | null>(null);
  const [overIndex, setOverIndex] = useState<number | null>(null);
  const dragTrackId = useRef<string | null>(null);

  if (tracks.length === 0) {
    return (
      <div className="px-6 py-12 text-center text-[var(--sp-text-subdued)]">
        <Clock size={48} className="mx-auto mb-4 opacity-30" />
        <div className="text-lg">No tracks here yet</div>
      </div>
    );
  }

  const hasPlaylistMenu = !!playlists && !!onAddToPlaylist && !!onCreatePlaylistWithTrack;
  const hasReorder = !!onReorder && !!canReorder;

  const handleDragStart = (e: React.DragEvent, index: number, trackId: string) => {
    if (!hasReorder) return;
    setDragIndex(index);
    dragTrackId.current = trackId;
    e.dataTransfer.effectAllowed = "move";
    e.dataTransfer.setData("text/plain", trackId);
  };

  const handleDragOver = (e: React.DragEvent, index: number) => {
    if (!hasReorder || dragIndex === null) return;
    e.preventDefault();
    e.dataTransfer.dropEffect = "move";
    if (overIndex !== index) setOverIndex(index);
  };

  const handleDragLeave = () => {
    if (!hasReorder) return;
    // Don't clear on every leave — only clear if we leave the table entirely
  };

  const handleDrop = (e: React.DragEvent, index: number) => {
    if (!hasReorder || dragIndex === null) return;
    e.preventDefault();
    if (dragIndex !== index) {
      onReorder?.(dragIndex, index);
    }
    setDragIndex(null);
    setOverIndex(null);
    dragTrackId.current = null;
  };

  const handleDragEnd = () => {
    setDragIndex(null);
    setOverIndex(null);
    dragTrackId.current = null;
  };

  return (
    <div className="px-6 pb-6">
      {/* Header row */}
      <div className={`grid items-center gap-4 border-b border-white/10 px-4 py-2 text-xs uppercase tracking-wider text-[var(--sp-text-subdued)] sticky top-0 z-10 bg-black/40 backdrop-blur-sm ${hasPlaylistMenu ? "grid-cols-[16px_minmax(0,4fr)_minmax(0,3fr)_minmax(70px,1fr)_auto_minmax(60px,auto)]" : hasReorder ? "grid-cols-[20px_16px_minmax(0,4fr)_minmax(0,3fr)_minmax(70px,1fr)_minmax(60px,auto)]" : "grid-cols-[16px_minmax(0,4fr)_minmax(0,3fr)_minmax(70px,1fr)_minmax(60px,auto)]"}`}>
        {hasReorder && <div></div>}
        <div className="text-center">#</div>
        <div>Title</div>
        <div>Album</div>
        <div className="hidden md:block">Plays</div>
        {hasPlaylistMenu && <div></div>}
        <div className="text-right">
          <Clock size={14} className="ml-auto" />
        </div>
      </div>

      {/* Track rows */}
      <div>
        {tracks.map((t, i) => {
          const active = t.id === currentTrackId;
          const isDragging = dragIndex === i;
          const isOver = overIndex === i && dragIndex !== null && dragIndex !== i;
          return (
            <div
              key={`track-${i}-${t.id}`}
              data-track-id={t.id}
              data-track-index={i}
              draggable={hasReorder}
              onDragStart={(e) => handleDragStart(e, i, t.id)}
              onDragOver={(e) => handleDragOver(e, i)}
              onDragLeave={handleDragLeave}
              onDrop={(e) => handleDrop(e, i)}
              onDragEnd={handleDragEnd}
              onDoubleClick={() => onSelect(t, i)}
              className={`bl-track-row group grid items-center gap-4 rounded-md px-4 py-2 transition-all duration-200 hover:bg-white/10 ${
                hasPlaylistMenu ? "grid-cols-[16px_minmax(0,4fr)_minmax(0,3fr)_minmax(70px,1fr)_auto_minmax(60px,auto)]" :
                hasReorder ? "grid-cols-[20px_16px_minmax(0,4fr)_minmax(0,3fr)_minmax(70px,1fr)_minmax(60px,auto)]" :
                "grid-cols-[16px_minmax(0,4fr)_minmax(0,3fr)_minmax(70px,1fr)_minmax(60px,auto)]"
              } ${active ? "active bg-white/5" : ""} ${isDragging ? "opacity-40" : ""} ${isOver ? "border-t-2 border-emerald-400" : ""}`}
            >
              {/* Drag handle */}
              {hasReorder && (
                <div className={`flex items-center justify-center ${hasReorder ? "cursor-grab active:cursor-grabbing" : ""} text-[var(--sp-text-subdued)] opacity-0 group-hover:opacity-100 transition-opacity`}>
                  <GripVertical size={14} />
                </div>
              )}

              {/* Index / Play button */}
              <div className="text-center text-sm tabular-nums text-[var(--sp-text-subdued)]">
                {active && isPlaying ? (
                  <>
                    <span className="text-emerald-400 group-hover:hidden">
                      <span className="bl-eq-bar">
                        {[0,1,2,3].map(j => (
                          <span key={j} style={{
                            animationDelay: `${j*0.15}s`,
                            animationDuration: "0.8s",
                            height: `${[60,100,70,90][j]}%`,
                          }} />
                        ))}
                      </span>
                    </span>
                    <button
                      onClick={onTogglePlay}
                      className="hidden text-white group-hover:block"
                    >
                      <Pause size={14} fill="currentColor" />
                    </button>
                  </>
                ) : (
                  <>
                    <span className="group-hover:hidden">{i + 1}</span>
                    <button
                      onClick={() => onSelect(t, i)}
                      className="hidden text-white group-hover:block"
                    >
                      <Play size={14} fill="currentColor" />
                    </button>
                  </>
                )}
              </div>

              {/* Title + artist */}
              <div className="flex min-w-0 items-center gap-3">
                <div className="h-10 w-10 shrink-0 overflow-hidden rounded">
                  {t.coverUrl ? (
                    <img src={t.coverUrl} alt="" className="h-full w-full object-cover" />
                  ) : (
                    <div className="h-full w-full bg-white/10" />
                  )}
                </div>
                <div className="min-w-0">
                  <div className={`truncate text-sm font-medium ${active ? "text-emerald-400" : "text-white"}`}>
                    {t.title}
                  </div>
                  <div className="truncate text-xs text-[var(--sp-text-subdued)]">
                    {t.artists.join(", ")}
                  </div>
                </div>
              </div>

              {/* Album + Genre (with tooltip on hover) */}
              <div className="flex min-w-0 items-center gap-2" title={`${t.album || ""}${("genre" in t && (t as any).genre) ? " • " + (t as any).genre : ""}`}>
                <span className="truncate text-sm text-[var(--sp-text-subdued)]">
                  {t.album || "—"}
                </span>
                {"genre" in t && (t as any).genre && (
                  <span className="shrink-0 rounded bg-white/10 px-1.5 py-0.5 text-[9px] font-bold text-emerald-400/80">{(t as any).genre}</span>
                )}
              </div>

              {/* Plays (fake) */}
              <div className="hidden text-sm text-[var(--sp-text-subdued)] md:block">
                {(parseInt(t.id.slice(-4), 36) % 999 + 1).toLocaleString()}
              </div>

              {/* Add to playlist */}
              {hasPlaylistMenu && (
                <AddToPlaylistButton
                  trackId={t.id}
                  playlists={playlists!}
                  onAddToPlaylist={onAddToPlaylist!}
                  onCreatePlaylist={onCreatePlaylistWithTrack!}
                  onAddToQueue={onAddToQueue}
                />
              )}

              {/* Like + duration */}
              <div className="flex items-center justify-end gap-3">
                <button
                  onClick={() => onToggleLike(t.id)}
                  className={`transition-opacity ${t.liked ? "text-emerald-400 opacity-100" : "text-[var(--sp-text-subdued)] opacity-0 group-hover:opacity-100 hover:text-white"}`}
                >
                  <Heart size={14} fill={t.liked ? "currentColor" : "none"} />
                </button>
                <span className="text-sm tabular-nums text-[var(--sp-text-subdued)]">
                  {fmtDuration(t.duration)}
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
