"use client";

import { useState, useMemo, useEffect, useCallback } from "react";
import {
  Radio,
  Play,
  Heart,
  Clock,
  Music2,
  SkipForward,
  Mic2,
  Waves,
  Sun,
  Brain,
  Sparkles,
  Mountain,
  Star,
  ChevronRight,
  User,
} from "lucide-react";
import type { Track, PlayHistoryEntry } from "@/lib/types";

/* ------------------------------------------------------------------ */
/*  Props                                                              */
/* ------------------------------------------------------------------ */
interface Props {
  allTracks: Track[];
  history: PlayHistoryEntry[];
  likedTrackIds: string[];
  currentTrackId: string | null;
  isPlaying: boolean;
  onPlayAll: (tracks: Track[]) => void;
  onSelectTrack: (track: Track, index: number, list: Track[]) => void;
  onToggleLike: (trackId: string) => void;
  onSelectArtist: (name: string) => void;
}

/* ------------------------------------------------------------------ */
/*  Station definitions                                                */
/* ------------------------------------------------------------------ */
interface StationDef {
  id: string;
  name: string;
  description: string;
  gradient: string;
  icon: React.ReactNode;
  genreFilters: string[];
  fallbackKeywords: string[];
}

const STATIONS: StationDef[] = [
  {
    id: "chill-lounge",
    name: "Chill Lounge",
    description: "Smooth ambient & lo-fi beats for relaxing evenings.",
    gradient: "from-teal-600 via-teal-700 to-cyan-900",
    icon: <Waves size={28} className="text-white/90" />,
    genreFilters: ["Ambient", "Lo-Fi", "Chill", "Downtempo", "Lounge"],
    fallbackKeywords: ["chill", "lounge", "relax", "ambient", "calm"],
  },
  {
    id: "energy-boost",
    name: "Energy Boost",
    description: "High-energy tracks to keep you moving.",
    gradient: "from-orange-500 via-orange-600 to-amber-800",
    icon: <Sun size={28} className="text-white/90" />,
    genreFilters: ["Pop", "Rock", "Dance", "Electronic", "Upbeat"],
    fallbackKeywords: ["energy", "boost", "power", "upbeat", "dance"],
  },
  {
    id: "deep-focus",
    name: "Deep Focus",
    description: "Nature-inspired soundscapes for maximum clarity.",
    gradient: "from-violet-600 via-violet-700 to-purple-900",
    icon: <Brain size={28} className="text-white/90" />,
    genreFilters: ["Electronic", "Ambient", "Nature", "Minimal", "Focus"],
    fallbackKeywords: ["focus", "deep", "study", "electronic", "nature"],
  },
  {
    id: "throwback-mix",
    name: "Throwback Mix",
    description: "Timeless classics & hidden gems.",
    gradient: "from-pink-500 via-pink-600 to-rose-800",
    icon: <Sparkles size={28} className="text-white/90" />,
    genreFilters: ["Classic", "Retro", "Pop", "Rock", "Soul"],
    fallbackKeywords: ["throwback", "classic", "retro", "mix", "oldies"],
  },
  {
    id: "indie-discovery",
    name: "Indie Discovery",
    description: "Fresh sounds from the indie underground scene.",
    gradient: "from-amber-500 via-amber-600 to-yellow-800",
    icon: <Mountain size={28} className="text-white/90" />,
    genreFilters: ["Indie", "Rock", "Alternative", "Folk", "Indie Rock"],
    fallbackKeywords: ["indie", "discovery", "alternative", "rock", "folk"],
  },
  {
    id: "cosmic-vibes",
    name: "Cosmic Vibes",
    description: "Ambient cosmic soundscapes from the universe.",
    gradient: "from-indigo-600 via-indigo-700 to-blue-900",
    icon: <Star size={28} className="text-white/90" />,
    genreFilters: ["Ambient", "Space", "Electronic", "Cosmic", "Synth"],
    fallbackKeywords: ["cosmic", "space", "ambient", "drift", "synth"],
  },
];

/* ------------------------------------------------------------------ */
/*  DJ Commentary templates (8+)                                       */
/* ------------------------------------------------------------------ */
const DJ_TEMPLATES = [
  (s: string, t: string, a: string) =>
    `Welcome to ${s}! Let's kick things off with "${t}" by ${a}...`,
  (s: string, t: string, a: string) =>
    `That was "${t}" by ${a}. Up next, we've got something special for you...`,
  (s: string, t: string, a: string) =>
    `You're listening to ${s}. Here's "${t}" to keep the vibes going...`,
  (s: string, t: string, a: string) =>
    `Before we continue, did you know ${a} is one of your top artists? Let's hear more from them with "${t}"...`,
  (s: string, t: string, a: string) =>
    `This next one is a real gem — "${t}" by ${a}. Let it wash over you...`,
  (s: string, t: string, a: string) =>
    `We're deep in the groove now on ${s}. Coming up is "${t}" by ${a} — turn it up!`,
  (s: string, t: string, a: string) =>
    `Sometimes the perfect track finds you. Like "${t}" by ${a} — here it is, just for you...`,
  (s: string, t: string, a: string) =>
    `You've been great listeners on ${s}. Let's keep the energy alive with "${t}" by ${a}...`,
  (s: string, t: string, a: string) =>
    `And we're back on ${s}! This next one is close to my heart — "${t}" by ${a}...`,
  (s: string, t: string, a: string) =>
    `That last track was a vibe, right? Let's keep the momentum going with "${t}" by ${a}...`,
];

/* ------------------------------------------------------------------ */
/*  Helpers                                                            */
/* ------------------------------------------------------------------ */
function formatDuration(seconds: number | null): string {
  if (seconds == null) return "--:--";
  const m = Math.floor(seconds / 60);
  const s = Math.floor(seconds % 60);
  return `${m}:${String(s).padStart(2, "0")}`;
}

function shuffleArray<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

/* ------------------------------------------------------------------ */
/*  Component                                                          */
/* ------------------------------------------------------------------ */
export function RadioStationView({
  allTracks,
  history,
  likedTrackIds,
  currentTrackId,
  isPlaying,
  onPlayAll,
  onSelectTrack,
  onToggleLike,
  onSelectArtist,
}: Props) {
  const [selectedStationId, setSelectedStationId] = useState<string | null>(null);
  const [djCommentaryIndex, setDjCommentaryIndex] = useState(0);
  const [commentaryTrackId, setCommentaryTrackId] = useState<string | null>(null);

  const selectedStation = STATIONS.find((s) => s.id === selectedStationId) ?? null;

  // Derive user profile from history
  const userProfile = useMemo(() => {
    const genreCounts = new Map<string, number>();
    const artistCounts = new Map<string, number>();

    for (const h of history) {
      if (h.track.genre) genreCounts.set(h.track.genre, (genreCounts.get(h.track.genre) ?? 0) + 1);
      for (const a of h.track.artists) artistCounts.set(a, (artistCounts.get(a) ?? 0) + 1);
    }

    return {
      topGenres: Array.from(genreCounts.entries())
        .sort((a, b) => b[1] - a[1])
        .slice(0, 5)
        .map(([g]) => g),
      topArtists: Array.from(artistCounts.entries())
        .sort((a, b) => b[1] - a[1])
        .slice(0, 5)
        .map(([a]) => a),
    };
  }, [history]);

  // Filter tracks for the selected station
  const stationTracks = useMemo(() => {
    if (!selectedStation) return [];
    const { genreFilters, fallbackKeywords } = selectedStation;

    // Primary: match genre
    const genreMatched = allTracks.filter((t) =>
      genreFilters.some(
        (g) => t.genre?.toLowerCase().includes(g.toLowerCase())
      )
    );

    // Secondary: match title/album/artist keywords
    const keywordMatched = allTracks.filter((t) => {
      if (genreMatched.some((gm) => gm.id === t.id)) return false;
      const haystack = `${t.title} ${t.album} ${t.artists.join(" ")}`.toLowerCase();
      return fallbackKeywords.some((kw) => haystack.includes(kw));
    });

    // Fallback: include all tracks shuffled
    const rest = allTracks.filter(
      (t) => !genreMatched.some((gm) => gm.id === t.id) && !keywordMatched.some((km) => km.id === t.id)
    );

    return shuffleArray([...genreMatched, ...keywordMatched, ...rest]);
  }, [selectedStation, allTracks]);

  // Total duration
  const totalDuration = stationTracks.reduce((sum, t) => sum + (t.duration ?? 0), 0);
  const totalMinutes = Math.floor(totalDuration / 60);

  // DJ commentary — auto-rotate when current track changes
  useEffect(() => {
    if (currentTrackId && currentTrackId !== commentaryTrackId) {
      queueMicrotask(() => {
        setCommentaryTrackId(currentTrackId);
        setDjCommentaryIndex((prev) => (prev + 1) % DJ_TEMPLATES.length);
      });
    }
  }, [currentTrackId, commentaryTrackId]);

  // Current DJ commentary text
  const djCommentary = useMemo(() => {
    const currentTrack = stationTracks.find((t) => t.id === currentTrackId);
    if (!currentTrack || !selectedStation) return null;
    const template = DJ_TEMPLATES[djCommentaryIndex % DJ_TEMPLATES.length];
    return template(selectedStation.name, currentTrack.title, currentTrack.artists.join(", "));
  }, [selectedStation, stationTracks, currentTrackId, djCommentaryIndex]);

  // Up-next tracks (next 2 after current)
  const upNext = useMemo(() => {
    if (!currentTrackId) return stationTracks.slice(1, 3);
    const idx = stationTracks.findIndex((t) => t.id === currentTrackId);
    if (idx < 0) return stationTracks.slice(1, 3);
    return stationTracks.slice(idx + 1, idx + 3);
  }, [stationTracks, currentTrackId]);

  // Handle station selection
  const handleSelectStation = useCallback(
    (station: StationDef) => {
      setSelectedStationId(station.id);
      setDjCommentaryIndex(0);
      setCommentaryTrackId(null);
    },
    []
  );

  // Handle play all for station
  const handlePlayStation = useCallback(() => {
    if (stationTracks.length > 0) {
      onPlayAll(stationTracks);
    }
  }, [stationTracks, onPlayAll]);

  return (
    <div className="bl-scroll flex-1 bl-view-transition">
      {/* ── Hero header ── */}
      <div className="relative overflow-hidden px-6 pt-10 pb-4">
        <div className="pointer-events-none absolute inset-0 -z-10 opacity-50">
          <div className="absolute -left-20 -top-20 h-72 w-72 rounded-full bg-gradient-to-br from-emerald-500/20 to-transparent blur-3xl" />
          <div className="absolute -right-10 top-10 h-56 w-56 rounded-full bg-gradient-to-bl from-violet-500/15 to-transparent blur-3xl" />
        </div>

        <div className="flex items-end gap-6">
          {/* Radio icon cover */}
          <div className="relative flex h-44 w-44 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br from-emerald-600 via-teal-700 to-cyan-900 shadow-2xl">
            <Radio size={64} className="text-white/90" />
            <div className="absolute inset-0 rounded-2xl bg-gradient-to-t from-black/30 to-transparent" />
            {/* Animated radio wave overlay */}
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="bl-radio-wave text-white/30" />
            </div>
          </div>

          <div className="flex-1 pb-2">
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-white/70">
              <Radio size={12} />
              <span>Live Radio</span>
            </div>
            <h1 className="mt-2 text-5xl font-extrabold tracking-tight text-white bl-gradient-text">
              Radio Stations
            </h1>
            <p className="mt-3 max-w-xl text-sm text-white/70">
              Tune in to curated stations with live DJ commentary. Pick a vibe, sit back, and let the
              music flow — your personal DJ takes care of the rest.
            </p>
            <div className="mt-3 flex items-center gap-3 text-xs text-white/60">
              <span className="flex items-center gap-1">
                <Music2 size={12} />
                {STATIONS.length} stations
              </span>
              <span className="flex items-center gap-1">
                <Clock size={12} />
                {allTracks.length} tracks available
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* ── Station selection grid ── */}
      <section className="bl-section-in px-6 pb-6">
        <h2 className="mb-4 text-lg font-bold text-white">Choose Your Station</h2>
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
          {STATIONS.map((station) => {
            const isSelected = selectedStationId === station.id;
            return (
              <button
                key={station.id}
                onClick={() => handleSelectStation(station)}
                className={`bl-station-card bg-gradient-to-br ${station.gradient} text-left ${
                  isSelected ? "selected" : ""
                }`}
                aria-label={`Select ${station.name} station`}
              >
                <div className="mb-3 flex h-12 w-12 items-center justify-center rounded-xl bg-white/10">
                  {station.icon}
                </div>
                <h3 className="text-sm font-bold text-white">{station.name}</h3>
                <p className="mt-1 line-clamp-2 text-[10px] text-white/60 leading-relaxed">
                  {station.description}
                </p>
                {isSelected && (
                  <div className="mt-2 flex items-center gap-1 text-[10px] text-emerald-300">
                    <div className="bl-live-dot" />
                    <span className="font-semibold">TUNED IN</span>
                  </div>
                )}
              </button>
            );
          })}
        </div>
      </section>

      {/* ── Station content (only when a station is selected) ── */}
      {selectedStation && (
        <div className="bl-section-in px-6 pb-10">
          {/* Now Playing indicator */}
          <div className="mb-6 rounded-xl border border-white/5 bg-gradient-to-r from-white/5 to-transparent p-5">
            <div className="flex items-center gap-3">
              {/* LIVE badge */}
              <div className="flex items-center gap-2 rounded-full bg-red-500/10 px-3 py-1.5">
                <div className="bl-live-dot" />
                <span className="text-xs font-bold text-red-400 tracking-wider">LIVE</span>
              </div>

              {/* Station name */}
              <span className="text-sm font-semibold text-white/80">
                {selectedStation.name}
              </span>

              {/* Equalizer bars */}
              {isPlaying && currentTrackId && (
                <div className="bl-radio-playing ml-1">
                  <span style={{ animationDelay: "0ms" }} />
                  <span style={{ animationDelay: "150ms" }} />
                  <span style={{ animationDelay: "300ms" }} />
                  <span style={{ animationDelay: "450ms" }} />
                </div>
              )}

              {/* Play button */}
              <button
                onClick={handlePlayStation}
                className="ml-auto flex h-10 w-10 items-center justify-center rounded-full bg-emerald-500 text-black shadow-lg shadow-emerald-500/30 transition-all hover:scale-105 hover:bg-emerald-400"
                aria-label="Play station"
              >
                <Play size={18} fill="currentColor" />
              </button>
            </div>

            {/* Current track info */}
            {currentTrackId && (() => {
              const ct = stationTracks.find((t) => t.id === currentTrackId);
              if (!ct) return null;
              return (
                <div className="mt-4 flex items-center gap-4">
                  {ct.coverUrl ? (
                    <img
                      src={ct.coverUrl}
                      alt=""
                      className="h-14 w-14 rounded-lg object-cover shadow-lg"
                    />
                  ) : (
                    <div className="flex h-14 w-14 items-center justify-center rounded-lg bg-gradient-to-br from-emerald-500/40 to-teal-700/40">
                      <Music2 size={18} className="text-white/60" />
                    </div>
                  )}
                  <div className="min-w-0 flex-1">
                    <div className="truncate text-base font-bold text-white">{ct.title}</div>
                    <span
                      role="button"
                      tabIndex={0}
                      onClick={() => ct.artists[0] && onSelectArtist(ct.artists[0])}
                      onKeyDown={(e) => {
                        if (e.key === "Enter") ct.artists[0] && onSelectArtist(ct.artists[0]);
                      }}
                      className="block truncate text-sm text-[var(--sp-text-subdued)] hover:text-white hover:underline cursor-pointer"
                    >
                      {ct.artists.join(", ")}
                    </span>
                  </div>
                  <SkipForward size={18} className="text-white/40" />
                </div>
              );
            })()}

            {/* Up Next preview */}
            {upNext.length > 0 && (
              <div className="mt-4 border-t border-white/5 pt-3">
                <div className="mb-2 text-[10px] font-bold uppercase tracking-wider text-white/50">
                  Up Next
                </div>
                <div className="flex flex-col gap-2">
                  {upNext.map((track) => (
                    <div key={track.id} className="flex items-center gap-3">
                      {track.coverUrl ? (
                        <img
                          src={track.coverUrl}
                          alt=""
                          className="h-8 w-8 rounded object-cover"
                        />
                      ) : (
                        <div className="flex h-8 w-8 items-center justify-center rounded bg-white/5">
                          <Music2 size={12} className="text-white/40" />
                        </div>
                      )}
                      <div className="min-w-0 flex-1">
                        <div className="truncate text-xs font-medium text-white/80">
                          {track.title}
                        </div>
                        <div className="truncate text-[10px] text-white/50">
                          {track.artists.join(", ")}
                        </div>
                      </div>
                      <span className="text-[10px] text-white/40">
                        {formatDuration(track.duration)}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* DJ Commentary bubble */}
          {djCommentary && (
            <div className="mb-6 bl-section-in">
              <div className="bl-dj-bubble">
                <div className="flex items-start gap-3">
                  {/* DJ avatar */}
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-emerald-500 to-teal-700 shadow-lg">
                    <Mic2 size={16} className="text-white" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-emerald-400">
                        {selectedStation.name} DJ
                      </span>
                      <span className="text-[10px] text-white/40">• Live</span>
                    </div>
                    <p className="mt-1 text-sm text-white/80 leading-relaxed">{djCommentary}</p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Track Queue */}
          <div className="mb-6">
            <h2 className="mb-3 flex items-center gap-2 text-lg font-bold text-white">
              <ChevronRight size={16} className="text-emerald-400" />
              Station Queue
            </h2>
            <div className="max-h-96 overflow-y-auto bl-scroll rounded-xl border border-white/5 bg-white/[0.02]">
              {/* Header row */}
              <div className="grid grid-cols-[16px_4fr_2fr_1fr_60px_50px] items-center gap-3 border-b border-white/5 px-4 py-2 text-[10px] font-bold uppercase tracking-wider text-[var(--sp-text-subdued)] sticky top-0 bg-[var(--sp-base-2)]/90 backdrop-blur-sm z-10">
                <span>#</span>
                <span>Title</span>
                <span>Artist</span>
                <span>Genre</span>
                <span className="text-right">
                  <Clock size={12} className="inline" />
                </span>
                <span />
              </div>

              {/* Track rows */}
              {stationTracks.map((track, i) => {
                const isCurrent = currentTrackId === track.id;
                const isCurrentPlaying = isCurrent && isPlaying;
                const isLiked = likedTrackIds.includes(track.id);

                return (
                  <div
                    key={track.id}
                    onClick={() => onSelectTrack(track, i, stationTracks)}
                    className={`bl-track-row group grid grid-cols-[16px_4fr_2fr_1fr_60px_50px] items-center gap-3 px-4 py-2.5 cursor-pointer ${
                      isCurrent ? "active" : ""
                    }`}
                  >
                    {/* Index / EQ */}
                    <div className="flex h-4 w-4 items-center justify-center text-xs text-[var(--sp-text-subdued)]">
                      {isCurrentPlaying ? (
                        <div className="bl-radio-playing">
                          <span style={{ animationDelay: "0ms" }} />
                          <span style={{ animationDelay: "150ms" }} />
                          <span style={{ animationDelay: "300ms" }} />
                        </div>
                      ) : (
                        <>
                          <span className="group-hover:hidden">{i + 1}</span>
                          <Play
                            size={10}
                            fill="currentColor"
                            className="hidden group-hover:block text-white"
                          />
                        </>
                      )}
                    </div>

                    {/* Title + cover */}
                    <div className="flex min-w-0 items-center gap-3">
                      {track.coverUrl ? (
                        <img
                          src={track.coverUrl}
                          alt=""
                          className="h-9 w-9 rounded object-cover"
                        />
                      ) : (
                        <div className="flex h-9 w-9 items-center justify-center rounded bg-gradient-to-br from-emerald-500/40 to-teal-700/40">
                          <Music2 size={12} className="text-white/60" />
                        </div>
                      )}
                      <span
                        className={`truncate text-sm font-medium ${
                          isCurrent ? "text-emerald-400" : "text-white"
                        }`}
                      >
                        {track.title}
                      </span>
                    </div>

                    {/* Artist */}
                    <span
                      role="button"
                      tabIndex={0}
                      onClick={(e) => {
                        e.stopPropagation();
                        track.artists[0] && onSelectArtist(track.artists[0]);
                      }}
                      onKeyDown={(e) => {
                        if (e.key === "Enter") {
                          track.artists[0] && onSelectArtist(track.artists[0]);
                        }
                      }}
                      className="truncate text-xs text-[var(--sp-text-subdued)] hover:text-white hover:underline cursor-pointer"
                    >
                      {track.artists.join(", ")}
                    </span>

                    {/* Genre */}
                    <span className="truncate text-xs text-[var(--sp-text-subdued)]">
                      {track.genre}
                    </span>

                    {/* Duration */}
                    <span className="text-right text-xs text-[var(--sp-text-subdued)]">
                      {formatDuration(track.duration)}
                    </span>

                    {/* Like */}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onToggleLike(track.id);
                      }}
                      className={`flex items-center justify-center transition-colors ${
                        isLiked
                          ? "text-rose-400"
                          : "text-white/20 hover:text-white/60"
                      }`}
                      aria-label={isLiked ? "Unlike" : "Like"}
                    >
                      <Heart size={14} fill={isLiked ? "currentColor" : "none"} />
                    </button>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Station Info Panel */}
          <div className="bl-glass rounded-xl p-6">
            <div className="flex items-start gap-4">
              <div
                className={`flex h-14 w-14 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br ${selectedStation.gradient} shadow-lg`}
              >
                {selectedStation.icon}
              </div>
              <div className="flex-1">
                <h3 className="text-base font-bold text-white">{selectedStation.name}</h3>
                <p className="mt-1 text-sm text-[var(--sp-text-subdued)] leading-relaxed">
                  {selectedStation.description}
                </p>
                <div className="mt-3 flex flex-wrap items-center gap-4 text-xs text-white/60">
                  <span className="flex items-center gap-1">
                    <Music2 size={12} />
                    {stationTracks.length} tracks
                  </span>
                  <span className="flex items-center gap-1">
                    <Clock size={12} />
                    {totalMinutes} min
                  </span>
                </div>
                <div className="mt-4 rounded-lg border border-white/5 bg-white/[0.03] p-3">
                  <div className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-wider text-emerald-400/80">
                    <User size={10} />
                    <span>Based on your listening history</span>
                  </div>
                  {userProfile.topGenres.length > 0 && (
                    <p className="mt-2 text-xs text-white/60">
                      <span className="font-semibold text-white/80">Detected genres:</span>{" "}
                      {userProfile.topGenres.join(", ")}
                    </p>
                  )}
                  {userProfile.topArtists.length > 0 && (
                    <p className="mt-1 text-xs text-white/60">
                      <span className="font-semibold text-white/80">Top artists:</span>{" "}
                      {userProfile.topArtists.join(", ")}
                    </p>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* No station selected state */}
      {!selectedStation && (
        <div className="bl-section-in flex flex-col items-center justify-center px-6 pb-20 pt-10">
          <div className="flex h-20 w-20 items-center justify-center rounded-full bg-gradient-to-br from-emerald-500/20 to-teal-700/20">
            <Radio size={36} className="text-emerald-400/60" />
          </div>
          <p className="mt-4 text-sm text-white/50">
            Select a station above to start listening
          </p>
        </div>
      )}
    </div>
  );
}
