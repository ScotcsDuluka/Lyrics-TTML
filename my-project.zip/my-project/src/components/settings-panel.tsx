"use client";
import { useState } from "react";
import {
  X, Settings, Sliders, Volume2, VolumeX, Waves, Gauge, Zap, Moon,
  Music2, Headphones, Activity, Crown, Sparkles, RotateCcw
} from "lucide-react";
import { useAppStore } from "@/lib/store";
import { toast } from "sonner";

interface Props {
  isOpen: boolean;
  onClose: () => void;
  onOpenSleepTimer: () => void;
  onOpenEqualizer: () => void;
  onOpenRecap: () => void;
}

export function SettingsPanel({ isOpen, onClose, onOpenSleepTimer, onOpenEqualizer, onOpenRecap }: Props) {
  const volume = useAppStore(s => s.volume);
  const setVolume = useAppStore(s => s.setVolume);
  const muted = useAppStore(s => s.muted);
  const setMuted = useAppStore(s => s.setMuted);
  const crossfadeDuration = useAppStore(s => s.crossfadeDuration);
  const setCrossfadeDuration = useAppStore(s => s.setCrossfadeDuration);
  const normalizeVolume = useAppStore(s => s.normalizeVolume);
  const setNormalizeVolume = useAppStore(s => s.setNormalizeVolume);
  const playbackRate = useAppStore(s => s.playbackRate);
  const setPlaybackRate = useAppStore(s => s.setPlaybackRate);
  const eqPreset = useAppStore(s => s.eqPreset);

  const [audioQuality, setAudioQuality] = useState<"low" | "normal" | "high">("high");
  const [monoAudio, setMonoAudio] = useState(false);
  const [gapless, setGapless] = useState(true);
  const [autoplay, setAutoplay] = useState(true);
  const [showFriendActivity, setShowFriendActivity] = useState(useAppStore.getState().showFriendActivity);

  if (!isOpen) return null;

  const handleReset = () => {
    setVolume(0.7);
    setMuted(false);
    setCrossfadeDuration(0);
    setNormalizeVolume(false);
    setPlaybackRate(1);
    setMonoAudio(false);
    setGapless(true);
    setAutoplay(true);
    setAudioQuality("high");
    toast.success("Settings reset to defaults");
  };

  return (
    <div
      className="fixed inset-0 z-[200] flex items-center justify-center bg-black/70 backdrop-blur-sm bl-fade-in"
      onClick={onClose}
    >
      <div
        className="relative w-[560px] max-w-[92vw] max-h-[88vh] overflow-hidden overflow-y-auto rounded-2xl border border-white/15 bg-gradient-to-b from-[#1a1a1a] to-[#0a0a0a] shadow-2xl bl-scale-in"
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="sticky top-0 z-10 relative overflow-hidden border-b border-white/10 bg-gradient-to-br from-emerald-900/40 via-[#1a1a1a] to-[#0a0a0a] px-6 pb-4 pt-6">
          <div className="absolute -right-12 -top-12 h-40 w-40 rounded-full bg-emerald-500/15 blur-3xl" />
          <div className="absolute -left-12 -top-12 h-40 w-40 rounded-full bg-teal-500/10 blur-3xl" />
          <div className="relative flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-br from-emerald-500 to-teal-700 shadow-lg shadow-emerald-500/30">
                <Settings size={18} className="text-white" />
              </div>
              <div>
                <h2 className="text-lg font-bold text-white">Settings</h2>
                <p className="text-xs text-[var(--sp-text-subdued)]">Audio, playback & preferences</p>
              </div>
            </div>
            <button onClick={onClose} className="rounded-full p-1.5 text-white/60 hover:bg-white/10 hover:text-white">
              <X size={18} />
            </button>
          </div>
        </div>

        <div className="px-6 py-5 space-y-5">
          {/* Playback section */}
          <Section title="Playback" icon={<Activity size={14} className="text-emerald-400" />}>
            {/* Crossfade */}
            <Row
              label="Crossfade"
              hint="Smooth transitions between tracks"
              icon={<Waves size={14} className="text-cyan-400" />}
              control={
                <div className="flex items-center gap-3 w-48">
                  <input
                    type="range"
                    min={0}
                    max={12}
                    step={1}
                    value={crossfadeDuration}
                    onChange={e => setCrossfadeDuration(parseInt(e.target.value))}
                    className="bl-slider flex-1"
                  />
                  <span className="w-12 text-right text-xs font-bold tabular-nums text-white">
                    {crossfadeDuration === 0 ? "Off" : `${crossfadeDuration}s`}
                  </span>
                </div>
              }
            />

            {/* Gapless playback */}
            <Row
              label="Gapless playback"
              hint="Remove silence between tracks"
              icon={<Music2 size={14} className="text-emerald-400" />}
              control={<Toggle checked={gapless} onChange={setGapless} />}
            />

            {/* Autoplay */}
            <Row
              label="Autoplay"
              hint="Continue with similar tracks when queue ends"
              icon={<Sparkles size={14} className="text-purple-400" />}
              control={<Toggle checked={autoplay} onChange={setAutoplay} />}
            />

            {/* Playback speed */}
            <Row
              label="Playback speed"
              hint="Adjust audio playback rate"
              icon={<Gauge size={14} className="text-amber-400" />}
              control={
                <div className="flex items-center gap-1">
                  {[0.75, 1, 1.25, 1.5, 2].map(r => (
                    <button
                      key={r}
                      onClick={() => { setPlaybackRate(r); toast.success(`Speed: ${r}×`); }}
                      className={`rounded-md px-2 py-1 text-xs font-bold transition-colors ${
                        playbackRate === r
                          ? "bg-emerald-500 text-white"
                          : "bg-white/5 text-[var(--sp-text-subdued)] hover:bg-white/10 hover:text-white"
                      }`}
                    >
                      {r}×
                    </button>
                  ))}
                </div>
              }
            />
          </Section>

          {/* Audio section */}
          <Section title="Audio" icon={<Headphones size={14} className="text-fuchsia-400" />}>
            {/* Volume */}
            <Row
              label="Volume"
              hint="Master volume level"
              icon={muted ? <VolumeX size={14} className="text-rose-400" /> : <Volume2 size={14} className="text-emerald-400" />}
              control={
                <div className="flex items-center gap-2 w-48">
                  <button
                    onClick={() => setMuted(!muted)}
                    className="rounded-full p-1.5 text-white/70 hover:bg-white/10 hover:text-white"
                    aria-label={muted ? "Unmute" : "Mute"}
                  >
                    {muted ? <VolumeX size={14} /> : <Volume2 size={14} />}
                  </button>
                  <input
                    type="range"
                    min={0}
                    max={1}
                    step={0.01}
                    value={muted ? 0 : volume}
                    onChange={e => { const v = parseFloat(e.target.value); setVolume(v); setMuted(v === 0); }}
                    className="bl-slider flex-1"
                  />
                  <span className="w-10 text-right text-xs font-bold tabular-nums text-white">
                    {Math.round((muted ? 0 : volume) * 100)}%
                  </span>
                </div>
              }
            />

            {/* Normalize volume */}
            <Row
              label="Normalize volume"
              hint="Set the same loudness level for all tracks"
              icon={<Zap size={14} className="text-amber-400" />}
              control={<Toggle checked={normalizeVolume} onChange={(v) => { setNormalizeVolume(v); toast.success(v ? "Volume normalization on" : "Volume normalization off"); }} />}
            />

            {/* Mono audio */}
            <Row
              label="Mono audio"
              hint="Combine stereo channels into one"
              icon={<Activity size={14} className="text-cyan-400" />}
              control={<Toggle checked={monoAudio} onChange={setMonoAudio} />}
            />

            {/* Audio quality */}
            <Row
              label="Audio quality"
              hint="Streaming quality (when available)"
              icon={<Crown size={14} className="text-amber-300" />}
              control={
                <div className="flex items-center gap-1">
                  {(["low", "normal", "high"] as const).map(q => (
                    <button
                      key={q}
                      onClick={() => setAudioQuality(q)}
                      className={`rounded-md px-2.5 py-1 text-xs font-bold capitalize transition-colors ${
                        audioQuality === q
                          ? "bg-fuchsia-500 text-white"
                          : "bg-white/5 text-[var(--sp-text-subdued)] hover:bg-white/10 hover:text-white"
                      }`}
                    >
                      {q}
                    </button>
                  ))}
                </div>
              }
            />

            {/* EQ preset display */}
            <Row
              label="Equalizer"
              hint={`Active preset: ${eqPreset}`}
              icon={<Sliders size={14} className="text-fuchsia-400" />}
              control={
                <button
                  onClick={() => { onClose(); onOpenEqualizer(); }}
                  className="rounded-full bg-white/10 px-3 py-1.5 text-xs font-bold text-white hover:bg-white/20"
                >
                  Open EQ
                </button>
              }
            />
          </Section>

          {/* Quick actions */}
          <Section title="Quick Actions" icon={<Sparkles size={14} className="text-purple-400" />}>
            <div className="grid grid-cols-2 gap-2">
              <QuickAction
                icon={<Moon size={16} className="text-indigo-300" />}
                label="Sleep Timer"
                description="Auto-pause playback"
                onClick={() => { onClose(); onOpenSleepTimer(); }}
              />
              <QuickAction
                icon={<Crown size={16} className="text-amber-300" />}
                label="Yearly Recap"
                description="Your year in music"
                onClick={() => { onClose(); onOpenRecap(); }}
              />
              <QuickAction
                icon={<Sliders size={16} className="text-fuchsia-400" />}
                label="Equalizer"
                description="Tune audio frequencies"
                onClick={() => { onClose(); onOpenEqualizer(); }}
              />
              <QuickAction
                icon={<Headphones size={16} className="text-emerald-300" />}
                label="Friend Activity"
                description={showFriendActivity ? "Currently visible" : "Currently hidden"}
                onClick={() => {
                  const next = !showFriendActivity;
                  setShowFriendActivity(next);
                  useAppStore.getState().setShowFriendActivity(next);
                  toast.success(next ? "Friend Activity shown" : "Friend Activity hidden");
                }}
              />
            </div>
          </Section>

          {/* About */}
          <div className="rounded-xl border border-white/5 bg-white/[0.02] p-4">
            <div className="flex items-center gap-2 text-xs text-[var(--sp-text-subdued)]">
              <Music2 size={12} />
              <span className="font-semibold uppercase tracking-wider">About</span>
            </div>
            <p className="mt-2 text-xs text-[var(--sp-text-subdued)] leading-relaxed">
              Run Poll is a Spotify-style music player built with Next.js, Web Audio API, and Prisma.
              Settings persist across sessions in your browser. Audio is processed locally with 10-band parametric EQ via BiquadFilters.
            </p>
          </div>

          {/* Footer actions */}
          <div className="flex items-center justify-between border-t border-white/10 pt-4">
            <button
              onClick={handleReset}
              className="inline-flex items-center gap-1.5 rounded-full bg-white/5 px-3 py-1.5 text-xs font-bold text-[var(--sp-text-subdued)] transition-colors hover:bg-white/10 hover:text-white"
            >
              <RotateCcw size={12} />
              Reset to defaults
            </button>
            <button
              onClick={onClose}
              className="rounded-full bg-emerald-500 px-5 py-2 text-xs font-bold text-white shadow-lg shadow-emerald-500/30 transition-all hover:bg-emerald-400"
            >
              Done
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function Section({ title, icon, children }: { title: string; icon: React.ReactNode; children: React.ReactNode }) {
  return (
    <div>
      <div className="mb-2 flex items-center gap-1.5">
        {icon}
        <span className="text-xs font-bold uppercase tracking-wider text-white/70">{title}</span>
      </div>
      <div className="space-y-1 rounded-xl border border-white/5 bg-white/[0.02] p-2">
        {children}
      </div>
    </div>
  );
}

function Row({
  label, hint, icon, control
}: {
  label: string;
  hint: string;
  icon: React.ReactNode;
  control: React.ReactNode;
}) {
  return (
    <div className="flex items-center gap-3 rounded-lg px-2 py-2 hover:bg-white/[0.02]">
      <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-md bg-white/5">
        {icon}
      </div>
      <div className="flex-1 min-w-0">
        <div className="text-sm font-semibold text-white">{label}</div>
        <div className="text-[10px] text-[var(--sp-text-subdued)] truncate">{hint}</div>
      </div>
      <div className="shrink-0">{control}</div>
    </div>
  );
}

function Toggle({ checked, onChange }: { checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      onClick={() => onChange(!checked)}
      role="switch"
      aria-checked={checked}
      className={`relative inline-flex h-5 w-9 shrink-0 items-center rounded-full transition-colors ${
        checked ? "bg-emerald-500" : "bg-white/15"
      }`}
    >
      <span
        className={`inline-block h-4 w-4 transform rounded-full bg-white shadow transition-transform ${
          checked ? "translate-x-4" : "translate-x-0.5"
        }`}
      />
    </button>
  );
}

function QuickAction({
  icon, label, description, onClick
}: {
  icon: React.ReactNode;
  label: string;
  description: string;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className="group flex items-start gap-3 rounded-xl border border-white/5 bg-white/[0.02] p-3 text-left transition-all hover:border-white/15 hover:bg-white/[0.06]"
    >
      <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-white/5 group-hover:bg-white/10">
        {icon}
      </div>
      <div className="min-w-0">
        <div className="text-xs font-bold text-white">{label}</div>
        <div className="text-[10px] text-[var(--sp-text-subdued)] truncate">{description}</div>
      </div>
    </button>
  );
}
