"use client";
import { useState } from "react";
import { Home, Search, Library, Plus, Heart, Clock, ListMusic, Music2, History, User, Upload, Disc3, BarChart3, Sparkles, Users, Radio, Star, Podcast, Sliders, Award, Play, Pause, RadioTower } from "lucide-react";
import type { Playlist, Track } from "@/lib/types";
import { useAppStore } from "@/lib/store";
import { TrackUpload } from "./track-upload";

interface Artist {
  name: string;
  coverUrl: string | null;
  trackCount: number;
}

interface Props {
  playlists: Playlist[];
  likedTrackCount: number;
  artists: Artist[];
  albums: { name: string; coverUrl: string | null; trackCount: number }[];
  currentTrack: Track | null;
  isPlaying: boolean;
  pollActive: boolean;
  onSelectPlaylist: (id: string) => void;
  onCreatePlaylist: () => void;
  onGoHome: () => void;
  onGoSearch: () => void;
  onGoLiked: () => void;
  onGoHistory: () => void;
  onGoStats: () => void;
  onGoDiscover: () => void;
  onGoRadio: () => void;
  onGoPersonality: () => void;
  onGoPodcasts: () => void;
  onGoEqualizer: () => void;
  onGoRecap: () => void;
  onSelectArtist: (name: string) => void;
  onSelectAlbum: (name: string) => void;
  onUploadComplete: () => void;
  onToggleFriendActivity: () => void;
  friendActivityActive: boolean;
}

export function Sidebar({ playlists, likedTrackCount, artists, albums, currentTrack, isPlaying, pollActive, onSelectPlaylist, onCreatePlaylist, onGoHome, onGoSearch, onGoLiked, onGoHistory, onGoStats, onGoDiscover, onGoRadio, onGoPersonality, onGoPodcasts, onGoEqualizer, onGoRecap, onSelectArtist, onSelectAlbum, onUploadComplete, onToggleFriendActivity, friendActivityActive }: Props) {
  const view = useAppStore(s => s.view);
  const activePlaylistId = view.type === "playlist" ? view.id : null;
  const [activeFilter, setActiveFilter] = useState<"playlists" | "artists" | "albums">("playlists");

  return (
    <div className="bl-sidebar">
      {/* Now Playing mini section */}
      {currentTrack && (
        <div className="bl-bg-elevated rounded-lg p-3">
          <div className="flex items-center gap-3">
            <div className="relative h-10 w-10 shrink-0 overflow-hidden rounded">
              {currentTrack.coverUrl ? (
                <img src={currentTrack.coverUrl} alt="" className="h-full w-full object-cover" />
              ) : (
                <div className="h-full w-full bg-white/10" />
              )}
              {isPlaying && (
                <div className="absolute inset-0 flex items-center justify-center bg-black/40">
                  <div className="flex items-end gap-[2px] h-4">
                    <span className="bl-bar-anim w-[3px] bg-emerald-400 rounded-full" style={{ animationDelay: "0ms" }} />
                    <span className="bl-bar-anim w-[3px] bg-emerald-400 rounded-full" style={{ animationDelay: "150ms" }} />
                    <span className="bl-bar-anim w-[3px] bg-emerald-400 rounded-full" style={{ animationDelay: "300ms" }} />
                  </div>
                </div>
              )}
            </div>
            <div className="min-w-0 flex-1">
              <div className="truncate text-xs font-medium text-white">{currentTrack.title}</div>
              <div className="truncate text-[10px] text-[var(--sp-text-subdued)]">{currentTrack.artists.join(", ")}</div>
            </div>
          </div>
          {/* Poll indicator */}
          {pollActive && (
            <div className="mt-2 flex items-center gap-1.5 rounded-full bg-emerald-500/10 px-2 py-1">
              <span className="relative flex h-2 w-2">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75" />
                <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-400" />
              </span>
              <RadioTower size={10} className="text-emerald-400" />
              <span className="text-[10px] font-medium text-emerald-400">Poll Active</span>
            </div>
          )}
        </div>
      )}

      {/* Top nav */}
      <nav className="bl-bg-elevated rounded-lg p-2">
        <NavButton icon={<Home size={24} />} label="Home" active={view.type === "home"} onClick={onGoHome} />
        <NavButton icon={<Search size={24} />} label="Search" active={view.type === "search"} onClick={onGoSearch} />
        <NavButton icon={<History size={24} />} label="History" active={view.type === "history"} onClick={onGoHistory} />
        <NavButton icon={<BarChart3 size={24} />} label="Your Stats" active={view.type === "stats"} onClick={onGoStats} />
        <NavButton icon={<Sparkles size={24} />} label="Discover" active={view.type === "discover"} onClick={onGoDiscover} />
        <NavButton icon={<Radio size={24} />} label="Radio" active={view.type === "radio"} onClick={onGoRadio} />
        <NavButton icon={<Star size={24} />} label="Music DNA" active={view.type === "personality"} onClick={onGoPersonality} />
        <NavButton icon={<Podcast size={24} />} label="Podcasts" active={view.type === "podcasts"} onClick={onGoPodcasts} />
        <NavButton icon={<Sliders size={24} />} label="Equalizer" active={view.type === "equalizer"} onClick={onGoEqualizer} />
        <NavButton icon={<Award size={24} />} label="Yearly Recap" active={view.type === "recap"} onClick={onGoRecap} />
        <NavButton
          icon={<Users size={24} />}
          label="Friends"
          active={friendActivityActive}
          onClick={onToggleFriendActivity}
        />
      </nav>

      {/* Library */}
      <div className="bl-bg-elevated rounded-lg flex flex-col min-h-0 overflow-hidden">
        {/* Library header */}
        <div className="flex items-center justify-between px-4 py-3">
          <button className="flex items-center gap-3 text-[var(--sp-text-subdued)] hover:text-white transition-colors">
            <Library size={22} />
            <span className="text-sm font-bold">Your Library</span>
          </button>
          <div className="flex items-center gap-1">
            <TrackUpload onUploadComplete={onUploadComplete} />
            <button
              onClick={onCreatePlaylist}
              className="rounded-full p-2 text-[var(--sp-text-subdued)] hover:bg-white/10 hover:text-white transition-colors"
              title="Create playlist"
            >
              <Plus size={18} />
            </button>
          </div>
        </div>

        {/* Filter chips */}
        <div className="flex gap-2 px-3 pb-2">
          <button
            onClick={() => setActiveFilter("playlists")}
            className={`rounded-full px-3 py-1 text-xs font-medium transition-colors ${
              activeFilter === "playlists" ? "bg-white/10 text-white" : "bg-white/5 text-[var(--sp-text-subdued)] hover:bg-white/10"
            }`}
          >
            Playlists
          </button>
          <button
            onClick={() => setActiveFilter("artists")}
            className={`rounded-full px-3 py-1 text-xs font-medium transition-colors ${
              activeFilter === "artists" ? "bg-white/10 text-white" : "bg-white/5 text-[var(--sp-text-subdued)] hover:bg-white/10"
            }`}
          >
            Artists
          </button>
          <button
            onClick={() => setActiveFilter("albums")}
            className={`rounded-full px-3 py-1 text-xs font-medium transition-colors ${
              activeFilter === "albums" ? "bg-white/10 text-white" : "bg-white/5 text-[var(--sp-text-subdued)] hover:bg-white/10"
            }`}
          >
            Albums
          </button>
        </div>

        {/* Library list */}
        <div className="bl-scroll flex-1 px-2 pb-2">
          {activeFilter === "playlists" ? (
            <>
              {/* Liked Songs (special) */}
              <LibraryItem
                cover={<div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-md bg-gradient-to-br from-purple-500 to-pink-600 shadow-lg shadow-purple-500/20"><Heart size={20} fill="currentColor" className="text-white" /></div>}
                title="Liked Songs"
                subtitle={`${likedTrackCount} songs`}
                active={view.type === "liked"}
                onClick={onGoLiked}
              />

              {playlists.filter(p => !p.isSystem).map(pl => (
                <LibraryItem
                  key={pl.id}
                  cover={
                    pl.coverUrl ? (
                      <img src={pl.coverUrl} alt="" className="h-12 w-12 shrink-0 rounded-md object-cover shadow-lg shadow-black/40" />
                    ) : (
                      <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-md bg-gradient-to-br from-emerald-500/40 to-teal-700/40 shadow-lg shadow-black/20">
                        <ListMusic size={18} className="text-white/60" />
                      </div>
                    )
                  }
                  title={pl.name}
                  subtitle={`Playlist • ${pl.trackCount} songs`}
                  active={activePlaylistId === pl.id}
                  onClick={() => onSelectPlaylist(pl.id)}
                />
              ))}

              {playlists.filter(p => p.isSystem && p.name !== "Liked Songs").map(pl => (
                <LibraryItem
                  key={pl.id}
                  cover={
                    pl.coverUrl ? (
                      <img src={pl.coverUrl} alt="" className="h-12 w-12 shrink-0 rounded-md object-cover shadow-lg shadow-black/40" />
                    ) : (
                      <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-md bg-white/10 shadow-lg shadow-black/20">
                        <Clock size={18} className="text-white/60" />
                      </div>
                    )
                  }
                  title={pl.name}
                  subtitle={`Playlist • ${pl.trackCount} songs`}
                  active={activePlaylistId === pl.id}
                  onClick={() => onSelectPlaylist(pl.id)}
                />
              ))}
            </>
          ) : activeFilter === "artists" ? (
            <>
              {artists.length === 0 ? (
                <div className="px-3 py-4 text-center text-xs text-[var(--sp-text-subdued)]">
                  No artists yet
                </div>
              ) : (
                artists.map(a => (
                  <LibraryItem
                    key={a.name}
                    cover={
                      a.coverUrl ? (
                        <img src={a.coverUrl} alt="" className="h-12 w-12 shrink-0 rounded-full object-cover shadow-lg shadow-black/40" />
                      ) : (
                        <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-violet-500/40 to-fuchsia-700/40 shadow-lg shadow-black/20">
                          <User size={18} className="text-white/60" />
                        </div>
                      )
                    }
                    title={a.name}
                    subtitle={`Artist • ${a.trackCount} track${a.trackCount !== 1 ? "s" : ""}`}
                    active={view.type === "artist" && view.name === a.name}
                    onClick={() => onSelectArtist(a.name)}
                  />
                ))
              )}
            </>
          ) : (
            <>
              {albums.length === 0 ? (
                <div className="px-3 py-4 text-center text-xs text-[var(--sp-text-subdued)]">
                  No albums yet
                </div>
              ) : (
                albums.map(a => (
                  <LibraryItem
                    key={a.name}
                    cover={
                      a.coverUrl ? (
                        <img src={a.coverUrl} alt="" className="h-12 w-12 shrink-0 rounded-md object-cover shadow-lg shadow-black/40" />
                      ) : (
                        <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-md bg-gradient-to-br from-violet-500/40 to-fuchsia-700/40 shadow-lg shadow-black/20">
                          <Disc3 size={18} className="text-white/60" />
                        </div>
                      )
                    }
                    title={a.name}
                    subtitle={`Album • ${a.trackCount} track${a.trackCount !== 1 ? "s" : ""}`}
                    active={view.type === "album" && view.name === a.name}
                    onClick={() => onSelectAlbum(a.name)}
                  />
                ))
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}

function NavButton({ icon, label, active, onClick }: { icon: React.ReactNode; label: string; active: boolean; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className={`flex w-full items-center gap-4 rounded-md py-2 font-bold transition-all duration-200 ${
        active
          ? "bl-sidebar-active text-white"
          : "bl-nav-hover text-[var(--sp-text-subdued)] hover:text-white"
      } ${active ? "px-[9px]" : "px-3"}`}
    >
      <span className={`transition-transform duration-200 ${active ? "scale-110" : ""}`}>
        {icon}
      </span>
      <span className="text-sm">{label}</span>
    </button>
  );
}

function LibraryItem({ cover, title, subtitle, active, onClick }: { cover: React.ReactNode; title: string; subtitle: string; active: boolean; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className={`group flex w-full items-center gap-3 rounded-lg p-2 text-left transition-all duration-200 ${
        active ? "bg-white/10" : "hover:bg-white/5"
      }`}
    >
      {cover}
      <div className="min-w-0 flex-1">
        <div className={`truncate text-sm font-medium transition-colors ${active ? "text-emerald-400" : "text-white group-hover:text-white"}`}>{title}</div>
        <div className="truncate text-xs text-[var(--sp-text-subdued)]">{subtitle}</div>
      </div>
    </button>
  );
}
