"use client";
import { useState } from "react";
import { Music2, X, Trash2, ListPlus, GripVertical } from "lucide-react";
import type { Track } from "@/lib/types";
import { toast } from "sonner";

interface Props {
  queue: Track[];
  currentTrackId: string | null;
  onClose: () => void;
  onSelect: (track: Track) => void;
  onRemove?: (trackId: string) => void;
  onClear?: () => void;
}

export function QueuePanel({ queue, currentTrackId, onClose, onSelect, onRemove, onClear }: Props) {
  const [dragIndex, setDragIndex] = useState<number | null>(null);
  const [overIndex, setOverIndex] = useState<number | null>(null);
  const currentIndex = queue.findIndex(t => t.id === currentTrackId);
  const upcoming = currentIndex >= 0 ? queue.slice(currentIndex + 1) : queue;
  const currentTrack = currentIndex >= 0 ? queue[currentIndex] : null;

  return (
    <div className="flex h-full flex-col bg-[var(--sp-highlight)] rounded-lg overflow-hidden">
      <div className="flex shrink-0 items-center justify-between border-b border-white/5 px-4 py-3">
        <div className="flex items-center gap-2">
          <h2 className="text-sm font-bold text-white">Queue</h2>
          {upcoming.length > 0 && (
            <span className="rounded-full bg-white/10 px-2 py-0.5 text-[10px] font-semibold text-white/70">
              {upcoming.length + (currentTrack ? 1 : 0)}
            </span>
          )}
        </div>
        <div className="flex items-center gap-1">
          {upcoming.length > 0 && onClear && (
            <button
              onClick={() => {
                onClear();
                toast.success("Queue cleared");
              }}
              className="rounded-full p-1 text-[var(--sp-text-subdued)] hover:bg-white/10 hover:text-white"
              title="Clear queue (keep current track)"
            >
              <Trash2 size={14} />
            </button>
          )}
          <button onClick={onClose} className="rounded-full p-1 text-[var(--sp-text-subdued)] hover:bg-white/10 hover:text-white">
            <X size={14} />
          </button>
        </div>
      </div>

      <div className="bl-scroll flex-1 px-2 pb-2">
        {currentTrack && (
          <div className="mb-4 mt-2">
            <div className="px-2 py-1 text-xs font-bold uppercase tracking-wider text-[var(--sp-text-subdued)]">
              Now playing
            </div>
            <QueueItem
              key={`now-${currentTrack.id}`}
              track={currentTrack}
              active
              onClick={() => onSelect(currentTrack)}
              onRemove={onRemove}
            />
          </div>
        )}

        <div>
          <div className="flex items-center justify-between px-2 py-1">
            <div className="text-xs font-bold uppercase tracking-wider text-[var(--sp-text-subdued)]">
              Next up
            </div>
            {upcoming.length > 1 && (
              <span className="text-[10px] text-[var(--sp-text-subdued)]/70">
                Drag to reorder
              </span>
            )}
          </div>
          {upcoming.length === 0 ? (
            <div className="px-2 py-8 text-center">
              <ListPlus size={32} className="mx-auto mb-2 opacity-30 text-[var(--sp-text-subdued)]" />
              <div className="text-sm text-[var(--sp-text-subdued)]">No upcoming tracks</div>
              <div className="mt-1 text-xs text-[var(--sp-text-subdued)]/70">
                Play a track to start the queue
              </div>
            </div>
          ) : (
            upcoming.map((t, i) => (
              <QueueItem
                key={`queue-${i}-${t.id}`}
                track={t}
                onClick={() => onSelect(t)}
                onRemove={onRemove}
                draggable
                onDragStart={() => setDragIndex(currentIndex + 1 + i)}
                onDragOver={(e) => {
                  e.preventDefault();
                  const idx = currentIndex + 1 + i;
                  if (overIndex !== idx) setOverIndex(idx);
                }}
                onDrop={(e) => {
                  e.preventDefault();
                  const idx = currentIndex + 1 + i;
                  if (dragIndex !== null && dragIndex !== idx) {
                    // Reorder via parent — for now we'll use a custom event
                    window.dispatchEvent(new CustomEvent("bl-queue-reorder", { detail: { from: dragIndex, to: idx } }));
                  }
                  setDragIndex(null);
                  setOverIndex(null);
                }}
                onDragEnd={() => { setDragIndex(null); setOverIndex(null); }}
                isOver={overIndex === currentIndex + 1 + i && dragIndex !== null}
              />
            ))
          )}
        </div>
      </div>
    </div>
  );
}

function QueueItem({
  track,
  active,
  onClick,
  onRemove,
  draggable,
  onDragStart,
  onDragOver,
  onDrop,
  onDragEnd,
  isOver,
}: {
  track: Track;
  active?: boolean;
  onClick: () => void;
  onRemove?: (trackId: string) => void;
  draggable?: boolean;
  onDragStart?: () => void;
  onDragOver?: (e: React.DragEvent) => void;
  onDrop?: (e: React.DragEvent) => void;
  onDragEnd?: () => void;
  isOver?: boolean;
}) {
  return (
    <div
      draggable={draggable}
      onDragStart={onDragStart}
      onDragOver={onDragOver}
      onDrop={onDrop}
      onDragEnd={onDragEnd}
      className={`group relative flex w-full items-center gap-2 rounded-md p-2 text-left transition-colors ${
        active ? "bg-white/10" : "hover:bg-white/5"
      } ${isOver ? "border-t-2 border-emerald-400" : ""}`}
    >
      {draggable && (
        <div className="cursor-grab text-[var(--sp-text-subdued)] opacity-0 group-hover:opacity-100">
          <GripVertical size={12} />
        </div>
      )}
      <button onClick={onClick} className="flex min-w-0 flex-1 items-center gap-3 text-left">
        <div className="h-10 w-10 shrink-0 overflow-hidden rounded">
          {track.coverUrl ? (
            <img src={track.coverUrl} alt="" className="h-full w-full object-cover" />
          ) : (
            <div className="flex h-full w-full items-center justify-center bg-white/10">
              <Music2 size={14} className="text-white/40" />
            </div>
          )}
        </div>
        <div className="min-w-0 flex-1">
          <div className={`truncate text-sm font-medium ${active ? "text-emerald-400" : "text-white"}`}>
            {track.title}
          </div>
          <div className="truncate text-xs text-[var(--sp-text-subdued)]">
            {track.artists.join(", ")}
          </div>
        </div>
      </button>
      {onRemove && !active && (
        <button
          onClick={() => onRemove(track.id)}
          className="rounded-full p-1 text-[var(--sp-text-subdued)] opacity-0 transition-opacity hover:bg-white/10 hover:text-white group-hover:opacity-100"
          title="Remove from queue"
        >
          <X size={14} />
        </button>
      )}
    </div>
  );
}
