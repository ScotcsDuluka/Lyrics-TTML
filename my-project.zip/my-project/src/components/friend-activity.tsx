"use client";
import { useEffect, useState } from "react";
import { Users, Music2, Heart, MoreHorizontal, X, Volume2 } from "lucide-react";
import type { Track } from "@/lib/types";

interface Friend {
  id: string;
  name: string;
  avatarColor: string;
  avatarInitial: string;
  trackIndex: number;
  progress: number; // 0-1
  isPlaying: boolean;
  liked: boolean;
}

interface Props {
  allTracks: Track[];
  onClose: () => void;
  onSelectTrack: (track: Track) => void;
  onSelectArtist: (name: string) => void;
}

// Mock friends with stable identities
const MOCK_FRIENDS: Omit<Friend, "trackIndex" | "progress" | "isPlaying" | "liked">[] = [
  { id: "f1", name: "Alex Rivers", avatarColor: "from-rose-500 to-pink-600", avatarInitial: "A" },
  { id: "f2", name: "Maya Chen", avatarColor: "from-amber-500 to-orange-600", avatarInitial: "M" },
  { id: "f3", name: "Jordan Lee", avatarColor: "from-emerald-500 to-teal-600", avatarInitial: "J" },
  { id: "f4", name: "Sam Park", avatarColor: "from-violet-500 to-purple-600", avatarInitial: "S" },
  { id: "f5", name: "Riley Quinn", avatarColor: "from-cyan-500 to-blue-600", avatarInitial: "R" },
  { id: "f6", name: "Taylor Brooks", avatarColor: "from-fuchsia-500 to-pink-600", avatarInitial: "T" },
];

function pickTrackIndex(seed: string, total: number): number {
  let h = 0;
  for (let i = 0; i < seed.length; i++) h = (h * 31 + seed.charCodeAt(i)) >>> 0;
  return total > 0 ? h % total : 0;
}

export function FriendActivity({ allTracks, onClose, onSelectTrack, onSelectArtist }: Props) {
  const [friends, setFriends] = useState<Friend[]>([]);

  // Initialize friends
  useEffect(() => {
    if (allTracks.length === 0) return;
    const initial: Friend[] = MOCK_FRIENDS.map(f => ({
      ...f,
      trackIndex: pickTrackIndex(f.id, allTracks.length),
      progress: Math.random(),
      isPlaying: Math.random() > 0.3,
      liked: Math.random() > 0.5,
    }));
    queueMicrotask(() => setFriends(initial));
  }, [allTracks]);

  // Simulate playback progress
  useEffect(() => {
    if (friends.length === 0) return;
    const interval = setInterval(() => {
      setFriends(prev => prev.map(f => {
        if (!f.isPlaying) return f;
        let newProgress = f.progress + 0.01;
        let newTrackIndex = f.trackIndex;
        let newLiked = f.liked;
        if (newProgress >= 1) {
          newProgress = 0;
          newTrackIndex = (f.trackIndex + 1) % allTracks.length;
          newLiked = Math.random() > 0.5;
        }
        return { ...f, progress: newProgress, trackIndex: newTrackIndex, liked: newLiked };
      }));
    }, 1000);
    return () => clearInterval(interval);
  }, [friends.length, allTracks.length]);

  if (allTracks.length === 0) return null;

  const activeCount = friends.filter(f => f.isPlaying).length;

  return (
    <aside className="bl-panel bl-friend-activity flex flex-col overflow-hidden">
      <div className="flex items-center justify-between px-4 py-3 border-b border-white/5">
        <div className="flex items-center gap-2">
          <Users size={18} className="text-emerald-400" />
          <h2 className="text-sm font-bold text-white">Friend Activity</h2>
          <span className="ml-1 rounded-full bg-emerald-500/20 px-2 py-0.5 text-[10px] font-bold text-emerald-300">
            {activeCount} active
          </span>
        </div>
        <button
          onClick={onClose}
          className="rounded-full p-1.5 text-[var(--sp-text-subdued)] hover:bg-white/10 hover:text-white transition-colors"
          aria-label="Close friend activity"
        >
          <X size={14} />
        </button>
      </div>

      <div className="bl-scroll flex-1 px-2 py-2 pb-24">
        {friends.length === 0 ? (
          <div className="flex h-full flex-col items-center justify-center px-4 text-center">
            <div className="mb-3 rounded-full bg-white/5 p-3">
              <Users size={20} className="text-[var(--sp-text-subdued)]" />
            </div>
            <p className="text-xs text-[var(--sp-text-subdued)]">
              Friends who listen to music will appear here.
            </p>
          </div>
        ) : (
          <ul className="flex flex-col gap-1">
            {friends.map(friend => {
              const track = allTracks[friend.trackIndex];
              if (!track) return null;
              const progressPct = Math.min(100, Math.max(0, friend.progress * 100));
              const currentSec = Math.floor((track.duration ?? 0) * friend.progress);
              return (
                <li
                  key={friend.id}
                  className="bl-friend-card group rounded-lg p-2 transition-all hover:bg-white/5"
                >
                  <div className="flex gap-3">
                    {/* Avatar with playing indicator */}
                    <div className="relative shrink-0">
                      <div className={`flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-br ${friend.avatarColor} text-sm font-bold text-white shadow-lg`}>
                        {friend.avatarInitial}
                      </div>
                      {friend.isPlaying && (
                        <div className="absolute -bottom-1 -right-1 flex h-5 w-5 items-center justify-center rounded-full border-2 border-[#121212] bg-emerald-500">
                          <div className="flex items-end gap-[2px] h-2.5">
                            <div className="bl-eq-bar w-[2px] bg-white" style={{ animationDelay: "0ms", height: "60%" }} />
                            <div className="bl-eq-bar w-[2px] bg-white" style={{ animationDelay: "150ms", height: "100%" }} />
                            <div className="bl-eq-bar w-[2px] bg-white" style={{ animationDelay: "300ms", height: "40%" }} />
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Friend info + track */}
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-1">
                        <p className="truncate text-sm font-semibold text-white">{friend.name}</p>
                        <span className="text-[10px] text-[var(--sp-text-subdued)]">
                          {friend.isPlaying ? "• listening now" : "• paused"}
                        </span>
                      </div>

                      <button
                        onClick={() => onSelectTrack(track)}
                        className="mt-1 flex w-full items-center gap-1.5 rounded text-left hover:text-emerald-300 transition-colors"
                      >
                        <Music2 size={11} className="shrink-0 text-[var(--sp-text-subdued)]" />
                        <span className="truncate text-xs font-medium text-white/90 group-hover:text-emerald-300">
                          {track.title}
                        </span>
                        {friend.liked && <Heart size={10} fill="currentColor" className="shrink-0 text-rose-400" />}
                      </button>

                      <button
                        onClick={() => track.artists[0] && onSelectArtist(track.artists[0])}
                        className="mt-0.5 block w-full truncate text-[11px] text-[var(--sp-text-subdued)] hover:text-white hover:underline transition-colors text-left"
                      >
                        {track.artists.join(", ")}
                      </button>

                      {/* Album art + progress */}
                      <div className="mt-1.5 flex items-center gap-2">
                        <button
                          onClick={() => onSelectTrack(track)}
                          className="relative h-9 w-9 shrink-0 overflow-hidden rounded"
                        >
                          {track.coverUrl ? (
                            <img src={track.coverUrl} alt="" className="h-full w-full object-cover" />
                          ) : (
                            <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-emerald-500/40 to-teal-700/40">
                              <Music2 size={14} className="text-white/60" />
                            </div>
                          )}
                          <div className="absolute inset-0 flex items-center justify-center bg-black/40 opacity-0 transition-opacity group-hover:opacity-100">
                            <Volume2 size={12} className="text-white" />
                          </div>
                        </button>

                        <div className="flex-1">
                          {/* Progress bar */}
                          <div className="h-1 w-full overflow-hidden rounded-full bg-white/10">
                            <div
                              className={`h-full rounded-full transition-all duration-1000 ease-linear ${
                                friend.isPlaying
                                  ? "bg-gradient-to-r from-emerald-500 to-teal-400"
                                  : "bg-white/30"
                              }`}
                              style={{ width: `${progressPct}%` }}
                            />
                          </div>
                          <div className="mt-1 flex items-center justify-between text-[10px] text-[var(--sp-text-subdued)]">
                            <span className="truncate">{track.album}</span>
                            <span className="shrink-0 tabular-nums">{currentSec}s</span>
                          </div>
                        </div>

                        <button
                          className="rounded-full p-1 text-[var(--sp-text-subdued)] opacity-0 hover:bg-white/10 hover:text-white transition-all group-hover:opacity-100"
                          aria-label="More options"
                        >
                          <MoreHorizontal size={12} />
                        </button>
                      </div>
                    </div>
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </div>

      <div className="border-t border-white/5 px-4 py-2">
        <p className="text-[10px] text-[var(--sp-text-subdued)]">
          <span className="font-semibold text-white/70">Tip:</span> Click a track to play it yourself.
        </p>
      </div>
    </aside>
  );
}
