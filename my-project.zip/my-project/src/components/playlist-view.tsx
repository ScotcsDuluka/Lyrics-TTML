"use client";
import { useState } from "react";
import { Play, Pause, Heart, Clock, MoreHorizontal, Pencil, Trash2, Share2, Download, Clock3, Shuffle } from "lucide-react";
import type { Playlist, Track } from "@/lib/types";
import { TrackTable } from "./track-table";
import { useAppStore } from "@/lib/store";
import { toast } from "sonner";

interface Props {
  playlist: Playlist | null;
  tracks: Track[];
  currentTrackId: string | null;
  isPlaying: boolean;
  isLikedPlaylist?: boolean;
  coverHue: number;
  onPlay: () => void;
  onSelectTrack: (track: Track, index: number) => void;
  onToggleLike: (trackId: string) => void;
  onEditPlaylist?: () => void;
  onDeletePlaylist?: () => void;
  allPlaylists?: Playlist[];
  onAddToPlaylist?: (playlistId: string, trackId: string) => Promise<boolean>;
  onCreatePlaylistWithTrack?: (name: string, trackId: string) => Promise<string | null>;
  onReorder?: (fromIndex: number, toIndex: number) => void;
  onAddToQueue?: (trackId: string) => void;
}

export function PlaylistView(p: Props) {
  const [menuOpen, setMenuOpen] = useState(false);
  const setSharePayload = useAppStore(s => s.setSharePayload);
  const setShowShareModal = useAppStore(s => s.setShowShareModal);

  if (!p.playlist) {
    return (
      <div className="flex h-full items-center justify-center text-[var(--sp-text-subdued)]">
        Playlist not found
      </div>
    );
  }

  const isSystemLiked = p.playlist.isSystem && p.playlist.name === "Liked Songs";
  const gradientFrom = isSystemLiked
    ? "from-purple-600"
    : `from-[hsl(${p.coverHue},40%,30%)]`;

  const handleShare = () => {
    setSharePayload({
      type: "playlist",
      id: p.playlist!.id,
      title: p.playlist!.name,
      subtitle: `${p.tracks.length} songs`,
    });
    setShowShareModal(true);
    setMenuOpen(false);
  };

  const handleCopyLink = () => {
    const url = `${window.location.origin}/?share=playlist_${p.playlist!.id}`;
    navigator.clipboard?.writeText(url);
    toast.success("Playlist link copied");
    setMenuOpen(false);
  };

  // Calculate total duration
  const totalDuration = p.tracks.reduce((acc, t) => acc + (t.duration || 0), 0);
  const totalMin = Math.floor(totalDuration / 60);
  const totalHr = Math.floor(totalMin / 60);
  const totalSec = Math.floor(totalDuration % 60);
  const durationLabel = totalHr > 0
    ? `${totalHr} hr ${totalMin % 60} min`
    : totalMin > 0
    ? `${totalMin} min${totalSec > 30 ? "" : ""}`
    : totalDuration > 0
    ? `${totalSec} sec`
    : "";

  return (
    <div className="bl-scroll flex-1">
      {/* Header — Spotify style: smaller top padding */}
      <div className={`bg-gradient-to-b ${gradientFrom} to-transparent px-6 pb-6 pt-6`}>
        <div className="flex items-end gap-6">
          {p.playlist.coverUrl ? (
            <img src={p.playlist.coverUrl} alt="" className="h-48 w-48 shrink-0 rounded-md object-cover shadow-2xl" />
          ) : isSystemLiked ? (
            <div className="flex h-48 w-48 shrink-0 items-center justify-center rounded-md bg-gradient-to-br from-purple-500 to-pink-600 shadow-2xl">
              <Heart size={80} fill="currentColor" className="text-white" />
            </div>
          ) : (
            <div className="flex h-48 w-48 shrink-0 items-center justify-center rounded-md bg-gradient-to-br from-emerald-500/40 to-teal-700/40 shadow-2xl">
              <Clock size={64} className="text-white/60" />
            </div>
          )}
          <div className="min-w-0 flex-1 pb-4">
            <div className="text-xs font-bold uppercase tracking-wider text-white">Playlist</div>
            <h1 className="mt-2 truncate text-7xl font-extrabold tracking-tight text-white">
              {p.playlist.name}
            </h1>
            <p className="mt-4 text-sm text-white/70">{p.playlist.description || ""}</p>
            <div className="mt-2 flex items-center gap-1 text-sm text-white/80">
              <span className="font-bold text-white">Beautiful Lyrics</span>
              <span>•</span>
              <span>{p.tracks.length} songs</span>
              {totalDuration > 0 && durationLabel && (
                <>
                  <span>•</span>
                  <span className="flex items-center gap-1">
                    <Clock3 size={12} />
                    {durationLabel}
                  </span>
                </>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Toolbar */}
      <div className="bg-black/20 px-6 py-4">
        <div className="flex items-center gap-6">
          <button
            onClick={p.onPlay}
            disabled={p.tracks.length === 0}
            className="flex h-14 w-14 items-center justify-center rounded-full bg-emerald-500 text-black shadow-lg transition-all hover:scale-105 hover:bg-emerald-400 active:scale-95 disabled:opacity-40 bl-float"
          >
            {p.isPlaying ? <Pause size={24} fill="currentColor" /> : <Play size={24} fill="currentColor" className="ml-1" />}
          </button>

          {/* Shuffle Play button */}
          <button
            onClick={() => {
              if (p.tracks.length === 0) return;
              const shuffled = [...p.tracks].sort(() => Math.random() - 0.5);
              p.onSelectTrack(shuffled[0], 0);
              toast.success("Shuffle play started", { description: p.playlist.name });
            }}
            disabled={p.tracks.length === 0}
            className="flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-4 py-2 text-xs font-medium text-white/80 transition-all hover:border-emerald-400/30 hover:bg-emerald-500/10 hover:text-emerald-400 disabled:opacity-40"
            title="Shuffle play"
          >
            <Shuffle size={14} />
            <span className="hidden sm:inline">Shuffle</span>
          </button>

          {/* Quick share button */}
          <button
            onClick={handleShare}
            className="flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-4 py-2 text-xs font-medium text-white/80 transition-all hover:border-white/20 hover:bg-white/10 hover:text-white"
            title="Share playlist"
          >
            <Share2 size={14} />
            <span className="hidden sm:inline">Share</span>
          </button>

          {!p.playlist.isSystem && (
            <div className="relative">
              <button
                onClick={() => setMenuOpen(v => !v)}
                className="text-[var(--sp-text-subdued)] hover:text-white"
              >
                <MoreHorizontal size={28} />
              </button>
              {menuOpen && (
                <>
                  <div className="fixed inset-0 z-30" onClick={() => setMenuOpen(false)} />
                  <div className="absolute right-0 top-full mt-2 z-40 w-52 overflow-hidden rounded-lg border border-white/10 bg-[var(--sp-elevated)] py-1 shadow-2xl bl-msg-in">
                    <button
                      onClick={handleShare}
                      className="flex w-full items-center gap-3 px-3 py-2 text-sm text-white hover:bg-white/10"
                    >
                      <Share2 size={14} /> Share
                    </button>
                    <button
                      onClick={handleCopyLink}
                      className="flex w-full items-center gap-3 px-3 py-2 text-sm text-white hover:bg-white/10"
                    >
                      <Download size={14} /> Copy link
                    </button>
                    {p.onEditPlaylist && (
                      <button
                        onClick={() => { p.onEditPlaylist?.(); setMenuOpen(false); }}
                        className="flex w-full items-center gap-3 px-3 py-2 text-sm text-white hover:bg-white/10"
                      >
                        <Pencil size={14} /> Edit details
                      </button>
                    )}
                    {p.onDeletePlaylist && (
                      <button
                        onClick={() => { p.onDeletePlaylist?.(); setMenuOpen(false); }}
                        className="flex w-full items-center gap-3 px-3 py-2 text-sm text-red-400 hover:bg-white/10"
                      >
                        <Trash2 size={14} /> Delete
                      </button>
                    )}
                  </div>
                </>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Track table */}
      <TrackTable
        tracks={p.tracks}
        currentTrackId={p.currentTrackId}
        isPlaying={p.isPlaying}
        onSelect={p.onSelectTrack}
        onTogglePlay={p.onPlay}
        onToggleLike={p.onToggleLike}
        playlists={p.allPlaylists}
        onAddToPlaylist={p.onAddToPlaylist}
        onCreatePlaylistWithTrack={p.onCreatePlaylistWithTrack}
        onReorder={p.onReorder}
        canReorder={!p.playlist?.isSystem}
        onAddToQueue={p.onAddToQueue}
      />
    </div>
  );
}
