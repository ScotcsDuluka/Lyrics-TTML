"use client";
import { useMemo, useState } from "react";
import { Clock, TrendingUp, Music2, Disc3, User, Heart, Calendar, Flame, BarChart3, Headphones, Activity, Award, Zap, Moon, Sunrise, Sunset, Sun } from "lucide-react";
import type { Track, PlayHistoryEntry } from "@/lib/types";

interface Props {
  history: PlayHistoryEntry[];
  allTracks: Track[];
  likedTrackCount: number;
  onSelectTrack: (track: Track) => void;
  onSelectArtist: (name: string) => void;
  onSelectAlbum: (name: string) => void;
}

interface DayBucket {
  date: string;
  label: string;
  shortLabel: string;
  count: number;
  minutes: number;
}

const GENRE_DONUT_COLORS = [
  "#10b981", "#a855f7", "#f97316", "#06b6d4", "#ec4899",
  "#eab308", "#3b82f6", "#ef4444", "#84cc16", "#6366f1",
];

export function ListeningStatsView({ history, allTracks, likedTrackCount, onSelectTrack, onSelectArtist, onSelectAlbum }: Props) {
  const [timeRange, setTimeRange] = useState<"7d" | "30d" | "all">("30d");
  const [hoveredDay, setHoveredDay] = useState<number | null>(null);
  const [hoveredHour, setHoveredHour] = useState<number | null>(null);

  const filteredHistory = useMemo(() => {
    if (timeRange === "all") return history;
    const days = timeRange === "7d" ? 7 : 30;
    const cutoff = Date.now() - days * 24 * 60 * 60 * 1000;
    return history.filter(h => new Date(h.playedAt).getTime() >= cutoff);
  }, [history, timeRange]);

  // Total listening time
  const totalSeconds = useMemo(() => {
    return filteredHistory.reduce((sum, h) => sum + (h.track.duration ?? 0), 0);
  }, [filteredHistory]);

  const totalMinutes = Math.round(totalSeconds / 60);
  const totalHours = (totalMinutes / 60).toFixed(1);

  // Top tracks (by play count)
  const topTracks = useMemo(() => {
    const counts = new Map<string, number>();
    for (const h of filteredHistory) {
      counts.set(h.trackId, (counts.get(h.trackId) ?? 0) + 1);
    }
    return Array.from(counts.entries())
      .map(([id, count]) => {
        const track = allTracks.find(t => t.id === id);
        return track ? { track, count } : null;
      })
      .filter(Boolean)
      .sort((a, b) => b!.count - a!.count)
      .slice(0, 5) as { track: Track; count: number }[];
  }, [filteredHistory, allTracks]);

  // Top artists
  const topArtists = useMemo(() => {
    const counts = new Map<string, number>();
    for (const h of filteredHistory) {
      for (const artist of h.track.artists) {
        counts.set(artist, (counts.get(artist) ?? 0) + 1);
      }
    }
    return Array.from(counts.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5);
  }, [filteredHistory]);

  // Top genres
  const topGenres = useMemo(() => {
    const counts = new Map<string, number>();
    for (const h of filteredHistory) {
      const g = h.track.genre;
      if (g) counts.set(g, (counts.get(g) ?? 0) + 1);
    }
    return Array.from(counts.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, 6);
  }, [filteredHistory]);

  // Top albums
  const topAlbums = useMemo(() => {
    const counts = new Map<string, number>();
    for (const h of filteredHistory) {
      const a = h.track.album;
      if (a) counts.set(a, (counts.get(a) ?? 0) + 1);
    }
    return Array.from(counts.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5);
  }, [filteredHistory]);

  // Activity by day (for chart)
  const dayBuckets = useMemo<DayBucket[]>(() => {
    const days = timeRange === "7d" ? 7 : 30;
    const buckets: DayBucket[] = [];
    const now = new Date();
    for (let i = days - 1; i >= 0; i--) {
      const d = new Date(now);
      d.setDate(d.getDate() - i);
      const dateStr = d.toISOString().slice(0, 10);
      const label = d.toLocaleDateString("en-US", { weekday: "short" });
      const shortLabel = d.toLocaleDateString("en-US", { month: "numeric", day: "numeric" });
      buckets.push({ date: dateStr, label, shortLabel, count: 0, minutes: 0 });
    }
    for (const h of filteredHistory) {
      const d = new Date(h.playedAt);
      const dateStr = d.toISOString().slice(0, 10);
      const bucket = buckets.find(b => b.date === dateStr);
      if (bucket) {
        bucket.count += 1;
        bucket.minutes += (h.track.duration ?? 0) / 60;
      }
    }
    return buckets;
  }, [filteredHistory, timeRange]);

  const maxDayCount = Math.max(1, ...dayBuckets.map(b => b.count));

  // Streak calculation (consecutive days with at least 1 play)
  const streak = useMemo(() => {
    let s = 0;
    const now = new Date();
    for (let i = 0; i < 365; i++) {
      const d = new Date(now);
      d.setDate(d.getDate() - i);
      const dateStr = d.toISOString().slice(0, 10);
      const hasPlay = history.some(h => h.playedAt.slice(0, 10) === dateStr);
      if (hasPlay) s++;
      else if (i > 0) break; // allow today to be empty
    }
    return s;
  }, [history]);

  // Hour-of-day histogram
  const hourBuckets = useMemo(() => {
    const buckets = new Array(24).fill(0);
    for (const h of filteredHistory) {
      const hr = new Date(h.playedAt).getHours();
      buckets[hr]++;
    }
    return buckets;
  }, [filteredHistory]);

  const maxHourCount = Math.max(1, ...hourBuckets);

  // Day-of-week x hour-of-day heatmap (7x24)
  const weekdayHourBuckets = useMemo(() => {
    const grid: number[][] = Array.from({ length: 7 }, () => new Array(24).fill(0));
    for (const h of filteredHistory) {
      const d = new Date(h.playedAt);
      const day = d.getDay();
      const hr = d.getHours();
      grid[day][hr]++;
    }
    return grid;
  }, [filteredHistory]);

  const maxCellCount = Math.max(1, ...weekdayHourBuckets.flat());

  // Compute SVG line chart path for listening activity
  const activityLinePoints = useMemo(() => {
    const W = 600;
    const H = 140;
    const pad = 8;
    if (dayBuckets.length === 0) return { linePath: "", areaPath: "", points: [] as { x: number; y: number; count: number; label: string }[] };
    const step = (W - pad * 2) / Math.max(1, dayBuckets.length - 1);
    const points = dayBuckets.map((b, i) => ({
      x: pad + i * step,
      y: H - pad - (b.count / maxDayCount) * (H - pad * 2),
      count: b.count,
      label: b.label,
    }));
    // Build smooth line path (Catmull-Rom-ish)
    let linePath = "";
    points.forEach((p, i) => {
      if (i === 0) linePath += `M ${p.x} ${p.y}`;
      else {
        const prev = points[i - 1];
        const cx = (prev.x + p.x) / 2;
        linePath += ` Q ${cx} ${prev.y} ${cx} ${(prev.y + p.y) / 2} T ${p.x} ${p.y}`;
      }
    });
    const areaPath = linePath + ` L ${points[points.length - 1].x} ${H - pad} L ${points[0].x} ${H - pad} Z`;
    return { linePath, areaPath, points };
  }, [dayBuckets, maxDayCount]);

  // Genre donut chart data
  const genreDonut = useMemo(() => {
    const total = topGenres.reduce((s, [, c]) => s + c, 0);
    if (total === 0) return { segments: [], total };
    let cumulative = 0;
    const segments = topGenres.map(([genre, count], i) => {
      const start = (cumulative / total) * 360;
      cumulative += count;
      const end = (cumulative / total) * 360;
      return {
        genre,
        count,
        color: GENRE_DONUT_COLORS[i % GENRE_DONUT_COLORS.length],
        startAngle: start,
        endAngle: end,
        percent: Math.round((count / total) * 100),
      };
    });
    return { segments, total };
  }, [topGenres]);

  // Insight: peak hour
  const peakHour = useMemo(() => {
    let max = 0;
    let hr = 0;
    hourBuckets.forEach((c, i) => {
      if (c > max) { max = c; hr = i; }
    });
    return { hour: hr, count: max };
  }, [hourBuckets]);

  const peakDay = useMemo(() => {
    let max = 0;
    let idx = 0;
    dayBuckets.forEach((b, i) => {
      if (b.count > max) { max = b.count; idx = i; }
    });
    return { bucket: dayBuckets[idx], count: max };
  }, [dayBuckets]);

  // Hour-of-day "vibe" categorization
  const vibeByHour = (hr: number) => {
    if (hr >= 5 && hr < 11) return { label: "Morning", icon: <Sunrise size={12} />, color: "text-amber-400" };
    if (hr >= 11 && hr < 17) return { label: "Afternoon", icon: <Sun size={12} />, color: "text-orange-400" };
    if (hr >= 17 && hr < 22) return { label: "Evening", icon: <Sunset size={12} />, color: "text-rose-400" };
    return { label: "Late night", icon: <Moon size={12} />, color: "text-violet-400" };
  };

  // Sparkline data for stat cards
  const playsSparkline = useMemo(() => dayBuckets.slice(-7).map(b => b.count), [dayBuckets]);
  const minutesSparkline = useMemo(() => dayBuckets.slice(-7).map(b => b.minutes), [dayBuckets]);

  return (
    <div className="bl-scroll flex-1 px-6 pb-10 bl-view-transition">
      {/* Header */}
      <div className="pt-8 pb-6">
        <div className="flex items-center gap-3">
          <div className="bl-stat-icon-grad flex h-12 w-12 items-center justify-center rounded-2xl">
            <BarChart3 size={24} className="text-white" />
          </div>
          <div>
            <h1 className="text-3xl font-extrabold tracking-tight text-white bl-gradient-text">Your Listening Stats</h1>
            <p className="mt-1 text-sm text-[var(--sp-text-subdued)]">
              {filteredHistory.length} plays • {totalMinutes >= 60 ? `${totalHours} hrs` : `${totalMinutes} min`} listened
            </p>
          </div>
        </div>
      </div>

      {/* Time range selector */}
      <div className="mb-6 flex items-center gap-2">
        {(["7d", "30d", "all"] as const).map(range => (
          <button
            key={range}
            onClick={() => setTimeRange(range)}
            className={`rounded-full px-4 py-1.5 text-xs font-bold transition-all ${
              timeRange === range
                ? "bg-emerald-500 text-white shadow-lg shadow-emerald-500/30"
                : "bg-white/5 text-[var(--sp-text-subdued)] hover:bg-white/10 hover:text-white"
            }`}
          >
            {range === "7d" ? "Last 7 days" : range === "30d" ? "Last 30 days" : "All time"}
          </button>
        ))}
      </div>

      {/* Stat cards row with sparklines */}
      <div className="mb-8 grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard
          icon={<Headphones size={18} />}
          label="Total Plays"
          value={filteredHistory.length.toString()}
          accent="from-emerald-500 to-teal-600"
          sublabel={`${(() => {
            const r = filteredHistory.length / Math.max(1, dayBuckets.length);
            if (r === 0) return "—";
            if (r < 1) return "<1 / day";
            return `${Math.round(r)} / day`;
          })()}`}
          spark={playsSparkline}
          sparkColor="#10b981"
        />
        <StatCard
          icon={<Clock size={18} />}
          label="Listen Time"
          value={totalMinutes >= 60 ? `${totalHours}h` : `${totalMinutes}m`}
          accent="from-violet-500 to-purple-600"
          sublabel={`${(() => {
            const r = totalMinutes / Math.max(1, dayBuckets.length);
            if (r === 0) return "0 min total";
            if (r < 1) return `${totalMinutes} min total`;
            return `${Math.round(r)} min/day • ${totalMinutes}m total`;
          })()}`}
          spark={minutesSparkline}
          sparkColor="#a855f7"
        />
        <StatCard
          icon={<Flame size={18} />}
          label="Day Streak"
          value={streak.toString()}
          accent="from-amber-500 to-orange-600"
          sublabel={streak >= 7 ? "On fire!" : "Keep it going!"}
        />
        <StatCard
          icon={<Heart size={18} />}
          label="Liked Songs"
          value={likedTrackCount.toString()}
          accent="from-rose-500 to-pink-600"
          sublabel="In your library"
        />
      </div>

      {/* Insight banner */}
      {filteredHistory.length > 0 && (
        <div className="mb-6 relative overflow-hidden rounded-xl border border-emerald-500/30 bg-gradient-to-r from-emerald-500/15 via-teal-500/10 to-cyan-500/5 px-4 py-4 shadow-lg shadow-emerald-500/5">
          {/* Decorative animated orbs */}
          <div className="pointer-events-none absolute -top-12 -right-12 h-32 w-32 rounded-full bg-emerald-500/10 blur-3xl" />
          <div className="pointer-events-none absolute -bottom-12 -left-12 h-32 w-32 rounded-full bg-teal-500/10 blur-3xl" />
          <div className="relative flex flex-wrap items-center gap-3">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-emerald-400 to-teal-600 shadow-lg shadow-emerald-500/30">
              <Zap size={18} className="text-white" fill="currentColor" />
            </div>
            <div className="flex-1 text-sm">
              <div className="mb-0.5 flex items-center gap-2">
                <span className="rounded-full bg-emerald-500/20 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-emerald-300">Insight</span>
              </div>
              <span className="text-white/90">
                You listen most around <span className="font-bold text-emerald-300">{peakHour.hour}:00</span>{" "}
                <span className={`inline-flex items-center gap-1 ${vibeByHour(peakHour.hour).color}`}>
                  {vibeByHour(peakHour.hour).icon} {vibeByHour(peakHour.hour).label}
                </span>
                {peakDay.count > 0 && (
                  <>
                    {" "}— peak day was <span className="font-bold text-emerald-300">{peakDay.bucket.label}</span> with {peakDay.count} plays.
                  </>
                )}
              </span>
            </div>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        {/* Activity line chart (SVG) */}
        <section className="bl-stat-card rounded-xl p-5">
          <div className="mb-4 flex items-center gap-2">
            <Activity size={16} className="text-emerald-400" />
            <h2 className="text-sm font-bold text-white">Listening Activity</h2>
            <span className="ml-auto text-[10px] text-[var(--sp-text-subdued)]">last {dayBuckets.length} days</span>
          </div>
          <svg viewBox="0 0 600 160" className="w-full" preserveAspectRatio="none" style={{ height: 160 }}>
            <defs>
              <linearGradient id="activityArea" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#10b981" stopOpacity="0.5" />
                <stop offset="100%" stopColor="#10b981" stopOpacity="0" />
              </linearGradient>
              <linearGradient id="activityLine" x1="0" y1="0" x2="1" y2="0">
                <stop offset="0%" stopColor="#34d399" />
                <stop offset="100%" stopColor="#06b6d4" />
              </linearGradient>
            </defs>
            {/* Grid lines */}
            {[0, 1, 2, 3].map(i => (
              <line key={i} x1="8" x2="592" y1={8 + i * 36} y2={8 + i * 36} stroke="rgba(255,255,255,0.05)" strokeWidth="1" />
            ))}
            {/* Area */}
            {activityLinePoints.areaPath && <path d={activityLinePoints.areaPath} fill="url(#activityArea)" />}
            {/* Line */}
            {activityLinePoints.linePath && (
              <path d={activityLinePoints.linePath} fill="none" stroke="url(#activityLine)" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
            )}
            {/* Points */}
            {activityLinePoints.points.map((p, i) => (
              <g key={i} onMouseEnter={() => setHoveredDay(i)} onMouseLeave={() => setHoveredDay(null)}>
                <circle cx={p.x} cy={p.y} r={hoveredDay === i ? 5 : 3} fill="#34d399" stroke="#0a0a0a" strokeWidth="2" className="transition-all" />
                <rect x={p.x - 12} y={0} width={24} height={160} fill="transparent" />
                {hoveredDay === i && (
                  <g>
                    <rect x={p.x - 28} y={p.y - 30} width="56" height="20" rx="4" fill="#000" opacity="0.9" />
                    <text x={p.x} y={p.y - 16} textAnchor="middle" fill="#fff" fontSize="10" fontWeight="bold">{p.count} plays</text>
                    <text x={p.x} y={p.y - 4} textAnchor="middle" fill="#9ca3af" fontSize="9">{p.label}</text>
                  </g>
                )}
              </g>
            ))}
          </svg>
          <div className="mt-2 flex justify-between text-[9px] text-[var(--sp-text-subdued)]">
            {dayBuckets.length > 0 && (
              <>
                <span>{dayBuckets[0].shortLabel}</span>
                <span>{dayBuckets[Math.floor(dayBuckets.length / 2)].shortLabel}</span>
                <span>{dayBuckets[dayBuckets.length - 1].shortLabel}</span>
              </>
            )}
          </div>
        </section>

        {/* Hour of day bar chart with hover */}
        <section className="bl-stat-card rounded-xl p-5">
          <div className="mb-4 flex items-center gap-2">
            <Clock size={16} className="text-violet-400" />
            <h2 className="text-sm font-bold text-white">When You Listen</h2>
            <span className="ml-auto text-[10px] text-[var(--sp-text-subdued)]">by hour of day</span>
          </div>
          <div className="flex h-32 items-end gap-[2px]">
            {hourBuckets.map((count, hr) => (
              <div key={hr} className="group flex flex-1 flex-col items-center gap-1">
                <div className="relative w-full flex-1 flex items-end">
                  <div
                    className={`w-full rounded-t transition-all hover:brightness-125 ${
                      hoveredHour === hr
                        ? "bg-gradient-to-t from-violet-500 to-fuchsia-300"
                        : "bg-gradient-to-t from-violet-700 to-fuchsia-400"
                    }`}
                    style={{ height: `${(count / maxHourCount) * 100}%`, minHeight: count > 0 ? "3px" : "1px" }}
                    onMouseEnter={() => setHoveredHour(hr)}
                    onMouseLeave={() => setHoveredHour(null)}
                  >
                    {hoveredHour === hr && (
                      <div className="absolute -top-7 left-1/2 -translate-x-1/2 rounded bg-black/90 px-1.5 py-0.5 text-[10px] text-white whitespace-nowrap border border-violet-500/30">
                        {count} plays @ {hr}:00
                      </div>
                    )}
                  </div>
                </div>
                {hr % 3 === 0 && (
                  <span className="text-[9px] text-[var(--sp-text-subdued)]">{hr}</span>
                )}
              </div>
            ))}
          </div>
          <div className="mt-3 flex flex-wrap items-center gap-3 text-[10px] text-[var(--sp-text-subdued)]">
            <span className="inline-flex items-center gap-1"><Sunrise size={10} className="text-amber-400" /> 5-11</span>
            <span className="inline-flex items-center gap-1"><Sun size={10} className="text-orange-400" /> 11-17</span>
            <span className="inline-flex items-center gap-1"><Sunset size={10} className="text-rose-400" /> 17-22</span>
            <span className="inline-flex items-center gap-1"><Moon size={10} className="text-violet-400" /> 22-5</span>
          </div>
        </section>

        {/* Genre donut + legend */}
        <section className="bl-stat-card rounded-xl p-5">
          <div className="mb-4 flex items-center gap-2">
            <Disc3 size={16} className="text-rose-400" />
            <h2 className="text-sm font-bold text-white">Genre Distribution</h2>
            <span className="ml-auto text-[10px] text-[var(--sp-text-subdued)]">{genreDonut.total} plays</span>
          </div>
          {genreDonut.segments.length === 0 ? (
            <EmptyState text="No genre data yet in this range" />
          ) : (
            <div className="flex items-center gap-4">
              {/* Donut SVG */}
              <svg viewBox="0 0 120 120" width="120" height="120" className="shrink-0">
                <circle cx="60" cy="60" r="48" fill="none" stroke="rgba(255,255,255,0.05)" strokeWidth="14" />
                {genreDonut.segments.map((seg, i) => {
                  const startRad = (seg.startAngle - 90) * Math.PI / 180;
                  const endRad = (seg.endAngle - 90) * Math.PI / 180;
                  const x1 = 60 + 48 * Math.cos(startRad);
                  const y1 = 60 + 48 * Math.sin(startRad);
                  const x2 = 60 + 48 * Math.cos(endRad);
                  const y2 = 60 + 48 * Math.sin(endRad);
                  const largeArc = seg.endAngle - seg.startAngle > 180 ? 1 : 0;
                  return (
                    <path
                      key={i}
                      d={`M ${x1} ${y1} A 48 48 0 ${largeArc} 1 ${x2} ${y2}`}
                      fill="none"
                      stroke={seg.color}
                      strokeWidth="14"
                      strokeLinecap="round"
                      className="transition-all hover:stroke-[18]"
                    >
                      <title>{seg.genre}: {seg.percent}% ({seg.count} plays)</title>
                    </path>
                  );
                })}
                <text x="60" y="58" textAnchor="middle" fill="#fff" fontSize="20" fontWeight="bold">
                  {genreDonut.segments.length}
                </text>
                <text x="60" y="72" textAnchor="middle" fill="#9ca3af" fontSize="9">genres</text>
              </svg>
              {/* Legend */}
              <ul className="flex-1 space-y-1.5">
                {genreDonut.segments.map((seg, i) => (
                  <li key={i} className="flex items-center gap-2 text-xs">
                    <span className="h-3 w-3 shrink-0 rounded-sm" style={{ background: seg.color }} />
                    <span className="flex-1 truncate font-medium text-white/90">{seg.genre}</span>
                    <span className="font-bold text-white/70">{seg.percent}%</span>
                    <span className="text-[10px] text-[var(--sp-text-subdued)]">({seg.count})</span>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </section>

        {/* Day-of-week x Hour heatmap */}
        <section className="bl-stat-card rounded-xl p-5">
          <div className="mb-4 flex items-center gap-2">
            <Calendar size={16} className="text-cyan-400" />
            <h2 className="text-sm font-bold text-white">Activity Heatmap</h2>
            <span className="ml-auto text-[10px] text-[var(--sp-text-subdued)]">day × hour</span>
          </div>
          <div className="overflow-x-auto">
            <div className="min-w-[400px]">
              {/* Hour labels (top) */}
              <div className="mb-1 flex gap-[2px] pl-8">
                {Array.from({ length: 24 }).map((_, hr) => (
                  <div key={hr} className="flex-1 text-center text-[7px] text-[var(--sp-text-subdued)]">
                    {hr % 3 === 0 ? hr : ""}
                  </div>
                ))}
              </div>
              {/* Rows */}
              {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((dayName, dayIdx) => (
                <div key={dayIdx} className="mb-[2px] flex items-center gap-[2px]">
                  <span className="w-8 text-right text-[9px] font-bold text-[var(--sp-text-subdued)]">{dayName}</span>
                  <div className="flex flex-1 gap-[2px]">
                    {weekdayHourBuckets[dayIdx].map((count, hr) => {
                      const intensity = count / maxCellCount;
                      const bg = count === 0
                        ? "rgba(255,255,255,0.03)"
                        : `rgba(16, 185, 129, ${0.15 + intensity * 0.85})`;
                      return (
                        <div
                          key={hr}
                          className="group relative aspect-square flex-1 rounded-[2px] transition-all hover:scale-125 hover:ring-1 hover:ring-emerald-300"
                          style={{ background: bg }}
                          title={`${dayName} ${hr}:00 — ${count} plays`}
                        />
                      );
                    })}
                  </div>
                </div>
              ))}
              {/* Legend */}
              <div className="mt-3 flex items-center justify-end gap-1 text-[9px] text-[var(--sp-text-subdued)]">
                <span>Less</span>
                {[0.1, 0.3, 0.5, 0.7, 1].map((v, i) => (
                  <span
                    key={i}
                    className="h-3 w-3 rounded-[2px]"
                    style={{ background: `rgba(16, 185, 129, ${0.15 + v * 0.85})` }}
                  />
                ))}
                <span>More</span>
              </div>
            </div>
          </div>
        </section>

        {/* Top tracks */}
        <section className="bl-stat-card rounded-xl p-5">
          <div className="mb-4 flex items-center gap-2">
            <Award size={16} className="text-amber-400" />
            <h2 className="text-sm font-bold text-white">Top Tracks</h2>
          </div>
          {topTracks.length === 0 ? (
            <EmptyState text="No plays yet in this range" />
          ) : (
            <ol className="flex flex-col gap-1.5">
              {topTracks.map((item, i) => (
                <li key={item.track.id}>
                  <button
                    onClick={() => onSelectTrack(item.track)}
                    className="group flex w-full items-center gap-3 rounded-lg p-2 text-left transition-colors hover:bg-white/5"
                  >
                    <span className={`w-5 text-center text-sm font-bold ${i === 0 ? "text-amber-400" : i === 1 ? "text-zinc-300" : i === 2 ? "text-amber-700" : "text-[var(--sp-text-subdued)]"}`}>
                      {i + 1}
                    </span>
                    {item.track.coverUrl ? (
                      <img src={item.track.coverUrl} alt="" className="h-10 w-10 rounded object-cover" />
                    ) : (
                      <div className="flex h-10 w-10 items-center justify-center rounded bg-gradient-to-br from-emerald-500/40 to-teal-700/40">
                        <Music2 size={14} className="text-white/60" />
                      </div>
                    )}
                    <div className="min-w-0 flex-1">
                      <div className="truncate text-sm font-medium text-white group-hover:text-emerald-300">{item.track.title}</div>
                      <div className="truncate text-xs text-[var(--sp-text-subdued)]">{item.track.artists.join(", ")}</div>
                    </div>
                    <span className="rounded-full bg-emerald-500/10 px-2 py-0.5 text-[10px] font-bold text-emerald-300">
                      {item.count} plays
                    </span>
                  </button>
                </li>
              ))}
            </ol>
          )}
        </section>

        {/* Top artists */}
        <section className="bl-stat-card rounded-xl p-5">
          <div className="mb-4 flex items-center gap-2">
            <User size={16} className="text-cyan-400" />
            <h2 className="text-sm font-bold text-white">Top Artists</h2>
          </div>
          {topArtists.length === 0 ? (
            <EmptyState text="No plays yet in this range" />
          ) : (
            <ul className="flex flex-col gap-1.5">
              {topArtists.map(([name, count], i) => (
                <li key={name}>
                  <button
                    onClick={() => onSelectArtist(name)}
                    className="group flex w-full items-center gap-3 rounded-lg p-2 text-left transition-colors hover:bg-white/5"
                  >
                    <span className={`w-5 text-center text-sm font-bold ${i === 0 ? "text-cyan-400" : "text-[var(--sp-text-subdued)]"}`}>
                      {i + 1}
                    </span>
                    <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-br from-cyan-500/40 to-blue-700/40">
                      <User size={14} className="text-white/70" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="truncate text-sm font-medium text-white group-hover:text-cyan-300">{name}</div>
                      <div className="mt-1 h-1 w-full overflow-hidden rounded-full bg-white/5">
                        <div
                          className="h-full rounded-full bg-gradient-to-r from-cyan-500 to-blue-400 transition-all"
                          style={{ width: `${(count / topArtists[0][1]) * 100}%` }}
                        />
                      </div>
                    </div>
                    <span className="text-[10px] font-bold text-[var(--sp-text-subdued)]">{count} plays</span>
                  </button>
                </li>
              ))}
            </ul>
          )}
        </section>

        {/* Top albums */}
        <section className="bl-stat-card rounded-xl p-5">
          <div className="mb-4 flex items-center gap-2">
            <Disc3 size={16} className="text-fuchsia-400" />
            <h2 className="text-sm font-bold text-white">Top Albums</h2>
          </div>
          {topAlbums.length === 0 ? (
            <EmptyState text="No plays yet in this range" />
          ) : (
            <ul className="flex flex-col gap-1.5">
              {topAlbums.map(([album, count], i) => (
                <li key={album}>
                  <button
                    onClick={() => onSelectAlbum(album)}
                    className="group flex w-full items-center gap-3 rounded-lg p-2 text-left transition-colors hover:bg-white/5"
                  >
                    <span className={`w-5 text-center text-sm font-bold ${i === 0 ? "text-fuchsia-400" : "text-[var(--sp-text-subdued)]"}`}>
                      {i + 1}
                    </span>
                    <div className="flex h-10 w-10 items-center justify-center rounded bg-gradient-to-br from-fuchsia-500/40 to-purple-700/40">
                      <Disc3 size={14} className="text-white/70" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="truncate text-sm font-medium text-white group-hover:text-fuchsia-300">{album}</div>
                      <div className="truncate text-xs text-[var(--sp-text-subdued)]">{count} plays</div>
                    </div>
                  </button>
                </li>
              ))}
            </ul>
          )}
        </section>

        {/* Top genres list (with progress bars) */}
        <section className="bl-stat-card rounded-xl p-5">
          <div className="mb-4 flex items-center gap-2">
            <TrendingUp size={16} className="text-rose-400" />
            <h2 className="text-sm font-bold text-white">Genre Breakdown</h2>
          </div>
          {topGenres.length === 0 ? (
            <EmptyState text="No plays yet in this range" />
          ) : (
            <ul className="flex flex-col gap-2">
              {topGenres.map(([genre, count], i) => (
                <li key={genre}>
                  <div className="flex items-center justify-between text-sm">
                    <span className="font-medium text-white">{genre}</span>
                    <span className="text-[10px] font-bold text-[var(--sp-text-subdued)]">{count} plays</span>
                  </div>
                  <div className="mt-1 h-2 w-full overflow-hidden rounded-full bg-white/5">
                    <div
                      className="h-full rounded-full transition-all"
                      style={{
                        width: `${(count / topGenres[0][1]) * 100}%`,
                        background: `linear-gradient(to right, ${GENRE_DONUT_COLORS[i % GENRE_DONUT_COLORS.length]}, ${GENRE_DONUT_COLORS[(i + 1) % GENRE_DONUT_COLORS.length]})`,
                      }}
                    />
                  </div>
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>
    </div>
  );
}

function StatCard({ icon, label, value, accent, sublabel, spark, sparkColor }: {
  icon: React.ReactNode;
  label: string;
  value: string;
  accent: string;
  sublabel: string;
  spark?: number[];
  sparkColor?: string;
}) {
  const sparkPath = useMemo(() => {
    if (!spark || spark.length === 0) return "";
    const max = Math.max(1, ...spark);
    const w = 80;
    const h = 24;
    const step = w / Math.max(1, spark.length - 1);
    return spark.map((v, i) => `${i === 0 ? "M" : "L"} ${i * step} ${h - (v / max) * h}`).join(" ");
  }, [spark]);

  return (
    <div className="bl-stat-card group relative overflow-hidden rounded-xl p-4 transition-transform hover:scale-[1.02]">
      <div className={`absolute inset-0 bg-gradient-to-br ${accent} opacity-10 transition-opacity group-hover:opacity-20`} />
      <div className="relative">
        <div className="mb-3 flex items-start justify-between">
          <div className={`inline-flex rounded-lg bg-gradient-to-br ${accent} p-2 text-white shadow-lg`}>
            {icon}
          </div>
          {spark && sparkPath && (
            <svg width="80" height="24" viewBox="0 0 80 24" className="opacity-60">
              <path d={sparkPath} fill="none" stroke={sparkColor || "#10b981"} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          )}
        </div>
        <div className="text-2xl font-extrabold text-white">{value}</div>
        <div className="mt-0.5 text-xs font-medium text-white/70">{label}</div>
        <div className="mt-1 text-[10px] text-[var(--sp-text-subdued)]">{sublabel}</div>
      </div>
    </div>
  );
}

function EmptyState({ text }: { text: string }) {
  return (
    <div className="flex h-32 items-center justify-center text-xs text-[var(--sp-text-subdued)]">
      {text}
    </div>
  );
}
