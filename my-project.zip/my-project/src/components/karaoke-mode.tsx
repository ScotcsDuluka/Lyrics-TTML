"use client";
import { memo, useEffect, useRef, useState } from "react";
import { parseSpicyTTML } from "@/lib/spicy-ttml";
import { X, Minimize2 } from "lucide-react";
import type { Track } from "@/lib/types";

interface Props {
  track: Track | null;
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  onSeek: (s: number) => void;
  onClose: () => void;
}

export const KaraokeMode = memo(function KaraokeMode({ track, isPlaying, currentTime, duration, onSeek, onClose }: Props) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const scrollRef = useRef<HTMLDivElement | null>(null);
  const lineRefs = useRef<(HTMLDivElement | null)[]>([]);
  const [parsed, setParsed] = useState<Awaited<ReturnType<typeof parseSpicyTTML>> | null>(null);
  const [activeIdx, setActiveIdx] = useState(-1);
  const lastActiveRef = useRef(-1);
  const rafRef = useRef<number | null>(null);

  useEffect(() => {
    if (!track?.lyricsUrl) { setParsed(null); return; }
    let cancelled = false;
    (async () => {
      try {
        const res = await fetch(track.lyricsUrl);
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const text = await res.text();
        if (cancelled) return;
        const p = parseSpicyTTML(text);
        if (cancelled) return;
        setParsed(p);
        setActiveIdx(-1);
        lastActiveRef.current = -1;
        if (scrollRef.current) scrollRef.current.scrollTop = 0;
      } catch (e) { console.error("[KaraokeMode] failed:", e); setParsed(null); }
    })();
    return () => { cancelled = true; };
  }, [track?.lyricsUrl]);

  // Get current audio time from global audio element
  const getTime = () => {
    const audio = document.querySelector("audio");
    return audio?.currentTime ?? 0;
  };

  useEffect(() => {
    if (!parsed || parsed.Content.length === 0) return;
    const tick = () => {
      const t = getTime();
      const lines = parsed.Content;
      let idx = -1;
      for (let i = 0; i < lines.length; i++) {
        if (lines[i].StartTime <= t && t < lines[i].EndTime) { idx = i; break; }
      }
      if (idx === -1) {
        for (let i = lines.length - 1; i >= 0; i--) {
          if (lines[i].StartTime <= t) { idx = i; break; }
        }
      }
      if (idx !== lastActiveRef.current) {
        lastActiveRef.current = idx;
        setActiveIdx(idx);
        if (idx >= 0 && lineRefs.current[idx]) {
          lineRefs.current[idx]!.scrollIntoView({ behavior: "smooth", block: "center" });
        }
      }
      rafRef.current = requestAnimationFrame(tick);
    };
    rafRef.current = requestAnimationFrame(tick);
    return () => { if (rafRef.current) cancelAnimationFrame(rafRef.current); };
  }, [parsed]);

  // ESC to close
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.code === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  if (!parsed || parsed.Content.length === 0) {
    return (
      <div className="bl-karaoke-overlay">
        <div className="text-white/30 text-lg">No lyrics available</div>
        <button onClick={onClose} className="mt-4 text-white/50 hover:text-white">
          <X size={24} />
        </button>
      </div>
    );
  }

  return (
    <div className="bl-karaoke-overlay" ref={containerRef}>
      {/* Header */}
      <div className="absolute top-0 left-0 right-0 z-10 flex items-center justify-between p-4 bg-gradient-to-b from-black/80 to-transparent">
        <div className="flex items-center gap-3">
          {track?.coverUrl && (
            <img src={track.coverUrl} alt="" className="h-10 w-10 rounded object-cover shadow-lg" />
          )}
          <div>
            <div className="text-sm font-medium text-white">{track?.title}</div>
            <div className="text-xs text-white/50">{track?.artists.join(", ")}</div>
          </div>
        </div>
        <button onClick={onClose} className="rounded-full p-2 text-white/50 hover:text-white hover:bg-white/10 transition-colors">
          <Minimize2 size={20} />
        </button>
      </div>

      {/* Lyrics */}
      <div ref={scrollRef} className="h-full w-full max-w-3xl overflow-y-auto px-8 bl-scroll" style={{ padding: "20vh 2rem 30vh" }}>
        {parsed.Content.map((line, i) => {
          const isActive = i === activeIdx;
          const isPast = i < activeIdx;
          if (line.IsInterlude || line.Content.length === 0) {
            return (
              <div
                key={i}
                ref={el => { lineRefs.current[i] = el; }}
                className={`bl-karaoke-line ${isActive ? "Active" : isPast ? "Sung" : "NotSung"}`}
                style={{ height: "2em" }}
                onClick={() => {
                  const audio = document.querySelector("audio");
                  if (audio) audio.currentTime = line.StartTime;
                }}
              />
            );
          }
          const lead = line.Content[0]?.Lead;
          const syllables = lead?.Syllables ?? [];
          return (
            <div
              key={i}
              ref={el => { lineRefs.current[i] = el; }}
              className={`bl-karaoke-line ${isActive ? "Active" : isPast ? "Sung" : "NotSung"}`}
              onClick={() => {
                const audio = document.querySelector("audio");
                if (audio) audio.currentTime = line.StartTime;
              }}
            >
              {syllables.map((syl, j) => (
                <span key={j} className={`word ${j === syllables.length - 1 ? "LastWordInLine" : ""} ${syl.IsPartOfWord ? "PartOfWord" : ""}`} style={{ display: "inline-block" }}>
                  {syl.Text}
                </span>
              ))}
            </div>
          );
        })}
      </div>

      {/* Progress bar at bottom */}
      <div className="absolute bottom-0 left-0 right-0 z-10 bg-gradient-to-t from-black/80 to-transparent p-4 pt-8">
        <div className="mx-auto max-w-2xl">
          <div className="flex items-center gap-2">
            <span className="text-[10px] tabular-nums text-white/50">
              {fmt(currentTime)}
            </span>
            <div className="relative h-1 flex-1 rounded-full bg-white/10">
              <div
                className="absolute left-0 top-0 h-full rounded-full bg-emerald-400 transition-all"
                style={{ width: `${duration > 0 ? (currentTime / duration) * 100 : 0}%` }}
              />
              <input
                type="range"
                min={0}
                max={duration > 0 ? duration : 1}
                step={0.05}
                value={currentTime}
                onChange={e => onSeek(parseFloat(e.target.value))}
                className="absolute inset-0 w-full opacity-0 cursor-pointer"
                aria-label="Seek"
              />
            </div>
            <span className="text-[10px] tabular-nums text-white/50">
              {fmt(duration)}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
});

function fmt(s: number): string {
  if (!isFinite(s) || s < 0) return "0:00";
  const t = Math.floor(s);
  return `${Math.floor(t/60)}:${(t%60).toString().padStart(2,"0")}`;
}
