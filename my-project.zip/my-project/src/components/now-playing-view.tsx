"use client";
import { memo, useEffect, useState, useMemo, useRef } from "react";
import { X, Play, Pause, SkipBack, SkipForward, Heart, Shuffle, Repeat, Repeat1, Mic2, ListMusic, Maximize2, Minimize2, Waves, Volume2, VolumeX, Volume1, ChevronRight } from "lucide-react";
import type { Track } from "@/lib/types";
import type { RepeatMode } from "@/lib/types";
import { LyricsView } from "./lyrics-view";
import { AudioVisualizer } from "./audio-visualizer";

interface Props {
  track: Track | null;
  nextTrack: Track | null;
  currentTime: number;
  duration: number;
  isPlaying: boolean;
  volume: number;
  muted: boolean;
  shuffle: boolean;
  repeat: RepeatMode;
  isLiked: boolean;
  onClose: () => void;
  onToggle: () => void;
  onSeek: (s: number) => void;
  onPrev: () => void;
  onNext: () => void;
  onVolume: (v: number) => void;
  onToggleMute: () => void;
  onToggleShuffle: () => void;
  onToggleRepeat: () => void;
  onToggleLike: () => void;
  frequencyData?: Uint8Array;
  waveformData?: Uint8Array;
}

function fmt(s: number): string {
  if (!isFinite(s) || s < 0) return "0:00";
  const t = Math.floor(s);
  return `${Math.floor(t/60)}:${(t%60).toString().padStart(2,"0")}`;
}

// ── Particle System ──────────────────────────────────────────────────────────

interface Particle {
  id: number;
  symbol: string;
  left: number;
  size: number;
  duration: number;
  delay: number;
  opacity: number;
}

function generateParticles(count: number): Particle[] {
  const symbols = ["♪", "♫", "♩", "♬"];
  return Array.from({ length: count }, (_, i) => ({
    id: i,
    symbol: symbols[Math.floor(Math.random() * symbols.length)],
    left: Math.random() * 90 + 5,
    size: Math.random() * 14 + 10,
    duration: Math.random() * 5 + 6,
    delay: Math.random() * 8,
    opacity: Math.random() * 0.4 + 0.3,
  }));
}

// ── Component ────────────────────────────────────────────────────────────────

export const NowPlayingView = memo(function NowPlayingView(p: Props) {
  const [showLyrics, setShowLyrics] = useState(false);
  const [vizMode, setVizMode] = useState<"bars" | "wave" | "circular">("bars");
  const [trackKey, setTrackKey] = useState(p.track?.id ?? "");
  const [trackTransitioning, setTrackTransitioning] = useState(false);
  const prevTrackIdRef = useRef<string>(p.track?.id ?? "");
  const pct = p.duration > 0 ? (p.currentTime / p.duration) * 100 : 0;

  // Generate particles (stable across renders)
  const particles = useMemo(() => generateParticles(18), []);

  // Track transition detection
  useEffect(() => {
    const currentId = p.track?.id ?? "";
    if (currentId !== prevTrackIdRef.current && prevTrackIdRef.current !== "") {
      setTrackTransitioning(true);
      const timer = setTimeout(() => {
        setTrackKey(currentId);
        setTrackTransitioning(false);
      }, 300);
      return () => clearTimeout(timer);
    } else {
      setTrackKey(currentId);
    }
    prevTrackIdRef.current = currentId;
  }, [p.track?.id]);

  // Generate waveform bars from frequency data
  const waveformBars = useMemo(() => {
    if (!p.waveformData || p.waveformData.length === 0) {
      // Fallback: generate random bars
      return Array.from({ length: 60 }, () => Math.random() * 0.6 + 0.2);
    }
    const count = 60;
    const step = p.waveformData.length / count;
    return Array.from({ length: count }, (_, i) => {
      const start = Math.floor(i * step);
      const end = Math.floor((i + 1) * step);
      let sum = 0;
      for (let j = start; j < end; j++) sum += p.waveformData![j] ?? 128;
      return ((sum / (end - start || 1)) - 0) / 255;
    });
  }, [p.waveformData]);

  // Esc to close
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") p.onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [p.onClose]);

  if (!p.track) return null;

  const coverUrl = p.track.coverUrl;
  const hasVisualizerData = p.frequencyData && p.waveformData && p.frequencyData.length > 0;

  return (
    <div className="fixed inset-0 z-[9990] flex bl-np-in">
      {/* Blurred background */}
      <div className="absolute inset-0 overflow-hidden">
        {coverUrl ? (
          <img src={coverUrl} alt="" className="h-full w-full object-cover scale-125 blur-3xl opacity-40" />
        ) : (
          <div className="h-full w-full bg-gradient-to-br from-emerald-900/60 to-black" />
        )}
        <div className="absolute inset-0 bg-black/50" />

        {/* Enhanced Background: Animated gradient orbs */}
        <div className="bl-np-gradient-orb" style={{ width: "400px", height: "400px", top: "10%", left: "5%", background: "radial-gradient(circle, rgba(16,185,129,0.4), transparent 70%)", animationDelay: "0s" }} />
        <div className="bl-np-gradient-orb" style={{ width: "350px", height: "350px", bottom: "15%", right: "10%", background: "radial-gradient(circle, rgba(20,184,166,0.35), transparent 70%)", animationDelay: "-7s" }} />
        <div className="bl-np-gradient-orb" style={{ width: "300px", height: "300px", top: "50%", left: "50%", background: "radial-gradient(circle, rgba(52,211,153,0.3), transparent 70%)", animationDelay: "-14s" }} />

        {/* Vignette effect */}
        <div className="bl-np-vignette" />
      </div>

      {/* Particle System: floating music notes */}
      {p.isPlaying && (
        <div className="absolute inset-0 z-[2] pointer-events-none overflow-hidden">
          {particles.map((particle) => (
            <span
              key={particle.id}
              className="bl-note-particle"
              style={{
                left: `${particle.left}%`,
                bottom: "5%",
                fontSize: `${particle.size}px`,
                opacity: particle.opacity,
                animationDuration: `${particle.duration}s`,
                animationDelay: `${particle.delay}s`,
                animationIterationCount: "infinite",
              }}
            >
              {particle.symbol}
            </span>
          ))}
        </div>
      )}

      {/* Audio Visualizer behind content */}
      {hasVisualizerData && (
        <div className="absolute inset-0 z-[1] opacity-30 pointer-events-none">
          <AudioVisualizer
            frequencyData={p.frequencyData!}
            waveformData={p.waveformData!}
            isPlaying={p.isPlaying}
            mode={vizMode}
            color="#1db954"
          />
        </div>
      )}

      {/* Content */}
      <div className="relative z-10 flex w-full flex-col p-6 overflow-y-auto bl-scroll">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowLyrics(!showLyrics)}
              className={`flex items-center gap-2 rounded-full px-4 py-2 text-sm font-semibold transition-colors ${
                showLyrics ? "bg-white text-black" : "bg-white/10 text-white hover:bg-white/20"
              }`}
            >
              <Mic2 size={16} />
              {showLyrics ? "Lyrics" : "Now Playing"}
            </button>
            {/* Visualizer mode toggle */}
            {hasVisualizerData && (
              <button
                onClick={() => setVizMode(prev => prev === "bars" ? "wave" : prev === "wave" ? "circular" : "bars")}
                className="flex items-center gap-2 rounded-full bg-white/10 px-3 py-2 text-sm text-white/70 hover:bg-white/20 hover:text-white transition-colors"
                title="Change visualization"
              >
                <Waves size={14} />
                <span className="text-xs capitalize">{vizMode}</span>
              </button>
            )}
          </div>
          <button
            onClick={p.onClose}
            className="flex h-10 w-10 items-center justify-center rounded-full bg-white/10 text-white hover:bg-white/20 transition-colors"
            title="Close"
          >
            <X size={20} />
          </button>
        </div>

        <div className="flex flex-1 flex-col items-center justify-center gap-8 lg:flex-row lg:items-start">
          {/* Left: Album art + Visualizer */}
          <div className="flex flex-col items-center gap-6 lg:w-1/2">
            {/* Vinyl Record + Album Art */}
            <div className="relative w-full max-w-md aspect-square">
              {/* Vinyl record (behind album art) */}
              <div
                className={`bl-vinyl-record absolute inset-0 ${p.isPlaying ? "spinning" : "paused"}`}
              >
                <div className="bl-vinyl-grooves" />
                <div className="bl-vinyl-center-dot" />
                <div className="bl-vinyl-center-hole" />
              </div>

              {/* Album art (circular, on top of vinyl) */}
              <div
                key={trackKey}
                className={`bl-track-transition absolute inset-[12%] rounded-full overflow-hidden shadow-2xl ${
                  trackTransitioning ? "bl-track-transition-exit" : "bl-track-transition-active"
                }`}
              >
                {coverUrl ? (
                  <img
                    src={coverUrl}
                    alt={p.track.title}
                    className="h-full w-full object-cover"
                    style={{ borderRadius: "50%" }}
                  />
                ) : (
                  <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-emerald-600/40 to-teal-900/40" style={{ borderRadius: "50%" }}>
                    <Maximize2 size={64} className="text-white/30" />
                  </div>
                )}
                {/* Mini visualizer overlay on album art */}
                {hasVisualizerData && p.isPlaying && (
                  <div className="absolute bottom-0 left-0 right-0 h-16 opacity-40">
                    <AudioVisualizer
                      frequencyData={p.frequencyData!}
                      waveformData={p.waveformData!}
                      isPlaying={p.isPlaying}
                      mode="bars"
                      color="#1db954"
                    />
                  </div>
                )}
              </div>
            </div>

            {/* Track info + controls */}
            <div className="w-full max-w-md">
              <div key={trackKey} className={`mb-4 ${trackTransitioning ? "" : "bl-track-info-slide"}`}>
                <h1 className="truncate text-3xl font-extrabold text-white">{p.track.title}</h1>
                <p className="mt-1 truncate text-lg text-white/70">{p.track.artists.join(", ")}</p>
                <div className="flex items-center gap-2 mt-0.5">
                  {p.track.album && (
                    <p className="truncate text-sm text-white/50">{p.track.album}</p>
                  )}
                  {/* Genre Badge */}
                  {p.track.genre && (
                    <span className="inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 whitespace-nowrap">
                      {p.track.genre}
                    </span>
                  )}
                </div>
              </div>

              {/* Progress bar (enhanced) */}
              <div className="mb-4">
                <div
                  className="group relative h-1.5 cursor-pointer rounded-full bg-white/20 overflow-visible"
                  onClick={(e) => {
                    const rect = e.currentTarget.getBoundingClientRect();
                    const ratio = (e.clientX - rect.left) / rect.width;
                    p.onSeek(ratio * p.duration);
                  }}
                >
                  {/* Waveform preview behind progress bar */}
                  <div className="bl-waveform-preview">
                    {waveformBars.map((bar, i) => (
                      <div
                        key={i}
                        className="bl-waveform-bar"
                        style={{ height: `${Math.max(15, bar * 100)}%` }}
                      />
                    ))}
                  </div>

                  {/* Gradient fill (emerald to teal) */}
                  <div
                    className="absolute inset-y-0 left-0 rounded-full"
                    style={{
                      width: `${pct}%`,
                      background: "linear-gradient(90deg, #10b981, #14b8a6)",
                    }}
                  />
                  {/* Progress knob with glow */}
                  <div
                    className="bl-progress-glow absolute top-1/2 h-3.5 w-3.5 -translate-y-1/2 rounded-full bg-white opacity-0 transition-opacity group-hover:opacity-100"
                    style={{ left: `calc(${pct}% - 7px)` }}
                  />
                </div>
                {/* Time markers */}
                <div className="relative mt-1.5">
                  <div className="flex justify-between text-xs text-white/60 tabular-nums">
                    <span>{fmt(p.currentTime)}</span>
                    <span>{fmt(p.duration)}</span>
                  </div>
                  {/* Time marker ticks at 25%, 50%, 75% */}
                  <div className="absolute top-0 left-0 right-0 pointer-events-none">
                    <div className="relative h-0">
                      {[25, 50, 75].map((mark) => (
                        <span
                          key={mark}
                          className="absolute -top-3.5 text-[9px] text-white/25"
                          style={{ left: `${mark}%`, transform: "translateX(-50%)" }}
                        >
                          │
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* Controls */}
              <div className="flex items-center justify-between">
                <button
                  onClick={p.onToggleLike}
                  className={`rounded-full p-2 transition-colors ${p.isLiked ? "text-emerald-400" : "text-white/60 hover:text-white"}`}
                >
                  <Heart size={22} fill={p.isLiked ? "currentColor" : "none"} />
                </button>
                <div className="flex items-center gap-5">
                  <button
                    onClick={p.onToggleShuffle}
                    className={`transition-colors ${p.shuffle ? "text-emerald-400" : "text-white/60 hover:text-white"}`}
                  >
                    <Shuffle size={20} />
                  </button>
                  <button onClick={p.onPrev} className="text-white/80 hover:text-white">
                    <SkipBack size={28} fill="currentColor" />
                  </button>
                  <button
                    onClick={p.onToggle}
                    className="flex h-14 w-14 items-center justify-center rounded-full bg-white text-black shadow-lg transition-transform hover:scale-105 active:scale-95"
                  >
                    {p.isPlaying ? <Pause size={26} fill="currentColor" /> : <Play size={26} fill="currentColor" className="ml-1" />}
                  </button>
                  <button onClick={p.onNext} className="text-white/80 hover:text-white">
                    <SkipForward size={28} fill="currentColor" />
                  </button>
                  <button
                    onClick={p.onToggleRepeat}
                    className={`transition-colors ${p.repeat !== "off" ? "text-emerald-400" : "text-white/60 hover:text-white"}`}
                  >
                    {p.repeat === "one" ? <Repeat1 size={20} /> : <Repeat size={20} />}
                  </button>
                </div>
                <div className="flex items-center gap-2 w-28">
                  <button onClick={p.onToggleMute} className="text-white/60 hover:text-white transition-colors">
                    {p.muted || p.volume === 0 ? (
                      <VolumeX size={18} />
                    ) : p.volume < 0.33 ? (
                      <Volume1 size={18} />
                    ) : p.volume < 0.66 ? (
                      <Volume1 size={18} />
                    ) : (
                      <Volume2 size={18} />
                    )}
                  </button>
                  <input
                    type="range" min={0} max={1} step={0.01}
                    value={p.muted ? 0 : p.volume}
                    onChange={e => p.onVolume(parseFloat(e.target.value))}
                    className="bl-slider flex-1"
                    style={{ "--progress": `${(p.muted ? 0 : p.volume) * 100}%` } as React.CSSProperties}
                    aria-label="Volume"
                  />
                </div>
              </div>

              {/* Up Next Preview */}
              {p.nextTrack && (
                <div className="mt-5">
                  <div className="flex items-center gap-1.5 mb-2">
                    <span className="text-xs font-semibold uppercase tracking-wider text-white/40">Next up</span>
                    <ChevronRight size={12} className="text-white/30" />
                  </div>
                  <div className="bl-up-next-card" onClick={p.onNext}>
                    <div className="h-10 w-10 flex-shrink-0 rounded overflow-hidden bg-white/10">
                      {p.nextTrack.coverUrl ? (
                        <img src={p.nextTrack.coverUrl} alt="" className="h-full w-full object-cover" />
                      ) : (
                        <div className="flex h-full w-full items-center justify-center">
                          <ListMusic size={14} className="text-white/30" />
                        </div>
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="truncate text-sm font-medium text-white/90">{p.nextTrack.title}</p>
                      <p className="truncate text-xs text-white/50">{p.nextTrack.artists.join(", ")}</p>
                    </div>
                    <SkipForward size={16} className="text-white/30 flex-shrink-0" />
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Right: Lyrics or credits */}
          <div className="lg:w-1/2 lg:max-h-[70vh]">
            {showLyrics && p.track.lyricsUrl ? (
              <div className="h-[50vh] lg:h-[60vh] rounded-xl overflow-hidden bg-black/30">
                <LyricsView lyricsUrl={p.track.lyricsUrl} />
              </div>
            ) : showLyrics ? (
              <div className="flex h-[50vh] items-center justify-center text-white/40">
                <div className="text-center">
                  <Mic2 size={48} className="mx-auto mb-3 opacity-30" />
                  <p className="text-sm">No lyrics available for this track</p>
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                {/* Full visualizer panel */}
                {hasVisualizerData && (
                  <div className="rounded-xl bg-black/30 p-4 backdrop-blur-sm overflow-hidden" style={{ height: "200px" }}>
                    <AudioVisualizer
                      frequencyData={p.frequencyData!}
                      waveformData={p.waveformData!}
                      isPlaying={p.isPlaying}
                      mode={vizMode}
                      color="#1db954"
                    />
                  </div>
                )}
                {/* About this track */}
                <div className="rounded-xl bg-black/30 p-6 backdrop-blur-sm">
                  <h3 className="mb-4 text-sm font-bold uppercase tracking-wider text-white/60">About this track</h3>
                  <div className="space-y-3">
                    <div>
                      <span className="text-xs text-white/50">Title</span>
                      <p className="text-white">{p.track.title}</p>
                    </div>
                    <div>
                      <span className="text-xs text-white/50">Artist</span>
                      <p className="text-white">{p.track.artists.join(", ")}</p>
                    </div>
                    {p.track.album && (
                      <div>
                        <span className="text-xs text-white/50">Album</span>
                        <p className="text-white">{p.track.album}</p>
                      </div>
                    )}
                    {p.track.genre && (
                      <div>
                        <span className="text-xs text-white/50">Genre</span>
                        <p className="text-white">{p.track.genre}</p>
                      </div>
                    )}
                    <div>
                      <span className="text-xs text-white/50">Duration</span>
                      <p className="text-white">{fmt(p.duration || 0)}</p>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      <style>{`
        @keyframes bl-np-in {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        .bl-np-in { animation: bl-np-in 0.3s ease-out; }
      `}</style>
    </div>
  );
});
