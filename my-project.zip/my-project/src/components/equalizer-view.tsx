"use client";
import { useState, useMemo, useEffect } from "react";
import {
  Sliders, Play, RotateCcw, Save, Volume2, VolumeX, Gauge,
  Waves, AudioWaveform, Headphones, Sparkles, Check, ChevronRight
} from "lucide-react";
import { EQ_PRESETS, EQ_FREQS, type EqPreset } from "@/lib/eq-presets";

interface Props {
  currentPresetId: string;
  currentGains: number[];
  currentVolume: number;
  currentSpeed: number;
  onApplyPreset: (preset: EqPreset) => void;
  onGainChange: (index: number, gain: number) => void;
  onVolumeChange: (volume: number) => void;
  onSpeedChange: (speed: number) => void;
  onResetEq: () => void;
}

const PLAYBACK_SPEEDS = [0.5, 0.75, 1, 1.25, 1.5, 1.75, 2];

function formatFreq(hz: number): string {
  if (hz >= 1000) return `${hz / 1000}k`;
  return `${hz}`;
}

export function EqualizerView({
  currentPresetId,
  currentGains,
  currentVolume,
  currentSpeed,
  onApplyPreset,
  onGainChange,
  onVolumeChange,
  onSpeedChange,
  onResetEq,
}: Props) {
  const [localGains, setLocalGains] = useState<number[]>(currentGains);
  const [muted, setMuted] = useState(false);
  const [savedPresets, setSavedPresets] = useState<{ name: string; gains: number[] }[]>([]);
  const [showSaveDialog, setShowSaveDialog] = useState(false);
  const [newPresetName, setNewPresetName] = useState("");

  // Sync local gains when preset changes externally
  useEffect(() => {
    setLocalGains(currentGains);
  }, [currentGains]);

  const isPresetActive = (preset: EqPreset): boolean => {
    return preset.gains.every((g, i) => g === localGains[i]);
  };

  const isModified = useMemo(() => {
    return !EQ_PRESETS.some(p => p.gains.every((g, i) => g === localGains[i]));
  }, [localGains]);

  const handleSliderChange = (index: number, value: number) => {
    const next = [...localGains];
    next[index] = value;
    setLocalGains(next);
    onGainChange(index, value);
  };

  const handleReset = () => {
    setLocalGains([0, 0, 0, 0, 0, 0, 0, 0, 0, 0]);
    onResetEq();
  };

  const handleSavePreset = () => {
    if (!newPresetName.trim()) return;
    setSavedPresets(prev => [...prev, { name: newPresetName.trim(), gains: [...localGains] }]);
    setNewPresetName("");
    setShowSaveDialog(false);
  };

  // Compute the "shape" of the EQ curve for the visual preview
  const curvePoints = useMemo(() => {
    const W = 600;
    const H = 120;
    const pad = 20;
    const step = (W - pad * 2) / Math.max(1, EQ_FREQS.length - 1);
    return EQ_FREQS.map((_, i) => {
      const x = pad + i * step;
      const y = H / 2 - (localGains[i] / 12) * (H / 2 - pad);
      return { x, y };
    });
  }, [localGains]);

  const curvePath = useMemo(() => {
    if (curvePoints.length === 0) return "";
    let path = `M ${curvePoints[0].x} ${curvePoints[0].y}`;
    for (let i = 1; i < curvePoints.length; i++) {
      const prev = curvePoints[i - 1];
      const curr = curvePoints[i];
      const cx = (prev.x + curr.x) / 2;
      path += ` Q ${cx} ${prev.y} ${cx} ${(prev.y + curr.y) / 2} T ${curr.x} ${curr.y}`;
    }
    return path;
  }, [curvePoints]);

  return (
    <div className="bl-scroll flex-1 px-6 pb-32 bl-view-transition">
      {/* Hero header */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-fuchsia-900/40 via-purple-900/30 to-indigo-900/20 px-6 pt-10 pb-8 mb-6">
        <div className="pointer-events-none absolute inset-0 -z-10 opacity-50">
          <div className="absolute -top-20 -left-20 h-60 w-60 rounded-full bg-fuchsia-500/30 blur-3xl" />
          <div className="absolute -bottom-20 -right-20 h-60 w-60 rounded-full bg-purple-500/30 blur-3xl" />
        </div>
        <div className="flex items-center gap-4">
          <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-fuchsia-500 to-purple-600 shadow-lg shadow-fuchsia-500/30">
            <Sliders size={32} className="text-white" />
          </div>
          <div>
            <div className="text-xs font-bold uppercase tracking-wider text-white/70">Audio Settings</div>
            <h1 className="mt-1 text-3xl font-extrabold tracking-tight text-white sm:text-4xl bl-gradient-text">
              Equalizer & Playback
            </h1>
            <p className="mt-1 text-sm text-white/70">
              {EQ_PRESETS.length} presets • {EQ_FREQS.length} frequency bands • {PLAYBACK_SPEEDS.length} playback speeds
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        {/* ────────── EQ Visualizer + Sliders ────────── */}
        <section className="lg:col-span-2 rounded-xl border border-white/5 bg-black/30 p-6 backdrop-blur-sm">
          <div className="mb-4 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <AudioWaveform size={18} className="text-fuchsia-400" />
              <h2 className="text-sm font-bold text-white">10-Band Equalizer</h2>
              {isModified && (
                <span className="rounded-full bg-amber-500/20 px-2 py-0.5 text-[10px] font-bold text-amber-400">
                  Modified
                </span>
              )}
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={handleReset}
                className="inline-flex items-center gap-1.5 rounded-full bg-white/5 px-3 py-1.5 text-xs font-bold text-[var(--sp-text-subdued)] transition-all hover:bg-white/10 hover:text-white"
              >
                <RotateCcw size={12} />
                Reset
              </button>
              <button
                onClick={() => setShowSaveDialog(s => !s)}
                className="inline-flex items-center gap-1.5 rounded-full bg-fuchsia-500/10 px-3 py-1.5 text-xs font-bold text-fuchsia-300 transition-all hover:bg-fuchsia-500/20"
              >
                <Save size={12} />
                Save custom
              </button>
            </div>
          </div>

          {/* Save dialog */}
          {showSaveDialog && (
            <div className="mb-4 rounded-lg border border-fuchsia-500/30 bg-fuchsia-500/5 p-3">
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={newPresetName}
                  onChange={e => setNewPresetName(e.target.value)}
                  placeholder="Preset name (e.g. My Bass Boost)"
                  className="flex-1 rounded-md border border-white/10 bg-white/5 px-3 py-1.5 text-sm text-white placeholder:text-[var(--sp-text-subdued)] focus:border-fuchsia-500/40 focus:outline-none"
                  onKeyDown={e => { if (e.key === "Enter") handleSavePreset(); }}
                />
                <button
                  onClick={handleSavePreset}
                  disabled={!newPresetName.trim()}
                  className="rounded-md bg-fuchsia-500 px-3 py-1.5 text-sm font-bold text-white transition-colors hover:bg-fuchsia-400 disabled:opacity-50"
                >
                  Save
                </button>
              </div>
            </div>
          )}

          {/* EQ Curve SVG preview */}
          <div className="mb-6 overflow-hidden rounded-lg bg-gradient-to-b from-white/[0.03] to-transparent p-4">
            <svg viewBox="0 0 600 120" className="w-full" style={{ height: 120 }} preserveAspectRatio="none">
              <defs>
                <linearGradient id="eqCurveFill" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#d946ef" stopOpacity="0.4" />
                  <stop offset="100%" stopColor="#d946ef" stopOpacity="0" />
                </linearGradient>
                <linearGradient id="eqCurveLine" x1="0" y1="0" x2="1" y2="0">
                  <stop offset="0%" stopColor="#a855f7" />
                  <stop offset="50%" stopColor="#d946ef" />
                  <stop offset="100%" stopColor="#ec4899" />
                </linearGradient>
              </defs>
              {/* Grid lines */}
              {[0, 1, 2, 3].map(i => (
                <line key={i} x1="20" x2="580" y1={20 + i * 26} y2={20 + i * 26} stroke="rgba(255,255,255,0.05)" strokeWidth="1" />
              ))}
              {/* Center line (0 dB) */}
              <line x1="20" x2="580" y1="60" y2="60" stroke="rgba(255,255,255,0.15)" strokeWidth="1" strokeDasharray="4 4" />
              {/* Curve fill */}
              {curvePath && <path d={`${curvePath} L 580 60 L 20 60 Z`} fill="url(#eqCurveFill)" />}
              {/* Curve line */}
              {curvePath && <path d={curvePath} fill="none" stroke="url(#eqCurveLine)" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />}
              {/* Frequency points */}
              {curvePoints.map((p, i) => (
                <circle key={i} cx={p.x} cy={p.y} r="3" fill="#d946ef" stroke="#0a0a0a" strokeWidth="2" />
              ))}
            </svg>
          </div>

          {/* Vertical sliders */}
          <div className="flex justify-between gap-2 sm:gap-4">
            {EQ_FREQS.map((freq, i) => {
              const gain = localGains[i] ?? 0;
              const pct = ((gain + 12) / 24) * 100; // -12 to +12 → 0% to 100%
              return (
                <div key={i} className="flex flex-1 flex-col items-center gap-2">
                  {/* dB readout */}
                  <div className={`text-[10px] font-bold tabular-nums ${gain > 0 ? "text-fuchsia-400" : gain < 0 ? "text-cyan-400" : "text-[var(--sp-text-subdued)]"}`}>
                    {gain > 0 ? "+" : ""}{gain}
                  </div>
                  {/* Slider track */}
                  <div className="group/slider relative h-32 w-8 flex items-center justify-center">
                    {/* Track background (groove) */}
                    <div className="absolute h-full w-1.5 rounded-full bg-gradient-to-b from-white/5 via-white/10 to-white/5" />
                    {/* Center line (0 dB reference) */}
                    <div className="absolute h-px w-3 bg-white/25" style={{ top: "50%" }} />
                    {/* Tick marks at +6 and -6 */}
                    <div className="absolute h-px w-2 bg-white/10" style={{ top: "25%" }} />
                    <div className="absolute h-px w-2 bg-white/10" style={{ top: "75%" }} />
                    {/* Filled portion (from center to current value) */}
                    <div
                      className="absolute w-1.5 rounded-full shadow-[0_0_8px_rgba(217,70,239,0.4)]"
                      style={{
                        background: gain >= 0
                          ? "linear-gradient(to top, rgba(217,70,239,0.3), #d946ef)"
                          : "linear-gradient(to bottom, rgba(6,182,212,0.3), #06b6d4)",
                        boxShadow: gain !== 0 ? (gain > 0 ? "0 0 10px rgba(217,70,239,0.5)" : "0 0 10px rgba(6,182,212,0.5)") : "none",
                        bottom: gain >= 0 ? "50%" : `${50 - Math.abs(pct - 50)}%`,
                        top: gain >= 0 ? `${100 - pct}%` : "50%",
                      }}
                    />
                    {/* Thumb */}
                    <div
                      className="absolute h-5 w-5 rounded-full bg-white shadow-lg ring-2 ring-fuchsia-500 transition-transform group-hover/slider:scale-110"
                      style={{
                        bottom: `calc(${pct}% - 10px)`,
                        boxShadow: "0 2px 8px rgba(0,0,0,0.4), 0 0 0 2px rgba(217,70,239,0.4)",
                      }}
                    />
                    {/* Glow halo behind thumb */}
                    <div
                      className="absolute h-7 w-7 rounded-full bg-fuchsia-500/20 blur-md pointer-events-none"
                      style={{ bottom: `calc(${pct}% - 14px)` }}
                    />
                    {/* Invisible range input for interaction */}
                    <input
                      type="range"
                      min={-12}
                      max={12}
                      step={1}
                      value={gain}
                      onChange={e => handleSliderChange(i, parseInt(e.target.value))}
                      className="absolute inset-0 h-full w-full cursor-pointer opacity-0"
                      style={{ writingMode: "vertical-lr" as any, WebkitAppearance: "slider-vertical" as any }}
                      aria-label={`${formatFreq(freq)} Hz`}
                    />
                  </div>
                  {/* Frequency label */}
                  <div className="text-[10px] font-medium text-[var(--sp-text-subdued)]">
                    {formatFreq(freq)}
                  </div>
                </div>
              );
            })}
          </div>
          <div className="mt-3 flex justify-between text-[9px] text-[var(--sp-text-subdued)]">
            <span>Sub</span>
            <span>Bass</span>
            <span>Low Mids</span>
            <span>Mids</span>
            <span>High Mids</span>
            <span>Presence</span>
            <span>Brilliance</span>
          </div>
        </section>

        {/* ────────── Presets ────────── */}
        <section className="rounded-xl border border-white/5 bg-black/30 p-6 backdrop-blur-sm">
          <div className="mb-4 flex items-center gap-2">
            <Sparkles size={18} className="text-purple-400" />
            <h2 className="text-sm font-bold text-white">Presets</h2>
            <span className="ml-auto text-[10px] text-[var(--sp-text-subdued)]">{EQ_PRESETS.length + savedPresets.length} total</span>
          </div>
          <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
            {EQ_PRESETS.map(preset => {
              const active = isPresetActive(preset);
              return (
                <button
                  key={preset.id}
                  onClick={() => onApplyPreset(preset)}
                  className={`group relative flex items-center gap-3 rounded-lg border p-3 text-left transition-all ${
                    active
                      ? "border-fuchsia-500/50 bg-fuchsia-500/10 shadow-lg shadow-fuchsia-500/20"
                      : "border-white/5 bg-white/5 hover:bg-white/10 hover:border-white/10"
                  }`}
                >
                  <div className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-gradient-to-br ${preset.color} text-lg`}>
                    {preset.icon}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-1.5">
                      <span className={`truncate text-sm font-bold ${active ? "text-fuchsia-300" : "text-white"}`}>{preset.name}</span>
                      {active && <Check size={12} className="shrink-0 text-fuchsia-400" />}
                    </div>
                    <div className="truncate text-[10px] text-[var(--sp-text-subdued)]">{preset.description}</div>
                  </div>
                </button>
              );
            })}
            {/* Saved custom presets */}
            {savedPresets.map((preset, i) => {
              const active = preset.gains.every((g, j) => g === localGains[j]);
              return (
                <button
                  key={`saved-${i}`}
                  onClick={() => onApplyPreset({ ...preset, id: `saved-${i}`, icon: "★", color: "from-amber-500/40 to-orange-700/40", description: "Your custom preset" })}
                  className={`group relative flex items-center gap-3 rounded-lg border p-3 text-left transition-all ${
                    active
                      ? "border-amber-500/50 bg-amber-500/10 shadow-lg shadow-amber-500/20"
                      : "border-white/5 bg-white/5 hover:bg-white/10 hover:border-white/10"
                  }`}
                >
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-gradient-to-br from-amber-500/40 to-orange-700/40 text-lg">
                    ★
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-1.5">
                      <span className={`truncate text-sm font-bold ${active ? "text-amber-300" : "text-white"}`}>{preset.name}</span>
                      {active && <Check size={12} className="shrink-0 text-amber-400" />}
                    </div>
                    <div className="truncate text-[10px] text-[var(--sp-text-subdued)]">Custom preset</div>
                  </div>
                </button>
              );
            })}
          </div>
        </section>

        {/* ────────── Volume & Playback Speed ────────── */}
        <section className="rounded-xl border border-white/5 bg-black/30 p-6 backdrop-blur-sm">
          <div className="mb-4 flex items-center gap-2">
            <Gauge size={18} className="text-emerald-400" />
            <h2 className="text-sm font-bold text-white">Volume & Playback</h2>
          </div>

          {/* Volume control */}
          <div className="mb-6">
            <div className="mb-2 flex items-center justify-between">
              <label className="text-xs font-bold uppercase tracking-wider text-white/60">
                <Volume2 size={12} className="inline mr-1.5" />
                Volume
              </label>
              <span className="text-xs font-bold tabular-nums text-white">{Math.round(currentVolume * 100)}%</span>
            </div>
            <div className="flex items-center gap-3">
              <button
                onClick={() => { setMuted(!muted); onVolumeChange(muted ? currentVolume : 0); }}
                className="rounded-full p-2 text-[var(--sp-text-subdued)] hover:bg-white/10 hover:text-white transition-colors"
                aria-label={muted ? "Unmute" : "Mute"}
              >
                {muted || currentVolume === 0 ? <VolumeX size={16} /> : <Volume2 size={16} />}
              </button>
              <div className="relative h-1.5 flex-1 rounded-full bg-white/10">
                <div
                  className="absolute inset-y-0 left-0 rounded-full bg-gradient-to-r from-emerald-500 to-teal-400"
                  style={{ width: `${(muted ? 0 : currentVolume) * 100}%` }}
                />
                <div
                  className="absolute top-1/2 h-3.5 w-3.5 -translate-y-1/2 rounded-full bg-white shadow"
                  style={{ left: `calc(${(muted ? 0 : currentVolume) * 100}% - 7px)` }}
                />
                <input
                  type="range"
                  min={0}
                  max={1}
                  step={0.01}
                  value={muted ? 0 : currentVolume}
                  onChange={e => { onVolumeChange(parseFloat(e.target.value)); setMuted(false); }}
                  className="absolute inset-0 h-full w-full cursor-pointer opacity-0"
                  aria-label="Volume"
                />
              </div>
            </div>
          </div>

          {/* Playback speed */}
          <div>
            <div className="mb-2 flex items-center justify-between">
              <label className="text-xs font-bold uppercase tracking-wider text-white/60">
                <Gauge size={12} className="inline mr-1.5" />
                Playback Speed
              </label>
              <span className="text-xs font-bold tabular-nums text-white">{currentSpeed.toFixed(2)}x</span>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {PLAYBACK_SPEEDS.map(speed => {
                const active = Math.abs(currentSpeed - speed) < 0.01;
                return (
                  <button
                    key={speed}
                    onClick={() => onSpeedChange(speed)}
                    className={`rounded-full px-3 py-1.5 text-xs font-bold transition-all ${
                      active
                        ? "bg-emerald-500 text-black shadow-lg shadow-emerald-500/30"
                        : "bg-white/5 text-[var(--sp-text-subdued)] hover:bg-white/10 hover:text-white"
                    }`}
                  >
                    {speed === 1 ? "1× Normal" : `${speed}×`}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Audio info card */}
          <div className="mt-6 rounded-lg border border-white/5 bg-white/5 p-4">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-emerald-500/20">
                <Headphones size={16} className="text-emerald-400" />
              </div>
              <div className="flex-1">
                <div className="text-xs font-bold text-white">Audio Engine</div>
                <div className="text-[10px] text-[var(--sp-text-subdued)]">
                  Web Audio API • BiquadFilter × 10 • 10-band parametric EQ
                </div>
              </div>
              <ChevronRight size={14} className="text-[var(--sp-text-subdued)]" />
            </div>
          </div>
        </section>
      </div>

      {/* Quick tutorial / tip */}
      <div className="mt-6 rounded-xl border border-emerald-500/20 bg-gradient-to-r from-emerald-500/10 to-teal-500/5 px-5 py-4">
        <div className="flex items-start gap-3">
          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-emerald-500/20">
            <Waves size={16} className="text-emerald-300" />
          </div>
          <div className="flex-1">
            <h3 className="text-sm font-bold text-white">Pro tip: Match the EQ to your music</h3>
            <p className="mt-1 text-xs text-white/70">
              Try <span className="font-bold text-emerald-300">Bass Boost</span> for electronic & hip-hop,
              <span className="font-bold text-amber-300"> Vocal</span> for podcasts & acoustic sets,
              and <span className="font-bold text-fuchsia-300">Rock</span> for guitar-driven tracks.
              Your custom presets are saved locally for the session.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
