#!/bin/bash
set -e

# Directories
SONGS_DIR="/home/z/my-project/public/songs"
COVERS_DIR="/home/z/my-project/public/covers"
LYRICS_DIR="/home/z/my-project/public/lyrics"
REPO_DIR="/tmp/Lyrics-TTML"

# Create directories
mkdir -p "$SONGS_DIR" "$COVERS_DIR" "$LYRICS_DIR"

# Counter for track IDs
TRACK_ID=1

# Function to process a song
process_song() {
    local mp3_file="$1"
    local ttml_file="$2"
    local playlist="$3"
    local track_num="$TRACK_ID"
    
    local basename_mp3=$(basename "$mp3_file")
    local dest_mp3="track${track_num}.mp3"
    local dest_cover="cover${track_num}.jpg"
    local dest_ttml="thai-${track_num}.ttml"
    
    echo "Processing track $track_num: $basename_mp3"
    
    # Copy MP3
    cp "$mp3_file" "$SONGS_DIR/$dest_mp3"
    
    # Extract cover art from MP3
    ffmpeg -y -i "$mp3_file" -an -vcodec copy "$COVERS_DIR/$dest_cover" 2>/dev/null || {
        # If cover extraction fails, try with different approach
        ffmpeg -y -i "$mp3_file" -vf "scale=640:640" -frames:v 1 "$COVERS_DIR/$dest_cover" 2>/dev/null || echo "  Warning: No cover art found for $basename_mp3"
    }
    
    # Copy TTML if exists
    if [ -f "$ttml_file" ]; then
        cp "$ttml_file" "$LYRICS_DIR/$dest_ttml"
        echo "  TTML copied"
    else
        echo "  Warning: No TTML file found"
    fi
    
    TRACK_ID=$((TRACK_ID + 1))
}

echo "=== Processing TTML Playlist ==="
for mp3_file in "$REPO_DIR/Playlists/TTML/"*.mp3; do
    basename_mp3=$(basename "$mp3_file" .mp3)
    # Find matching TTML file
    ttml_file=""
    for ttml in "$REPO_DIR/Playlists/TTML/"*.ttml; do
        ttml_base=$(basename "$ttml" .ttml)
        # Check if TTML name matches (partial match)
        if echo "$basename_mp3" | grep -qF "$(echo "$ttml_base" | sed 's/-Full//;s/-Full-ReMake//')" || \
           echo "$ttml_base" | grep -qF "$(echo "$basename_mp3" | cut -c1-5)"; then
            ttml_file="$ttml"
            break
        fi
    done
    
    process_song "$mp3_file" "$ttml_file" "TTML"
done

echo ""
echo "=== Processing Damn Playlist ==="
for mp3_file in "$REPO_DIR/Playlists/Damn/"*.mp3; do
    basename_mp3=$(basename "$mp3_file" .mp3)
    # Find matching TTML file
    ttml_file=""
    for ttml in "$REPO_DIR/Playlists/Damn/"*.ttml; do
        ttml_base=$(basename "$ttml" .ttml)
        # Check if TTML name matches (partial match)
        if echo "$basename_mp3" | grep -qF "$(echo "$ttml_base" | sed 's/-Full//')" || \
           echo "$ttml_base" | grep -qF "$(echo "$basename_mp3" | cut -c1-5)"; then
            ttml_file="$ttml"
            break
        fi
    done
    
    process_song "$mp3_file" "$ttml_file" "Damn"
done

echo ""
echo "Total tracks processed: $((TRACK_ID - 1))"
echo "Files in songs/: $(ls "$SONGS_DIR" | wc -l)"
echo "Files in covers/: $(ls "$COVERS_DIR" | wc -l)"  
echo "Files in lyrics/: $(ls "$LYRICS_DIR" | wc -l)"
