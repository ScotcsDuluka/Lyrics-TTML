import ZAI from 'z-ai-web-dev-sdk';
import fs from 'fs';

const COVERS = [
  { file: 'cover1.png', prompt: 'Album cover art for "Midnight Serenade", dreamy nocturnal landscape with moonlit ocean waves, deep blue and purple tones, ethereal atmospheric mood, minimalist digital art, no text' },
  { file: 'cover2.png', prompt: 'Album cover art for "Sunrise Melody", warm golden sunrise over misty mountains, orange and pink gradient sky, serene morning atmosphere, minimalist digital art, no text' },
  { file: 'cover3.png', prompt: 'Album cover art for "Ocean Whispers", abstract underwater scene with coral reef, teal and aquamarine colors, gentle light rays through water, minimalist digital art, no text' },
  { file: 'cover4.png', prompt: 'Album cover art for "Forest Rain", lush green forest with rain droplets, emerald and deep green tones, misty atmospheric mood, minimalist digital art, no text' },
  { file: 'cover5.png', prompt: 'Album cover art for "City Lights", neon city skyline at night, purple and magenta glow, urban cyberpunk atmosphere, minimalist digital art, no text' },
];

async function main() {
  const zai = await ZAI.create();
  for (const c of COVERS) {
    try {
      const resp = await zai.images.generations.create({ prompt: c.prompt, size: '1024x1024' });
      const b64 = resp.data[0].base64;
      fs.writeFileSync(`/home/z/my-project/public/covers/${c.file}`, Buffer.from(b64, 'base64'));
      console.log(`✓ ${c.file}`);
    } catch (e) {
      console.error(`✗ ${c.file}: ${e.message}`);
    }
  }
}
main();
