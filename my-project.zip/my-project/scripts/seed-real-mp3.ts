import { PrismaClient } from "@prisma/client";
import { execSync } from "child_process";
import { readFileSync, writeFileSync, mkdirSync, copyFileSync, existsSync, readdirSync, statSync } from "fs";
import { join, basename } from "path";

const prisma = new PrismaClient();
const TTML_DIR = "/tmp/Lyrics-TTML";
const PUBLIC_SONGS = "/home/z/my-project/public/songs";
const PUBLIC_LYRICS = "/home/z/my-project/public/lyrics";
const PUBLIC_COVERS = "/home/z/my-project/public/covers";

// Find MP3 files in TTML and Damn folders
interface SongEntry {
  mp3Path: string;
  ttmlPath: string | null;
  title: string;
  artists: string[];
  album: string;
  duration: number;
  playlist: string;
  genre: string;
}

const songs: SongEntry[] = [];

// Helper: parse TTML metadata
function parseTTMLMeta(filePath: string) {
  const content = readFileSync(filePath, "utf8");
  const titleMatch = content.match(/key="musicName"\s+value="([^"]+)"/);
  const title = titleMatch ? titleMatch[1] : basename(filePath, ".ttml");
  const artistMatches = [...content.matchAll(/key="artists"\s+value="([^"]+)"/g)];
  const artists = artistMatches.map(m => m[1]);
  const albumMatch = content.match(/key="album"\s+value="([^"]+)"/);
  const album = albumMatch ? albumMatch[1] : title;
  const durMatch = content.match(/body[^>]*dur="([^"]+)"/);
  let duration = 30;
  if (durMatch) {
    const durStr = durMatch[1];
    const parts = durStr.match(/^(?:(\d+):)?(\d+):(\d+(?:\.\d+)?)$/);
    if (parts) {
      duration = (parts[1] ? parseInt(parts[1]) : 0) * 3600 + parseInt(parts[2]) * 60 + parseFloat(parts[3]);
    }
  }
  return { title, artists, album, duration };
}

// Helper: get duration from MP3
function getMp3Duration(mp3Path: string): number {
  try {
    const out = execSync(`ffprobe -v quiet -print_format json -show_format "${mp3Path}"`, { encoding: "utf8" });
    const data = JSON.parse(out);
    return parseFloat(data.format?.duration || "30");
  } catch { return 30; }
}

// Helper: extract cover from MP3
function extractCover(mp3Path: string, outputPath: string): boolean {
  try {
    execSync(`ffmpeg -i "${mp3Path}" -an -vcodec copy -update 1 -frames:v 1 "${outputPath}" -y 2>/dev/null`);
    return existsSync(outputPath);
  } catch { return false; }
}

// === TTML folder: MP3 + TTML pairs ===
const ttmlFolder = join(TTML_DIR, "Playlists", "TTML");
const ttmlMp3s = readdirSync(ttmlFolder).filter(f => f.endsWith(".mp3"));
const ttmlLyrics = readdirSync(ttmlFolder).filter(f => f.endsWith(".ttml"));

for (const mp3File of ttmlMp3s) {
  const mp3Path = join(ttmlFolder, mp3File);
  // Find matching TTML file
  const baseName = mp3File.replace(".mp3", "");
  const ttmlFile = ttmlLyrics.find(t => t.replace(".ttml", "") === baseName || t.startsWith(baseName.substring(0, 5)));
  const ttmlPath = ttmlFile ? join(ttmlFolder, ttmlFile) : null;
  
  let meta;
  if (ttmlPath) {
    meta = parseTTMLMeta(ttmlPath);
  } else {
    meta = { title: baseName, artists: ["Unknown"], album: baseName, duration: 30 };
  }
  
  const duration = getMp3Duration(mp3Path);
  songs.push({
    mp3Path,
    ttmlPath,
    title: meta.title,
    artists: meta.artists.length > 0 ? meta.artists : ["Unknown"],
    album: meta.album || meta.title,
    duration,
    playlist: "Thai Hits 🇹🇭",
    genre: "Thai Pop",
  });
}

// === Damn folder: MP3 + TTML pairs ===
const damnFolder = join(TTML_DIR, "Playlists", "Damn");
const damnMp3s = readdirSync(damnFolder).filter(f => f.endsWith(".mp3"));
const damnLyrics = readdirSync(damnFolder).filter(f => f.endsWith(".ttml"));

for (const mp3File of damnMp3s) {
  const mp3Path = join(damnFolder, mp3File);
  const baseName = mp3File.replace(".mp3", "");
  const ttmlFile = damnLyrics.find(t => t.replace(".ttml", "") === baseName || t.startsWith(baseName.substring(0, 5)));
  const ttmlPath = ttmlFile ? join(damnFolder, ttmlFile) : null;
  
  let meta;
  if (ttmlPath) {
    meta = parseTTMLMeta(ttmlPath);
  } else {
    meta = { title: baseName, artists: ["Unknown"], album: baseName, duration: 30 };
  }
  
  const duration = getMp3Duration(mp3Path);
  songs.push({
    mp3Path,
    ttmlPath,
    title: meta.title,
    artists: meta.artists.length > 0 ? meta.artists : ["Unknown"],
    album: meta.album || meta.title,
    duration,
    playlist: "เศร้าซึม 😢",
    genre: "Thai Pop",
  });
}

// === Other folder: TTML + try to find MP3 ===
const otherFolder = join(TTML_DIR, "Other");
const otherTtmls = readdirSync(otherFolder).filter(f => f.endsWith(".ttml"));
const otherMp3s = readdirSync(otherFolder).filter(f => f.endsWith(".mp3"));

for (const ttmlFile of otherTtmls) {
  const ttmlPath = join(otherFolder, ttmlFile);
  const meta = parseTTMLMeta(ttmlPath);
  const baseName = ttmlFile.replace(".ttml", "");
  const mp3File = otherMp3s.find(m => m.replace(".mp3", "") === baseName);
  const mp3Path = mp3File ? join(otherFolder, mp3File) : null;
  
  const duration = mp3Path ? getMp3Duration(mp3Path) : meta.duration;
  songs.push({
    mp3Path: mp3Path || "",
    ttmlPath,
    title: meta.title,
    artists: meta.artists.length > 0 ? meta.artists : ["Unknown"],
    album: meta.album || meta.title,
    duration,
    playlist: "Thai Hits 🇹🇭",
    genre: "Thai Pop",
  });
}

console.log(`\nFound ${songs.length} songs total:\n`);
for (const s of songs) {
  console.log(`  ${s.title} by ${s.artists.join(", ")} [${s.album}] - ${Math.round(s.duration)}s → ${s.playlist} (TTML: ${s.ttmlPath ? "✓" : "✗"})`);
}

// Remove old generated tracks (track11-32) and covers (cover11-32)
console.log("\n=== Cleaning up old generated files ===");
for (let i = 11; i <= 32; i++) {
  const audioPath = join(PUBLIC_SONGS, `track${i}.mp3`);
  const coverPath = join(PUBLIC_COVERS, `cover${i}.png`);
  const ttmlPath = join(PUBLIC_LYRICS, `thai-${i - 10}.ttml`);
  if (existsSync(audioPath)) { execSync(`rm -f "${audioPath}"`); console.log(`  Removed ${audioPath}`); }
  if (existsSync(coverPath)) { execSync(`rm -f "${coverPath}"`); console.log(`  Removed ${coverPath}`); }
  if (existsSync(ttmlPath)) { execSync(`rm -f "${ttmlPath}"`); console.log(`  Removed ${ttmlPath}`); }
}

// Copy MP3 files, extract covers, copy TTML
console.log("\n=== Copying real MP3 files and extracting covers ===");
mkdirSync(PUBLIC_SONGS, { recursive: true });
mkdirSync(PUBLIC_LYRICS, { recursive: true });
mkdirSync(PUBLIC_COVERS, { recursive: true });

for (let i = 0; i < songs.length; i++) {
  const s = songs[i];
  const trackNum = i + 11;
  const audioFileName = `track${trackNum}.mp3`;
  const coverFileName = `cover${trackNum}.jpg`;
  const ttmlFileName = `thai-${i + 1}.ttml`;
  
  const audioDest = join(PUBLIC_SONGS, audioFileName);
  const coverDest = join(PUBLIC_COVERS, coverFileName);
  const ttmlDest = join(PUBLIC_LYRICS, ttmlFileName);
  
  // Copy MP3
  if (s.mp3Path && existsSync(s.mp3Path)) {
    copyFileSync(s.mp3Path, audioDest);
    console.log(`  Copied ${audioFileName} (${(statSync(audioDest).size / 1024 / 1024).toFixed(1)}MB)`);
  } else {
    // Generate sine wave placeholder
    const freq = 220 + (trackNum * 37) % 200;
    execSync(`ffmpeg -f lavfi -i "sine=frequency=${freq}:duration=30" -c:a libmp3lame -q:a 5 "${audioDest}" -y 2>/dev/null`);
    console.log(`  Generated ${audioFileName} (placeholder)`);
  }
  
  // Extract cover from MP3
  let hasCover = false;
  if (s.mp3Path && existsSync(s.mp3Path)) {
    hasCover = extractCover(s.mp3Path, coverDest);
  }
  if (!hasCover) {
    // Generate simple cover with ffmpeg
    const colors = ["ff6b6b", "4ecdc4", "45b7d1", "f9ca24", "6c5ce7", "a29bfe", "fd79a8", "00cec9"];
    const color = colors[i % colors.length];
    try {
      execSync(`ffmpeg -f lavfi -i "color=c=0x${color}:s=512x512:d=1" -frames:v 1 -update 1 "${coverDest}" -y 2>/dev/null`);
      console.log(`  Generated ${coverFileName} (color fill)`);
    } catch {
      console.log(`  Skipped cover for ${s.title}`);
    }
  } else {
    console.log(`  Extracted ${coverFileName} from MP3`);
  }
  
  // Copy TTML
  if (s.ttmlPath && existsSync(s.ttmlPath)) {
    copyFileSync(s.ttmlPath, ttmlDest);
    console.log(`  Copied ${ttmlFileName}`);
  }
  
  // Store file names for DB seeding
  (s as any).audioFileName = audioFileName;
  (s as any).coverFileName = coverFileName;
  (s as any).ttmlFileName = s.ttmlPath ? ttmlFileName : null;
}

// Delete old thai tracks from DB
console.log("\n=== Updating database ===");
const oldThaiTracks = await prisma.track.findMany({ where: { id: { startsWith: "thai-track-" } } });
for (const t of oldThaiTracks) {
  await prisma.playlistTrack.deleteMany({ where: { trackId: t.id } });
  await prisma.like.deleteMany({ where: { trackId: t.id } });
  await prisma.playHistory.deleteMany({ where: { trackId: t.id } });
  await prisma.track.delete({ where: { id: t.id } });
}
console.log(`  Deleted ${oldThaiTracks.length} old thai tracks`);

// Create playlists
const thaiPlaylist = await prisma.playlist.upsert({
  where: { id: "thai-hits-playlist" },
  update: { name: "Thai Hits 🇹🇭", description: "เพลงไทยสุดฮิต - Thai Hits with synced TTML lyrics" },
  create: { id: "thai-hits-playlist", name: "Thai Hits 🇹🇭", description: "เพลงไทยสุดฮิต - Thai Hits with synced TTML lyrics" },
});

const sadPlaylist = await prisma.playlist.upsert({
  where: { id: "thai-sad-playlist" },
  update: { name: "เศร้าซึม 😢", description: "เพลงเศร้า - Thai Sad Songs" },
  create: { id: "thai-sad-playlist", name: "เศร้าซึม 😢", description: "เพลงเศร้า - Thai Sad Songs" },
});

// Seed new tracks
for (let i = 0; i < songs.length; i++) {
  const s = songs[i] as SongEntry & { audioFileName: string; coverFileName: string; ttmlFileName: string | null };
  const trackId = `thai-track-${i + 1}`;
  const coverUrl = `/covers/${s.coverFileName}`;
  const lyricsUrl = s.ttmlFileName ? `/lyrics/${s.ttmlFileName}` : null;
  
  const track = await prisma.track.upsert({
    where: { id: trackId },
    update: {
      title: s.title,
      artists: JSON.stringify(s.artists),
      album: s.album,
      genre: s.genre,
      audioUrl: `/songs/${s.audioFileName}`,
      lyricsUrl,
      coverUrl,
      duration: s.duration,
    },
    create: {
      id: trackId,
      title: s.title,
      artists: JSON.stringify(s.artists),
      album: s.album,
      genre: s.genre,
      audioUrl: `/songs/${s.audioFileName}`,
      lyricsUrl,
      coverUrl,
      duration: s.duration,
    },
  });
  
  const playlistId = s.playlist.includes("เศร้า") ? sadPlaylist.id : thaiPlaylist.id;
  
  const existingPT = await prisma.playlistTrack.findFirst({
    where: { playlistId, trackId: track.id },
  });
  if (!existingPT) {
    await prisma.playlistTrack.create({
      data: { playlistId, trackId: track.id, position: i },
    });
  }
  
  console.log(`  ✅ ${s.title} → ${s.playlist} (lyrics: ${lyricsUrl ? "✓" : "✗"})`);
}

// Update manifest
const manifestPath = join(PUBLIC_SONGS, "manifest.json");
const manifest = JSON.parse(readFileSync(manifestPath, "utf8"));
// Remove old thai entries from manifest
manifest.tracks = manifest.tracks.filter((t: any) => !t.audioUrl.includes("track1") || parseInt(t.audioUrl.match(/track(\d+)/)?.[1] || "0") <= 10);
// Add new thai tracks
for (let i = 0; i < songs.length; i++) {
  const s = songs[i] as SongEntry & { audioFileName: string; coverFileName: string; ttmlFileName: string | null };
  manifest.tracks.push({
    title: s.title,
    artists: s.artists,
    album: s.album,
    audioUrl: `/songs/${s.audioFileName}`,
    coverUrl: `/covers/${s.coverFileName}`,
    lyricsUrl: s.ttmlFileName ? `/lyrics/${s.ttmlFileName}` : null,
    duration: s.duration,
    genre: s.genre,
    playlist: s.playlist,
  });
}
writeFileSync(manifestPath, JSON.stringify(manifest, null, 2));

await prisma.$disconnect();
console.log("\n✅ Done! All Thai songs seeded with real MP3 + TTML lyrics!");
