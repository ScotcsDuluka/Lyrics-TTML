/**
 * Clean up duplicate playlists from the database.
 * Only keep: "Thai Hits 🇹🇭" (id: thai-hits-playlist) and "เศร้าซึม 😢" (id: thai-sad-playlist)
 */
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

const DELETE_IDS = [
  "cms5zpfvo0000rmmm307qmybb",  // Chill Vibes (from manifest)
  "cms5zpfvx0007rmmmm6h18zi8",  // Morning Mood (from manifest)
  "cms5zpfvz000brmmmwil5d088",  // Nature (from manifest)
  "cms5zpfw2000frmmmzdb9ukke",  // Urban Vibes (from manifest)
  "cms5zpfw4000jrmmm3cdnbd8h",  // Liked Songs (from manifest)
  "chill-vibes",                  // Chill Vibes (from seed)
  "liked-songs",                  // Liked Songs (from seed)
];

async function main() {
  console.log("Cleaning up duplicate playlists...");
  
  for (const id of DELETE_IDS) {
    try {
      const playlist = await prisma.playlist.findUnique({ where: { id } });
      if (playlist) {
        // Delete PlaylistTracks first (cascade should handle this, but be safe)
        await prisma.playlistTrack.deleteMany({ where: { playlistId: id } });
        await prisma.playlist.delete({ where: { id } });
        console.log(`  Deleted: ${playlist.name} (${id})`);
      } else {
        console.log(`  Not found: ${id}`);
      }
    } catch (e) {
      console.error(`  Error deleting ${id}:`, e);
    }
  }
  
  // Verify remaining playlists
  const remaining = await prisma.playlist.findMany();
  console.log("\nRemaining playlists:");
  for (const p of remaining) {
    console.log(`  ${p.name} (${p.id}) - isSystem: ${p.isSystem}`);
  }
  
  await prisma.$disconnect();
  console.log("\nDone!");
}

main().catch(console.error);
