/**
 * Seed the database with real Thai songs from the GitHub repo.
 * Uses real MP3 files with embedded cover art, TTML lyrics files.
 */
import { PrismaClient } from "@prisma/client";
import { readFileSync } from "fs";
import { join } from "path";

const prisma = new PrismaClient();

const MANIFEST_PATH = "/home/z/my-project/public/songs/manifest.json";

interface ManifestTrack {
  title: string;
  artists: string[];
  album: string;
  audioUrl: string;
  coverUrl: string;
  lyricsUrl: string | null;
  duration: number;
  genre: string;
  playlist: string;
}

async function seed() {
  // Read manifest
  const manifest = JSON.parse(readFileSync(MANIFEST_PATH, "utf8"));
  const tracks: ManifestTrack[] = manifest.tracks;

  console.log(`Found ${tracks.length} tracks in manifest`);

  // Create playlists
  const thaiPlaylist = await prisma.playlist.upsert({
    where: { id: "thai-hits-playlist" },
    update: { name: "Thai Hits 🇹🇭", description: "เพลงไทยสุดฮิต - Thai Hits with synced TTML lyrics" },
    create: { id: "thai-hits-playlist", name: "Thai Hits 🇹🇭", description: "เพลงไทยสุดฮิต - Thai Hits with synced TTML lyrics" },
  });

  const sadPlaylist = await prisma.playlist.upsert({
    where: { id: "thai-sad-playlist" },
    update: { name: "เศร้าซึม 😢", description: "เพลงเศร้า - Thai Sad Songs with synced TTML lyrics" },
    create: { id: "thai-sad-playlist", name: "เศร้าซึม 😢", description: "เพลงเศร้า - Thai Sad Songs with synced TTML lyrics" },
  });

  // Keep the original playlists too
  const chillPlaylist = await prisma.playlist.upsert({
    where: { id: "chill-vibes" },
    update: { name: "Chill Vibes", description: "Relax and unwind" },
    create: { id: "chill-vibes", name: "Chill Vibes", description: "Relax and unwind" },
  });

  const likedPlaylist = await prisma.playlist.upsert({
    where: { id: "liked-songs" },
    update: { name: "Liked Songs", description: "Your favorite tracks" },
    create: { id: "liked-songs", name: "Liked Songs", description: "Your favorite tracks" },
  });

  // Delete old tracks first (clean slate)
  await prisma.playlistTrack.deleteMany({});
  await prisma.track.deleteMany({});
  console.log("Cleared old tracks");

  // Seed tracks
  for (let i = 0; i < tracks.length; i++) {
    const t = tracks[i];
    const trackId = `track-${i + 1}`;

    const track = await prisma.track.create({
      data: {
        id: trackId,
        title: t.title,
        artists: JSON.stringify(t.artists),
        album: t.album,
        genre: t.genre || "Thai Pop",
        audioUrl: t.audioUrl,
        lyricsUrl: t.lyricsUrl || null,
        coverUrl: t.coverUrl,
        duration: t.duration,
      },
    });

    // Determine playlist
    const playlistId = t.playlist === "เศร้าซึม 😢" ? sadPlaylist.id : thaiPlaylist.id;

    await prisma.playlistTrack.create({
      data: {
        playlistId,
        trackId: track.id,
        position: i,
      },
    });

    console.log(`Seeded: ${t.title} → ${t.playlist}`);
  }

  await prisma.$disconnect();
  console.log("Done seeding!");
}

seed().catch(console.error);
