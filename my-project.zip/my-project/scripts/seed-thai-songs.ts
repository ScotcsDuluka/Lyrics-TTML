/**
 * Parse TTML files from the GitHub repo, extract metadata, generate audio,
 * copy TTML files to public/lyrics, and seed the database with Thai songs.
 */
import { PrismaClient } from "@prisma/client";
import { execSync } from "child_process";
import { readFileSync, writeFileSync, mkdirSync, copyFileSync, existsSync } from "fs";
import { join, basename } from "path";

const prisma = new PrismaClient();

const TTML_DIR = "/tmp/Lyrics-TTML";
const PUBLIC_SONGS = "/home/z/my-project/public/songs";
const PUBLIC_LYRICS = "/home/z/my-project/public/lyrics";
const PUBLIC_COVERS = "/home/z/my-project/public/covers";

// Parse TTML to extract metadata
function parseTTMLMeta(filePath: string) {
  const content = readFileSync(filePath, "utf8");
  
  // Extract musicName
  const titleMatch = content.match(/key="musicName"\s+value="([^"]+)"/);
  const title = titleMatch ? titleMatch[1] : basename(filePath, ".ttml");
  
  // Extract artists
  const artistMatches = [...content.matchAll(/key="artists"\s+value="([^"]+)"/g)];
  const artists = artistMatches.map(m => m[1]);
  
  // Extract album
  const albumMatch = content.match(/key="album"\s+value="([^"]+)"/);
  const album = albumMatch ? albumMatch[1] : title;
  
  // Extract duration from body dur attribute
  const durMatch = content.match(/body[^>]*dur="([^"]+)"/);
  let duration = 30; // default 30 seconds
  if (durMatch) {
    const durStr = durMatch[1];
    // Parse "3:07.299" or "04:22.224" format
    const parts = durStr.match(/^(?:(\d+):)?(\d+):(\d+(?:\.\d+)?)$/);
    if (parts) {
      const hours = parts[1] ? parseInt(parts[1]) : 0;
      const minutes = parseInt(parts[2]);
      const seconds = parseFloat(parts[3]);
      duration = hours * 3600 + minutes * 60 + seconds;
    } else {
      const num = parseFloat(durStr);
      if (!isNaN(num)) duration = num;
    }
  }
  
  return { title, artists, album, duration };
}

// Find all TTML files
const ttmlFiles: string[] = [];
function findTTML(dir: string) {
  const items = execSync(`ls -1 "${dir}"`, { encoding: "utf8" }).trim().split("\n");
  for (const item of items) {
    const full = join(dir, item);
    if (existsSync(full) && full.endsWith(".ttml")) {
      ttmlFiles.push(full);
    }
  }
}

findTTML(join(TTML_DIR, "Playlists", "TTML"));
findTTML(join(TTML_DIR, "Playlists", "Damn"));
findTTML(join(TTML_DIR, "Other"));

console.log(`Found ${ttmlFiles.length} TTML files`);

// Parse all TTML files
const songs = ttmlFiles.map((fp, idx) => {
  const meta = parseTTMLMeta(fp);
  return {
    ...meta,
    filePath: fp,
    trackNum: idx + 11, // start from 11 since we have 10 existing tracks
    ttmlFileName: `thai-${idx + 1}.ttml`,
    audioFileName: `track${idx + 11}.mp3`,
    coverFileName: `cover${idx + 11}.png`,
  };
});

// Print parsed songs
for (const s of songs) {
  console.log(`  ${s.title} by ${s.artists.join(", ")} [${s.album}] - ${Math.round(s.duration)}s`);
}

// Generate audio files with ffmpeg (sine waves at different frequencies)
mkdirSync(PUBLIC_SONGS, { recursive: true });
for (const s of songs) {
  const audioPath = join(PUBLIC_SONGS, s.audioFileName);
  if (!existsSync(audioPath)) {
    const freq = 220 + (s.trackNum * 37) % 200; // varying frequencies
    const dur = Math.min(s.duration, 30); // cap at 30 seconds for demo
    console.log(`Generating ${s.audioFileName} (${dur}s, ${freq}Hz)...`);
    execSync(`ffmpeg -f lavfi -i "sine=frequency=${freq}:duration=${dur}" -c:a libmp3lame -q:a 5 "${audioPath}" -y 2>/dev/null`);
  }
}

// Copy TTML files to public/lyrics
mkdirSync(PUBLIC_LYRICS, { recursive: true });
for (const s of songs) {
  const destPath = join(PUBLIC_LYRICS, s.ttmlFileName);
  copyFileSync(s.filePath, destPath);
  console.log(`Copied ${s.ttmlFileName}`);
}

// Update manifest.json
const manifestPath = join(PUBLIC_SONGS, "manifest.json");
const existingManifest = JSON.parse(readFileSync(manifestPath, "utf8"));
const newTracks = songs.map(s => ({
  title: s.title,
  artists: s.artists,
  album: s.album,
  audioUrl: `/songs/${s.audioFileName}`,
  coverUrl: `/covers/${s.coverFileName}`,
  lyricsUrl: `/lyrics/${s.ttmlFileName}`,
  duration: Math.min(s.duration, 30),
  genre: "Thai Pop",
  playlist: "Thai Hits 🇹🇭",
}));
existingManifest.tracks = [...existingManifest.tracks, ...newTracks];
writeFileSync(manifestPath, JSON.stringify(existingManifest, null, 2));
console.log("Updated manifest.json");

// Seed database
async function seed() {
  // Create "Thai Hits" playlist
  const thaiPlaylist = await prisma.playlist.upsert({
    where: { id: "thai-hits-playlist" },
    update: { name: "Thai Hits 🇹🇭", description: "เพลงไทยสุดฮิต - Thai Hits with synced TTML lyrics" },
    create: { id: "thai-hits-playlist", name: "Thai Hits 🇹🇭", description: "เพลงไทยสุดฮิต - Thai Hits with synced TTML lyrics" },
  });
  
  // Create "Thai Sad Songs" playlist for Damn folder
  const sadPlaylist = await prisma.playlist.upsert({
    where: { id: "thai-sad-playlist" },
    update: { name: "เศร้าซึม 😢", description: "เพลงเศร้า - Thai Sad Songs" },
    create: { id: "thai-sad-playlist", name: "เศร้าซึม 😢", description: "เพลงเศร้า - Thai Sad Songs" },
  });

  for (let i = 0; i < songs.length; i++) {
    const s = songs[i];
    const trackId = `thai-track-${i + 1}`;
    
    const track = await prisma.track.upsert({
      where: { id: trackId },
      update: {
        title: s.title,
        artists: JSON.stringify(s.artists),
        album: s.album,
        genre: "Thai Pop",
        audioUrl: `/songs/${s.audioFileName}`,
        lyricsUrl: `/lyrics/${s.ttmlFileName}`,
        coverUrl: `/covers/${s.coverFileName}`,
        duration: Math.min(s.duration, 30),
      },
      create: {
        id: trackId,
        title: s.title,
        artists: JSON.stringify(s.artists),
        album: s.album,
        genre: "Thai Pop",
        audioUrl: `/songs/${s.audioFileName}`,
        lyricsUrl: `/lyrics/${s.ttmlFileName}`,
        coverUrl: `/covers/${s.coverFileName}`,
        duration: Math.min(s.duration, 30),
      },
    });
    
    // Determine which playlist this song belongs to
    const isDamn = s.filePath.includes("/Damn/");
    const playlistId = isDamn ? sadPlaylist.id : thaiPlaylist.id;
    
    // Add to playlist
    const existingPT = await prisma.playlistTrack.findFirst({
      where: { playlistId, trackId: track.id },
    });
    if (!existingPT) {
      await prisma.playlistTrack.create({
        data: {
          playlistId,
          trackId: track.id,
          position: i,
        },
      });
    }
    
    console.log(`Seeded: ${s.title} → ${isDamn ? "เศร้าซึม" : "Thai Hits"}`);
  }
  
  await prisma.$disconnect();
  console.log("Done seeding!");
}

seed().catch(console.error);
