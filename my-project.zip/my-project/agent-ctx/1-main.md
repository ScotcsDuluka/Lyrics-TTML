---
Task ID: 1
Agent: Main
Task: Clean up duplicate playlists, improve sidebar, add Karaoke Mode, fix cover art, integrate Poll

Work Log:
- Read worklog.md and understood full project history (3 previous task stages)
- Cleaned up 7 duplicate playlists from database using cleanup script:
  - Deleted: Chill Vibes (cms5zpfvo0000rmmm307qmybb), Morning Mood (cms5zpfvx0007rmmmm6h18zi8), Nature (cms5zpfvz000brmmmwil5d088), Urban Vibes (cms5zpfw2000frmmmzdb9ukke), Liked Songs (cms5zpfw4000jrmmm3cdnbd8h) - from manifest
  - Deleted: Chill Vibes (chill-vibes), Liked Songs (liked-songs) - from seed
  - Kept: Thai Hits 🇹🇭 (thai-hits-playlist) and เศร้าซึม 😢 (thai-sad-playlist)
- Improved sidebar component:
  - Added "Now Playing" mini section at top with cover art, track title, artist, and animated bars
  - Added "Running Poll" indicator with green ping dot and RadioTower icon
  - Added new props: currentTrack, isPlaying, pollActive
  - Improved LibraryItem styling: rounded-lg, shadow-lg on covers, group hover effects
  - Added bl-bar-anim CSS for sidebar now playing animation
- Added Karaoke Mode:
  - Created /src/components/karaoke-mode.tsx: full-screen lyrics overlay with large text, pulsing glow effect on active line
  - Added karaoke mode toggle button in player bar (Mic icon, next to lyrics toggle)
  - Added karaokeMode state and onToggleKaraoke prop to PlayerBar
  - Added KaraokeMode component to page.tsx
  - Added CSS: bl-karaoke-overlay, bl-karaoke-line, bl-karaoke-glow animations
- Fixed cover art display:
  - Verified all 20 tracks in database have correct .jpg cover URLs matching actual files
  - All cover files in /public/covers/ are .jpg (cover1.jpg through cover20.jpg)
  - Updated playlist cover URLs: Thai Hits → /covers/cover1.jpg, Sad → /covers/cover14.jpg
  - No hardcoded .png extensions found in source code
- Integrated Poll functionality:
  - Added useChatPoll hook to page.tsx
  - handlePollUserCommand: parses "Play [song] by [artist]" commands (English + Thai), finds matching track, plays it
  - handlePollAiReply: shows toast notification with AI reply text
  - pollActive state set to true when poll commands are received
  - Poll API at /api/poll verified working (returns entries from commands.log)
- Fixed lint error in seed-real-mp3.ts (require() → statSync import)
- Verified project builds successfully with `npx next build` (0 errors)

Stage Summary:
- Database cleaned: only 2 playlists remain (Thai Hits, เศร้าซึม)
- Sidebar now shows: Now Playing mini section, Poll indicator, improved card styling
- Karaoke Mode: full-screen lyrics with pulsing glow, accessible via Mic button in player bar
- Cover art: all 20 tracks + 2 playlists have correct .jpg URLs
- Poll integration: commands from commands.log auto-play matching tracks, AI replies show toast
- 0 lint errors, 30 warnings (all from spicy-orig library, not our code)
- Build succeeds cleanly
